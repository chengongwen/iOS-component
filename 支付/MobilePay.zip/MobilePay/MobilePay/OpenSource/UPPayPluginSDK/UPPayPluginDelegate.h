//
//  UPPayPluginDelegate.h
//  UPPayPluginDelegate
//
//  Created by wang li on 12-2-7.
//  Copyright (c) 2012年 China UnionPay. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol UPPayPluginDelegate <NSObject>

/**
 *  处理支付结果
 *
 *  @param result 支付状态返回值：success、fail、cancel，分别代表：支付成功、支付失败、用户取消支付
 */
- (void)UPPayPluginResult:(NSString*)result;

@end
