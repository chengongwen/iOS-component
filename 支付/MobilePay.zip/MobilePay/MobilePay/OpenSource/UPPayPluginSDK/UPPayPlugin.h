//
//  UPPayPlugin.h
//  UPPayPlugin
//
//  Created by wxzhao on 12-10-10.
//  Copyright (c) 2012年 China UnionPay. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "UPPayPluginDelegate.h"

@interface UPPayPlugin : NSObject

/**
 *  实现银联支付控件的调用
 *
 *  @param tn             交易流水号信息，银联后台生成，通过商户后台返回到客户端并传入支付控件
 *  @param mode           接入模式设定，两个值：@"00":代表接入生产环境（正式版本需要）；@"01"：代表接入开发测试环境（测试版本需要）；
 *  @param viewController 商户应用程序调用银联手机支付的当前UIViewController
 *  @param delegate       实现UPPayPluginDelegate方法的UIViewController
 *
 *  @return 返回 YES 成功；NO 失败
 */
+ (BOOL)startPay:(NSString*)tn mode:(NSString*)mode viewController:(UIViewController*)viewController delegate:(id<UPPayPluginDelegate>)delegate;


@end
