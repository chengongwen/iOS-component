//
//  UserMacroDefinition.h
//  MobilePay
//
//  Created by yuanshanit on 15/6/18.
//  Copyright (c) 2015年 元善科技. All rights reserved.
//

#ifndef MobilePay_UserMacroDefinition_h
#define MobilePay_UserMacroDefinition_h


/********** 设置支付宝相关信息 **********/

// 账户ID。用签约支付宝账号登录ms.alipay.com后，在账户信息页面获取。
#define AlipayPartnerID   @"2088101568358171"
#define AlipaySellerID    @"2088101568358171"

// 安全校验码（MD5）密钥  用签约支付宝账号登录ms.alipay.com后，在密钥管理页面获取
#define AlipayMD5_KEY     @"uxt01uurwxvstkxpmleeok76ezicp8k4"

// 商户私钥，自助生成
#define AlipayPrivateKey @"MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAMspRqs3boEbxaqz8ZR/VUAm0Aw+5klaQzTtYEMKHBQXZTePOdPhDiaThtQutfVrlDh2k8dukf+yCcVeIcOJRqukDW9D+rg7xVdNlWGHuUNaMaiZbPg3XsVDNG+MP8ZV/vyYeFFi8ypOkCt/8/GDxAaWbOg/oGdfoiAJJbjswZ/vAgMBAAECgYA7AFTGusV7923ToojBYK2IgP0g4U+N9AnaoCm5roDzEMxTc2QO9ahfaa7ZhmtPyBt2vnEylRkPkkwmJq1VlVORVo5NhGHqW0e1YtuCRWZGS6x/6EWdKn2nUgNSiUAiciWstMNfi+MWt2U7m7pkZdTvabucxZixeI7WM5Oxndzc+QJBAPjgV3JdafsSRYJLhwiXU+9oipTGY5oAsVYxwU4wTH9hahFCxLog3Q5xqfmgBPtb6bdzoW19rapc4pxBXCxC4i0CQQDQ+fQ04q+agaThFFU7ZyC2mCnpTJeLpHPUw6wD8i9p9lHQEYns8Fd3WMyy+C13zfSQmS5FbPGCleQtSXBa4ogLAkAYzDGqYYhnzeBDJUdlIb7pQd9dB49xDtScpASAx+s3Xft1kNONQC0GfWjUSI92hCf7cXgKMtWU/gBOVWzbtCZZAkBASKOWoSTjon3Vvyt42oB1qtk5qxXzHuOCz65aiGWNcvg3yS1kdYpybB6L70wNTo2s7XIOaTThtro6NB0b2BOBAkEAmF9/rdipc/7UGpHrbUJPKAZBGwbE1tRoHFbWWXWooBvHqh/z+9ElApUo7ttPUsdCdTGuPHIw8Cy1tFdpfDGiwQ=="

// 支付宝公钥，用签约支付宝账号登录ms.alipay.com后获取。
#define AlipayPublicKey   @"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDLKUarN26BG8Wqs/GUf1VAJtAMPuZJWkM07WBDChwUF2U3jznT4Q4mk4bULrX1a5Q4dpPHbpH/sgnFXiHDiUarpA1vQ/q4O8VXTZVhh7lDWjGomWz4N17FQzRvjD/GVf78mHhRYvMqTpArf/Pxg8QGlmzoP6BnX6IgCSW47MGf7wIDAQAB"
/********** 设置支付宝相关信息 **********/


/********** 设置微信相关信息 **********/
#define WXAppID         @"wxd930ea5d5a258f4f"
#define WXAppSecret     @"db426a9829e4b49a0dcac7b4162da6b6"

#define WXAppKey       @"L8LrMqqeGRxST5reouB0K66CaYAWpqhAVsq7ggKkxHCOastWksvuX1uvmvQclxaHoYd3ElNBrNO2DHnnzgfVG9Qs473M3DTOZug5er46FhuGofumV8H2FVR9qkjSlC5K"

//商户号，填写商户对应参数
#define WXPartnerID      @"1900000109"

//商户API密钥，填写相应参数
#define WXPartnerKey     @"8934e7d15453e97507ef794cf7b0519d"

//支付结果回调页面
#define WXNOTIFY_URL      @"http://wxpay.weixin.qq.com/pub_v2/pay/notify.v2.php"

//获取服务器端支付数据地址（商户自定义）
#define WXSP_URL          @"http://wxpay.weixin.qq.com/pub_v2/app/app_pay.php"
/********** 设置微信相关信息 **********/


/********** 设置银联相关信息 **********/
//测试卡号信息：
//
//卡号：6226440123456785
//密码：111101
//
//借记卡：6226090000000048
//手机号：18100000000
//密码：111101
//短信验证码：123456
//（短信验证码记得点下获取验证码之后再输入）
//
//贷记卡：6226388000000095；
//手机号：18100000000；
//cvn2：248；
//有效期：1219；
//短信验证码：123456
//（短信验证码记得点下获取验证码之后再输入）

//tn（http://202.101.25.178:8080/sim/gettn或http://101.231.204.84:8091/sim/getacptn）

#define kUUPMode_Development             @"01"
#define kUUPURL_TN_Normal                @"http://202.101.25.178:8080/sim/gettn"
#define kUUPURL_TN_Configure             @"http://202.101.25.178:8080/sim/app.jsp?user=123456789"
/********** 设置银联相关信息 **********/

#define kDeveloperAppId   @"912344566" // 用账户登陆itunes connect创建应用时会产生一个app id
#define kDeveloperCompany @"元善科技" // developer的公司名称
#define kDeveloperCompanyServiceHotline @"400-0083-084" // developer公司服务热线
#define kCompanyWebsite @"http://www.yuanshanit.com" //公司官网

#define appDelegate ((AppDelegate *)[[UIApplication sharedApplication] delegate])
#define kSystemVersion [[[UIDevice currentDevice] systemVersion] floatValue]
#define kSystemVersionGetY ((CGFloat)kSystemVersion >= 7.0?20:0)

#define kScreenWidth [[UIScreen mainScreen] bounds].size.width
#define kScreenHeight ((kSystemVersion >= 7.0)?[[UIScreen mainScreen] bounds].size.height:[[UIScreen mainScreen] bounds].size.height-20)

#define kAppDocumentPath [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]    //获取应用Document目录路径
#define RGB(r,g,b) [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:1.0f]

#define RGBA(r,g,b,a) [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:a]

/**系统皮肤定义相关宏 start **/
#define kThemeDidChangeNotification @"kThemeDidChangeNotification"
#define kThemeColor @"color"    //列表颜色
#define kThemeBackgroundColor @"backgroundColor"    //背景颜色
#define kThemeCornerRadius @"cornerRadius"    //控件(UIButton)的圆角半径
#define kThemeFont  @"font"     //列表字体
#define kThemeSize  @"size"     //列表字体大小

#define kThemeListFontStyle         @"kThemeListFontStyle"          //  列表大字体、颜色集合。
#define kThemeListSmallFontStyle    @"kThemeListSmallFontStyle"     //  列表小字体
#define kThemeButtonFontStyle       @"kThemeButtonFontStyle"        //  登录字体、颜色集合。
#define kThemeQQButtonFontStyle     @"kThemeQQButtonFontStyle"      //  QQ 登录样式
#define kThemeRightButtonFontStyle  @"kThemeRightButtonFontStyle"   //  右边按钮样式
#define kThemeSinaButtonFontStyle   @"kThemeSinaButtonFontStyle"    //  Sina 登录样式
#define kThemeBackgroundStyle       @"kThemeBackgroundStyle"        //  背景底图样式
#define kThemeFormPropertyStyle     @"kThemeFormPropertyStyle"      //  表单属性样式
#define kThemeFormValueStyle        @"kThemeFormValueStyle"         //  表单性性值性样式
#define kThemeFormTitleStyle        @"kThemeFormTitleStyle"         //  表单标题样式
#define kThemeTableViewCellStyle    @"kThemeTableViewCellStyle"     //  tableViewCell背景颜色
#define kThemeLeftMenuFontStyle         @"kThemeLeftMenuFontStyle"      
#define kThemeNavigationBarTitleStyle   @"kThemeNavigationBarTitleStyle" //TAB分类按扭字体、颜色集合。
#define kThemeTableViewSeparatorStyle   @"kThemeTableViewSeparatorStyle" //UITableView分隔线样式
#define kThemeMilkInputDayStyle     @"kThemeMilkInputDayStyle"      //选择日期框样式
#define kThemeTableViewHeaderBackgroundStyle  @"kThemeTableViewHeaderBackgroundStyle " //tableView表头背景底图样式
#define kThemeLeaderboardTitleFontStyle  @"kThemeLeaderboardTitleFontStyle"   //排行榜标题样式
/**系统皮肤定义相关宏 end **/

#define kLimitHighTemperature 60.0f
#define kSystemButtonHeight 44.0f

/**设置应用UITableViewCell的高度 start **/
#define kLoginTableViewCellHeight 50.0f
#define kLeftMenuTableViewCellHeight 45.0f
/**设置应用UITableViewCell的高度 end **/

/**系统动画时间定义 start **/
#define kUINavigationPushOrPopAnimationTime .5f
#define kSystemMenuSwitchAnimationTime .5f
#define kFormToggleAnimationTime .5f //表单切换动画时间
#define kHUDFadeAnimationTime 1.0f // HUD动画消失时间
#define kUploadDataTimeInterval  15.0f   // 上传间隔时间
#define kJumpNumberWithDuration  1.5f   // 数字显示时间
#define kHurrayAnimationTime .5f // 排行榜动画时间
#define kHurrayFadeAnimationTime 3.5f // 排行榜消失动画时间
/**系统动画时间定义 end **/

#define kConfigFolderName @"config"     //存放配置文件
#define kLogFolderName @"log"           //存放日志文件
#define kYsErrorMsgKey @"errorMsg"      //错误消息Key
#define kYsErrorCodeKey @"errorCode"    //错误消息编码key

typedef enum {
    LoginTypeWithDefault = 0,       // 系统默认
    LoginTypeWithTencent = 1,       // QQ
    LoginTypeWithSinaWeibo = 2,     // SinaWeibo
    LoginTypeOut                    // 退出
}LoginType; // 登录方式

typedef enum
{
    KysCustomKeyboardTypeAge,     //年龄
    KysCustomKeyboardTypeHeight,  //身高
    KysCustomKeyboardTypeWeight,  //体重
    KysCustomKeyboardTypeToothAmount, //牙齿数量
    KysCustomKeyboardTypeHeadCircum   //头围
}KysCustomKeyboardType; //宝宝成长信息输入键盘类型


typedef NS_ENUM(NSUInteger, kUploadState) {
    kUnUploadState = 0,   // 未上传
    kUploadedState,   // 已经上传
};
/*
 透传数据结构
 {
	unsigned char FF,step,cmd,len,chksum;	//头定义
	unsigned char data[len-5];	//数据
 }
 
 // char/int/long: 1/2/4个字节
 // FF: value = 0xff,
 // step: step inc when commulate ok,
 // len: data lengths,include head(value: [5,60]),
 // cmd: cmdId(value: [0,127]),命令0为透传联机命令，此时的step必须复位到0以同步，因为从可能在待机，故主发联机命令时，从系统的MCU可能接收不完整，主可以做0.5-1S
 //     超时判断后重发，重复如3-5次均不能得到从的透传联机命令则通讯断开，否则，主的step++，step&=0x7f
 // chksum: check sums, include head(=(u8)sum(0,len)).

typedef struct{
    unsigned char FF,step,cmd,len,chksum; //头定义
    unsigned char data[];	//数据
}YSBLECommand;
*/

typedef enum {
    CMD_ERR=0,				//0X00	后面接不能处理的命令及参数（如超长，参数会截尾）
    CMD_RST,                //0X01	无参数，BLE收到后不会应答，系统复位
    CMD_EXIT,     			//0X02	无参数，BLE收到后，允许关机
    CMD_TTM,      			//0X03	APP需要发给BLE的AT命令，BLE的返回信息亦为该命令
    CMD_MSTUP,				//0X04
    CMD_MSTUP_PROG, 		//0X05
    CMD_MSTUP_READ,			//0X06
    CMD_PROGRAME,   		//0X07
    CMD_MCURD,    			//0X08
    CMD_ONLINE,				//0X09
    CMD_ASK,                //0X0A
    CMD_DAT,				//0X0B
    CMD_INFO,				//0X0C
    CMD_GET_RTC,			//0X0D
    CMD_SET_RTC,			//0X0E
    CMD_EWRITE,     		//0X0F
    CMD_EREAD,      		//0X10
    CMD_3DVALUE,    		//0X11
    CMD_WT3D,       		//0X12
    CMD_RD3D,				//0X13
    CMD_SLVUP,				//0X14  BLE复位时，允许APP初始化更新程序
    CMD_SLVUP_PROG,			//0X15  APP更新BLE程序
    CMD_SLVUP_READ,			//0X16  APP读取BLE内容（程序，部分参数）
    CMD_APP_PROGRAME,		//0X17  APP设定BLE部分参数
    CMD_APP_MCURD,			//0X18  APP读取BLE部分参数
    CMD_APP_ERASE_FLASH,	//0X19  APP擦除外置FLASH的SECTOR
    CMD_APP_WT_FLASH,		//0X1a  APP写外置FLASH
    CMD_APP_RD_FLASH,		//0X1b  APP读外置FLASH
    CMD_APP_ADR_UPMASTER,	//0X1c  APP设定BLE更新挂件的数据内容地址
    CMD_APP_RDINFO,			//0X1d  APP读取BLE信息
    CMD_APP_RDDAT,			//0X1e  APP读取BLE的喝奶相关数据
    CMD_APP_ASK,			//0X1f  等同于CMD_APP_RDINFO
    CMD_APP_GET_RTC,		//0X20  APP读取BLE系统时间
    CMD_APP_SET_RTC,		//0X21  APP设定BLE系统时间
    CMD_APP_ONLINE			//0X22  相互告知版本等信息
}BLE_CMD;

typedef struct _PACKAGE_BLE_CMD_STRU {
    unsigned char constHead[4];	//恒等于HEX: 0x48,0x45,0x58,0x3A
    unsigned char lens;
    unsigned char cmd;
    unsigned char args[3]; //数据
    unsigned char chk;
    //unsigned char args[lens-3];	//如果cmd无参数，则无该项
}PKG_CMD_STRU,*PPKG_CMD_STRU;

typedef void(^YSResponseBlock)(id data,id error);

/** 接口URl地址宏 start **/ //
//#define kHostAddress @"http://112.74.81.212" // 外网服务器地址

#define kHostAddress @"http://192.168.1.41" //  内网服务器地址

#define kBaseAddress_URL(_URL_) [NSString stringWithFormat:@"%@%@",kHostAddress,_URL_]//接口的基础地址

#define kUserServiceBaseUrl         kBaseAddress_URL(@"/ws/userservice") //用户服务接口baseUrl
#define kFileServiceBaseUrl         kBaseAddress_URL(@"/ws/fileservice") //上传文件接口baseUrl
#define kFeedBackServiceBaseUrl     kBaseAddress_URL(@"/ws/feedbackservice") //保存反馈意见接口baseUrl
#define kDiaryServiceBaseUrl        kBaseAddress_URL(@"/ws/diaryservice") //添加成长日记接口baseUrl
#define kMonitorServiceBaseUrl      kBaseAddress_URL(@"/ws/monitorservice") // 喝奶、喝水接口baseUrl
#define kRankServiceBaseUrl         kBaseAddress_URL(@"/ws/rankservice") //排行榜接口baseUrl
#define kDeviceServiceBaseUrl       kBaseAddress_URL(@"/ws/deviceservice") //消息推送接受操纵接口baseUrl
#define kGetnotificationsBaseUrl    kBaseAddress_URL(@"/ws/pushservice") //获取消息中心信息接口baseUrl
#define kSaveMobileLoginLogBaseUrl   kBaseAddress_URL(@"/ws/userservice") //发生地理位置接口baseUrl
/** 接口URl地址宏 end **/

#define kGetRankTopCount 10 //获取排行榜前kGetRankTopCount的数据

//  个人信息
#define kFMDBUserMessagesInitSql @"CREATE  TABLE IF NOT EXISTS \"UserMessages\" ( \"resourceid\" INTEGER PRIMARY KEY  NOT NULL, \"account\" TEXT, \"password\" TEXT,\"content\" TEXT, \"updateDate\" DATETIME)"

#define kFMDBMilkDrinkInitSql @"CREATE  TABLE IF NOT EXISTS \"MilkDrink\" (\"resourceid\" INTEGER PRIMARY KEY  NOT NULL, \"account\" TEXT,\"drinkType\" TEXT,\"startTime\" TEXT, \"endTime\" TEXT,\"volume\" INTEGER,\"state\" INTEGER)"

#define kFMDBMessageCenterInitSql @"CREATE  TABLE IF NOT EXISTS \"MessageCenter\" (\"resourceid\" INTEGER PRIMARY KEY  NOT NULL, \"account\" TEXT, \"content\" TEXT, \"noticeId\" TEXT, \"author\" TEXT, \"title\" TEXT, \"pushTime\" TEXT, \"isRead\" INTEGER, \"state\" INTEGER)"

#endif
