//
//  Product.h
//  MobilePay
//
//  Created by yuanshanit on 15/6/19.
//  Copyright (c) 2015年 元善科技. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Product : NSObject
//
//测试商品信息封装在Product中,外部商户可以根据自己商品实际情况定义
//

@property (nonatomic, assign) float price;
@property (nonatomic, copy) NSString *subject;
@property (nonatomic, copy) NSString *body;
@property (nonatomic, copy) NSString *orderId;

@end
