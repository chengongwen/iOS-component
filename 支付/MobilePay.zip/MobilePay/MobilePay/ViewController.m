//
//  ViewController.m
//  MobilePay
//
//  Created by yuanshanit on 15/6/18.
//  Copyright (c) 2015年 元善科技. All rights reserved.
//

#import "ViewController.h"
#import "DetailViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.title = @"测试数据";
    
    [self generateData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -
#pragma mark   ==============产生订单信息==============

- (void)generateData{
    
    NSArray *subjects = @[@"1",@"2",@"3",@"4"];
    
    NSArray *body = @[@"我是测试数据1",
                      @"我是测试数据2",
                      @"我是测试数据3",
                      @"我是测试数据4"];
    
    if (nil == self.productList) {
        self.productList = [[NSMutableArray alloc] init];
    }
    else {
        [self.productList removeAllObjects];
    }
    
    for (int i = 0; i < [subjects count]; ++i) {
        Product *product = [[Product alloc] init];
        product.subject = [subjects objectAtIndex:i];
        product.body = [body objectAtIndex:i];
        product.price = 0.01f+ i*0.01;
        [self.productList addObject:product];
    }
}

#pragma mark -
#pragma mark UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50.0f;
}

#pragma mark UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.productList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"Cell"];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    Product *product = [self.productList objectAtIndex:indexPath.row];
    
    cell.textLabel.text = product.body;
    cell.detailTextLabel.text = [NSString stringWithFormat:@"一口价：%.2f",product.price];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    /*
     *点击获取prodcut实例并初始化订单信息
     */
    Product *product = [self.productList objectAtIndex:indexPath.row];
    
    DetailViewController *detailCtrl  = [[DetailViewController alloc] initWithNibName:@"DetailViewController" bundle:nil];
    detailCtrl.product = product;
    [self.navigationController pushViewController:detailCtrl animated:YES];
}



@end
