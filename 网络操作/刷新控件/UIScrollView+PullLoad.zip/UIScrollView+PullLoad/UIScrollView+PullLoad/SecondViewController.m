//
//  SecondViewController.m
//  UIScrollView+PullLoad
//
//  Created by DevilWaiting on 13-8-23.
//  Copyright (c) 2013年 DevilWaiting. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Second", @"Second");
        self.tabBarItem.image = [UIImage imageNamed:@"second"];
    }
    return self;
}
							
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    heightArray = [[NSMutableArray alloc] init];
    for (int i = 0; i < 35; i++) {
        [heightArray addObject:[NSNumber numberWithInt:[self caculHeight]]];
    }

    CGRect rect = [[UIScreen mainScreen] applicationFrame];
    _waterFlowView = [[WaterFlowView alloc] initWithFrame:CGRectMake(0, 0, 320, rect.size.height - 48)];
    _waterFlowView.viewDataSource = self;
    _waterFlowView.viewDelegate = self;
    _waterFlowView.pullDelegate = self;
    _waterFlowView.canPullDown = YES;
    _waterFlowView.canPullUp = YES;
    [self.view addSubview:_waterFlowView];
    [_waterFlowView release];
    [_waterFlowView loadData];

}

- (NSInteger)caculHeight {
    return arc4random()%100 + 50;
}

#pragma mark-
#pragma mark- WaterflowDataSource
//该视图中的小视图总数
- (NSInteger)numberOfViewsInWaterFlowView:(WaterFlowView *)waterFlowView {
    return [heightArray count];
}
//该视图每页有多少列
- (NSInteger)numberOfColumsInWaterFlowView:(WaterFlowView *)waterFlowView {
    return 4;
}

//每个cell高度
- (CGFloat)waterFlowView:(WaterFlowView *)waterFlowView heightForIndex:(NSInteger)index {
    return [[heightArray objectAtIndex:index] intValue];
}

//获取视图顶部高度
- (CGFloat)heightForHeaderInWaterFlowView:(WaterFlowView *)waterFlowView {
    return 10;
}
//获取页面宽度
- (CGFloat)widthForSiderInWaterFlowView:(WaterFlowView*)waterFlowView {
    return 10;
}

- (UIView*)waterFlowView:(WaterFlowView*)waterFlowView viewAtIndex:(NSInteger)index {
    static NSString *identifier = @"HomeWaterFlowCell";
    UIView *view = [waterFlowView dequeueReusableViewWithIdentifier:identifier];
    if (!view) {
        
        view = [[[UIView alloc] init] autorelease];
        view.identifier = identifier;
    }
    view.backgroundColor = [UIColor redColor];
    CGRect rect = [[UIScreen mainScreen] applicationFrame];
    view.frame = CGRectMake(0, 0, (rect.size.width - 20)/4 - 10, [[heightArray objectAtIndex:index] intValue] - 10);

    return view;
}

#pragma mark -
#pragma mark UIScrollView PullDelegate

- (void)scrollView:(UIScrollView*)scrollView loadWithState:(LoadState)state {
    //模拟加载过程
    if (state == PullDownLoadState) {
        [self performSelector:@selector(PullDownLoadEnd) withObject:nil afterDelay:2];
    }
    else {
        [self performSelector:@selector(PullUpLoadEnd) withObject:nil afterDelay:2];
    }
}

- (void)PullDownLoadEnd {
    [heightArray removeObjectsInRange:NSMakeRange(35, [heightArray count]-35)];
    _waterFlowView.canPullUp = YES;
    [_waterFlowView loadData];
    [_waterFlowView stopLoadWithState:PullDownLoadState];
}

- (void)PullUpLoadEnd {
    for (int i = 0; i< 20; i++) {
        [heightArray addObject:[NSNumber numberWithInt:[self caculHeight]]];
    }
    if ([heightArray count] > 80) {
        _waterFlowView.canPullUp = NO;
    }
    [_waterFlowView loadData];
    [_waterFlowView stopLoadWithState:PullUpLoadState];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [heightArray release];
    [super dealloc];
}

@end
