//
//  SecondViewController.h
//  UIScrollView+PullLoad
//
//  Created by DevilWaiting on 13-8-23.
//  Copyright (c) 2013年 DevilWaiting. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIScrollView+PullLoad.h"
#import "WaterFlowView.h"

@interface SecondViewController : UIViewController <WaterFlowViewDataSource,WaterFlowViewDelegate,PullDelegate>{
    WaterFlowView   *_waterFlowView;
    NSMutableArray *heightArray;
}

@end
