//
//  CustomProgressHUD.m
//  ProgressView
//
//  Created by yuanshanit on 14/12/20.
//  Copyright (c) 2014年 元善科技. All rights reserved.
//

#import "CustomProgressHUD.h"

#define kWidth 120.0f
#define kHeight 120.0f
#define kAnimationDuration 2.0f
#define kFadeOutDuration 2.0f

#define kActivityIndicatorSize 50.0f // ActivityIndicator \logo
#define kOtherIconsSize 35.0f // other

static const NSInteger kInsetValue = 10;
static const NSUInteger kFinalViewTag = 1337;
static const NSUInteger kAlertViewTag = 1338;

@interface CustomProgressHUD ()

+ (NSArray *)setupCustomActivityIndicator;
+ (UIView *)contentViewFromType:(AlertType)type;
+ (void)fadeOutView:(UIView *)view completion:(void (^)(BOOL finished))completion;

@end

static UIView *currentView = nil;

@implementation CustomProgressHUD

+ (UIView *)currentView
{
    return currentView;
}

+ (void)showAlertOnView:(UIView *)view
              withTitle:(NSString *)title
             titleColor:(UIColor *)titleColor
        backgroundImage:(UIImage *)backgroundImage
        backgroundColor:(UIColor *)backgroundColor
           cornerRadius:(CGFloat)cornerRadius
            shadowAlpha:(CGFloat)shadowAlpha
                  alpha:(CGFloat)alpha
                   type:(AlertType)type
{
    if ([view viewWithTag:kFinalViewTag]) {
        //don't allow 2 alerts on the same view
        NSLog(@"Can't add two FVCustomAlertViews on the same view. Hide the current view first.");
        return;
    }
    
    //get window size and position
    CGRect windowRect = [[UIScreen mainScreen] bounds];
    
    //create the final view with a special tag
    UIView *resultView = [[UIView alloc] initWithFrame:windowRect];
    resultView.tag = kFinalViewTag; //set tag to retrieve later
    
    //create shadow view by adding a black background with custom opacity
    UIView *shadowView = [[UIView alloc] initWithFrame:windowRect];
    shadowView.backgroundColor = [UIColor whiteColor];
    shadowView.alpha = shadowAlpha;
    [resultView addSubview:shadowView];
    
    //create the main alert view centered
    //with custom width and height
    //and custom background
    //and custom corner radius
    //and custom opacity
    UIView *alertView = [[UIView alloc] initWithFrame:CGRectMake(windowRect.size.width/2 - kWidth/2,
                                                                 windowRect.size.height/2 - kHeight/2,
                                                                 kWidth, kHeight)];
    alertView.tag = kAlertViewTag; //set tag to retrieve later
    
    //set background color
    //if a background image is used, use the image instead.
    alertView.backgroundColor = backgroundColor;
    if (backgroundImage) {
        alertView.backgroundColor = [[UIColor alloc] initWithPatternImage:backgroundImage];
    }
    alertView.layer.cornerRadius = cornerRadius;
    alertView.alpha = alpha;
    
    //check wether the alert is of custom type or not
    //if it is, set the custom view
    UIView *content = [self contentViewFromType:type];
    
    content.frame = CGRectApplyAffineTransform(content.frame, CGAffineTransformMakeTranslation(kWidth/2 - content.frame.size.width/2, kInsetValue));
    
    [alertView addSubview:content];
    
    //create the title label centered with multiple lines
    //and custom color
    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.text = title;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.textColor = titleColor;
    titleLabel.backgroundColor = [UIColor clearColor];
    
    //set the number of lines to 0 (unlimited)
    //set a maximum size to the label
    //then get the size that fits the maximum size
    titleLabel.numberOfLines = 0;
    CGSize requiredSize = [titleLabel sizeThatFits:CGSizeMake(kWidth - kInsetValue, kHeight - kInsetValue)];
    titleLabel.frame = CGRectMake(kWidth/2 - requiredSize.width / 2, kHeight*3/5+kInsetValue, requiredSize.width, requiredSize.height);
    [alertView addSubview:titleLabel];
    
    [resultView addSubview:alertView];
    [view addSubview:resultView];
    currentView = view;
}

+ (void)hideAlertFromView:(UIView *)view
{
    [self hideAlertFromView:view fading:NO];
}

+ (void)showDefaultLoadingAlertOnView:(UIView *)view withTitle:(NSString *)title {
    [self showAlertOnView:view
                withTitle:title
               titleColor:[UIColor whiteColor]
          backgroundImage:nil
          backgroundColor:[UIColor grayColor]
             cornerRadius:10.0
              shadowAlpha:0.1
                    alpha:0.8
                     type:AlertTypeLoading];
}

+ (void)showDefaultDoneAlertOnView:(UIView *)view withTitle:(NSString *)title {
    [self showAlertOnView:view
                withTitle:title
               titleColor:[UIColor whiteColor]
          backgroundImage:nil
          backgroundColor:[UIColor grayColor]
             cornerRadius:10.0
              shadowAlpha:0.1
                    alpha:0.8
                     type:AlertTypeDone];
    
    [self hideAlertFromView:view fading:YES];
}

+ (void)showDefaultErrorAlertOnView:(UIView *)view withTitle:(NSString *)title {
    [self showAlertOnView:view
                withTitle:title
               titleColor:[UIColor whiteColor]
          backgroundImage:nil
          backgroundColor:[UIColor grayColor]
             cornerRadius:10.0
              shadowAlpha:0.1
                    alpha:0.8
                     type:AlertTypeError];
    
    [self hideAlertFromView:view fading:YES];
}

+ (void)showDefaultWarningAlertOnView:(UIView *)view withTitle:(NSString *)title {
    [self showAlertOnView:view
                withTitle:title
               titleColor:[UIColor whiteColor]
          backgroundImage:nil
          backgroundColor:[UIColor grayColor]
             cornerRadius:10.0
              shadowAlpha:0.1
                    alpha:0.8
                     type:AlertTypeWarning];
    
    [self hideAlertFromView:view fading:YES];
}

+ (UIView *)contentViewFromType:(AlertType)type {
    UIImageView *content = [[UIImageView alloc] init];
    //generate default content views based on the type of the alert
    switch (type) {
        case AlertTypeLoading:
        {
            content.frame = CGRectMake(0, kInsetValue/2, kActivityIndicatorSize, kActivityIndicatorSize);
            content.animationDuration = kAnimationDuration;
            content.animationImages = [self setupCustomActivityIndicator];
            [content startAnimating];
        }
            break;
        case AlertTypeDone:
        {
            content.frame = CGRectMake(0, kInsetValue, kOtherIconsSize, kOtherIconsSize);
            content.image = [UIImage imageNamed:@"success"];
        }
            break;
        case AlertTypeError:
        {
            content.frame = CGRectMake(0, kInsetValue, kOtherIconsSize, kOtherIconsSize);
            content.image = [UIImage imageNamed:@"error"];
        }
            break;
        case AlertTypeWarning:
        {
            content.frame = CGRectMake(0, kInsetValue, kOtherIconsSize, kOtherIconsSize);
            content.image = [UIImage imageNamed:@"warning"];
        }
            break;
        default:
            //AlertTypeCustom never reached
            break;
    }
    
    return content;
}

+ (NSArray *)setupCustomActivityIndicator {
    NSMutableArray *array = [NSMutableArray array];
    //iterate through all the images and add it to the array for the animation
    for (int i = 0; i <= 9; i++) {
        UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"logo%d",i]];
        [array addObject:image];
    }
    return array;
}

+ (void)fadeOutView:(UIView *)view completion:(void (^)(BOOL finished))completion {
    [UIView animateWithDuration:kFadeOutDuration
                          delay:1.0
                        options:UIViewAnimationOptionCurveEaseOut
                     animations:^{
                         [view setAlpha:0.0];
                     }
                     completion:completion];
}

+ (void)hideAlertFromView:(UIView *)view fading:(BOOL)fading {
    if (fading) {
        [self fadeOutView:[view viewWithTag:kFinalViewTag] completion:^(BOOL finished) {
            [[view viewWithTag:kFinalViewTag] removeFromSuperview];
        }];
    } else {
        [[view viewWithTag:kFinalViewTag] removeFromSuperview];
    }
    currentView = nil;
}

@end
