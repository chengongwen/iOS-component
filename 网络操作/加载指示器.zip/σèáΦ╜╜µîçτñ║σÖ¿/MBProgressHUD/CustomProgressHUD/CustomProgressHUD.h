//
//  CustomProgressHUD.h
//  ProgressView
//
//  Created by yuanshanit on 14/12/20.
//  Copyright (c) 2014年 元善科技. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum {
    /** A view with a UIActivityIndicator and "Loading..." title. */
    AlertTypeLoading,
    /** A view with a checkmark and "Done" title. */
    AlertTypeDone,
    /** A view with a cross and "Error" title. */
    AlertTypeError,
    /** A view with an exclamation point and "Warning" title. */
    AlertTypeWarning,
}AlertType;;

@interface CustomProgressHUD : UIView

/**
 * Getter to the current FVCustomAlertView displayed
 * If no alert view is displayed on the screen, the result will be nil.
 * @return the current FVCustomAlertView
 */
+ (UIView *)currentView;

/**
 * Creates a new view and adds it to the view. Use hideAlertFromView to hide it.
 * Adds the view on top of all of the views.
 * Can't create more than one view at a time.
 * @param view The view that the alertView will be added to
 * @param title The title shown on the top of the alert view
 * @param titleColor The title text color
 * @param width The width of the view
 * @param height The height of the view
 * @param backgroundImage If set, will set the background as a tiled image. Background color will be unavalible.
 * @param backgroundColor Color of the background. Used if the image is not set.
 * @param cornerRadius The radius of the rounded corners
 * @param shadowAlpha The background shadow opacity
 * @param alpha The opacity of the alert view
 * @param contentView The content of the view. Can be nil and choose a special type. Can be filled with a UIView or other derived classes.
 * @param type
 */
+ (void)showAlertOnView:(UIView *)view
              withTitle:(NSString *)title
             titleColor:(UIColor *)titleColor
        backgroundImage:(UIImage *)backgroundImage
        backgroundColor:(UIColor *)backgroundColor
           cornerRadius:(CGFloat)cornerRadius
            shadowAlpha:(CGFloat)shadowAlpha
                  alpha:(CGFloat)alpha
                   type:(AlertType)type;

/**
 * Creates a default loading view
 * with the activity indicator from pictures 1.png 2.png...20.png
 * @param view The view that the alertView will be added to
 * @param title The title shown on the top of the alert view
 */
+ (void)showDefaultLoadingAlertOnView:(UIView *)view withTitle:(NSString *)title;

/**
 * Creates a default done view
 * with a checkmark and a title
 * @param view The view that the alertView will be added to
 * @param title The title shown on the top of the alert view
 */
+ (void)showDefaultDoneAlertOnView:(UIView *)view withTitle:(NSString *)title;

/**
 * Creates a default done view
 * with a cross (X) and a title
 * @param view The view that the alertView will be added to
 * @param title The title shown on the top of the alert view
 */
+ (void)showDefaultErrorAlertOnView:(UIView *)view withTitle:(NSString *)title;

/**
 * Creates a default done view
 * with an exclamation point (!) and a title
 * @param view The view that the alertView will be added to
 * @param title The title shown on the top of the alert view
 */
+ (void)showDefaultWarningAlertOnView:(UIView *)view withTitle:(NSString *)title;

/**
 * Hides the active view on the specified view.
 * @param view The view that the alertView is already added to
 * @param fading If set to YES, an animation will perform the hiding of the view as a fading effect.
 */
+ (void)hideAlertFromView:(UIView *)view fading:(BOOL)fading;

@end
