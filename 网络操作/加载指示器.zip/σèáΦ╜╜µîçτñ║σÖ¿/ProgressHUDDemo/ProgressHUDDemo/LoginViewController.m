//
//  ViewController.m
//  ProgressHUDDemo
//
//  Created by yuanshanit on 15/3/10.
//  Copyright (c) 2015年 元善科技. All rights reserved.
//

#import "LoginViewController.h"

#import "MBProgressHUD+MJ.h"
#import "CustomProgressHUD.h"
#import "SVProgressHUD.h"
#import "ProgressHUD.h"

@interface LoginViewController ()

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    UITextField *textfiled = [[UITextField alloc] initWithFrame:CGRectMake(self.view.center.x/2, self.view.center.y/2, self.view.center.x, 30)];
    textfiled.borderStyle = UITextBorderStyleLine;
    textfiled.placeholder = @"test 第一响应者";
    [self.view addSubview:textfiled];
    
    /**
     *  本项目用到4种不同的加载指示器，测试一种指示器时，需要将其他3个方法注释
     *  注：[self loadProgressHUD]的方法为异步线程操作
     */
    
    //  1.，默认系统支持ARC 和非ARC，但是外部需要手动释放内存,此类是一种默认加载指示器
    [self loadMBProgressHUD];
    
    /**
     *  2.支持ARC,此方法为异步线程操作，可以点击textfiled
     */
//    [self loadProgressHUD];

    // 3.支持ARC，这种支持换各种logo图片加载，也只做4种显示方法，，此类是一种默认加载指示器
//    [self loadCustomProgressHUD];
    
    // 4.支持ARC，此指示器也是对第一种方法的集成，可以更换加载背景色，更简单调用，此类是一种圆形加载指示器
//    [self loadSVProgressHUD];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)loadMBProgressHUD
{
    // 字数的长度可变性, dimBackground,代表需要蒙版效果
    [MBProgressHUD showMessage:@"测试加载中..." ];
    
    UIView *backgroundView = [[UIView alloc] initWithFrame:CGRectMake(self.view.center.x/2, self.view.center.y/2 + 50, 200, 200)];
    backgroundView.backgroundColor = [UIColor grayColor];
    
    [self.view addSubview:backgroundView];
    
//    [MBProgressHUD showMessage:@"加载中.." toView:backgroundView];
//    
//    [MBProgressHUD hideHUDForView:backgroundView];
    
//    [MBProgressHUD showSuccess:@"测试成功"];
    
    [MBProgressHUD hideHUD];
}


- (void)loadProgressHUD
{
    // 字数的长度可变性
    [ProgressHUD show:@"测试加载中..."];
    
//    [ProgressHUD showSuccess:@"showSuccess"];
}

- (void)loadCustomProgressHUD
{
    [CustomProgressHUD showDefaultLoadingAlertOnView:self.view withTitle:@"测试加载中..."];
    
//    [CustomProgressHUD hideAlertFromView:self.view fading:YES];
}

- (void)loadSVProgressHUD
{
    [SVProgressHUD showWithStatus:NSLocalizedString(@"测试加载中...", nil)];
    
    [SVProgressHUD setBackgroundColor:[UIColor colorWithWhite:0.637 alpha:1.000]];
//
//    // 字数的长度可变性
//    [SVProgressHUD showWithStatus:NSLocalizedString(@"测试加载中...", nil) maskType:SVProgressHUDMaskTypeClear];
}

@end
