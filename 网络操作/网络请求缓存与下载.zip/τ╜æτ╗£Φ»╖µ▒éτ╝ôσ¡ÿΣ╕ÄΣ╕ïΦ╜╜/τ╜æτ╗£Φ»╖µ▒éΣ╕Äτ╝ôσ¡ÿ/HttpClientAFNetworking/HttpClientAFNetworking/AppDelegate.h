//
//  AppDelegate.h
//  HttpClientAFNetworking
//
//  Created by yuanshanit on 16/1/5.
//  Copyright © 2016年 yuanshanit. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

