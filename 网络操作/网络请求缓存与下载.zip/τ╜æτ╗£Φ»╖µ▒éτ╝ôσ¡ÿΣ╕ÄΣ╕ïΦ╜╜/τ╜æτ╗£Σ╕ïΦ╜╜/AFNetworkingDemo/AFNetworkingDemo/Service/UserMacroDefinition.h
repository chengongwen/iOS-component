//
//  UserMacroDefinition.h
//  宏定义
//
//  Created by Victor on 13-4-26.
//  Copyright (c) 2013年 ysservice.com. All rights reserved.
//

#ifndef companionForiPhone_UserMacroDefinition_h
#define companionForiPhone_UserMacroDefinition_h

typedef void(^YSResponseBlock)(id data,id error);

#define kYsErrorMsgKey @"errorMsg"      //错误消息Key
#define kYsErrorCodeKey @"errorCode"    //错误消息编码key

/** 接口URl地址宏 start **/ //
#define kHostAddress @"https://api.app.net/" //服务器地址

#define kBaseAddress_URL(_URL_) [NSString stringWithFormat:@"%@%@",kHostAddress,_URL_]//接口的基础地址

#define kUserServiceBaseUrl     [NSURL URLWithString:kBaseAddress_URL(@"/stream/0/posts/stream/global")]    //用户服务接口baseUrl

/** 接口URl地址宏 end **/

#define kSystemVersion [[[UIDevice currentDevice] systemVersion] floatValue]
#define kSystemVersionGetY ((CGFloat)kSystemVersion >= 7.0?20:0)

#define kScreenWidth [[UIScreen mainScreen] bounds].size.width
#define kScreenHeight ((kSystemVersion >= 7.0)?[[UIScreen mainScreen] bounds].size.height:[[UIScreen mainScreen] bounds].size.height-20)

#define kAppDocumentPath [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]    //获取应用Document目录路径

#define RGB(r,g,b) [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:1.0f]
#define RGBA(r,g,b,a) [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:a]


#endif
