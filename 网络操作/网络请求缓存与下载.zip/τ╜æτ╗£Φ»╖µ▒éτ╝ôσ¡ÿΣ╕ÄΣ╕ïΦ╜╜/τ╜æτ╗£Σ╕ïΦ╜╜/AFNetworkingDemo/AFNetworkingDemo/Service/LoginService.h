//
//  LoginService.h
//  
//  登录服务接口类
//  Created by yuanshanit on 15/4/27.
//  Copyright (c) 2015年 元善科技. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "UserMacroDefinition.h"

@interface LoginService : NSObject

/**
 *  AFHTTPRequestOperationManager 封装方法GET请求数据
 *
 *  @param responseBlock responseBlock
 */
+ (void)doGlobalTimelinePostsWithBlock:(YSResponseBlock)responseBlock;

/**
 *  AFHTTPRequestOperationManager 封装方法POST请求数据
 *
 *  @param account       account description
 *  @param password      password description
 *  @param deviceType    deviceType description
 *  @param responseBlock responseBlock description
 */
+ (void)doLoginWithAccount:(NSString *)account password:(NSString *)password deviceType:(NSInteger)deviceType responseBlock:(YSResponseBlock)responseBlock;
@end
