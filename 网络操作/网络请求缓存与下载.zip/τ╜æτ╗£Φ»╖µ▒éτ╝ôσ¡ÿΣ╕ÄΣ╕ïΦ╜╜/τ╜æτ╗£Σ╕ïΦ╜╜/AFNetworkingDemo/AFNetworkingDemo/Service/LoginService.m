//
//  LoginService.m
//  LoginService
//
//  Created by yuanshanit on 15/4/27.
//  Copyright (c) 2015年 元善科技. All rights reserved.
//

#import "LoginService.h"

#import "AFAppDotNetAPIClient.h"

#import "AFNetworking.h"
#import "JSONKit.h"

#import "Post.h"

@implementation LoginService

#pragma mark -  https://api.app.net/stream/0/posts/stream/global

/**
 *  AFHTTPRequestOperationManager 封装方法请求数据
 */
+ (void)doGlobalTimelinePostsWithBlock:(YSResponseBlock)responseBlock
{
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:kUserServiceBaseUrl];
    [request setHTTPMethod:@"get"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    AFHTTPRequestOperationManager *operationManager = [AFHTTPRequestOperationManager manager];
    
    // 申明返回的结果是json类型
    operationManager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    // 设置AFSecurityPolicy
    operationManager.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
    
    AFHTTPRequestOperation *operation = [operationManager HTTPRequestOperationWithRequest:request success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        // 将json数据转换为NSString格式
        NSDictionary *JSONInfoDict = [operation.responseString objectFromJSONString];
        
        NSArray *postsFromResponse = [JSONInfoDict valueForKeyPath:@"data"];
        
        NSMutableArray *mutablePosts = [NSMutableArray arrayWithCapacity:[postsFromResponse count]];
        
        for (NSDictionary *attributes in postsFromResponse) {
            
            Post *post = [[Post alloc] initWithAttributes:attributes];
            [mutablePosts addObject:post];
        }
        
        if (JSONInfoDict) {
            
            responseBlock([NSArray arrayWithArray:mutablePosts],nil);
        }
             
        NSLog(@"mutablePosts2 = %@",mutablePosts);
             
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
            NSLog(@"error = %@",error.localizedDescription);
    }];
    
    [operationManager.operationQueue addOperation:operation];
    [request release];
}

/**
 *  AFHTTPRequestOperationManager 封装方法POST请求数据
 */
+ (void)doLoginWithAccount:(NSString *)account password:(NSString *)password deviceType:(NSInteger)deviceType responseBlock:(YSResponseBlock)responseBlock
{
    NSUserDefaults *userDefault=[NSUserDefaults standardUserDefaults];
    NSString *deviceToken =[userDefault objectForKey:@"deviceToken"];
    
    // 获取应用一些信息
    NSDictionary *appInfoDict =[[NSBundle mainBundle] infoDictionary];
    
    // 当前应用软件版本 App版本  比如：1.0.1
    NSString *appVersion = [appInfoDict objectForKey:@"CFBundleShortVersionString"];
    // 设备型号
    NSString *deviceModel = [[UIDevice currentDevice] model];
    // 手机系统版本
    NSString *phoneOSVersion = [[UIDevice currentDevice] systemVersion];
    
    NSDictionary *parameters = [NSDictionary dictionaryWithObjectsAndKeys:
                                account,@"account",
                                password,@"password",
                                [NSNumber numberWithInteger:deviceType],@"deviceType",
                                appVersion,@"appVersion",
                                deviceModel,@"deviceModel",
                                phoneOSVersion,@"OSVersion",
                                deviceToken,@"deviceToken",nil];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:@"http://192.168.1.41/ws/userservice/login"]];
    [request setHTTPMethod:@"POST"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:[parameters JSONData]];
    
    AFHTTPRequestOperationManager *operationManager = [AFHTTPRequestOperationManager manager];
    
    // 申明返回的结果是json类型
    operationManager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    // 设置AFSecurityPolicy
    operationManager.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
    
    AFHTTPRequestOperation *operation = [operationManager HTTPRequestOperationWithRequest:request success:^(AFHTTPRequestOperation *operation, id responseObject)
    {
        // 将json数据转换为NSString格式
        NSDictionary *userInfoDict = [operation.responseString objectFromJSONString];
        if (userInfoDict) {
            responseBlock(userInfoDict,nil);
        }
        else
        {
            //登录失败
            responseBlock(nil,[[userInfoDict objectForKey:@"info"] objectForKey:kYsErrorMsgKey]);
        }
        
        NSLog(@"%@",userInfoDict);
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        
        NSLog(@"%@",error.localizedDescription);
    }];
    
    [operationManager.operationQueue addOperation:operation];
    [request release];
}

@end
