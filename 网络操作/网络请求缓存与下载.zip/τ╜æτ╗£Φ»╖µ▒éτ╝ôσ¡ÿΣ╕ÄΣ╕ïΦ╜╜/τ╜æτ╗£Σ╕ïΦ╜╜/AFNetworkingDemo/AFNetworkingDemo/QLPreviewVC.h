//
//  QLPreviewVC.h
//  IphoneOA
//
//  Created by Victor on 13-7-14.
//  Copyright (c) 2013年 ysservice.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuickLook/QuickLook.h>

@interface QLPreviewVC : QLPreviewController<QLPreviewControllerDataSource,QLPreviewControllerDelegate>

- (id)initWidthPath:(NSString *)path;

@end
