//
//  DownloadViewController.m
//  AFNetworkingDemo
//
//  Created by yuanshanit on 15/12/1.
//  Copyright © 2015年 元善科技. All rights reserved.
//

#import "DownloadViewController.h"
#import "AFHTTPRequestOperation.h"
#import "AFURLSessionManager.h"
#import "QLPreviewVC.h"

#import "SDProgressView.h"

@interface DownloadViewController ()

@property (nonatomic, strong) NSString *savefilePath;
@property (nonatomic, assign) double totalLength;
@property (nonatomic, strong) NSMutableData *receiveData;
@property (nonatomic, strong) SDBaseProgressView *progressView;

@end

@implementation DownloadViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.title = @"根据URL下载文件";
    
    NSString *savedPath = [NSHomeDirectory() stringByAppendingString:@"/Documents/download"];
    
    NSString  *url = @"http://dlsw.baidu.com/sw-search-sp/soft/d1/25665/QQMacMgr_24_0_0.1426491288.dmg";
    
    // 下载方式一，下载前需要预知文件的类型（pdf，docx，doc，txt）
//    [self downloadFileURL:url savePath:savedPath fileName:@"QQMacMgr.dmg"];
    
    // 下载方式二，以第三方库和自己文件名下载网络文件
//    [self downloadFileURL:url savePath:savedPath];
    
    
    // 下载方式三，以系统方式和自己文件名下载网络文件
    [self downloadFileURL:url fileName:@"QQMacMgr.dmg" saveFilePath:savedPath];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/**
 * 下载文件
 */
- (void)downloadFileURL:(NSString *)aUrl savePath:(NSString *)aSavePath fileName:(NSString *)aFileName
{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    //检查本地文件是否已存在
    NSString *fileName = [aSavePath stringByAppendingPathComponent:aFileName];

    //检查附件是否存在
    if (![fileManager fileExistsAtPath:fileName]) {

        //创建附件存储目录
        if (![fileManager fileExistsAtPath:aSavePath]) {
            [fileManager createDirectoryAtPath:aSavePath withIntermediateDirectories:YES attributes:nil error:nil];
        }

        //下载附件
        NSURL *url = [[NSURL alloc] initWithString:aUrl];
        NSURLRequest *request = [NSURLRequest requestWithURL:url];
        
        AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
        
        operation.inputStream   = [NSInputStream inputStreamWithURL:url];
        operation.outputStream  = [NSOutputStream outputStreamToFileAtPath:fileName append:NO];
        
        //下载进度控制
         [operation setDownloadProgressBlock:^(NSUInteger bytesRead, long long totalBytesRead, long long totalBytesExpectedToRead) {
             
             float progress = (float)totalBytesRead / totalBytesExpectedToRead;
        
//              progress(progress);
             NSLog(@"download：%f", progress);
         }];
        
        
        //已完成下载
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
            
             NSLog(@"下载成功");
            
            [self openFileWithPath:fileName];
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            //下载失败
            NSLog(@"下载失败");
        }];
        
        [operation start];
    }
}

- (void)downloadFileURL:(NSString *)aUrl savePath:(NSString *)aSavePath {
    
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
    
    NSURL *URL = [NSURL URLWithString:aUrl];
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];
    
    NSURLSessionDownloadTask *downloadTask = [manager downloadTaskWithRequest:request progress:nil destination:^NSURL *(NSURL *targetPath, NSURLResponse *response) {
        
        NSFileManager *fileManager = [NSFileManager defaultManager];
        
        // 将下载文件保存在缓存路径中
        NSString *filePath = [aSavePath stringByAppendingPathComponent:response.suggestedFilename];
        
        //检查附件是否存在
        if (![fileManager fileExistsAtPath:filePath]) {
            
            //创建附件存储目录
            if (![fileManager fileExistsAtPath:aSavePath]) {
                [fileManager createDirectoryAtPath:aSavePath withIntermediateDirectories:YES attributes:nil error:nil];
            }
        }
        
        // URLWithString返回的是网络的URL,如果使用本地URL,需要注意
        NSURL *fileURL = [NSURL fileURLWithPath:filePath];
        
        return fileURL;
        
    } completionHandler:^(NSURLResponse *response, NSURL *filePath, NSError *error) {
        
        NSLog(@"File downloaded to: %@", filePath);
        
        [self openFileWithPath:filePath.path];
    }];

    [downloadTask resume];
}

#pragma mark - openFileWithPath
- (void)openFileWithPath:(NSString *)filePath {
    
    QLPreviewVC *qlCtrl=[[QLPreviewVC alloc] initWidthPath:filePath];
    
    [self presentViewController:qlCtrl
                       animated:YES
                     completion:^(void){
                         // Code
                         
                     }];
    [qlCtrl release];
}

/**
 *  第三种方式下载
 */
- (void)downloadFileURL:(NSString *)url fileName:(NSString *)afileName saveFilePath:(NSString *)saveFilePath  {
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    //检查本地文件是否已存在
    NSString *fileName = [saveFilePath stringByAppendingPathComponent:afileName];
    
    //检查附件是否存在
    if (![fileManager fileExistsAtPath:fileName]) {
        
        //创建附件存储目录
        if (![fileManager fileExistsAtPath:saveFilePath]) {
            [fileManager createDirectoryAtPath:saveFilePath withIntermediateDirectories:YES attributes:nil error:nil];
        }
    }
    self.savefilePath = fileName;
    
    UIImageView *bgView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"005.jpg"]];
    bgView.frame = self.view.bounds;
    [self.view addSubview:bgView];
    
    self.progressView = [[SDPieLoopProgressView alloc] initWithFrame:CGRectMake(self.view.center.x/2-50 , self.view.center.y - 50, 100, 100)];
    [self.view addSubview:self.progressView];
    
    NSURL *requestURL = [[NSURL alloc] initWithString:url];
    NSURLRequest *request = [NSURLRequest  requestWithURL:requestURL];
    NSURLConnection *connect = [NSURLConnection connectionWithRequest:request delegate:self];
    [connect start];
}

#pragma mark - NSURLConnectionDataDelegate
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    
    NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
    NSDictionary *httpResponseHeaderFields = [httpResponse allHeaderFields];
    long long contentLength = [[httpResponseHeaderFields objectForKey:@"Content-Length"] longLongValue];
    NSString *totalLength = [NSByteCountFormatter stringFromByteCount:contentLength countStyle:NSByteCountFormatterCountStyleFile];
    NSLog(@"接收到服务器的响应,%@,%lu",totalLength,httpResponse.statusCode);
    
    NSString *error = nil;
    if (httpResponse.statusCode == 200) {
        self.receiveData = [NSMutableData data];
    }
    else if (httpResponse.statusCode == 404) {
        error = @"文件找不到";
    }
    else if (httpResponse.statusCode == 500) {
        error = @"系统报错，请联系管理员";
    }
    
    // 拦截文件大小，超过上限提示
    float length = contentLength/(1024.0 *1024);
    self.totalLength = length;
    if (length >= 100) {
        error = @"选择的文件过大，请选择到Web版打开!";
    }
    
    if (error) {
        
        [connection cancel];
    }
    else {
        
    }
}

#pragma mark 接收响应数据（根据响应内容的大小此方法会被重复调用）
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    //    NSString *contentLength = [NSByteCountFormatter stringFromByteCount:data.length countStyle:NSByteCountFormatterCountStyleFile];
    //    NSLog(@"receive data = %@",contentLength);
    
    [self.receiveData appendData:data];
    
    if (self.receiveData) {
        float length = self.receiveData.length/(1024.0 *1024);
        float progress = length/self.totalLength;
        
        self.progressView.progress = progress;
    }
}

#pragma mark 数据接收完成
- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    
    // 接受数据的大小
    NSString *totalLength = [NSByteCountFormatter stringFromByteCount:self.receiveData.length countStyle:NSByteCountFormatterCountStyleFile];
    NSLog(@"loading finish. totalLength = %@",totalLength);
    
    [self.receiveData writeToFile:self.savefilePath atomically:YES];
    
    [connection cancel];
}

#pragma mark 请求失败
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    //如果连接超时或者连接地址错误可能就会报错
    NSLog(@"connection error,error detail is:%@",error);
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
