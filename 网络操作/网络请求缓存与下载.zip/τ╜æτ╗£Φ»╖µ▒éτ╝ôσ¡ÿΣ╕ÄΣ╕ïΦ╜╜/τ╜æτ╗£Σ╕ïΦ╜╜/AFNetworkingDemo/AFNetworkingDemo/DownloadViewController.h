//
//  DownloadViewController.h
//  AFNetworkingDemo
//
//  Created by yuanshanit on 15/12/1.
//  Copyright © 2015年 元善科技. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DownloadViewController : UIViewController

typedef void(^SuccessBlock)(id responseObject,id error);

typedef void(^FailureBlock)(NSError *error);

/**
 * 下载文件
 *
 * @param string aUrl 请求文件地址
 * @param string aSavePath 保存地址
 * @param string aFileName 文件名
 */
- (void)downloadFileURL:(NSString *)aUrl savePath:(NSString *)aSavePath fileName:(NSString *)fileName;

@end
