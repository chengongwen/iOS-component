//
//  QLPreviewVC.m
//  IphoneOA
//
//  Created by Victor on 13-7-14.
//  Copyright (c) 2013年 ysservice.com. All rights reserved.
//

#import "QLPreviewVC.h"

@interface QLPreviewVC()

@property (nonatomic, retain) NSString *path;

@end

@implementation QLPreviewVC
@synthesize path=_path;

-(void)dealloc
{
    [_path release];
    [super dealloc];
}

-(id)initWidthPath:(NSString *)path
{
    if (self=[super init]) {
        self.path=path;
        self.dataSource=self;
        self.delegate=self;
    }
    return self;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    //self.navigationController.navigationBar.barStyle = UIBarStyleBlackOpaque;
    [self.navigationController setNavigationBarHidden:NO];
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self.navigationController setNavigationBarHidden:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self performSelector:@selector(hiddenRightItem) withObject:nil afterDelay:0.1];
    self.delegate = self;
}

-(void)hiddenRightItem
{
    self.navigationItem.rightBarButtonItem = nil;
}


- (void)previewControllerDidDismiss:(QLPreviewController *)controller
{
    //    NSLog(@"previewControllerDidDismiss");
}

-(void)previewControllerWillDismiss:(QLPreviewController *)controller
{
    //    NSLog(@"previewControllerWillDismiss");
}

- (BOOL)previewController:(QLPreviewController *)controller shouldOpenURL:(NSURL *)url forPreviewItem:(id <QLPreviewItem>)item
{
    return YES;
}

- (CGRect)previewController:(QLPreviewController *)controller frameForPreviewItem:(id <QLPreviewItem>)item inSourceView:(UIView **)view
{
    CGPoint cpoint = self.view.center;
    return CGRectMake(cpoint.x-250,cpoint.y-50, 200, 295);
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}


#pragma mark - QLPreviewDataSource actions
- (NSInteger) numberOfPreviewItemsInPreviewController: (QLPreviewController *) controller
{
    return 1;
}

- (id <QLPreviewItem>)previewController: (QLPreviewController *)controller previewItemAtIndex:(NSInteger)index
{
	if (_path.length<=0) {
        return nil;
    }
    
    return [NSURL fileURLWithPath:_path];
}

@end
