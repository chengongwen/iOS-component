//
//  UserDTO.m
//  MobileMicroblogging
//
//  Created by yuanshanit on 14-3-31.
//  Copyright (c) 2014年 元善科技. All rights reserved.
//

#import "UserDTO.h"
#import "DateFormatter.h"
#import "MJExtension.h"

@implementation UserDTO

+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return @{
             @"userID" : @"id",
             @"createdAt" : @"created_at",
             };
}

/**
 *  将字符串时间改为NSDate时间格式
 */
- (id)mj_newValueFromOldValue:(id)oldValue property:(MJProperty *)property {
    if ([property.name isEqualToString:@"createdAt"]) {
        return [[DateFormatter weiboDataFormatter] dateFromString:oldValue];
    }
    
    return oldValue;
}

MJExtensionCodingImplementation

@end
