//
//  StatusService.m
//  MJExtensionDemo
//
//  Created by yuanshanit on 16/1/15.
//  Copyright © 2016年 元善科技. All rights reserved.
//

#import "StatusService.h"
#import "MJWeiboModel.h"
#import "MJExtension.h"

@implementation StatusService

/**
 *  获取最近的微博
 */
+ (void)doGetCurrentStatuses:(NSString *)account responseBlock:(void (^)(id data,id error))responseBlock {

    NSString *path =[[NSBundle mainBundle] pathForResource:@"weibo" ofType:@"json"];
    
    NSData *jsonData = [NSData dataWithContentsOfFile:path options:NSDataReadingMappedIfSafe error:nil];
    
    // 将json数据转换为NSString格式
    NSMutableDictionary *userInfoDict = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:nil];
    
    MJWeiboStatus *statusDTO = [MJWeiboStatus mj_objectWithKeyValues:userInfoDict];
    
    if (statusDTO) {
        responseBlock(statusDTO,nil);
    }
    else
    {
        //登录失败
        responseBlock(nil,@"error");
    }
}

@end
