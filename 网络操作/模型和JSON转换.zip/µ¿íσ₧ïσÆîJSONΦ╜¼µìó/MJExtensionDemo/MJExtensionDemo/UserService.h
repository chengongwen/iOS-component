//
//  UserService.h
//  MJExtensionDemo
//
//  Created by yuanshanit on 15/7/9.
//  Copyright (c) 2015年 元善科技. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserService : NSObject

/**
 *  AFHTTPRequestOperationManager 封装方法POST请求数据
 *
 *  @param account       account description
 *  @param password      password description
 *  @param deviceType    deviceType description
 *  @param responseBlock responseBlock description
 */
+ (void)doLoginWithAccount:(NSString *)account password:(NSString *)password deviceType:(NSInteger)deviceType responseBlock:(void (^)(id data,id error))responseBlock;



@end
