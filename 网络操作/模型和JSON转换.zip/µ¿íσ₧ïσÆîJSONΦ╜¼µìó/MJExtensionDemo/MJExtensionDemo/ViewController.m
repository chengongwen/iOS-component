//
//  ViewController.m
//  MJExtensionDemo
//
//  Created by yuanshanit on 15/7/9.
//  Copyright (c) 2015年 元善科技. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"
#import "AFNetworking.h"

#import "UserService.h"
#import "StatusService.h"

#import "UserDTO.h"
#import "MJWeiboModel.h"

@interface ViewController ()<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) UserDTO *userDTO;
@property (nonatomic, strong) MJWeiboStatus *weiboStatus;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.title  = @"MJExtensionDemo";
    
    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview:self.tableView];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
}

- (void)viewDidAppear:(BOOL)animated {
    
    [UserService doLoginWithAccount:@"18520266187" password:@"1" deviceType:1 responseBlock:^(id data, id error) {
        
        if (data) {
            
            self.userDTO = data;
            [self.tableView reloadData];
        }
        else {
            
            NSLog(@"error = %@",error);
        }
    }];
    
    [StatusService doGetCurrentStatuses:@"18520266187" responseBlock:^(id data, id error) {
        
        if (data) {
            
            self.weiboStatus = data;
            [self.tableView reloadData];
        }
        else {
            
            NSLog(@"error = %@",error);
        }
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark -
#pragma mark - UITableView DataSource and Delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return 4;
    }
    return 10;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        return @"user.json数据解析";
    }
    return @"statuses.json数据解析";
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *indentifier = @"dataSource";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:indentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                   reuseIdentifier:indentifier];
    }
    
    if (indexPath.section == 0) {
        
        switch (indexPath.row) {
            case 0:
                cell.textLabel.text = [NSString stringWithFormat:@"%lli",self.userDTO.userID];
                break;
            case 1:
                cell.textLabel.text = self.userDTO.screen_name;
                break;
            case 2:
                cell.textLabel.text = self.userDTO.url;
                break;
            case 3: {
                NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
                cell.textLabel.text =  [dateFormatter stringFromDate:self.userDTO.createdAt];
                break;
            }
            default:
                break;
        }
    }
    else {
        
        switch (indexPath.row) {
            case 0:
                cell.textLabel.text = [NSString stringWithFormat:@"%lli",self.weiboStatus.statusID];
                break;
            case 1:
                cell.textLabel.text = self.weiboStatus.user.screenName;
                break;
            case 2:
                cell.textLabel.text = self.weiboStatus.user.location;
                break;
            case 3:
                cell.textLabel.text = self.weiboStatus.mblogid;
                break;
            case 4:
                cell.textLabel.text = self.weiboStatus.text;
                break;
            case 5: {
                NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
                cell.textLabel.text =  [dateFormatter stringFromDate:self.weiboStatus.createdAt];
                break;
            }
            case 6:
                cell.textLabel.text = self.weiboStatus.mid;
                break;
            case 7:
                cell.textLabel.text = [NSString stringWithFormat:@"%lli",self.weiboStatus.user.userID];
                break;
            
                break;
            case 8:
                cell.textLabel.text = self.weiboStatus.user.verifiedReason;
                break;
            case 9:
                cell.textLabel.text = self.weiboStatus.user.profileImageURL;
                break;
            default:
                break;
        }
    }
    
    return cell;
}

@end
