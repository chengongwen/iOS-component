//
//  UserService.m
//  MJExtensionDemo
//
//  Created by yuanshanit on 15/7/9.
//  Copyright (c) 2015年 元善科技. All rights reserved.
//

#import "UserService.h"

#import "AppDelegate.h"

#import "AFNetworking.h"
#import "JSONKit.h"
#import "MJExtension.h"

#import "UserDTO.h"

#define kBaseAddress @"http://192.168.1.41" //  内网服务器地址

#define kUserServiceUrl    [NSString stringWithFormat:@"%@%@",kBaseAddress,@"/ws/userservice/login"] //用户服务接口baseUrl

@implementation UserService

/**
 *  使用账号以及密码登录
 */
+ (void)doLoginWithAccount:(NSString *)account password:(NSString *)password deviceType:(NSInteger)deviceType responseBlock:(void (^)(id data,id error))responseBlock
{
    /*
    NSUserDefaults *userDefault=[NSUserDefaults standardUserDefaults];
    NSString *deviceToken =[userDefault objectForKey:@"deviceToken"];
    
    // 获取应用一些信息
    NSDictionary *appInfoDict =[[NSBundle mainBundle] infoDictionary];
    
    // 当前应用软件版本 App版本  比如：1.0.1
    NSString *appVersion = [appInfoDict objectForKey:@"CFBundleShortVersionString"];
    // 设备型号
    NSString *deviceModel = [[UIDevice currentDevice] model];
    // 手机系统版本
    NSString *phoneOSVersion = [[UIDevice currentDevice] systemVersion];
    
    NSDictionary *parameters = [NSDictionary dictionaryWithObjectsAndKeys:
                                account,@"account",
                                password,@"password",
                                [NSNumber numberWithInteger:deviceType],@"deviceType",
                                appVersion,@"appVersion",
                                deviceModel,@"deviceModel",
                                phoneOSVersion,@"OSVersion",
                                deviceToken,@"deviceToken",nil];
    
    NSURL *url = [NSURL URLWithString:kUserServiceUrl];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
    [request setHTTPMethod:@"POST"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:[parameters JSONData]];
    
    AFHTTPRequestOperationManager *operationManager = [AFHTTPRequestOperationManager manager];
    
    // 申明返回的结果是json类型
    operationManager.responseSerializer = [AFJSONResponseSerializer serializer];
    
    // 设置AFSecurityPolicy
    operationManager.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
    
    AFHTTPRequestOperation *operation = [operationManager HTTPRequestOperationWithRequest:request success:^(AFHTTPRequestOperation *operation, id responseObject)
     {
         // 将json数据转换为NSString格式
         NSDictionary *userInfoDict = [operation.responseString objectFromJSONString];
         
         if ([[userInfoDict objectForKey:@"state"] integerValue]) {
             
             NSDictionary *userDict = [userInfoDict objectForKey:@"data"];
             
             UserDTO *userDTO = [UserDTO objectWithKeyValues:userDict];
             
             AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
             
             appDelegate.currentUserDTO = userDTO;
             
             responseBlock(userDTO,nil);
             //   [userDTO release];
         }
         else
         {
             //登录失败
             responseBlock(nil,[userInfoDict objectForKey:@"info"] );
         }
         
     } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
         
         
         //登录失败
         responseBlock(nil,error.localizedDescription);
     }];
    
    [operationManager.operationQueue addOperation:operation];
     */
    
    NSString *path =[[NSBundle mainBundle] pathForResource:@"user" ofType:@"json"];
    
    NSData *jsonData = [NSData dataWithContentsOfFile:path options:NSDataReadingMappedIfSafe error:nil];
    
    // 将json数据转换为NSString格式
    NSMutableDictionary *userInfoDict = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:nil];
    
    if (userInfoDict) {
        UserDTO *userDTO = [UserDTO mj_objectWithKeyValues:userInfoDict];
        responseBlock(userDTO,nil);
    }
    else
    {
        //登录失败
        responseBlock(nil,[userInfoDict objectForKey:@"info"] );
    }
    
}


@end
