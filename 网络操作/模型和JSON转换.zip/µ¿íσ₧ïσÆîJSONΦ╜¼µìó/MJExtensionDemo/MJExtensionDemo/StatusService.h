//
//  StatusService.h
//  MJExtensionDemo
//
//  Created by yuanshanit on 16/1/15.
//  Copyright © 2016年 元善科技. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StatusService : NSObject

/**
 *  获取最近的微博
 *
 *  @param account       account description
 *  @param responseBlock responseBlock description
 */
+ (void)doGetCurrentStatuses:(NSString *)account responseBlock:(void (^)(id data,id error))responseBlock;

@end
