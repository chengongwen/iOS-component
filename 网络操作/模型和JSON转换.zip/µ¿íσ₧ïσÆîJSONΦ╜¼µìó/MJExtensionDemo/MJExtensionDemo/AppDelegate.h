//
//  AppDelegate.h
//  MJExtensionDemo
//
//  Created by yuanshanit on 15/7/9.
//  Copyright (c) 2015年 元善科技. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UserDTO.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (nonatomic, strong) UserDTO *currentUserDTO;

@end

