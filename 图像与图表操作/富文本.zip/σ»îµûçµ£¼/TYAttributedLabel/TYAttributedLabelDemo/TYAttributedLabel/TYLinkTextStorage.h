//
//  TYLinkTextStorage.h
//  TYAttributedLabelDemo
//
//  Created by tanyang on 15/4/8.
//  Copyright (c) 2015年 tanyang. All rights reserved.
//

#import "TYTextStorage.h"

@interface TYLinkTextStorage : TYTextStorage

@property (nonatomic, strong) NSString *linkStr;

@end
