//
//  SHCustomNumLabel.h
//  SHLineGraphView
//
//  Created by yuanshanit on 14/12/9.
//  Copyright (c) 2014年 grevolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHCustomNumLabel : UILabel

@end
