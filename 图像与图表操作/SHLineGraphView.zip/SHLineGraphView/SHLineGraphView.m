// SHLineGraphView.m
//
// Copyright (c) 2014 Shan Ul Haq (http://grevolution.me)
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#import "SHLineGraphView.h"
#import "PopoverView.h"
#import "SHPlot.h"
#import <math.h>
#import <objc/runtime.h>
#import "SHCustomNumLabel.h"
#import "SHBar.h"

#define BOTTOM_MARGIN_TO_LEAVE 30.0
#define TOP_MARGIN_TO_LEAVE 30.0
#define INTERVAL_COUNT (10+1)
#define PLOT_WIDTH (self.bounds.size.width - _leftMarginToLeave)

#define kAssociatedPlotObject @"kAssociatedPlotObject"


@implementation SHLineGraphView
{
    float _leftMarginToLeave;
    BOOL flag; // 标志是否超出最大值
}

- (instancetype)init {
    if((self = [super init])) {
        [self loadDefaultTheme];
    }
    return self;
}

- (void)awakeFromNib
{
    [self loadDefaultTheme];
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self loadDefaultTheme];
    }
    return self;
}

- (void)loadDefaultTheme {
    
    _themeAttributes = @{
                         kXAxisLabelColorKey : RGBA(72, 170, 99,0.6),
                         kXAxisLabelFontKey : [UIFont fontWithName:@"TrebuchetMS" size:10],
                         kYAxisLabelColorKey : RGBA(72, 170, 99,0.6),
                         kYAxisLabelFontKey : [UIFont fontWithName:@"TrebuchetMS" size:12],
                         kYAxisLabelSideMarginsKey : @20,
                         kPlotBackgroundLineColorKye : [UIColor colorWithRed:0.48 green:0.48 blue:0.49 alpha:0.4]
                         };
}

- (void)addPlot:(SHPlot *)newPlot;
{
    if(nil == newPlot) {
        return;
    }

    if(_plots == nil){
        _plots = [NSMutableArray array];
    }
    [_plots addObject:newPlot];
}

- (void)setupTheView
{
    for(SHPlot *plot in _plots) {
      
        [self drawPlotWithPlot:plot];
    }
}

#pragma mark - Actual Plot Drawing Methods

- (void)drawPlotWithPlot:(SHPlot *)plot {
    
    //  判断是否存在超出最大值的点
    flag = NO;
    for (NSDictionary *dic in plot.plottingValues) {
        
        NSArray *arr = [dic allKeys];
        id key = arr[0];
        
        id value = [dic objectForKey:key];
        
        // 当前y坐标大于最大值 20150209 ****************
        if ([value doubleValue] > [self.yAxisRange doubleValue])
        {
            flag = YES;
            break;
        }
    }
    
    //draw y-axis labels. this has to be done first, so that we can determine the left margin to leave according to the
    //y-axis lables.
    [self drawYLabels:plot];

    //draw x-labels
    [self drawXLabels:plot];

    //draw the grey lines
    [self drawLines:plot];

    /*
    actual plot drawing
    */
    switch (self.currentType) {
        case SHLineGraphTypeChart:
            [self drawChartGraphPlot:plot]; // 重画图表
            break;
        case SHLineGraphTypeBar:
            [self drawBarGraphPlot:plot]; // 重画图表
            break;
        default:
            break;
    }
}

/**
 *   重画x轴坐标
 */
- (void)drawXLabels:(SHPlot *)plot {
  NSUInteger xIntervalCount = _xAxisValues.count;
  double xIntervalInPx = PLOT_WIDTH / _xAxisValues.count;
  
  //initialize actual x points values where the circle will be
  plot.xPoints = calloc(sizeof(CGPoint), xIntervalCount);
  
  for(int i=0; i < xIntervalCount; i++){
    CGPoint currentLabelPoint = CGPointMake((xIntervalInPx * i) + _leftMarginToLeave, self.bounds.size.height - BOTTOM_MARGIN_TO_LEAVE);
    CGRect xLabelFrame = CGRectMake(currentLabelPoint.x, currentLabelPoint.y, xIntervalInPx, BOTTOM_MARGIN_TO_LEAVE);
    
    plot.xPoints[i] = CGPointMake((int) xLabelFrame.origin.x + (xLabelFrame.size.width /2) , (int) 0);
    
    UILabel *xAxisLabel = [[UILabel alloc] initWithFrame:xLabelFrame];
    xAxisLabel.backgroundColor = [UIColor clearColor];
    xAxisLabel.font = (UIFont *)_themeAttributes[kXAxisLabelFontKey];
    
    xAxisLabel.textColor = (UIColor *)_themeAttributes[kXAxisLabelColorKey];
    xAxisLabel.textAlignment = NSTextAlignmentCenter;
    
    NSDictionary *dic = [_xAxisValues objectAtIndex:i];
    __block NSString *xLabel = nil;
    [dic enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
      xLabel = (NSString *)obj;
    }];
    
    xAxisLabel.text = [NSString stringWithFormat:@"%@", xLabel];
    [self addSubview:xAxisLabel];
  }
}

/**
 *   重画Y轴坐标
 */
- (void)drawYLabels:(SHPlot *)plot {
    double yRange = [_yAxisRange doubleValue]; // this value will be in dollars
    double yIntervalValue = yRange / (INTERVAL_COUNT-1);
    double intervalInPx = (self.bounds.size.height - BOTTOM_MARGIN_TO_LEAVE ) / (INTERVAL_COUNT + 1);

    NSMutableArray *labelArray = [NSMutableArray array];
    float maxWidth = 0;
  
    for(int i=INTERVAL_COUNT+ 1 ; i >= 1 ; i--){
        
        CGPoint currentLinePoint = CGPointMake(_leftMarginToLeave, i * intervalInPx);
        CGRect lableFrame = CGRectMake(0, currentLinePoint.y - (intervalInPx / 2), 100, intervalInPx);

        UILabel *yAxisLabel = [[UILabel alloc] initWithFrame:lableFrame];
        yAxisLabel.backgroundColor = [UIColor clearColor];
        yAxisLabel.font = (UIFont *)_themeAttributes[kYAxisLabelFontKey];
        yAxisLabel.textColor = (UIColor *)_themeAttributes[kYAxisLabelColorKey];
        yAxisLabel.textAlignment = NSTextAlignmentCenter;
        float val = (yIntervalValue * (INTERVAL_COUNT + 1- i));
        
        // 当前y坐标大于最大值 20150209 ****************
        if (i == 1) {
            if (flag) {
                // 标记Y轴刻度
                yAxisLabel.text = [NSString stringWithFormat:@"......"];
            }
        }
        else
        {
            if(val > 0){
                yAxisLabel.text = [NSString stringWithFormat:@"%.1f", val];
            } else {
                yAxisLabel.text = [NSString stringWithFormat:@"%.0f", val];
            }
        }
        
        [yAxisLabel sizeToFit];
        CGRect newLabelFrame = CGRectMake(0, currentLinePoint.y - (yAxisLabel.layer.frame.size.height / 2), yAxisLabel.frame.size.width, yAxisLabel.layer.frame.size.height);
        yAxisLabel.frame = newLabelFrame;
        
        if(newLabelFrame.size.width > maxWidth) {
            maxWidth = newLabelFrame.size.width;
        }
        
        [labelArray addObject:yAxisLabel];
        [self addSubview:yAxisLabel];
    }
  
    _leftMarginToLeave = maxWidth + [_themeAttributes[kYAxisLabelSideMarginsKey] doubleValue];

    for( UILabel *l in labelArray) {
        CGSize newSize = CGSizeMake(_leftMarginToLeave, l.frame.size.height);
        CGRect newFrame = l.frame;
        newFrame.size = newSize;
        l.frame = newFrame;
    }
}

/**
 *   画线,并在线上画刻度
 */
- (void)drawLines:(SHPlot *)plot {
    
    NSDictionary *theme = plot.plotThemeAttributes;
    
    CAShapeLayer *linesLayer = [CAShapeLayer layer];
    linesLayer.frame = self.bounds;
    linesLayer.lineWidth = 1;
    linesLayer.fillColor = ((UIColor *)theme[kPlotPointFillColorKey]).CGColor;
    linesLayer.backgroundColor = [UIColor clearColor].CGColor;
    [linesLayer setStrokeColor:((UIColor *)theme[kPlotPointFillColorKey]).CGColor];

    CGMutablePathRef linesPath = CGPathCreateMutable();
    
    double intervalInPx = (self.bounds.size.height- BOTTOM_MARGIN_TO_LEAVE) / (INTERVAL_COUNT + 1);
    
    for(int i= INTERVAL_COUNT + 1 ; i > 0; i--){
        
        CGPoint currentLinePoint = CGPointMake(_leftMarginToLeave, (i * intervalInPx));

        if (!flag && i== 1) {
            
            /* 画虚线
            UIImageView *imgvLine = [[UIImageView alloc]initWithFrame:CGRectMake(currentLinePoint.x, currentLinePoint.y, currentLinePoint.x + PLOT_WIDTH, 1)];
            [self addSubview:imgvLine];
            
            
            UIGraphicsBeginImageContext(imgvLine.frame.size);   //开始画线
            [imgvLine.image drawInRect:CGRectMake(0, 0, imgvLine.frame.size.width, imgvLine.frame.size.height)];
            CGContextSetLineCap(UIGraphicsGetCurrentContext(), kCGLineCapRound);  //设置线条终点形状
            
            const CGFloat lengths[] = {10,5};
            CGContextRef line = UIGraphicsGetCurrentContext();
            CGContextSetStrokeColorWithColor(line, ((UIColor *)theme[kPlotStrokeColorKey]).CGColor);
            
            CGContextSetLineDash(line, 0, lengths, linesLayer.lineWidth);  //画虚线
            CGContextMoveToPoint(line, 0.0, imgvLine.frame.size.height);    //开始画线
            CGContextAddLineToPoint(line, PLOT_WIDTH, imgvLine.frame.size.height);
            CGContextStrokePath(line);
            
            imgvLine.image = UIGraphicsGetImageFromCurrentImageContext();
            */
            continue;
        }
        
        CGPathMoveToPoint(linesPath, NULL, currentLinePoint.x, currentLinePoint.y);
        CGPathAddLineToPoint(linesPath, NULL, currentLinePoint.x + PLOT_WIDTH, currentLinePoint.y);
    }
    
    linesLayer.path = linesPath;
    [self.layer addSublayer:linesLayer];
    
    // 画刻度
    CAShapeLayer *circleLayer = [CAShapeLayer layer];
    circleLayer.frame = self.bounds;
    circleLayer.fillColor = ((UIColor *)theme[kPlotPointFillColorKey]).CGColor;
    circleLayer.backgroundColor = [UIColor clearColor].CGColor;
    [circleLayer setStrokeColor:((UIColor *)theme[kPlotPointFillColorKey]).CGColor];
    circleLayer.lineWidth = 3;
   
    CGMutablePathRef circlePath = CGPathCreateMutable();
    
    for (int i = 0; i< _xAxisValues.count; i++) {
        
        // Y轴点坐标
        CGPoint currentLinePoint = CGPointMake(_leftMarginToLeave, ((INTERVAL_COUNT + 1) * intervalInPx));
        
        // Y轴点坐标
        CGPoint point = plot.xPoints[i];
        
        CGPathMoveToPoint(circlePath, NULL, point.x,currentLinePoint.y-3);
        CGPathAddLineToPoint(circlePath, NULL, point.x,currentLinePoint.y+1);
        
        //  画圈
//        CGPathAddEllipseInRect(circlePath, NULL, CGRectMake(point.x,currentLinePoint.y-1.5, 3, 3));
    }
    
    circleLayer.path = circlePath;
    [self.layer addSublayer:circleLayer];
}


/**
 *  重画图表
 *
 *  @param plot 当前标记点
 */
- (void)drawChartGraphPlot:(SHPlot *)plot {
    
    NSDictionary *theme = plot.plotThemeAttributes;
    
    // 添加背景色图层
    CAShapeLayer *backgroundLayer = [CAShapeLayer layer];
    backgroundLayer.frame = self.bounds;
    backgroundLayer.fillColor = ((UIColor *)theme[kPlotFillColorKey]).CGColor;
    backgroundLayer.backgroundColor = [UIColor clearColor].CGColor;
    [backgroundLayer setStrokeColor:[UIColor clearColor].CGColor];
    [backgroundLayer setLineWidth:((NSNumber *)theme[kPlotStrokeWidthKey]).intValue];
    
    // 添加画线图层
    CAShapeLayer *graphLayer = [CAShapeLayer layer];
    graphLayer.frame = self.bounds;
    graphLayer.fillColor = [UIColor clearColor].CGColor;
    graphLayer.backgroundColor = [UIColor clearColor].CGColor;
    [graphLayer setStrokeColor:((UIColor *)theme[kPlotStrokeColorKey]).CGColor];
    [graphLayer setLineWidth:((NSNumber *)theme[kPlotStrokeWidthKey]).intValue];
    
    CGMutablePathRef backgroundPath = CGPathCreateMutable();
    CGMutablePathRef graphPath = CGPathCreateMutable();
    
    double yRange = [_yAxisRange doubleValue]; // this value will be in dollars
    double yIntervalValue = yRange / (INTERVAL_COUNT-1);
    
    // logic to fill the graph path, ciricle path, background path.
    [plot.plottingValues enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        NSDictionary *dic = (NSDictionary *)obj;
        
        __block NSNumber *_key = nil;
        __block NSNumber *_value = nil;
        
        [dic enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
            _key = (NSNumber *)key;
            _value = (NSNumber *)obj;
        }];
        
        int xIndex = [self getIndexForValue:_key forPlot:plot];
        
        // x value
        double height = self.bounds.size.height - BOTTOM_MARGIN_TO_LEAVE;
        double y = height - ((height / ([_yAxisRange doubleValue] + yIntervalValue+ yIntervalValue)) * [_value doubleValue]);
        (plot.xPoints[xIndex]).x = ceil((plot.xPoints[xIndex]).x);
        (plot.xPoints[xIndex]).y = ceil(y);
    }];
    
    //move to initial point for path and background.
    double yintervalInPx = (self.bounds.size.height - BOTTOM_MARGIN_TO_LEAVE) / (INTERVAL_COUNT + 1);
    CGPoint currentLinePoint = CGPointMake(_leftMarginToLeave, ((INTERVAL_COUNT + 1) * yintervalInPx));
    
    // x轴点坐标
    CGPoint pointX = plot.xPoints[0];
    
    CGPathMoveToPoint(graphPath, NULL, pointX.x, currentLinePoint.y);
    CGPathMoveToPoint(backgroundPath, NULL, pointX.x, currentLinePoint.y);
    
    /********* 所有点都连起来画线
     NSUInteger count = _xAxisValues.count;
     for(int i=0; i< count; i++){
     CGPoint point = plot.xPoints[i];
     CGPathAddLineToPoint(graphPath, NULL, point.x, point.y);
     CGPathAddLineToPoint(backgroundPath, NULL, point.x, point.y);
     CGPathAddEllipseInRect(circlePath, NULL, CGRectMake(point.x - 5, point.y - 5, 10, 10));
     }
     // move to initial point for path and background.
     NSUInteger count = plot.plottingValues.count;
     CGPathAddLineToPoint(graphPath, NULL, _leftMarginToLeave + PLOT_WIDTH, plot.xPoints[count -1].y);
     CGPathAddLineToPoint(backgroundPath, NULL, _leftMarginToLeave + PLOT_WIDTH, plot.xPoints[count - 1].y);
     */
    
    /********* 只选择有数据的连起来画线 ********/
    for (NSDictionary *dic in plot.plottingValues) {
        
        NSArray *arr = [dic allKeys];
        
        id key = arr[0];
        id value = [dic objectForKey:key];
        
        NSUInteger interger = [key integerValue];
        
        if (key) {
            
            CGPoint point = plot.xPoints[interger];
            
            // 当前y坐标大于最大值
            if ([value doubleValue] > [self.yAxisRange doubleValue]) {
                
                double intervalInPx = (self.bounds.size.height - BOTTOM_MARGIN_TO_LEAVE ) / (INTERVAL_COUNT + 1);
                
                point.y = intervalInPx;
            }
            
            CGPathAddLineToPoint(graphPath, NULL, point.x, point.y);
            CGPathAddLineToPoint(backgroundPath, NULL, point.x, point.y);
        }
    }
    /********* 只选择有数据的连起来画线 ********/
    
    
    // move to last point for path and background.
    CGPoint point = plot.xPoints[_xAxisValues.count -1];
    CGPathAddLineToPoint(graphPath, NULL, point.x, currentLinePoint.y);
    CGPathAddLineToPoint(backgroundPath, NULL, point.x, currentLinePoint.y);
    
    
    //additional points for background.
    CGPathAddLineToPoint(backgroundPath, NULL, _leftMarginToLeave + PLOT_WIDTH, self.bounds.size.height - BOTTOM_MARGIN_TO_LEAVE);
    CGPathAddLineToPoint(backgroundPath, NULL, _leftMarginToLeave, self.bounds.size.height - BOTTOM_MARGIN_TO_LEAVE);
    CGPathCloseSubpath(backgroundPath);
    
    backgroundLayer.path = backgroundPath;
    graphLayer.path = graphPath;
    
    
    //animation
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
    animation.duration = 1;
    animation.fromValue = @(0.0);
    animation.toValue = @(1.0);
    [graphLayer addAnimation:animation forKey:@"strokeEnd"];
    
    backgroundLayer.zPosition = 0;
    graphLayer.zPosition = 1;
    
    [self.layer addSublayer:graphLayer];
    
    // 添加背景色
//    [self.layer addSublayer:backgroundLayer];
    
    //  添加渐变背景
    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.frame = CGRectMake(0, 0, self.frame.size.width, self.frame.size.height);;
    gradient.colors = [NSArray arrayWithObjects:
                       (id)((UIColor *)theme[kPlotStrokeColorKey]).CGColor,
                       (id)([(UIColor *)theme[kPlotFillColorKey] colorWithAlphaComponent:.1]).CGColor,
                       nil];
    
    // 用targetLayer来截取渐变层gradient
    [gradient setMask:backgroundLayer];
    [self.layer addSublayer:gradient];
    
    
    /**
     *  添加数字圆圈 SHCustomNumLabel
     */
    for (NSDictionary *dic in plot.plottingValues) {
        
        NSArray *arr = [dic allKeys];
        
        id key = arr[0];
        id value = [dic objectForKey:key];
        
        NSUInteger interger = [key integerValue];
        
        if (key) {
            
            CGPoint point = plot.xPoints[interger];
            CGRect frame ;
            
            // 当前y坐标大于最大值
            if ([value doubleValue] > [self.yAxisRange doubleValue])
            {
                double intervalInPx = (self.bounds.size.height - BOTTOM_MARGIN_TO_LEAVE ) / (INTERVAL_COUNT + 1);
                
                frame = CGRectMake(point.x - 15, intervalInPx-15, 40, 40);
            }
            else
            {
                frame = CGRectMake(point.x - 15, point.y - 20, 40, 40);
            }
            
            SHCustomNumLabel *numLabel = [[SHCustomNumLabel alloc] initWithFrame:frame];
            numLabel.text = [NSString stringWithFormat:@"%@",value];
            [self addSubview:numLabel];
        }
    }
}

/**
 *  重画柱状图
 *
 *  @param plot 当前标记点
 */
- (void)drawBarGraphPlot:(SHPlot *)plot
{
    NSDictionary *theme = plot.plotThemeAttributes;
    
    double yRange = [_yAxisRange doubleValue]; // this value will be in dollars
    double yIntervalValue = yRange / (INTERVAL_COUNT-1);
    
    [plot.plottingValues enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        NSDictionary *dic = (NSDictionary *)obj;
        
        __block NSNumber *_key = nil;
        __block NSNumber *_value = nil;
        
        [dic enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
            _key = (NSNumber *)key;
            _value = (NSNumber *)obj;
        }];
        
        int xIndex = [self getIndexForValue:_key forPlot:plot];
        
        //x value
        double height = self.bounds.size.height - BOTTOM_MARGIN_TO_LEAVE;
        double y = height - ((height / ([_yAxisRange doubleValue] + yIntervalValue+ yIntervalValue)) * [_value doubleValue]);
        (plot.xPoints[xIndex]).x = ceil((plot.xPoints[xIndex]).x);
        (plot.xPoints[xIndex]).y = ceil(y);
    }];
    
    for (NSDictionary *dic in plot.plottingValues) {
        
        NSArray *arr = [dic allKeys];
        
        id key = arr[0];
        id value = [dic objectForKey:key];
        
        NSUInteger interger = [key integerValue];
        
        if (key) {
            
            CGPoint point = plot.xPoints[interger-1];
            CGRect frame;
            
            // 当前y坐标大于最大值 20150209 ****************
            double intervalInPx = (self.bounds.size.height - BOTTOM_MARGIN_TO_LEAVE ) / (INTERVAL_COUNT + 1);
            
            if ([value doubleValue] > [self.yAxisRange doubleValue])
            {
                frame = CGRectMake(point.x-20, intervalInPx-25, 40, 30);
            }
            else
            {
                frame = CGRectMake(point.x-20, point.y-25, 40, 30);
            }
            
            UILabel *lbValue = [[UILabel alloc] initWithFrame:frame];
            lbValue.textAlignment = NSTextAlignmentCenter;
            lbValue.textColor = (UIColor *)theme[kPlotStrokeColorKey];
            lbValue.backgroundColor = [UIColor clearColor];
            lbValue.font = [UIFont fontWithName:@"YouYuan" size:14];
            lbValue.text = [NSString stringWithFormat:@"%@",value];
            [self addSubview:lbValue];
            
            // Y轴点坐标
            CGPoint currentLinePoint = CGPointMake(_leftMarginToLeave, self.bounds.size.height - BOTTOM_MARGIN_TO_LEAVE);
            
            CGRect frame1;
            
            // 当前y坐标大于最大值 20150209 ****************
            if ([value doubleValue] > [self.yAxisRange doubleValue])
            {
                frame1 = CGRectMake(point.x-15, intervalInPx,30, -intervalInPx+ currentLinePoint.y);
            }
            else
            {
                frame1 = CGRectMake(point.x - 15, point.y, 30, -point.y + currentLinePoint.y);
            }
            
            
            SHBar * bar = [[SHBar alloc] initWithFrame:frame1];
            bar.barColor = (UIColor *)theme[kPlotStrokeColorKey];
            bar.grade = [self.yAxisRange doubleValue];
            [self addSubview:bar];
            
//            UILabel *labelBar = [[UILabel alloc] initWithFrame:frame1];
//            labelBar.backgroundColor = (UIColor *)theme[kPlotStrokeColorKey];
//            [self addSubview:labelBar];
        }
    }
}

- (int)getIndexForValue:(NSNumber *)value forPlot:(SHPlot *)plot {
    for(int i=0; i< _xAxisValues.count; i++) {
        NSDictionary *d = [_xAxisValues objectAtIndex:i];
        __block BOOL foundValue = NO;
        [d enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
            NSNumber *k = (NSNumber *)key;
            if([k doubleValue] == [value doubleValue]) {
                foundValue = YES;
                *stop = foundValue;
            }
        }];
        if(foundValue){
            return i;
        }
    }
    return -1;
}

#pragma mark - UIButton event methods
/*
- (void)clicked:(id)sender
{
	@try {
		UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 120, 30)];
		lbl.backgroundColor = [UIColor clearColor];
    UIButton *btn = (UIButton *)sender;
		NSUInteger tag = btn.tag;
    
    SHPlot *_plot = objc_getAssociatedObject(btn, kAssociatedPlotObject);
		NSString *text = [_plot.plottingPointsLabels objectAtIndex:tag];
		
		lbl.text = text;
		lbl.textColor = [UIColor whiteColor];
		lbl.textAlignment = NSTextAlignmentCenter;
		lbl.font = (UIFont *)_plot.plotThemeAttributes[kPlotPointValueFontKey];
		[lbl sizeToFit];
		lbl.frame = CGRectMake(0, 0, lbl.frame.size.width + 5, lbl.frame.size.height);
		
		CGPoint point =((UIButton *)sender).center;
		point.y -= 15;
		
		dispatch_async(dispatch_get_main_queue(), ^{
			[PopoverView showPopoverAtPoint:point
                               inView:self
                      withContentView:lbl
                             delegate:nil];
		});
	}
	@catch (NSException *exception) {
		NSLog(@"plotting label is not available for this point");
	}
}*/

#pragma mark - Theme Key Extern Keys

NSString *const kXAxisLabelColorKey         = @"kXAxisLabelColorKey";
NSString *const kXAxisLabelFontKey          = @"kXAxisLabelFontKey";
NSString *const kYAxisLabelColorKey         = @"kYAxisLabelColorKey";
NSString *const kYAxisLabelFontKey          = @"kYAxisLabelFontKey";
NSString *const kYAxisLabelSideMarginsKey   = @"kYAxisLabelSideMarginsKey";
NSString *const kPlotBackgroundLineColorKye = @"kPlotBackgroundLineColorKye";

@end
