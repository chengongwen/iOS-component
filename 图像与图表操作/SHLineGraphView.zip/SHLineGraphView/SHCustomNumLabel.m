//
//  SHCustomNumLabel.m
//  SHLineGraphView
//
//  Created by yuanshanit on 14/12/9.
//  Copyright (c) 2014年 grevolution. All rights reserved.
//

#import "SHCustomNumLabel.h"

@implementation SHCustomNumLabel

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setFrame:frame];
        self.backgroundColor = [UIColor clearColor];
    }
    return self;
}

- (void)drawRect:(CGRect)rect
{
//    [super drawRect:rect];
    CGContextRef con = UIGraphicsGetCurrentContext();
    CGContextSetAllowsAntialiasing(con, true);
    CGContextSetShouldAntialias(con, true);
    
    CGContextAddEllipseInRect(con, CGRectMake(0,0,30,30));
    
    CGContextSetFillColorWithColor(con, [UIColor colorWithRed:106.0f/255.0f green:189.0f/255.0f blue:111.0f/255.0f alpha:1.f].CGColor);
    
    CGContextFillPath(con);
    
    CGContextSetFillColorWithColor(con, [UIColor whiteColor].CGColor);
    
    [self.text drawInRect:CGRectMake(0, 8, 30, 30) withFont:[UIFont systemFontOfSize:10.0f] lineBreakMode:NSLineBreakByCharWrapping alignment:NSTextAlignmentCenter];
}

@end
