//
//  MetaDataTool.h
//  doubleTableView
//
//  Created by tarena13 on 15/10/14.
//  Copyright (c) 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MetaDataTool : NSObject

+ (NSArray *)customStocks;

@end
