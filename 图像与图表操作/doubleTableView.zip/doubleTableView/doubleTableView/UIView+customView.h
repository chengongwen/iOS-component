//
//  UIView+customView.h
//  doubleTableView
//
//  Created by tarena13 on 15/10/13.
//  Copyright (c) 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (customView)

+ (UIView *)viewWithLabelNumber:(NSInteger)num;

@end
