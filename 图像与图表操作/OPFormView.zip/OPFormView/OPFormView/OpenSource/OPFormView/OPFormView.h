//
//  OPFormView.h
//  OPFormView
//
//  Created by pantianxiang on 15/6/4.
//  Copyright (c) 2015年 元善科技. All rights reserved.
//

#import <UIKit/UIKit.h>
@class OPFormView;
@class FormBlock;
@class DrawView;


//表格中的坐标点，既是线的起点，也是子块的起点（左上角）。
struct LinePoint{
    NSInteger x;
    NSInteger y;
};
typedef struct LinePoint LinePoint;

//线的方向，即一个LinePoint点可以画出两条线，要怎么画取决于线的方向
typedef enum {
    LineDirectionRight, //起点向右
    LineDirectionDown //起点向下
}LineDirection;

//表格视图代理
@protocol OPFormViewDelegate <NSObject>
@optional
/**
 *  返回表头高度。
 */
- (CGFloat)heightForTitleInForm:(OPFormView *)formView;

/**
 *  返回第rowIndex + 1行的高度。
 *
 *  @param rowIndex 行下标，从0开始。
 *  @return 宽度。
 */
- (CGFloat)opFormView:(OPFormView *)formView heightForRowAtIndex:(NSInteger)rowIndex;

/**
 *  返回第lineIndex + 1列的宽度。
 *
 *  @param lineIndex 列下标，从0开始。
 *  @return 高度。
 */
- (CGFloat)opFormView:(OPFormView *)formView widthForLineAtIndex:(NSInteger)lineIndex;

/**
 *  判断是否画出某一个子块中的某条线。
 *
 *  @param point 子块坐标。
 *  @param direction 线的方向。
 *  @return YES代表画，NO代表不画。
 */
- (BOOL)shouldDrawLineInForm:(OPFormView *)formView Point:(LinePoint)point direction:(LineDirection)direction;

/**
 *  点击选择某一个子块或者合并块的响应事件。
 *
 *  @param point 子块坐标。
 */
- (void)opFormView:(OPFormView *)formView didSelectblockAtLinePoint:(LinePoint)point;

/**
 *  返回表头视图
 *
 *  @return 返回UIView对象
 */
- (UIView *)viewForTitleInForm:(OPFormView *)formView;

@end

//表格数据源代理
@protocol OPFormViewDataSource <NSObject>
@required
/**
 *  返回表示中的总行数
 *
 *  @return 总行数
 */
- (NSInteger)numberOfRowsInForm:(OPFormView *)formView;

/**
 *  返回表示中的总列数
 *
 *  @return 总列数
 */
- (NSInteger)numberOfLinesInForm:(OPFormView *)formView;

/**
 *  返回表格中字块或者合并块的显示视图
 *
 *  @param point 子块坐标
 *  @return 返回FormBlock对象
 */
- (FormBlock *)opFormView:(OPFormView *)formView blockForBlockAtLinePoint:(LinePoint)point;

@optional
/**
 *  返回标头内容
 *
 *  @return 内容字符串对象
 */
- (NSString *)titleInForm:(OPFormView *)formView;

/**
 *  判断是否允许编辑某个子块或合并块
 *
 *  @param point 子块坐标
 *  @return YES：表示允许编辑，NO：表示不允许编辑。默认为YES;
 */
- (BOOL)opFormView:(OPFormView *)formView canEditBlockAtLinePoint:(LinePoint)point;

@end

@interface OPFormView : UIScrollView <UIScrollViewDelegate>

@property (assign, nonatomic) CGFloat lineWidth; //表格线宽，默认为1。
@property (assign, nonatomic) UIColor *lineColor; //表格线的颜色，默认为黑色。

- (instancetype)initWithFrame:(CGRect)frame opFormViewDataSource:(id<OPFormViewDataSource>)vDataSource opFormViewDataSource:(id<OPFormViewDelegate>)vDelegate;

//刷新表格
- (void)reloadData;

@end

/**
 *  FormBlock是表格中，子块或者合并块中的一个可由用户自定义的视图(可以看作是UITableView中的UITableViewCell)。
 *
 *  可以使用titleLabel直接赋值，也可以在该类上任意添加控件。
 */
@interface FormBlock : UIView

@property (retain, nonatomic) UILabel *titleLabel; //显示子表格中的内容

@end
