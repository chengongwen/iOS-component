//
//  OPFormView.m
//  OPFormView
//
//  Created by pantianxiang on 15/6/4.
//  Copyright (c) 2015年 元善科技. All rights reserved.
//

#import "OPFormView.h"

#define DefaultWidth 44.f
#define DefaultHeight 44.f
#define DefaultTitleHeight 44.f

#define FixedTopViewKey @"fixedTopView"
#define FixedLeftViewKey @"fixedLeftView"
#define DrawViewKey @"drawView"

#pragma mark - implementation FormBlock
@interface FormBlock ()

- (void)setLabelFrame;

@end

@implementation FormBlock
@synthesize titleLabel = _titleLabel;

- (void)dealloc
{
    [_titleLabel release];
    [super dealloc];
}

- (id)init
{
    if (self = [super init]) {
        self.backgroundColor = [UIColor clearColor];
        [self initView];
    }
    return  self;
}

- (void)initView
{
    UILabel *lbValue = [[UILabel alloc]init];
    lbValue.backgroundColor = [UIColor clearColor];
    lbValue.textAlignment = NSTextAlignmentCenter;
    lbValue.numberOfLines = 0;
    lbValue.font = [UIFont systemFontOfSize:14.f];
    lbValue.textColor = [UIColor blackColor];
    [self addSubview:lbValue];
    self.titleLabel = lbValue;
    [lbValue release];
}

- (void)setLabelFrame
{
    _titleLabel.frame = CGRectMake(0, 0, self.frame.size.width, self.frame.size.height);
}

@end

#pragma mark - interface FixedTopView
//上下滑动时的固定块。
@interface FixedTopView : UIView
@property (retain, nonatomic) OPFormView *opFormView;
@property (retain, nonatomic) DrawView *drawView;
@property (retain, nonatomic) UILabel *lbTitle; //标题。
@property (assign, nonatomic) CGFloat titleWidthRange; //标题显示宽度范围。
@property (assign, nonatomic) CAShapeLayer *lineLayer;

- (instancetype)initWithFrame:(CGRect)frame opFormView:(OPFormView *)opFormView drawView:(DrawView *)drawView;
- (void)drawForm;

@end

#pragma mark - interface FixedLeftView
//左右滑动时的固定块。
@interface FixedLeftView : UIView
@property (retain, nonatomic) OPFormView *opFormView;
@property (retain, nonatomic) DrawView *drawView;
@property (assign, nonatomic) CAShapeLayer *lineLayer;

- (instancetype)initWithFrame:(CGRect)frame opFormView:(OPFormView *)opFormView drawView:(DrawView *)drawView;
- (void)drawForm;
@end

#pragma mark - interface FixedCommonView
//整个表格第一格。
@interface FixedCommonView : UIView
@property (retain, nonatomic) OPFormView *opFormView;
@property (retain, nonatomic) DrawView *drawView;
@property (assign, nonatomic) CAShapeLayer *lineLayer;
- (instancetype)initWithFrame:(CGRect)frame opFormView:(OPFormView *)opFormView drawView:(DrawView *)drawView;
- (void)drawForm;
@end

#pragma mark - interface DrawView
//运行程序后，所看到的整个表格都是添加在该类或者是画在该类。
@interface DrawView : UIView
@property (retain, nonatomic) OPFormView *opFormView;
@property (retain, nonatomic) FixedTopView *fixedTopView;
@property (retain, nonatomic) FixedLeftView *fixedLeftView;
@property (retain, nonatomic) FixedCommonView *fixedCommonView;
@property (assign, nonatomic) BOOL isFixedTop; //在上下滑动的过程中，表格标题和第一行是否固定。
@property (assign, nonatomic) BOOL isFixedLeft; //在左右滑动的过程中，左边第一列是否固定。
@property (retain, nonatomic) NSMutableDictionary *combineBlockDic; //去掉的块之间的线。
@property (retain, nonatomic) NSMutableDictionary *finalCombineBlock; //合并完成后的块。
@property (assign, nonatomic) CAShapeLayer *lineLayer;
@property (retain, nonatomic) UIView *bgView;

- (instancetype)initWithFrame:(CGRect)frame opFormView:(OPFormView *)opFormView;

- (NSString *)stringFromLinePoint:(LinePoint)point;
- (LinePoint)linePointFromString:(NSString *)string;

- (void)calculateCombineBlock;

- (void)upAndDownScroll:(BOOL)isFixed offsetY:(CGFloat)offsetY;
- (void)leftAndRightScroll:(BOOL)isFixed offsetX:(CGFloat)offsetX;
- (void)drawForm;
@end


#pragma mark - implementation OPFormView
@interface OPFormView ()
@property (assign, nonatomic) id<OPFormViewDelegate> vDelegate; //表格视图代理。
@property (assign, nonatomic) id<OPFormViewDataSource> vDataSource; //表格数据源代理。
@property (assign, nonatomic) CGFloat margin; //表格边距，默认为0.5
@property (retain, nonatomic) DrawView *drawView;
@property (assign, nonatomic) NSInteger totalRows; //总行数
@property (assign, nonatomic) NSInteger totalLines; //总列数
@property (assign, nonatomic) CGFloat titleHeight; //表头高
@property (assign, nonatomic) CGPoint firstPoint; //接触表时的第一个点
@property (assign, nonatomic) BOOL isScrollUpAndDown; //判断执行上下滑动还是左右滑动

@end

@implementation OPFormView
@synthesize drawView = _drawView;

- (void)dealloc
{
    [_drawView release];
    [super dealloc];
}

- (id)initWithFrame:(CGRect)frame opFormViewDataSource:(id<OPFormViewDataSource>)vDataSource opFormViewDataSource:(id<OPFormViewDelegate>)vDelegate
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        self.delegate = self;
        self.userInteractionEnabled = YES;
        self.showsHorizontalScrollIndicator = NO;
        self.showsVerticalScrollIndicator = NO;
        self.directionalLockEnabled = YES;
        self.vDataSource = vDataSource;
        self.vDelegate = vDelegate;
        self.margin = 0.5f;
        self.isScrollUpAndDown = YES;
        [self drawForm];
    }
    return self;
}

#pragma mark  Property get methods
- (CGFloat)widthAtIndex:(NSInteger)index
{
    CGFloat width = 0.f;
    if (_vDelegate && [_vDelegate respondsToSelector:@selector(opFormView:widthForLineAtIndex:)]) {
        width = [_vDelegate opFormView:self widthForLineAtIndex:index];
    }else{
        width = DefaultWidth;
    }
    return width;
}

- (CGFloat)heightAtIndex:(NSInteger)index
{
    CGFloat height = 0.f;
    
    if (_vDelegate && [_vDelegate respondsToSelector:@selector(opFormView:heightForRowAtIndex:)]) {
        height = [_vDelegate opFormView:self heightForRowAtIndex:index];
    }else{
        height = DefaultHeight;
    }
    return height;
}

- (NSInteger)totalRows
{
    return [_vDataSource numberOfRowsInForm:self];
}

- (NSInteger)totalLines
{
    return [_vDataSource numberOfLinesInForm:self];
}

- (CGFloat)titleHeight
{
    CGFloat height = 0.f;
    if(_vDelegate && [_vDelegate respondsToSelector:@selector(viewForTitleInForm:)]){
        UIView *temp = (UIView *)[_vDelegate viewForTitleInForm:self];
        height = temp.frame.size.height;
    }else if(_vDelegate && [_vDelegate respondsToSelector:@selector(heightForTitleInForm:)]){
        height = [_vDelegate heightForTitleInForm:self];
    }else if(_vDataSource && [_vDataSource respondsToSelector:@selector(titleInForm:)]){
        if ([_vDataSource titleInForm:self]) {
            height = DefaultTitleHeight;
        }
    }
    return height;
}

#pragma mark - public methods
- (void)setupContentSize
{
    CGFloat width = 0.f;
    CGFloat height = 0.f;
    
    for (NSInteger i = 0; i < self.totalLines; i ++) {
        width += [self widthAtIndex:i];
    }
    
    for (NSInteger i = 0; i < self.totalRows; i ++) {
        height += [self heightAtIndex:i];
    }
    
    self.contentSize = CGSizeMake(width + 2 * _margin, height + 2 * _margin + self.titleHeight);
}
- (void)drawForm
{
    if (self.totalLines == 0 || self.totalRows == 0) return;
    
    [self setupContentSize];
    
    if (!_drawView) {
        DrawView *drawView = [[DrawView alloc]initWithFrame:CGRectMake(0, 0, self.contentSize.width, self.contentSize.height) opFormView:self];
        [self addSubview:drawView];
        self.drawView =drawView;
        [drawView release];
    }else{
        _drawView.frame = CGRectMake(0, 0, self.contentSize.width, self.contentSize.height);
        [_drawView drawForm];
    }
    
}

#pragma mark  public methods
//刷新表格
- (void)reloadData
{
    //重置相关属性
    //DrawView
    [[_drawView.finalCombineBlock objectForKey:@"right"] removeAllObjects];
    [[_drawView.finalCombineBlock objectForKey:@"down"] removeAllObjects];
    
    [[_drawView.combineBlockDic objectForKey:@"right"] removeAllObjects];
    [[_drawView.combineBlockDic objectForKey:@"down"] removeAllObjects];
    
    [self drawForm];
}

/**
 *  处理点击子块事件
 *
 *  @param point 块坐标
 */
- (void)handleClickEvents:(LinePoint)point
{
    BOOL canEdit = YES;
    if (_vDataSource && [_vDataSource respondsToSelector:@selector(opFormView:canEditBlockAtLinePoint:)]) {
        canEdit = [_vDataSource opFormView:self canEditBlockAtLinePoint:point];
    }
    if (canEdit) {
        if (_vDelegate && [_vDelegate respondsToSelector:@selector(opFormView:didSelectblockAtLinePoint:)]) {
            [_vDelegate opFormView:self didSelectblockAtLinePoint:point];
        }
    }
}

#pragma mark  UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (scrollView.contentOffset.y > 0) {
        [_drawView upAndDownScroll:YES offsetY:scrollView.contentOffset.y];
    }else{
        [_drawView upAndDownScroll:NO offsetY:scrollView.contentOffset.y];
    }
    
    if (scrollView.contentOffset.x > 0) {
        [_drawView leftAndRightScroll:YES offsetX:scrollView.contentOffset.x];
    }else{
        [_drawView leftAndRightScroll:NO offsetX:scrollView.contentOffset.x];
    }
}


@end

#pragma mark - implementation DrawView
@implementation DrawView
@synthesize opFormView = _opFormView;
@synthesize combineBlockDic = _combineBlockDic;
@synthesize finalCombineBlock = _finalCombineBlock;
@synthesize fixedTopView = _fixedTopView;
@synthesize fixedLeftView = _fixedLeftView;
@synthesize fixedCommonView = _fixedCommonView;
@synthesize bgView = _bgView;

- (void)dealloc
{
    [_opFormView release];
    [_combineBlockDic release];
    [_finalCombineBlock release];
    [_fixedTopView release];
    [_fixedLeftView release];
    [_fixedCommonView release];
    [_bgView release];
    [super dealloc];
}

- (id)initWithFrame:(CGRect)frame opFormView:(OPFormView *)opFormView
{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor whiteColor];
        self.opFormView = opFormView;
        self.isFixedTop = NO;
        self.isFixedLeft= NO;
        
        NSMutableDictionary *temp1 = [[NSMutableDictionary alloc]init];
        self.combineBlockDic = temp1;
        [temp1 release];
        NSMutableArray *temp2 = [[NSMutableArray alloc]init];
        [self.combineBlockDic setValue:temp2 forKey:@"right"];
        [temp2 release];
        NSMutableArray *temp3 = [[NSMutableArray alloc]init];
        [self.combineBlockDic setValue:temp3 forKey:@"down"];
        [temp3 release];
        
        NSMutableDictionary *temp4 = [[NSMutableDictionary alloc]init];
        self.finalCombineBlock = temp4;
        [temp4 release];
        NSMutableDictionary *temp5 = [[NSMutableDictionary alloc]init];
        [self.finalCombineBlock setValue:temp5 forKey:@"right"];
        [temp5 release];
        NSMutableDictionary *temp6 = [[NSMutableDictionary alloc]init];
        [self.finalCombineBlock setValue:temp6 forKey:@"down"];
        [temp6 release];
        
        [self drawForm];
    }
    return self;
}

- (void)drawForm
{
    if (!_fixedLeftView) {
        FixedLeftView *leftView = [[FixedLeftView alloc]initWithFrame:CGRectMake(0, 0, _opFormView.margin + [_opFormView widthAtIndex:0], self.frame.size.height) opFormView:_opFormView drawView:self];
        [self insertSubview:leftView atIndex:2];
        self.fixedLeftView = leftView;
        [leftView release];
    }else{
        _fixedLeftView.frame = CGRectMake(0, 0, _opFormView.margin + [_opFormView widthAtIndex:0], self.frame.size.height);
        [_fixedLeftView drawForm];
    }
    
    if (!_fixedTopView) {
        FixedTopView *topView = [[FixedTopView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width, _opFormView.margin + _opFormView.titleHeight + [_opFormView heightAtIndex:0]) opFormView:_opFormView drawView:self];
        [self insertSubview:topView atIndex:2];
        self.fixedTopView = topView;
        [topView release];
    }else{
        _fixedTopView.frame = CGRectMake(0, 0, self.frame.size.width, _opFormView.margin + _opFormView.titleHeight + [_opFormView heightAtIndex:0]);
        [_fixedTopView drawForm];
    }
    
    if (!_fixedCommonView) {
        FixedCommonView *commonView = [[FixedCommonView alloc]initWithFrame:CGRectMake(0, _opFormView.margin + _opFormView.titleHeight, _opFormView.margin + [_opFormView widthAtIndex:0], [_opFormView heightAtIndex:0]) opFormView:_opFormView drawView:self];
        [self insertSubview:commonView atIndex:3];
        self.fixedCommonView = commonView;
        [commonView release];
    }else{
        _fixedCommonView.frame = CGRectMake(0, _opFormView.margin + _opFormView.titleHeight, _opFormView.margin + [_opFormView widthAtIndex:0], [_opFormView heightAtIndex:0]);
        [_fixedCommonView drawForm];
    }
    
    if(self.lineLayer)
    {
        [self.lineLayer removeFromSuperlayer];
    }
    
    //draw form
    if (self.bgView) {
        for (UIView *view in self.bgView.subviews) {
            if ([view isKindOfClass:[FormBlock class]]) {
                [view removeFromSuperview];
            }
        }
    }else {
        UIView *bgView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
        bgView.backgroundColor = [UIColor clearColor];
        bgView.userInteractionEnabled = YES;
        [self insertSubview:bgView atIndex:0];
        self.bgView = bgView;
        [bgView release];
    }
    
    self.lineLayer = [CAShapeLayer layer];
    self.lineLayer.frame = self.bounds;
    self.lineLayer.lineWidth = _opFormView.lineWidth == 0 ? 1.f : _opFormView.lineWidth;
    self.lineLayer.strokeColor = _opFormView.lineColor ? _opFormView.lineColor.CGColor : [UIColor blackColor].CGColor;
    
    CGMutablePathRef path = CGPathCreateMutable();
    
    CGFloat currentWidth = 0.f;
    CGFloat currentHeight = 0.f;
    CGFloat startX = 0.f;
    CGFloat startY = 0.f;
    //draw horizontal lines
    for (NSInteger i = 1; i < _opFormView.totalRows + 1; i ++) {
        startY = currentHeight;
        currentHeight += [_opFormView heightAtIndex:i];
        for (NSInteger j = 1; j < _opFormView.totalLines; j ++) {
            BOOL shouldDraw = YES;
            LinePoint point;
            point.x = j;
            point.y = i;
            if (_opFormView.vDelegate && [_opFormView.vDelegate respondsToSelector:@selector(shouldDrawLineInForm:Point:direction:)]) {
                shouldDraw = [_opFormView.vDelegate shouldDrawLineInForm:_opFormView Point:point direction:LineDirectionRight];
            }
            startX = currentWidth;
            currentWidth += [_opFormView widthAtIndex:j];
            if (shouldDraw) {
                CGPoint startPoint = CGPointMake(startX + CGRectGetMaxX(_fixedLeftView.frame), startY + CGRectGetMaxY(_fixedTopView.frame));
                CGPathMoveToPoint(path, nil, startPoint.x, startPoint.y);
                CGPathAddLineToPoint(path, nil, startPoint.x + [_opFormView widthAtIndex:j], startPoint.y);
            }else{
                if (point.y != 1 && point.y != _opFormView.totalRows) {
                    if (![[_combineBlockDic objectForKey:@"right"] containsObject:[self stringFromLinePoint:point]]) {
                        [[_combineBlockDic objectForKey:@"right"] addObject:[self stringFromLinePoint:point]];
                    }
                }
            }
        }
        startX = 0.f;
        currentWidth = 0.f;
    }
    
    startY = 0.f;
    currentHeight = 0.f;
    //draw vertical lines
    for (NSInteger i = 1; i < _opFormView.totalLines + 1; i ++) {
        startX = currentWidth;
        currentWidth += [_opFormView widthAtIndex:i];
        for (NSInteger j = 1 ; j < _opFormView.totalRows; j ++) {
            BOOL shouldDraw = YES;
            LinePoint point;
            point.x = i;
            point.y = j;
            if (_opFormView.vDelegate && [_opFormView.vDelegate respondsToSelector:@selector(shouldDrawLineInForm:Point:direction:)]) {
                shouldDraw = [_opFormView.vDelegate shouldDrawLineInForm:_opFormView Point:point direction:LineDirectionDown];
            }
            startY = currentHeight;
            currentHeight += [_opFormView heightAtIndex:j];
            if (shouldDraw) {
                CGPoint startPoint = CGPointMake(startX + CGRectGetMaxX(_fixedLeftView.frame), startY + CGRectGetMaxY(_fixedTopView.frame));
                CGPathMoveToPoint(path, nil, startPoint.x, startPoint.y);
                CGPathAddLineToPoint(path, nil, startPoint.x, startPoint.y + [_opFormView heightAtIndex:j]);
            }else{
                if (point.x != 1 && point.x != _opFormView.totalLines) {
                    if (![[_combineBlockDic objectForKey:@"down"] containsObject:[self stringFromLinePoint:point]]) {
                        [[_combineBlockDic objectForKey:@"down"] addObject:[self stringFromLinePoint:point]];
                    }
                }
            }
            
        }
        startY = 0.f;
        currentHeight = 0.f;
    }
    
    self.lineLayer.path = path;
    [self.bgView.layer addSublayer:self.lineLayer];
    
    //calculate how many combineBlock in this form.
    [self calculateCombineBlock];
    
    //show value
    [self showValue];
}

- (void)showValue
{
    CGFloat currentWidth = 0.f;
    CGFloat currentHeight = 0.f;
    CGFloat startX = 0.f;
    CGFloat startY = 0.f;
    NSInteger tag = 0;
    for (NSInteger i = 1; i < _opFormView.totalRows; i ++) {
        startY = currentHeight;
        currentHeight += [_opFormView heightAtIndex:i];
        for (NSInteger j = 1; j < _opFormView.totalLines; j ++) {
            startX = currentWidth;
            currentWidth += [_opFormView widthAtIndex:j];
            tag = (i - 1) * (_opFormView.totalLines - 1) + j;
            
            LinePoint point;
            point.x = j;
            point.y = i;
            
            CGRect blockFrame = CGRectMake(startX + _opFormView.margin + [_opFormView widthAtIndex:0] + _opFormView.lineWidth, startY + _opFormView.margin + _opFormView.titleHeight + [_opFormView heightAtIndex:0] + _opFormView.lineWidth, [_opFormView widthAtIndex:point.x] - 2 * _opFormView.lineWidth, [_opFormView heightAtIndex:point.y] - 2 * _opFormView.lineWidth);
            
            NSString *pointString = [self stringFromLinePoint:point];
            NSArray *downKeys = [[_finalCombineBlock objectForKey:@"down"] allKeys];
            NSArray *rightKeys = [[_finalCombineBlock objectForKey:@"right"] allKeys];
            
            BOOL addBlock = YES;
            if ([downKeys containsObject:pointString] || [rightKeys containsObject:pointString]) {
                CGSize blockSize ;
                if ([downKeys containsObject:pointString]) {
                    blockSize = CGSizeFromString([[[_finalCombineBlock objectForKey:@"down"] objectForKey:pointString] objectForKey:@"size"]);
                }else{
                    blockSize = CGSizeFromString([[[_finalCombineBlock objectForKey:@"right"] objectForKey:pointString] objectForKey:@"size"]);
                }
                blockFrame = CGRectMake(blockFrame.origin.x, blockFrame.origin.y, blockSize.width - 2 * _opFormView.lineWidth, blockSize.height - 2 * _opFormView.lineWidth);
            }else{
                if ([[_combineBlockDic objectForKey:@"down"] containsObject:pointString] || [[_combineBlockDic objectForKey:@"right"] containsObject:pointString]) {
                    addBlock = NO;
                }
            }
            if (addBlock) {
                FormBlock *block = (FormBlock *)[_opFormView.vDataSource opFormView:_opFormView blockForBlockAtLinePoint:point];
                if (block) {
                    block.frame = blockFrame;
                    block.tag = tag;
                    [self.bgView addSubview:block];
                    [block setLabelFrame];
                    
                    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(clickBlock:)];
                    [block addGestureRecognizer:tap];
                    [tap release];
                }
            }
        }
        startX = 0.f;
        currentWidth = 0.f;
    }
}

#pragma mark  计算合并块逻辑
- (void)calculateCombineBlock
{
    if (_combineBlockDic.count == 0) return;
    
    //计算竖直方向上合并的块
    [self commonArithmetic:LineDirectionRight];
    //计算水平方向上合并的块
    [self commonArithmetic:LineDirectionDown];
    
    //如果其中一个块在水平和竖直方向上都与其他块合并，这里将不显示值（不支持同时水平和竖直方向上合并。）
    NSArray *rightKeys = [[_finalCombineBlock objectForKey:@"right"] allKeys];
    NSArray *downKeys = [[_finalCombineBlock objectForKey:@"down"] allKeys];
    for (NSString *rightKey in rightKeys) {
        for (NSString *downKey in downKeys) {
            if ([rightKey isEqualToString:downKey]) {
                //首先将合并块对应的去除掉的子快之间的线从combineBlockDic中移除。
                [self removeContainsLine:@"right" pointString:rightKey];
                //其次移除合并块。
                [[_finalCombineBlock objectForKey:@"right"] removeObjectForKey:rightKey];
                
                [self removeContainsLine:@"down" pointString:downKey];
                [[_finalCombineBlock objectForKey:@"down"] removeObjectForKey:downKey];
            }
        }
    }
    
    NSMutableArray *both = [[NSMutableArray alloc]init];
    for (NSString *pointString1 in [_combineBlockDic objectForKey:@"right"]) {
        for (NSString *pointString2 in [_combineBlockDic objectForKey:@"down"]) {
            if ([pointString1 isEqualToString:pointString2]) {
                [both addObject:pointString2];
                continue;
            }
        }
    }
    
    for (NSString *pointString in both) {
        LinePoint point1 = [self linePointFromString:pointString];
        NSArray *rightKeys = [[_finalCombineBlock objectForKey:@"right"] allKeys];
        NSMutableArray *sameX = [[NSMutableArray alloc]init];
        for (NSString * rightkey in rightKeys) {
            LinePoint point2 = [self linePointFromString:rightkey];
            if (point1.x == point2.x && point1.y >= point2.y) {
                [sameX addObject:rightkey];
            }
        }
        if (sameX.count > 0) {
            LinePoint maxPoint = [self linePointFromString:[sameX objectAtIndex:0]];
            for (NSInteger i = 1; i < sameX.count; i ++) {
                LinePoint point = [self linePointFromString:[sameX objectAtIndex:i]];
                if (maxPoint.y < point.y) {
                    maxPoint = point;
                }
            }
            [self removeContainsLine:@"right" pointString:[self stringFromLinePoint:maxPoint]];
            [[_finalCombineBlock objectForKey:@"right"] removeObjectForKey:[self stringFromLinePoint:maxPoint]];
        }
        
        NSArray *downKeys = [[_finalCombineBlock objectForKey:@"down"] allKeys];
        NSMutableArray *sameY = [[NSMutableArray alloc]init];
        for (NSString * downKey in downKeys) {
            LinePoint point2 = [self linePointFromString:downKey];
            if (point1.y == point2.y && point1.x >= point2.x) {
                [sameY addObject:downKey];
            }
        }
        if (sameY.count > 0) {
            LinePoint maxPoint = [self linePointFromString:[sameY objectAtIndex:0]];
            for (NSInteger i = 1; i < sameY.count; i ++) {
                LinePoint point = [self linePointFromString:[sameY objectAtIndex:i]];
                if (maxPoint.x < point.x) {
                    maxPoint = point;
                }
            }
            [self removeContainsLine:@"down" pointString:[self stringFromLinePoint:maxPoint]];
            [[_finalCombineBlock objectForKey:@"down"] removeObjectForKey:[self stringFromLinePoint:maxPoint]];
        }
        [sameX release];
        [sameY release];
    }
    [both release];
}

- (void)commonArithmetic:(LineDirection)direction
{
    NSString *directionKey = nil;
    if (direction == LineDirectionRight) {
        directionKey = @"right";
    }else{
        directionKey = @"down";
    }
    
    NSMutableDictionary *combineArr = [[NSMutableDictionary alloc]init];
    for (NSInteger i = 0; i < [[_combineBlockDic objectForKey:directionKey] count]; i ++) {
        NSString *pointString = [[_combineBlockDic objectForKey:directionKey] objectAtIndex:i];
        LinePoint point = [self linePointFromString:pointString];
        NSString *key = nil;
        if ([directionKey isEqualToString:@"right"]) {
            key = [NSString stringWithFormat:@"%ld",(long)point.x];
        } else{
            key = [NSString stringWithFormat:@"%ld",(long)point.y];
        }
        NSArray *keys = [combineArr allKeys];
        if (![keys containsObject:key]) {
            NSMutableArray *temp = [[NSMutableArray alloc]init];
            [combineArr setValue:temp forKey:key];
            [temp release];
        }
        [[combineArr objectForKey:key] addObject:[NSString stringWithFormat:@"%ld",[directionKey isEqualToString:@"right"] ? (long)point.y : (long)point.x]];
    }
    
    NSArray *keys = [combineArr allKeys];
    for (NSString *key in keys) {
        NSMutableArray *temp = [combineArr objectForKey:key];
        //由于一开始保存的时候是从小到大，且用数组保存，所以此时同一列中的所有块的x或y值都是从小到大保存。
        for (NSInteger i = 0; i < temp.count; i ++) {
            NSMutableArray *containsLine = [[NSMutableArray alloc]init]; //记录同一个合并块中去掉的块之间的线
            NSInteger y = [[temp objectAtIndex:i] integerValue];
            CGFloat heightOrWidth = 0.f;
            if ([directionKey isEqualToString:@"right"]) {
                heightOrWidth = [_opFormView heightAtIndex:y];;
            }else{
                heightOrWidth = [_opFormView widthAtIndex:y];
            }
            
            LinePoint minPoint;
            if ([directionKey isEqualToString:@"right"]) {
                minPoint.x = [key integerValue];
                minPoint.y = [[temp objectAtIndex:i] integerValue];
            }else{
                minPoint.x = [[temp objectAtIndex:i] integerValue];
                minPoint.y = [key integerValue];
            }
            [containsLine addObject:[self stringFromLinePoint:minPoint]];
            
            if (i == temp.count - 1) {
                [self recordCombineBlock:directionKey point:minPoint heightOrWidth:heightOrWidth containsLine:containsLine];
            }
            
            for (NSInteger j = i + 1; j < temp.count; j ++) {
                NSInteger nextY = [[temp objectAtIndex:j] integerValue];
                if (nextY - y == 1) {
                    
                    LinePoint currentPoint;
                    if ([directionKey isEqualToString:@"right"]) {
                        heightOrWidth += [_opFormView heightAtIndex:nextY];
                        currentPoint.x = [key integerValue];
                        currentPoint.y = nextY;
                    }else{
                        heightOrWidth += [_opFormView widthAtIndex:nextY];
                        currentPoint.x = nextY;
                        currentPoint.y = [key integerValue];
                    }
                    [containsLine addObject:[self stringFromLinePoint:currentPoint]];
                    y = nextY;
                    if (j == temp.count - 1) {
                        [self recordCombineBlock:directionKey point:minPoint heightOrWidth:heightOrWidth containsLine:containsLine];
                        i = j;
                        break;
                    }else
                    {
                        continue;
                    }
                    
                }else
                {
                    [self recordCombineBlock:directionKey point:minPoint heightOrWidth:heightOrWidth containsLine:containsLine];
                    i = j - 1;
                    break;
                }
            }
            [containsLine removeAllObjects];
        }
    }
    [combineArr release];
}

- (void)recordCombineBlock:(NSString *)direction point:(LinePoint)point heightOrWidth:(CGFloat)heightOrWidth containsLine:(NSMutableArray *)containsLine
{
    NSMutableArray *temp = [[NSMutableArray alloc]init];
    for (NSString *tempString in containsLine) {
        [temp addObject:tempString];
    }
    LinePoint lastPoint;
    CGSize size;
    if ([direction isEqualToString:@"right"])
    {
        lastPoint.x = point.x;
        if (point.y == 0) {
            lastPoint.y = 0;
        }else{
            lastPoint.y = point.y - 1;
        }
        size = CGSizeMake([_opFormView widthAtIndex:point.x], heightOrWidth + (point.y == 0 ? 0 : [_opFormView heightAtIndex:lastPoint.y]));
    }
    else
    {
        lastPoint.y = point.y;
        if (point.x == 0) {
            lastPoint.x = 0;
        }else{
            lastPoint.x = point.x - 1;
        }
        size = CGSizeMake(heightOrWidth + (point.x == 0 ? 0 : [_opFormView widthAtIndex:lastPoint.x]), [_opFormView heightAtIndex:point.y]);
    }
    NSArray *keys = [[_finalCombineBlock objectForKey:direction] allKeys];
    if (![keys containsObject:[self stringFromLinePoint:lastPoint]]) {
        //以合并块的起始坐标为key值，对应合并块的大小和合并块中去除的块之间的线。
        NSMutableDictionary *temp = [[NSMutableDictionary alloc]init];
        [[_finalCombineBlock objectForKey:direction] setValue:temp forKey:[self stringFromLinePoint:lastPoint]];
        [temp release];
    }
    [[[_finalCombineBlock objectForKey:direction] objectForKey:[self stringFromLinePoint:lastPoint]] setValue:NSStringFromCGSize(size) forKey:@"size"];
    [[[_finalCombineBlock objectForKey:direction] objectForKey:[self stringFromLinePoint:lastPoint]] setValue:temp forKey:@"containsLine"];
    [temp release];
}

- (void)removeContainsLine:(NSString *)direction pointString:(NSString *)combineString
{
    NSMutableArray *containsLine = [[[_finalCombineBlock objectForKey:direction] objectForKey:combineString] objectForKey:@"containsLine"];
    for (NSString *pointString  in containsLine) {
        if ([[_combineBlockDic objectForKey:direction] containsObject:pointString]) {
            [[_combineBlockDic objectForKey:direction] removeObject:pointString];
        }
    }
}

#pragma mark  Events
//点击子块出发事件
- (void)clickBlock:(UITapGestureRecognizer *)tapGesture
{
    FormBlock *block = (FormBlock *)tapGesture.view;
    NSInteger tag = block.tag - 1;
    
    NSInteger x = tag % (_opFormView.totalLines - 1);
    NSInteger y = tag / (_opFormView.totalLines - 1);
    
    LinePoint point;
    point.x = x + 1;
    point.y = y + 1;
    
    [_opFormView handleClickEvents:point];
}

#pragma mark  self methods
//块坐标转换成string对象
- (NSString *)stringFromLinePoint:(LinePoint)point
{
    return [NSString stringWithFormat:@"%ld/%ld",(long)point.x,(long)point.y];
}

//string对象转换成块坐标
- (LinePoint)linePointFromString:(NSString *)string
{
    NSRange range = [string rangeOfString:@"/"];
    LinePoint point;
    point.x = [[string substringToIndex:range.location] integerValue];
    point.y = [[string substringFromIndex:range.location + 1] integerValue];
    return point;
}

//处理表格上下滑动
- (void)upAndDownScroll:(BOOL)isFixed offsetY:(CGFloat)offsetY
{
    if (isFixed) {
        if (!_isFixedTop) {
            _isFixedTop = YES;
        }
        
        CGRect fram = _fixedCommonView.frame;
        fram.origin.y = offsetY + _opFormView.margin + _opFormView.titleHeight;
        _fixedCommonView.frame = fram;
        
        CGRect frame = _fixedTopView.frame;
        frame.origin.y = offsetY;
        _fixedTopView.frame = frame;
    }
    
    if (!isFixed) {
        if (_isFixedTop) {
            _isFixedTop = NO;
            _fixedTopView.frame = CGRectMake(0, 0, self.frame.size.width, _opFormView.margin + _opFormView.titleHeight + [_opFormView heightAtIndex:0]);
            
            _fixedCommonView.frame = CGRectMake(0, _opFormView.margin + _opFormView.titleHeight, _opFormView.margin + [_opFormView widthAtIndex:0], [_opFormView heightAtIndex:0]);
        }
    }
}

//处理表格左右滑动
- (void)leftAndRightScroll:(BOOL)isFixed offsetX:(CGFloat)offsetX
{
    if (isFixed) {
        if (!_isFixedLeft) {
            _isFixedLeft = YES;
        }
        
        CGRect fram = _fixedCommonView.frame;
        fram.origin.x = offsetX;
        _fixedCommonView.frame = fram;
        
        CGRect frame = _fixedLeftView.frame;
        frame.origin.x = offsetX;
        _fixedLeftView.frame = frame;
        
        //固定标题
        if (offsetX > 0 && _fixedTopView.lbTitle) {
            CGRect titleFrame = _fixedTopView.lbTitle.frame;
            titleFrame.origin.x = (_fixedTopView.titleWidthRange - titleFrame.size.width) / 2 + offsetX;
            _fixedTopView.lbTitle.frame = titleFrame;
        }
        
    }
    
    if (!isFixed) {
        if (_isFixedLeft) {
            _isFixedLeft = NO;
            _fixedLeftView.frame = CGRectMake(0, 0, _opFormView.margin + [_opFormView widthAtIndex:0], self.frame.size.height);
            
            _fixedCommonView.frame = CGRectMake(0, _opFormView.margin + _opFormView.titleHeight, _opFormView.margin + [_opFormView widthAtIndex:0], [_opFormView heightAtIndex:0]);
            
            if (_fixedTopView.lbTitle) {
                //固定标题
                CGRect titleFrame = _fixedTopView.lbTitle.frame;
                titleFrame.origin.x = (_fixedTopView.titleWidthRange- titleFrame.size.width) / 2;
                _fixedTopView.lbTitle.frame = titleFrame;
            }
        }
    }
}

@end

#pragma mark - implementation FixedTopView
@implementation FixedTopView
@synthesize opFormView = _opFormView;
@synthesize drawView = _drawView;
@synthesize lbTitle = _lbTitle;

- (void)dealloc
{
    [_opFormView release];
    [_drawView release];
    [_lbTitle release];
    [super dealloc];
}

- (id)initWithFrame:(CGRect)frame opFormView:(OPFormView *)opFormView drawView:(DrawView *)drawView
{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor whiteColor];
        self.opFormView = opFormView;
        self.drawView = drawView;
        [self drawForm];
    }
    return self;
}

- (void)drawForm
{
    for (UIView *view in self.subviews) {
        if ([view isKindOfClass:[UIView class]]) {
            [view removeFromSuperview];
        }
        if ([view isKindOfClass:[UILabel class]]) {
            [view removeFromSuperview];
        }
    }
    
    if (self.lineLayer) {
        [self.lineLayer removeFromSuperlayer];
    }
    
    //draw
    self.lineLayer = [CAShapeLayer layer];
    self.lineLayer.frame = self.bounds;
    self.lineLayer.lineWidth = _opFormView.lineWidth == 0 ? 1.f : _opFormView.lineWidth;
    self.lineLayer.strokeColor = _opFormView.lineColor ? _opFormView.lineColor.CGColor : [UIColor blackColor].CGColor;
    self.lineLayer.fillColor = [UIColor clearColor].CGColor;
    
    CGMutablePathRef path = CGPathCreateMutable();
    
    //draw title
    if (_opFormView.titleHeight > 0) {
        CGPathMoveToPoint(path, nil, _opFormView.margin, _opFormView.margin + _opFormView.titleHeight);
        CGPathAddLineToPoint(path, nil, _opFormView.margin, _opFormView.margin);
        CGPathAddLineToPoint(path, nil, self.frame.size.width - _opFormView.margin, _opFormView.margin);
        CGPathAddLineToPoint(path, nil, self.frame.size.width - _opFormView.margin, _opFormView.margin + _opFormView.titleHeight);
        if (_opFormView.vDelegate && [_opFormView.vDelegate respondsToSelector:@selector(viewForTitleInForm:)]) {
            if ([_opFormView.vDelegate viewForTitleInForm:_opFormView]) {
                UIView *titleView = (UIView *)[_opFormView.vDelegate viewForTitleInForm:_opFormView];
                titleView.frame = CGRectMake(_opFormView.margin, _opFormView.margin, titleView.frame.size.width > (self.frame.size.width - 2 * _opFormView.margin) ? self.frame.size.width - 2 * _opFormView.margin : titleView.frame.size.width, titleView.frame.size.height > _opFormView.titleHeight ? _opFormView.titleHeight : titleView.frame.size.height);
                [self addSubview:titleView];
            }
        }else if(_opFormView.vDataSource && [_opFormView.vDataSource respondsToSelector:@selector(titleInForm:)]) {
            if ([_opFormView.vDataSource titleInForm:_opFormView]) {
                NSString *title = (NSString *)[_opFormView.vDataSource titleInForm:_opFormView];
                CGRect titleFrame = [title boundingRectWithSize:CGSizeMake(MAXFLOAT, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName : [UIFont boldSystemFontOfSize:16.f]} context:nil];
                
                self.titleWidthRange = self.frame.size.width + 2 * _opFormView.margin < _opFormView.frame.size.width ? self.frame.size.width + 2 * _opFormView.margin : _opFormView.frame.size.width;
                UILabel *lbTitle = [[UILabel alloc]initWithFrame:CGRectMake((self.titleWidthRange- titleFrame.size.width) / 2, _opFormView.margin + (_opFormView.titleHeight - titleFrame.size.height) / 2, titleFrame.size.width, titleFrame.size.height)];
                lbTitle.textAlignment = NSTextAlignmentCenter;
                lbTitle.textColor = [UIColor blackColor];
                lbTitle.font = [UIFont boldSystemFontOfSize:16.f];
                lbTitle.backgroundColor = [UIColor clearColor];
                lbTitle.text = title;
                [self addSubview:lbTitle];
                self.lbTitle = lbTitle;
                [lbTitle release];
            }
        }
        
    }
    CGFloat currentWidth = 0.f;
    CGFloat currentHeight = 0.f;
    CGFloat startX = 0.f;
    CGFloat startY = 0.f;
    //draw horizontal lines
    for (NSInteger i = 0; i < 2; i ++) {
        startY = currentHeight;
        currentHeight += [_opFormView heightAtIndex:i];
        for (NSInteger j = 0; j < _opFormView.totalLines; j ++) {
            BOOL shouldDraw = YES;
            LinePoint point;
            point.x = j;
            point.y = i;
            if (_opFormView.vDelegate && [_opFormView.vDelegate respondsToSelector:@selector(shouldDrawLineInForm:Point:direction:)]) {
                shouldDraw = [_opFormView.vDelegate shouldDrawLineInForm:_opFormView Point:point direction:LineDirectionRight];
            }
            startX = currentWidth;
            currentWidth += [_opFormView widthAtIndex:j];
            if (shouldDraw) {
                CGPoint startPoint = CGPointMake(startX + _opFormView.margin, startY + _opFormView.margin + _opFormView.titleHeight);
                CGPathMoveToPoint(path, nil, startPoint.x, startPoint.y);
                CGPathAddLineToPoint(path, nil, startPoint.x + [_opFormView widthAtIndex:j], startPoint.y);
            }else{
                if (point.y != 1) {
                    if (![[_drawView.combineBlockDic objectForKey:@"right"] containsObject:[_drawView stringFromLinePoint:point]]) {
                        [[_drawView.combineBlockDic objectForKey:@"right"] addObject:[_drawView stringFromLinePoint:point]];
                    }
                }
            }
        }
        currentWidth = 0;
        startX = 0;
    }
    
    startY = 0.f;
    currentHeight = 0.f;
    //draw vertical lines
    for (NSInteger i = 0; i < _opFormView.totalLines + 1; i ++) {
        startX = currentWidth;
        currentWidth += [_opFormView widthAtIndex:i];
        BOOL shouldDraw = YES;
        LinePoint point;
        point.x = i;
        point.y = 0;
        if (_opFormView.vDelegate && [_opFormView.vDelegate respondsToSelector:@selector(shouldDrawLineInForm:Point:direction:)]) {
            shouldDraw = [_opFormView.vDelegate shouldDrawLineInForm:_opFormView Point:point direction:LineDirectionDown];
        }
        if (shouldDraw) {
            CGPoint startPoint = CGPointMake(startX + _opFormView.margin, _opFormView.margin + _opFormView.titleHeight);
            CGPathMoveToPoint(path, nil, startPoint.x, startPoint.y);
            CGPathAddLineToPoint(path, nil, startPoint.x, startPoint.y + [_opFormView heightAtIndex:0]);
        }else{
            if (point.x != 1 && point.x != _opFormView.totalLines) {
                if (![[_drawView.combineBlockDic objectForKey:@"down"] containsObject:[_drawView stringFromLinePoint:point]]) {
                    [[_drawView.combineBlockDic objectForKey:@"down"] addObject:[_drawView stringFromLinePoint:point]];
                }
            }
        }
    }
    
    self.lineLayer.path = path;
    [self.layer addSublayer:self.lineLayer];
    
    [_drawView calculateCombineBlock];
    //show value
    [self showValue];
}

- (void)showValue
{
    
    CGFloat currentWidth = [_opFormView widthAtIndex:0];
    CGFloat startX = currentWidth;
    NSInteger tag = 2;
    for (NSInteger i = 1; i < _opFormView.totalLines; i ++) {
        startX = currentWidth;
        currentWidth += [_opFormView widthAtIndex:i];
        LinePoint point;
        point.x = i;
        point.y = 0;
        
        CGRect blockFrame = CGRectMake(startX + _opFormView.margin + _opFormView.lineWidth,  _opFormView.margin + _opFormView.titleHeight + _opFormView.lineWidth, [_opFormView widthAtIndex:i] - 2 * _opFormView.lineWidth, [_opFormView heightAtIndex:0] - 2 * _opFormView.lineWidth);
        NSString *pointString = [_drawView stringFromLinePoint:point];
        NSArray *downKeys = [[_drawView.finalCombineBlock objectForKey:@"down"] allKeys];
        NSArray *rightKeys = [[_drawView.finalCombineBlock objectForKey:@"right"] allKeys];
        
        BOOL addBlock = YES;
        if ([downKeys containsObject:pointString] || [rightKeys containsObject:pointString]) {
            CGSize blockSize ;
            if ([downKeys containsObject:pointString]) {
                blockSize = CGSizeFromString([[[_drawView.finalCombineBlock objectForKey:@"down"] objectForKey:pointString] objectForKey:@"size"]);
            }else{
                blockSize = CGSizeFromString([[[_drawView.finalCombineBlock objectForKey:@"right"] objectForKey:pointString] objectForKey:@"size"]);
            }
            blockFrame = CGRectMake(blockFrame.origin.x, blockFrame.origin.y, blockSize.width - 2 * _opFormView.lineWidth, blockSize.height - 2 * _opFormView.lineWidth);
        }else{
            if ([[_drawView.combineBlockDic objectForKey:@"down"] containsObject:pointString] || [[_drawView.combineBlockDic objectForKey:@"right"] containsObject:pointString]) {
                tag ++;
                addBlock = NO;
            }
        }
        if (addBlock) {
            FormBlock *block = (FormBlock *)[_opFormView.vDataSource opFormView:_opFormView blockForBlockAtLinePoint:point];
            if (block) {
                block.frame = blockFrame;
                block.tag = tag;
                [self addSubview:block];
                [block setLabelFrame];
                
                UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(clickBlock:)];
                [block addGestureRecognizer:tap];
                [tap release];
            }
        }
        
        tag ++;
    }
}

- (void)clickBlock:(UITapGestureRecognizer *)tapGesture
{
    FormBlock *block = (FormBlock *)tapGesture.view;
    NSInteger tag = block.tag - 1;
    
    LinePoint point;
    point.x = tag;
    point.y = 0;
    
    [_opFormView handleClickEvents:point];
}

@end

#pragma mark - implementation FixedLeftView
@implementation FixedLeftView

@synthesize opFormView = _opFormView;
@synthesize drawView = _drawView;

- (void)dealloc
{
    [_opFormView release];
    [_drawView release];
    [super dealloc];
}

- (id)initWithFrame:(CGRect)frame opFormView:(OPFormView *)opFormView drawView:(DrawView *)drawView
{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor whiteColor];
        self.opFormView = opFormView;
        self.drawView = drawView;
        [self drawForm];
    }
    return self;
}

- (void)drawForm
{
    if (self.lineLayer) {
        [self.lineLayer removeFromSuperlayer];
    }
    //draw
    self.lineLayer = [CAShapeLayer layer];
    self.lineLayer.frame = self.bounds;
    self.lineLayer.lineWidth = _opFormView.lineWidth == 0 ? 1.f : _opFormView.lineWidth;
    self.lineLayer.strokeColor = _opFormView.lineColor ? _opFormView.lineColor.CGColor : [UIColor blackColor].CGColor;
    
    CGMutablePathRef path = CGPathCreateMutable();
    
    CGFloat currentWidth = 0.f;
    CGFloat currentHeight = 0.f;
    CGFloat startX = 0.f;
    CGFloat startY = 0.f;
    //draw horizontal lines
    for (NSInteger i = 0; i < _opFormView.totalRows + 1; i ++) {
        startY = currentHeight;
        currentHeight += [_opFormView heightAtIndex:i];
        BOOL shouldDraw = YES;
        LinePoint point;
        point.x = 0;
        point.y = i;
        if (_opFormView.vDelegate && [_opFormView.vDelegate respondsToSelector:@selector(shouldDrawLineInForm:Point:direction:)]) {
            shouldDraw = [_opFormView.vDelegate shouldDrawLineInForm:_opFormView Point:point direction:LineDirectionRight];
        }
        if (shouldDraw) {
            CGPoint startPoint = CGPointMake(_opFormView.margin, startY + _opFormView.margin + _opFormView.titleHeight);
            CGPathMoveToPoint(path, nil, startPoint.x, startPoint.y);
            CGPathAddLineToPoint(path, nil, startPoint.x + [_opFormView widthAtIndex:0], startPoint.y);
        }else{
            if (point.y != 1) {
                if (![[_drawView.combineBlockDic objectForKey:@"right"] containsObject:[_drawView stringFromLinePoint:point]]) {
                    [[_drawView.combineBlockDic objectForKey:@"right"] addObject:[_drawView stringFromLinePoint:point]];
                }
            }
        }
    }
    currentHeight = [_opFormView heightAtIndex:0];
    startY = currentHeight;
    //draw vertical lines
    for (NSInteger i = 0; i < 2; i ++) {
        startX = currentWidth;
        currentWidth += [_opFormView widthAtIndex:i];
        for (NSInteger j = 1 ; j < _opFormView.totalRows; j ++) {
            BOOL shouldDraw = YES;
            LinePoint point;
            point.x = i;
            point.y = j;
            if (_opFormView.vDelegate && [_opFormView.vDelegate respondsToSelector:@selector(shouldDrawLineInForm:Point:direction:)]) {
                shouldDraw = [_opFormView.vDelegate shouldDrawLineInForm:_opFormView Point:point direction:LineDirectionDown];
            }
            startY = currentHeight;
            currentHeight += [_opFormView heightAtIndex:j];
            if (shouldDraw) {
                CGPoint startPoint = CGPointMake(startX + _opFormView.margin, startY + _opFormView.margin + _opFormView.titleHeight);
                CGPathMoveToPoint(path, nil, startPoint.x, startPoint.y);
                CGPathAddLineToPoint(path, nil, startPoint.x, startPoint.y + [_opFormView heightAtIndex:j]);
            }else{
                if (point.x != 1) {
                    if (![[_drawView.combineBlockDic objectForKey:@"down"] containsObject:[_drawView stringFromLinePoint:point]]) {
                        [[_drawView.combineBlockDic objectForKey:@"down"] addObject:[_drawView stringFromLinePoint:point]];
                    }
                }
                
            }
            
        }
        currentHeight = [_opFormView heightAtIndex:0];
        startY = currentHeight;
    }
    
    self.lineLayer.path = path;
    [self.layer addSublayer:self.lineLayer];
    
    [_drawView calculateCombineBlock];
    //show value
    [self showValue];
}
- (void)showValue
{
    for (UIView *view in self.subviews) {
        if ([view isKindOfClass:[FormBlock class]]) {
            [view removeFromSuperview];
        }
    }
    
    CGFloat currentHeight = [_opFormView heightAtIndex:0];
    CGFloat startY = currentHeight;
    NSInteger tag = 2;
    for (NSInteger i = 1; i < _opFormView.totalRows; i ++) {
        startY = currentHeight;
        currentHeight += [_opFormView heightAtIndex:i];
        LinePoint point;
        point.x = 0;
        point.y = i;
        
        CGRect blockFrame = CGRectMake(_opFormView.margin + _opFormView.lineWidth, startY + _opFormView.lineWidth + _opFormView.margin + _opFormView.titleHeight, [_opFormView widthAtIndex:0] - 2 * _opFormView.lineWidth, [_opFormView heightAtIndex:i] - 2 * _opFormView.lineWidth);
        NSString *pointString = [_drawView stringFromLinePoint:point];
        NSArray *downKeys = [[_drawView.finalCombineBlock objectForKey:@"down"] allKeys];
        NSArray *rightKeys = [[_drawView.finalCombineBlock objectForKey:@"right"] allKeys];
        
        BOOL addBlock = YES;
        if ([downKeys containsObject:pointString] || [rightKeys containsObject:pointString]) {
            CGSize blockSize ;
            if ([downKeys containsObject:pointString]) {
                blockSize = CGSizeFromString([[[_drawView.finalCombineBlock objectForKey:@"down"] objectForKey:pointString] objectForKey:@"size"]);
            }else{
                blockSize = CGSizeFromString([[[_drawView.finalCombineBlock objectForKey:@"right"] objectForKey:pointString] objectForKey:@"size"]);
            }
            blockFrame = CGRectMake(blockFrame.origin.x, blockFrame.origin.y, blockSize.width - 2 * _opFormView.lineWidth, blockSize.height - 2 * _opFormView.lineWidth);
        }else{
            if ([[_drawView.combineBlockDic objectForKey:@"down"] containsObject:pointString] || [[_drawView.combineBlockDic objectForKey:@"right"] containsObject:pointString]) {
                tag ++;
                addBlock = NO;
            }
        }
        if (addBlock) {
            FormBlock *block = (FormBlock *)[_opFormView.vDataSource opFormView:_opFormView blockForBlockAtLinePoint:point];
            if (block) {
                block.frame = blockFrame;
                block.tag = tag;
                [self addSubview:block];
                [block setLabelFrame];
                
                UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(clickBlock:)];
                [block addGestureRecognizer:tap];
                [tap release];
            }
        }
        tag ++;
    }
    
}

- (void)clickBlock:(UITapGestureRecognizer *)tapGesture
{
    FormBlock *block = (FormBlock *)tapGesture.view;
    NSInteger tag = block.tag - 1;
    
    LinePoint point;
    point.x = 0;
    point.y = tag;
    
    [_opFormView handleClickEvents:point];
}

@end


#pragma mark - implementation FixedCommonView
@implementation FixedCommonView

@synthesize opFormView = _opFormView;
@synthesize drawView = _drawView;

- (void)dealloc
{
    [_opFormView release];
    [_drawView release];
    [super dealloc];
}

- (id)initWithFrame:(CGRect)frame opFormView:(OPFormView *)opFormView drawView:(DrawView *)drawView
{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor whiteColor];
        self.opFormView = opFormView;
        self.drawView = drawView;
        [self drawForm];
    }
    return self;
}

- (void)drawForm
{
    
    if (self.lineLayer) {
        [self.lineLayer removeFromSuperlayer];
    }
    //draw
    self.lineLayer = [CAShapeLayer layer];
    self.lineLayer.frame = self.bounds;
    self.lineLayer.lineWidth = _opFormView.lineWidth == 0 ? 1.f : _opFormView.lineWidth;
    self.lineLayer.strokeColor = _opFormView.lineColor ? _opFormView.lineColor.CGColor : [UIColor blackColor].CGColor;
    
    CGMutablePathRef path = CGPathCreateMutable();
    
    CGFloat currentWidth = 0.f;
    CGFloat currentHeight = 0.f;
    CGFloat startX = 0.f;
    CGFloat startY = 0.f;
    //draw horizontal lines
    for (NSInteger i = 0; i < 2; i ++) {
        startY = currentHeight;
        currentHeight += [_opFormView heightAtIndex:i];
        BOOL shouldDraw = YES;
        LinePoint point;
        point.x = 0;
        point.y = i;
        if (_opFormView.vDelegate && [_opFormView.vDelegate respondsToSelector:@selector(shouldDrawLineInForm:Point:direction:)]) {
            shouldDraw = [_opFormView.vDelegate shouldDrawLineInForm:_opFormView Point:point direction:LineDirectionRight];
        }
        if (shouldDraw) {
            CGPoint startPoint = CGPointMake(_opFormView.margin, startY);
            CGPathMoveToPoint(path, nil, startPoint.x, startPoint.y);
            CGPathAddLineToPoint(path, nil, startPoint.x + [_opFormView widthAtIndex:0], startPoint.y);
        }else{
            if (point.y != 1) {
                if (![[_drawView.combineBlockDic objectForKey:@"right"] containsObject:[_drawView stringFromLinePoint:point]]) {
                    [[_drawView.combineBlockDic objectForKey:@"right"] addObject:[_drawView stringFromLinePoint:point]];
                }
            }
            
        }
    }
    //draw vertical lines
    for (NSInteger i = 0; i < 2; i ++) {
        startX = currentWidth;
        currentWidth += [_opFormView widthAtIndex:i];
        BOOL shouldDraw = YES;
        LinePoint point;
        point.x = i;
        point.y = 0;
        if (_opFormView.vDelegate && [_opFormView.vDelegate respondsToSelector:@selector(shouldDrawLineInForm:Point:direction:)]) {
            shouldDraw = [_opFormView.vDelegate shouldDrawLineInForm:_opFormView Point:point direction:LineDirectionDown];
        }
        if (shouldDraw) {
            CGPoint startPoint = CGPointMake( _opFormView.margin + startX, 0);
            CGPathMoveToPoint(path, nil, startPoint.x, startPoint.y);
            CGPathAddLineToPoint(path, nil, startPoint.x, startPoint.y + [_opFormView heightAtIndex:0]);
        }else{
            if (point.x != 1) {
                if (![[_drawView.combineBlockDic objectForKey:@"down"] containsObject:[_drawView stringFromLinePoint:point]]) {
                    [[_drawView.combineBlockDic objectForKey:@"down"] addObject:[_drawView stringFromLinePoint:point]];
                }
            }
            
        }
    }
    self.lineLayer.path = path;
    [self.layer addSublayer:self.lineLayer];
    
    [_drawView calculateCombineBlock];
    //show value
    [self showValue];
}

- (void)showValue
{
    for (UIView *view in self.subviews) {
        if ([view isKindOfClass:[FormBlock class]]) {
            [view removeFromSuperview];
        }
    }
    LinePoint point;
    point.x = 0;
    point.y = 0;
    NSString *pointString = [_drawView stringFromLinePoint:point];
    CGRect blockFrame = CGRectMake(_opFormView.margin + _opFormView.lineWidth, _opFormView.lineWidth, [_opFormView widthAtIndex:0] - 2 * _opFormView.lineWidth, [_opFormView heightAtIndex:0] - 2 * _opFormView.lineWidth);
    NSArray *downKeys = [[_drawView.finalCombineBlock objectForKey:@"down"] allKeys];
    NSArray *rightKeys = [[_drawView.finalCombineBlock objectForKey:@"right"] allKeys];
    BOOL addBlock = YES;
    if ([downKeys containsObject:pointString] || [rightKeys containsObject:pointString]) {
        CGSize blockSize ;
        if ([downKeys containsObject:pointString]) {
            blockSize = CGSizeFromString([[[_drawView.finalCombineBlock objectForKey:@"down"] objectForKey:pointString] objectForKey:@"size"]);
        }else{
            blockSize = CGSizeFromString([[[_drawView.finalCombineBlock objectForKey:@"right"] objectForKey:pointString] objectForKey:@"size"]);
        }
        blockFrame = CGRectMake(blockFrame.origin.x, blockFrame.origin.y, blockSize.width - 2 * _opFormView.lineWidth, blockSize.height - 2 * _opFormView.lineWidth);
    }else{
        if ([[_drawView.combineBlockDic objectForKey:@"down"] containsObject:pointString] || [[_drawView.combineBlockDic objectForKey:@"right"] containsObject:pointString]) {
            addBlock = NO;
        }
    }
    if (addBlock) {
        FormBlock *block = (FormBlock *)[_opFormView.vDataSource opFormView:_opFormView blockForBlockAtLinePoint:point];
        if (block) {
            block.frame = blockFrame;
            block.tag = 1;
            [self addSubview:block];
            [block setLabelFrame];
            
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(clickBlock:)];
            [block addGestureRecognizer:tap];
            [tap release];
        }
    }
}

- (void)clickBlock:(UITapGestureRecognizer *)tapGesture
{
    LinePoint point;
    point.x = 0;
    point.y = 0;
    
    [_opFormView handleClickEvents:point];
}

@end
