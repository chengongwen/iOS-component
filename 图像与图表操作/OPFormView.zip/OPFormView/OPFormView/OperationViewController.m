//
//  OperationViewController.m
//  OPFormView
//
//  Created by pantianxiang on 15/6/4.
//  Copyright (c) 2015年 元善科技. All rights reserved.
//

#import "OperationViewController.h"


@interface OperationViewController ()
@property (retain, nonatomic) OPFormView *opFormView;
@property (assign, nonatomic) NSInteger testRows;
@property (assign, nonatomic) NSInteger testLines;
@property (assign, nonatomic) NSInteger totalBlock;
@end

@implementation OperationViewController
@synthesize opFormView = _opFormView;

- (void)dealloc
{
    [_opFormView release];
    [super dealloc];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        _testRows = 20;
        _testLines = 20;
        self.totalBlock = 0;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = YES;
    self.view.backgroundColor = [UIColor whiteColor];
    
    OPFormView *opFormView = [[OPFormView alloc]initWithFrame:CGRectMake(20, 40.f, self.view.frame.size.width -40, self.view.frame.size.height - 60.f) opFormViewDataSource:self opFormViewDataSource:self];
    opFormView.lineWidth = 1.f;
    opFormView.lineColor = [UIColor blackColor];
    [self.view addSubview:opFormView];
    self.opFormView = opFormView;
    [opFormView release];
    
    //    [self performSelector:@selector(reload) withObject:self afterDelay:1]; //刷新表格
}

- (void)reload
{
    _testRows = 9;
    _testLines = 6;
    [_opFormView reloadData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - OPFormViewDelegate,OPFormViewDataSource
//表格总列数
- (NSInteger)numberOfLinesInForm:(OPFormView *)formView
{
    return _testLines;
}

//表格总行数
- (NSInteger)numberOfRowsInForm:(OPFormView *)formView
{
    return _testRows;
}

//子块中显示内容
- (FormBlock *)opFormView:(OPFormView *)formView blockForBlockAtLinePoint:(LinePoint)point
{
    FormBlock *block = [[[FormBlock alloc]init] autorelease];
    block.titleLabel.text = [NSString stringWithFormat:@"(%ld,%ld)",point.x,point.y];
    return block;
}

//返回列宽
- (CGFloat)opFormView:(OPFormView *)formView widthForLineAtIndex:(NSInteger)lineIndex
{
    
    //    if (lineIndex == 0) {
    //        return 100.f;
    //    }
    //    if (lineIndex == 1) {
    //        return 20.f;
    //    }
    //    if (lineIndex == 2) {
    //        return 120.f;
    //    }
    //    if (lineIndex == 3) {
    //        return 120.f;
    //    }
    return 44.f;
}

//返回行高
- (CGFloat)opFormView:(OPFormView *)formView heightForRowAtIndex:(NSInteger)rowIndex
{
    //    if (rowIndex == 3) {
    //        return 20.f;
    //    }
    //    if (rowIndex == 4) {
    //        return 100.f;
    //    }
    //
    //    if (rowIndex == 6) {
    //        return 20.f;
    //    }
    //    if (rowIndex == 7) {
    //        return 100.f;
    //    }
    
    return 44.f;
}

//自定义表格标题视图
//- (UIView *)viewForTitleInForm:(OPFormView *)formView
//{
//    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, _testLines * 44.f, 80)];
//    view.backgroundColor = [UIColor greenColor];
//    return [view autorelease];
//}


//表格标题高度
//- (CGFloat)heightForTitleInForm:(OPFormView *)formView
//{
//    return 60.f;
//}

//表格标题
//- (NSString *)titleInForm:(OPFormView *)formView
//{
//    return @"OPFormView";
//}

//是否禁止画某条线
- (BOOL)shouldDrawLineInForm:(OPFormView *)formView Point:(LinePoint)point direction:(LineDirection)direction
{
    //    if (point.x == 2 && point.y == 0 && direction == LineDirectionDown) {
    //        return NO;
    //    }
    //    if (point.x == 5 && point.y == 1 && direction == LineDirectionDown) {
    //        return NO;
    //    }
    //
    //    if (point.x == 5 && point.y == 9 && direction == LineDirectionDown) {
    //        return NO;
    //    }
    //
    //    if (point.x == 5 && point.y == 12 && direction == LineDirectionDown) {
    //        return NO;
    //    }
    //
    //    if (point.x == 5 && point.y == 13 && direction == LineDirectionDown) {
    //        return NO;
    //    }
    //
    //    if (point.x == 4 && point.y == 13 && direction == LineDirectionDown) {
    //        return NO;
    //    }
    //
    //    if (point.x == 5 && point.y == 4 && direction == LineDirectionRight) {
    //        return NO;
    //    }
    //
    //    if (point.x == 1 && point.y == 3 && direction == LineDirectionRight) {
    //        return NO;
    //    }
    //    if (point.x == 6 && point.y == 4 && direction == LineDirectionRight) {
    //        return NO;
    //    }
    //
    //    if (point.x == 6 && point.y == 5 && direction == LineDirectionRight) {
    //        return NO;
    //    }
    //
    //    if (point.x == 0 && point.y == 9 && direction == LineDirectionRight) {
    //        return NO;
    //    }
    //
    //    if (point.x == 2 && point.y == 10 && direction == LineDirectionRight) {
    //        return NO;
    //    }
    return YES;
}

//是否接受点击子块事件
- (BOOL)opFormView:(OPFormView *)formView canEditBlockAtLinePoint:(LinePoint)point
{
    if (point.x == 4 && point.y == 3) {
        return NO;
    }
    return YES;
}

//接受点击子块响应
- (void)opFormView:(OPFormView *)formView didSelectblockAtLinePoint:(LinePoint)point
{
    NSLog(@"选择了---%ld,%ld",point.x,point.y);
}

@end
