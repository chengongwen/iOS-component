//
//  ViewController.m
//  SDCycleScrollView
//
//  Created by aier on 15-3-22.
//  Copyright (c) 2015年 GSD. All rights reserved.
//

#import "ViewController.h"
#import "SDCycleScrollView.h"

@interface ViewController () <SDCycleScrollViewDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:0.98 green:0.98 blue:0.98 alpha:0.99];
    NSArray *images = @[[UIImage imageNamed:@"h1.jpg"],
                        [UIImage imageNamed:@"h2.jpg"],
                        [UIImage imageNamed:@"h3.jpg"],
                        [UIImage imageNamed:@"h4.jpg"]
                        ];
    
    NSArray *titles = @[@"感谢您的支持，如果下载的-1",
                        @"如果代码在使用过程中出现问题-2",
                        @"您可以发邮件到gsdios@126.com感谢您的支持-3",
                        @"感谢您的支持-4"
                        ];
    
    CGFloat w = self.view.bounds.size.width;
    
    // 创建不带标题的图片轮播器
    SDCycleScrollView *cycleScrollView = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 60, w, 180) imagesGroup:images];
    cycleScrollView.delegate = self;
//    cycleScrollView.autoScrollTimeInterval = 2.0;
    [self.view addSubview:cycleScrollView];
    
    
    // 创建带标题的图片轮播器
    SDCycleScrollView *cycleScrollView2 = [SDCycleScrollView cycleScrollViewWithFrame:CGRectMake(0, 280, w, 180) imagesGroup:images];
    cycleScrollView2.pageControlAliment = SDCycleScrollViewPageContolAlimentRight;
    cycleScrollView2.delegate = self;
    cycleScrollView2.autoScrollTimeInterval = 2.0;
    cycleScrollView2.titlesGroup = titles;
    [self.view addSubview:cycleScrollView2];
}

#pragma mark - SDCycleScrollViewDelegate

- (void)cycleScrollView:(SDCycleScrollView *)cycleScrollView didSelectItemAtIndex:(NSInteger)index
{
    UIImage *image = cycleScrollView.imagesGroup[index];
    NSLog(@"---点击了第%ld张图片, %@", index,image);
}

@end
