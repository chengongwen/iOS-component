//
//  CalendarMonth.h
//  Calendar
//
//  Created by Lloyd Bottomley on 29/04/10.
//  Copyright 2010 Savage Media Pty Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CalendarViewDelegate.h"

@class CalendarLogic;

@interface CalendarMonth : UIView {
	CalendarLogic *calendarLogic;
	NSArray *datesIndex;
	NSArray *buttonsIndex;
	
	NSInteger numberOfDaysInWeek;
	NSInteger selectedButton;
	NSDate *selectedDate;
}
@property (nonatomic, retain) CalendarLogic *calendarLogic;
@property (nonatomic, retain) NSArray *datesIndex;
@property (nonatomic, retain) NSArray *buttonsIndex;

@property (nonatomic) NSInteger numberOfDaysInWeek;
@property (nonatomic) NSInteger selectedButton;
@property (nonatomic, retain) NSDate *selectedDate;
@property (assign,nonatomic)UIButton * currentButton;

@property (assign,nonatomic)float calendarDayWidth;
@property (assign,nonatomic)float calendarDayheight;
@property (retain,nonatomic)UIFont * font;
@property (copy ,nonatomic)NSArray * todoList;

@property (assign,nonatomic) id<CalendarViewDelegate>delegate;

/*
 初始化月份视图，frame确定初始化位置，根据传入button宽高确定视图大小。
 */
- (id)initWithFrame:(CGRect)frame logic:(CalendarLogic *)aLogic dayButtonWidth:(float)width dayButtonHeight:(float)height font:(UIFont *)font;

- (void)selectButtonForDate:(NSDate *)aDate;

/*
 加载视图及标记
 */
-(id)showCalendarAndMarkDownButton;
/*
 刷新button状态
 */
-(void)refreshButton;
@end
