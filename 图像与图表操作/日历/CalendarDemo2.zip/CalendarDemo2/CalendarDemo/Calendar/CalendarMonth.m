//
//  CalendarMonth.m
//  Calendar
//
//  Created by Lloyd Bottomley on 29/04/10.
//  Copyright 2010 Savage Media Pty Ltd. All rights reserved.
//

#import "CalendarMonth.h"
#import "CalendarLogic.h"
#import "CalendarDayButton.h"

#define kCalendarDayWidth	[self calendarDayWidth]
#define kCalendarDayHeight	[self calendarDayheight]
#define kNumberOfWeeks 5

@implementation CalendarMonth


#pragma mark -
#pragma mark Getters / setters

@synthesize calendarLogic;
@synthesize datesIndex;
@synthesize buttonsIndex;

@synthesize numberOfDaysInWeek;
@synthesize selectedButton;
@synthesize selectedDate;

#pragma mark -
#pragma mark Memory management

- (void)dealloc {

    [_font release];
    [_todoList release];
    
    [self.calendarLogic release];
	[self.datesIndex release];
	[self.buttonsIndex release];
	[self.selectedDate release];
    [super dealloc];
}


#pragma mark -
#pragma mark Initialization

// Calendar object init
- (id)initWithFrame:(CGRect)frame logic:(CalendarLogic *)aLogic dayButtonWidth:(float)width dayButtonHeight:(float)height font:(UIFont *)font{

    self.calendarDayWidth = width;
    self.calendarDayheight = height;
    
	// Size is static
	NSInteger numberOfWeeks = 5;
	frame.size.width = 7*kCalendarDayWidth;
	frame.size.height = ((numberOfWeeks + 1) * kCalendarDayHeight) + 60;
	selectedButton = -1;
	
    if ((self = [super initWithFrame:frame])) {
        
//        self.backgroundColor = RGB(223, 223, 229);
		self.backgroundColor = [UIColor clearColor];
        // Red should show up fails.
		self.opaque = YES;
		self.clipsToBounds = NO;
		self.clearsContextBeforeDrawing = NO;
		
		NSDateFormatter *formatter = [[[NSDateFormatter alloc] init] autorelease];
        formatter.locale = [[NSLocale alloc] initWithLocaleIdentifier:@"zh_CN"];
		NSArray *daySymbols = [formatter shortWeekdaySymbols];
		self.numberOfDaysInWeek = [daySymbols count];
        self.font = font;
		self.calendarLogic = aLogic;
    }
    return self;
}


- (void)changeButtonState:(id)sender
{
    CalendarDayButton * button = sender;

    if (self.currentButton ==nil) {
        self.currentButton = button;
        button.selected = YES;
    }
    if (self.currentButton!=button) {
        self.currentButton.selected = NO;
        button.selected = YES;
    }
    self.currentButton = button;
}

#pragma mark -
#pragma mark update the calendar
- (id)showCalendarAndMarkDownButton
{
    // 显示年月份
    NSDateFormatter *formatter = [[[NSDateFormatter alloc] init] autorelease];
    formatter.locale = [[NSLocale alloc] initWithLocaleIdentifier:@"zh_CN"];
    NSArray *daySymbols = [formatter shortWeekdaySymbols];
    self.numberOfDaysInWeek = [daySymbols count];
    NSCalendar * calendar = [NSCalendar currentCalendar];

//    // 今天按钮
//    UIButton *btnToday = [UIButton buttonWithType:UIButtonTypeCustom];
//    [btnToday setTitle:@"今" forState:UIControlStateNormal];
//    [btnToday setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
//    btnToday.frame = CGRectMake(CGRectGetWidth(self.frame)-100, 0, 60, 40);
//    //    btnToday.imageEdgeInsets = UIEdgeInsetsMake(0, 20, 20, 0);
//    //    [btnToday setImage:[UIImage imageNamed:@"CalendarArrowRight.png"] forState:UIControlStateNormal];
//    [btnToday addTarget:self.calendarLogic
//                 action:@selector(turnBackToday)
//       forControlEvents:UIControlEventTouchUpInside];
//    btnToday.hidden = YES;
//    [self addSubview:btnToday];
    
    UIColor * color = [UIColor colorWithRed:213/255.0f green:213/255.0f blue:212/255.0f alpha:1];
    
    // Setup weekday names
    
    NSDateComponents *components = [calendar components:(NSDayCalendarUnit | NSMonthCalendarUnit | NSYearCalendarUnit) fromDate:[NSDate date]];
    NSDate *todayDate = [calendar dateFromComponents:components];
    
    // Build calendar buttons (6 weeks of 7 days)
    NSMutableArray *aDatesIndex = [[[NSMutableArray alloc] init] autorelease];
    NSMutableArray *aButtonsIndex = [[[NSMutableArray alloc] init] autorelease];
    
    NSInteger numberOfWeekInMonth = 0;
    
    for (NSInteger aWeek = 0; aWeek <= kNumberOfWeeks; aWeek ++) {
//        CGFloat positionY = (aWeek * kCalendarDayHeight) + 60;
         CGFloat positionY = (aWeek * kCalendarDayHeight);
        
        for (NSInteger aWeekday = 1; aWeekday <= numberOfDaysInWeek; aWeekday ++) {
            CGFloat positionX = ((aWeekday - 1) * kCalendarDayWidth) - 1;
            CGRect dayFrame = CGRectMake(positionX, positionY, kCalendarDayWidth, kCalendarDayHeight);
            NSDate *dayDate = [CalendarLogic dateForWeekday:aWeekday
                                                     onWeek:aWeek
                                              referenceDate:[calendarLogic referenceDate]];
            
            UIColor *titleColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"CalendarTitleColor.png"]];
            
            if ([calendarLogic distanceOfDateFromCurrentMonth:dayDate] != 0) {
                titleColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"CalendarTitleDimColor.png"]];
            }
            
            /****** 判断连续一周不是本月，是否要显示坐标 ******/
            NSDate *dayDate1 = [CalendarLogic dateForWeekday:1
                                                      onWeek:aWeek
                                               referenceDate:[self.calendarLogic referenceDate]];
            
            NSDate *dayDate2 = [CalendarLogic dateForWeekday:numberOfDaysInWeek
                                                      onWeek:aWeek
                                               referenceDate:[self.calendarLogic referenceDate]];
            
            if ([self.calendarLogic distanceOfDateFromCurrentMonth:dayDate]  != 0 &&
                [self.calendarLogic distanceOfDateFromCurrentMonth:dayDate1] != 0 &&
                [self.calendarLogic distanceOfDateFromCurrentMonth:dayDate2] != 0) {
                
                // 如果连续一周不是本月，不显示坐标
                numberOfWeekInMonth ++;
            }
            else
            {
                // 显示坐标
                 CalendarDayButton * dayButton = [[CalendarDayButton alloc]initWithDate:dayDate color:titleColor font:_font];
                dayButton.opaque = YES;
                dayButton.clipsToBounds = NO;
                dayButton.clearsContextBeforeDrawing = NO;
                dayButton.frame = dayFrame;
                dayButton.tag = [aDatesIndex count];
                dayButton.adjustsImageWhenHighlighted = NO;
                dayButton.adjustsImageWhenDisabled = NO;
                dayButton.showsTouchWhenHighlighted = YES;
                
                // Normal
                dayButton.layer.borderColor = color.CGColor;
                dayButton.layer.borderWidth = 0.8;
                
                if ([dayDate compare:todayDate] != NSOrderedSame) {
                    // Normal
                    [dayButton setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"CalendarDayTitle"]]];
                }
                else {
                    [dayButton setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"CalendarDayToday"]]];
                }
                
//                /*** 隐藏今天按钮 ***/
//                NSDate *beforeDayDate = [CalendarLogic dateForWeekday:aWeekday-1
//                                                               onWeek:aWeek
//                                                        referenceDate:[self.calendarLogic referenceDate]];
//                
//                if ([self.calendarLogic distanceOfDateFromCurrentMonth:beforeDayDate] != 0 &&
//                    [self.calendarLogic distanceOfDateFromCurrentMonth:todayDate]     != 0 &&
//                    [self.calendarLogic distanceOfDateFromCurrentMonth:dayDate] == 0)
//                {
//                    //
//                    btnToday.hidden = NO;
////                    [self dayButtonPressed:dayButton];
//                }
//                /*** 隐藏本月的今天按钮 ***/
                
                [dayButton addTarget:self action:@selector(dayButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
                [self addSubview:dayButton];
                
                // Save
                [aDatesIndex addObject:dayDate];
                [aButtonsIndex addObject:dayButton];
                [dayButton release];
            }
        }
    }
    self.datesIndex = [[aDatesIndex copy] autorelease];
    self.buttonsIndex = [[aButtonsIndex copy] autorelease];
    
    // 计算不在本月的周数
    NSInteger numberOfWeekInMonthCount = numberOfWeekInMonth/7;
    
    CGRect frame1 = self.frame;
    frame1.size.height = frame1.size.height - kCalendarDayHeight*numberOfWeekInMonthCount;
    self.frame = frame1;
    
    [self refreshButton];
        
    return nil;
}

// 刷新按钮响应事件
- (void)refreshButton
{
    dispatch_queue_t getlistQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_async(getlistQueue, ^{
        
        [self getDayButtonTodoList]; // 异步加载请求数据
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [self updateButton]; // 刷新按钮事件
        });
    });
}

// 加载datesIndex数组的所有事件
- (void)getDayButtonTodoList
{
    /*
    NSDate * beginDate = [self.datesIndex objectAtIndex:0];
    NSDate * endDate = [self.datesIndex lastObject];
    NSCalendar * calendar = [NSCalendar currentCalendar];
    NSDateComponents * beginComponents = [calendar components:NSDayCalendarUnit|NSMonthCalendarUnit|NSYearCalendarUnit fromDate:beginDate];
    NSDateComponents * endComponents = [calendar components:NSDayCalendarUnit|NSMonthCalendarUnit|NSYearCalendarUnit fromDate:endDate];
    
    self.todoList = [[delegate homeService]getAgenda:beginComponents.year endYear:endComponents.year begMonth:beginComponents.month endMonth:endComponents.month begDay:beginComponents.day endDay:endComponents.day splitFlag:YES];
     */
}

// 刷新按钮事件
- (void)updateButton
{
    for (CalendarDayButton * dayButton in self.buttonsIndex) {
        [dayButton.dayTodoList removeAllObjects];
        [dayButton.currentMonthTodoList removeAllObjects];
        dayButton.shouldMark = YES;
    }
    
    /* 给所有按钮赋值相应todoList事件
    for (CalendarDTO * dto in self.todoList) {
        NSInteger index = [self.calendarLogic indexOfCalendarDate:dto.flagDate];
        CalendarDayButton * button = [self.buttonsIndex objectAtIndex:index];
        NSCalendar * calendar = [NSCalendar currentCalendar];

        NSDateComponents * dtoComponents = [calendar components:NSDayCalendarUnit|NSMonthCalendarUnit|NSYearCalendarUnit fromDate:dto.flagDate];
        NSDateComponents * buttonComponents = [calendar components:NSDayCalendarUnit|NSMonthCalendarUnit|NSYearCalendarUnit fromDate:button.date];
        
        if (dtoComponents.month ==buttonComponents.month) {
            // mark down
            [button.dayTodoList addObject:dto];
            [button.currentMonthTodoList addObject:dto];
            button.shouldMark = YES;
        }
        else
        {
            for (CalendarDayButton * dayButton in self.buttonsIndex) {
                NSDateComponents * dayButtonComponents = [calendar components:NSMonthCalendarUnit|NSDayCalendarUnit fromDate:dayButton.date];
                if (dayButtonComponents.month ==dtoComponents.month &&dayButtonComponents.day ==dtoComponents.day) {
                    //mark down
                    [dayButton.dayTodoList addObject:dto];
                    dayButton.shouldMark = YES;
                    break;
                }
            }
        }
    }
    */
}

#pragma mark -
#pragma mark UI Controls
- (void)titlePressed:(id)sender
{
    
}

// 响应单击按钮事件
- (void)dayButtonPressed:(id)sender
{
    CalendarDayButton * button = sender;
    NSDate * date = [datesIndex objectAtIndex:[button tag]];
    
    //计算是否本月，可设置是否响应该button
    NSInteger distance = [calendarLogic distanceOfDateFromCurrentMonth:date];
    if (distance != 0)
    {
         // return; // 不是本月日期，不响应按钮事件发生
    }
    
    //  CalendarViewDelegate
    if (self.delegate && [self.delegate respondsToSelector:@selector(showScheduleWithArray:)]) {
        
        [self.delegate showScheduleWithArray:button.dayTodoList];
    }
    
    // 响应按钮事件1
    [self changeButtonState:sender];
    
    // 响应按钮事件2
	[calendarLogic setReferenceDate:date];
}

- (void)selectButtonForDate:(NSDate *)aDate
{
	if (selectedButton >= 0) {
		NSDate *todayDate = [CalendarLogic dateForToday];
		UIButton *button = [buttonsIndex objectAtIndex:selectedButton];
		
		CGRect selectedFrame = button.frame;
		if ([selectedDate compare:todayDate] != NSOrderedSame) {
			selectedFrame.origin.y = selectedFrame.origin.y + 1;
			selectedFrame.size.width = kCalendarDayWidth;
			selectedFrame.size.height = kCalendarDayHeight;
		}
		
		button.selected = NO;
		button.frame = selectedFrame;
		
		self.selectedButton = -1;
		self.selectedDate = nil;
	}
	
	if (aDate != nil) {
		// Save
		self.selectedButton = [calendarLogic indexOfCalendarDate:aDate];
		self.selectedDate = aDate;
        
		NSDate *todayDate = [CalendarLogic dateForToday];
		UIButton *button = [buttonsIndex objectAtIndex:selectedButton];
		
		CGRect selectedFrame = button.frame;
		if ([aDate compare:todayDate] != NSOrderedSame) {
			selectedFrame.origin.y = selectedFrame.origin.y - 1;
			selectedFrame.size.width = kCalendarDayWidth + 1;
			selectedFrame.size.height = kCalendarDayHeight + 1;
		}
		
		button.selected = YES;
		button.frame = selectedFrame;
		[self bringSubviewToFront:button];	
	}
}

@end
