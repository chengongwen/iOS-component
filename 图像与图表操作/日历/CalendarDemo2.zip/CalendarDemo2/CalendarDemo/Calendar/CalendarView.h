//
//  CalendarView.h
//  CalendarDemo
//
//  Created by chengongwen on 15/11/8.
//  Copyright © 2015年 元善科技. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CalendarLogicDelegate.h"
#import "CalendarLogic.h"
#import "CalendarMonth.h"
#import "CalendarDayButton.h"
#import "CalendarViewDelegate.h"


@interface CalendarView : UIView <CalendarLogicDelegate,UIGestureRecognizerDelegate>

@property (nonatomic, retain) CalendarLogic *calendarLogic;
@property (nonatomic, retain) CalendarMonth *calendarView;
@property (nonatomic, retain) CalendarMonth *calendarViewNew;
@property (nonatomic, retain) NSDate *selectedDate;

@property (nonatomic, retain) UIScrollView * scrollView;
@property (nonatomic, assign) BOOL isUpdatingCalendar; // 是否正在加载日历视图

@property (nonatomic, assign) CGFloat width;
@property (nonatomic, assign) CGFloat height;
@property (nonatomic, assign) UIFont *font;
@property (nonatomic, retain) UILabel * titleLabel;
@property (nonatomic, retain) UIButton *todayButton;

@property (assign,nonatomic) id<CalendarViewDelegate>delegate;

/*
 初始化月份视图，frame确定初始化位置，根据传入button宽高确定视图大小。
 */
- (id)initWithFrame:(CGRect)frame dayButtonWidth:(float)width dayButtonHeight:(float)height font:(UIFont *)font;

- (void)updateCalendarView;

@end
