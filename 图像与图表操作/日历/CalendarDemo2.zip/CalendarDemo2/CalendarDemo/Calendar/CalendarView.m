//
//  CalendarView.m
//  CalendarDemo
//
//  Created by chengongwen on 15/11/8.
//  Copyright © 2015年 元善科技. All rights reserved.
//

#import "CalendarView.h"

@implementation CalendarView
@synthesize calendarLogic = _calendarLogic;
@synthesize calendarView = _calendarView;
@synthesize calendarViewNew = _calendarViewNew;
@synthesize selectedDate = _selectedDate;
@synthesize scrollView = _scrollView;

#pragma mark -
#pragma mark Memory management
- (void)dealloc
{
    [_todayButton release];
    [_titleLabel release];
    [_scrollView release];
    [_calendarLogic release];
    [_calendarView release];
    [_calendarViewNew release];
    [_selectedDate release];
    [super dealloc];
}

#pragma mark -
#pragma mark Initialization
- (id)initWithFrame:(CGRect)frame dayButtonWidth:(float)width dayButtonHeight:(float)height font:(UIFont *)font {
    
    if ((self = [super initWithFrame:frame])) {
        
        self.isUpdatingCalendar = NO;
        
        self.width = width;
        self.height = height;
        self.font = font;
        
        CGRect aFrame = frame;
        aFrame.origin.x = 0;
        aFrame.origin.y = 0;
        
        // 初始化scrollView
        UIScrollView * scrollView = [[UIScrollView alloc]initWithFrame:aFrame];
        scrollView.backgroundColor = [UIColor greenColor];
        [self addSubview:scrollView];
        self.scrollView = scrollView;
        [scrollView release];
        
        NSDate *aDate = self.selectedDate;
        if (aDate == nil) {
            aDate = [CalendarLogic dateForToday];
        }
        NSDateComponents *components = [[[NSDateComponents alloc] init] autorelease];
        aDate = [[[NSCalendar currentCalendar] dateByAddingComponents:components toDate:aDate options:0] retain];
        
        // 初始化代理类
        CalendarLogic *calendarLogic = [[CalendarLogic alloc] initWithDelegate:self referenceDate:aDate];
        self.calendarLogic = calendarLogic;
        
        NSDateFormatter *formatter = [[[NSDateFormatter alloc] init] autorelease];
        formatter.locale = [[NSLocale alloc] initWithLocaleIdentifier:@"zh_CN"];
        UILabel *titleLabel = [[[UILabel alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.bounds), 40)] autorelease];
        titleLabel.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"CalendarBackground"]];
        titleLabel.textAlignment = NSTextAlignmentCenter;
        titleLabel.font = [UIFont boldSystemFontOfSize:20];
        titleLabel.textColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"CalendarTitleColor.png"]];
        titleLabel.shadowColor = [UIColor whiteColor];
        titleLabel.shadowOffset = CGSizeMake(0, 1);
        //    [formatter setDateFormat:@"MMMM yyyy"];
        [formatter setDateFormat:@"yyyy年 MMM"];
        titleLabel.text = [formatter stringFromDate:calendarLogic.referenceDate];
        self.titleLabel = titleLabel;
        [self addSubview:titleLabel];
        [titleLabel release];
        
        // 今天按钮
        UIButton *btnToday = [UIButton buttonWithType:UIButtonTypeCustom];
        [btnToday setTitle:@"今" forState:UIControlStateNormal];
        [btnToday setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        btnToday.frame = CGRectMake(CGRectGetWidth(self.frame)-100, 0, 60, 40);
        //    btnToday.imageEdgeInsets = UIEdgeInsetsMake(0, 20, 20, 0);
        //    [btnToday setImage:[UIImage imageNamed:@"CalendarArrowRight.png"] forState:UIControlStateNormal];
        self.todayButton = btnToday;
        [btnToday addTarget:self.calendarLogic
                     action:@selector(turnBackToday)
           forControlEvents:UIControlEventTouchUpInside];
//        btnToday.hidden = YES;
        [self addSubview:btnToday];
    
        // 显示左右按钮
        UIButton *aLeftButton = [UIButton buttonWithType:UIButtonTypeCustom];
        aLeftButton.frame = CGRectMake(0, 0, 60, 60);
        aLeftButton.imageEdgeInsets = UIEdgeInsetsMake(0, 0, 20, 20);
        [aLeftButton setImage:[UIImage imageNamed:@"CalendarArrowLeft.png"] forState:UIControlStateNormal];
        [aLeftButton addTarget:self.calendarLogic
                        action:@selector(selectPreviousMonth)
              forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:aLeftButton];
        
        UIButton *aRightButton = [UIButton buttonWithType:UIButtonTypeCustom];
        aRightButton.frame = CGRectMake(CGRectGetWidth(self.frame)-60, 0, 60, 60);
        aRightButton.imageEdgeInsets = UIEdgeInsetsMake(0, 20, 20, 0);
        [aRightButton setImage:[UIImage imageNamed:@"CalendarArrowRight.png"] forState:UIControlStateNormal];
        [aRightButton addTarget:self.calendarLogic
                         action:@selector(selectNextMonth)
               forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:aRightButton];
        
        NSArray *daySymbols = [formatter shortWeekdaySymbols];
        NSInteger numberOfDaysInWeek = [daySymbols count];
        NSCalendar * calendar = [NSCalendar currentCalendar];
        
        UILabel * weekNameLabel = nil;
        NSInteger firstWeekday = [calendar firstWeekday] - 1;
        for (NSInteger aWeekday = 0; aWeekday < numberOfDaysInWeek; aWeekday ++) {
            NSInteger symbolIndex = aWeekday + firstWeekday;
            if (symbolIndex >= numberOfDaysInWeek) {
                symbolIndex -= numberOfDaysInWeek;
            }
            weekNameLabel= [[[UILabel alloc] initWithFrame:CGRectZero] autorelease];
            NSString *symbol = [daySymbols objectAtIndex:symbolIndex];
            CGFloat positionX = (aWeekday * width) - 1;
            CGRect aFrame = CGRectMake(positionX, CGRectGetMaxY(titleLabel.frame), width, 20);
            weekNameLabel.frame = aFrame;
            weekNameLabel.backgroundColor = [UIColor clearColor];
            weekNameLabel.textAlignment = NSTextAlignmentCenter;
            weekNameLabel.text = symbol;
            weekNameLabel.textColor = [UIColor darkGrayColor];
            weekNameLabel.font = [UIFont systemFontOfSize:12];
            weekNameLabel.shadowColor = [UIColor whiteColor];
            weekNameLabel.shadowOffset = CGSizeMake(0, 1);
            [self addSubview:weekNameLabel];
        }
        
        aFrame.origin.y = CGRectGetMinY(weekNameLabel.frame);
        // 初始化日历
        CalendarMonth *aCalendarView = [[CalendarMonth alloc] initWithFrame:aFrame
                                                                      logic:calendarLogic
                                                             dayButtonWidth:width
                                                            dayButtonHeight:height
                                                                       font:font];
        
        [aCalendarView selectButtonForDate:self.selectedDate];
        [self.scrollView addSubview:aCalendarView];
        aCalendarView.delegate = self.delegate;
        self.calendarView = aCalendarView;
        [aCalendarView release];
        [calendarLogic release];
        
        // 显示日历标记按钮
        [self.calendarView showCalendarAndMarkDownButton];
                
        // 添加左右手势进行滑动，切换日历视图
        UISwipeGestureRecognizer *swipeLeftGesture=[[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(updateCalendar:)];
        swipeLeftGesture.direction=UISwipeGestureRecognizerDirectionLeft;
        [self addGestureRecognizer:swipeLeftGesture];
        UISwipeGestureRecognizer *swipeRightGesture=[[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(updateCalendar:)];
        swipeRightGesture.direction=UISwipeGestureRecognizerDirectionRight;
        [self addGestureRecognizer:swipeRightGesture];
        [swipeLeftGesture release];
        [swipeRightGesture release];
    }
    
    return self;
}

#pragma mark -
#pragma mark - UIGestureRecognizer delegate
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch;
{
    CGPoint currentPoint = [gestureRecognizer locationInView:self];
    if (CGRectContainsPoint(self.frame, currentPoint) ) {
        return YES;
    }
    
    return NO;
}

- (void)updateCalendar:(UIGestureRecognizer *)recognizer
{
    if ([recognizer isKindOfClass:[UISwipeGestureRecognizer class]])
    {
        UISwipeGestureRecognizer *swipeGesture=(UISwipeGestureRecognizer *)recognizer;
        if (swipeGesture.direction == UISwipeGestureRecognizerDirectionLeft && !self.isUpdatingCalendar)
        {
            // 左滑动
            [self.calendarLogic performSelector:@selector(selectNextMonth) withObject:nil afterDelay:0];
        }
        if (swipeGesture.direction == UISwipeGestureRecognizerDirectionRight && !self.isUpdatingCalendar)
        {
            // 右滑动
            [self.calendarLogic performSelector:@selector(selectPreviousMonth) withObject:nil afterDelay:0];
        }
    }
}

#pragma mark -
#pragma mark - CalendarLogic delegate
- (void)calendarLogic:(CalendarLogic *)aLogic dateSelected:(NSDate *)aDate distance:(NSInteger)distance
{
    [self.selectedDate autorelease];
    self.selectedDate = [aDate retain];
    
    [self updateCalendarDateTitle:aDate];
    
    if (distance == 0) {
        
        [self.calendarView selectButtonForDate:self.selectedDate];
    }
}

- (void)calendarLogic:(CalendarLogic *)aLogic monthChangeDirection:(Direction)aDirection
{
    if (!self.isUpdatingCalendar) {
        
        CGFloat distance = CGRectGetWidth(_calendarView.frame)*aDirection;
        
        self.isUpdatingCalendar = YES;
        
        // 重新初始化日历视图
        CalendarMonth *calendarViewNew = [[CalendarMonth alloc] initWithFrame:CGRectMake(distance+2,_calendarView.frame.origin.y, 0,0)
                                                                        logic:self.calendarLogic
                                                               dayButtonWidth:self.width
                                                              dayButtonHeight:self.height
                                                                         font:self.font];
        // calendarViewNew.delegate = self;
        calendarViewNew.userInteractionEnabled = NO;
//        calendarViewNew.backgroundColor = [UIColor redColor];
        
        [calendarViewNew showCalendarAndMarkDownButton];
        
        if ([self.calendarLogic distanceOfDateFromCurrentMonth:_selectedDate] == 0) {
            
            [calendarViewNew selectButtonForDate:self.selectedDate];
        }
        
        [self.scrollView insertSubview:calendarViewNew belowSubview:self.calendarView];
        self.calendarViewNew = calendarViewNew;
        
        [UIView beginAnimations:NULL context:nil];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDidStopSelector:@selector(animationMonthSlideComplete)];
        [UIView setAnimationDuration:0.5];
        [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
        
        self.calendarView.frame = CGRectOffset(self.calendarView.frame, -distance, 0);
        calendarViewNew.frame = CGRectOffset(calendarViewNew.frame, -distance, 0);
        
        [UIView commitAnimations];
        [calendarViewNew release];
    }
}

- (void)animationMonthSlideComplete
{
    // Get rid of the old one.
    [_calendarView removeFromSuperview];
    self.calendarView = nil;
    
    // replace
    self.calendarView = _calendarViewNew;
    
    _calendarViewNew = nil;
    [_calendarViewNew removeFromSuperview];
    
    self.calendarView.userInteractionEnabled = YES;
    self.isUpdatingCalendar = NO;
    self.calendarView.delegate = self.delegate;
    
//    // 重置todoListTableView 的Y坐标
//    CGFloat y = CGRectGetMaxY(self.calendarView.frame);
//    self.todoListTableView.frame = CGRectMake(0, y+1, CGRectGetWidth(self.scrollView.frame),CGRectGetHeight(self.scrollView.frame)-y-5);
//    
    // 刷新按钮事件
    [self.calendarView refreshButton];
}

- (void)updateCalendarDateTitle:(NSDate *)aDate {
    
    NSDateFormatter *formatter = [[[NSDateFormatter alloc] init] autorelease];
    formatter.locale = [[NSLocale alloc] initWithLocaleIdentifier:@"zh_CN"];
    //    [formatter setDateFormat:@"MMMM yyyy"];
    [formatter setDateFormat:@"yyyy年 MMM"];
    self.titleLabel.text = [formatter stringFromDate:aDate];
    
    //*** 显示隐藏今天按钮 ***/
    [formatter setDateFormat:@"yyyy MM"];
    NSString *todaty = [formatter stringFromDate:[NSDate date]];
    NSString *aaDate = [formatter stringFromDate:aDate];
    if ([todaty isEqualToString:aaDate ]) {
        self.todayButton.hidden = YES;
    }
    else {
        self.todayButton.hidden = NO;
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (void)updateCalendarView {
    
    // 刷新按钮事件
    [self.calendarView refreshButton];
}

@end
