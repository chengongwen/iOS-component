//
//  UserMacroDefinition.h
//  IphoneOA
//
//  Created by Victor on 13-4-26.
//  Copyright (c) 2013年 ysservice.com. All rights reserved.
//

#ifndef IphoneOA_UserMacroDefinition_h
#define IphoneOA_UserMacroDefinition_h

#define kDeveloperAppId @"738897124" // 用developer账户登陆itunes connect创建应用时会产生一个app id

#define kSystemVersion [[[UIDevice currentDevice] systemVersion] floatValue]
#define kSystemVersionIOS7 (kSystemVersion >= 7.0?YES:NO)
#define kVersionGetY ((kSystemVersion >= 7.0)?20:0)

#define kScreenWidth [[UIScreen mainScreen] bounds].size.width
#define kScreenHeight ((kSystemVersion >= 7.0)?[[UIScreen mainScreen] bounds].size.height:[[UIScreen mainScreen] bounds].size.height-20)

#define kAppDocumentPath [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]    //获取应用Document目录路径
#define RGB(r,g,b) [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:1.0f]

/**系统皮肤定义相关宏 start **/
#define kThemeDidChangeNotification @"kThemeDidChangeNotification"
#define kThemeListFontColors @"kThemeListFontColors" //列表字体、颜色集合。
#define kThemeLoginFontColors @"kThemeLoginFontColors" //登录字体、颜色集合。
#define kThemeLoginSettingFontColors @"kThemeLoginSettingFontColors" //登录设置服务器地址字体、颜色集合。
#define kThemeButtonFontColors @"kThemeButtonFontColors" //登录字体、颜色集合。
#define kThemeBackButtonFontColors @"kThemeBackButtonFontColors" //返回按扭字体、颜色集合。
#define kThemeTitleTabButtonFontColors @"kThemeTitleTabButtonFontColors" //TAB分类按扭字体、颜色集合。
#define kThemeModelTitleFontColors @"kThemeModelTitleFontColors" //登录字体、颜色集合。
#define kThemeTableViewSeparatorColor @"kThemeTableViewSeparatorColor" //UITableView分隔线样式。
#define kThemeFormPropertyStyle @"kThemeFormPropertyStyle" //表单属性样式
#define kThemeFormValueStyle @"kThemeFormValueStyle" //表单性性值性样式
#define kThemeFormTitleStyle @"kThemeFormTitleStyle" //表单标题样式
#define kThemeFolderNameStyle @"kThemeFolderNameStyle" //文件柜名称样式
#define kThemeFileNameStyle @"kThemeFileNameStyle" //文件名称样式
#define kThemeFlowButtonStyle @"kThemeFlowButtonStyle" //流程按扭名称样式
#define kThemeRecordDateStyle @"kThemeRecordDateStyle"//随身记时间Label
#define kThemeRecordPreviewStyle @"kThemeRecordPreviewStyle"//随身记预览
#define kThemeColor @"color" //列表颜色
#define kThemeFont @"font" //列表字体
#define kThemeSize @"size" //列表字体大小
/**系统皮肤定义相关宏 end **/

/**系统动画时间定义 start **/
#define kUINavigationPushOrPopAnimationTime .5f
#define kSystemMenuSwitchAnimationTime .5f
#define kFormToggleAnimationTime .5f //表单切换动画时间
#define kHUDFadeAnimationTime 1.0f // HUD动画消失时间
/**系统动画时间定义 end **/

/**获取系统菜单视图Key值 start **/
#define kSystemMenuHomeKey @"home"
#define kSystemMenuLoginKey @"login"
/**获取系统菜单视图Key值 end **/

/**设置应用UITableViewCell的高度 start **/
#define kDocumentTableViewCellHeight 34.5f
/**设置应用UITableViewCell的高度 end **/

/**设置应用搜索框的x,Width,Height start **/
#define kSearchTextFieldX 15
#define kSearchTextFieldLeftPadding 17
#define kSearchTextFieldRightPadding 30
#define kSearchTextFieldWidth kScreenWidth-30
#define kSearchTextFieldHeight 80
/**设置应用搜索框的x,Width,Height end **/

#define kConfigFolderName @"config" //存放配置文件
#define kLogFolderName @"log" //存放日志文件
#endif
