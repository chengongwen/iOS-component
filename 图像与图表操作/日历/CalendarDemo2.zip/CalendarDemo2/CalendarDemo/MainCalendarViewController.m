//
//  MainCalendarViewController.m
//  CalendarDemo
//
//  Created by yuanshanit on 15/3/19.
//  Copyright (c) 2015年 元善科技. All rights reserved.
//

#import "MainCalendarViewController.h"
#import "CalendarView.h"

@interface MainCalendarViewController ()

@property (nonatomic, retain) CalendarView *calendarView;
@end

@implementation MainCalendarViewController
@synthesize todoList = _todoList;
@synthesize todoListTableView = _todoListTableView;
@synthesize calendarView = _calendarView;

#pragma mark -
#pragma mark Memory management

- (void)dealloc
{
    [_todoListTableView release];
    [_todoList release];
    [super dealloc];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    // 初始化日历视图
    [self initlizeCalenderView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/**
 初始化日历视图
 */
- (void)initlizeCalenderView
{
    CalendarView *aCalendarView = [[CalendarView alloc] initWithFrame:CGRectMake(0, 100, kScreenWidth,kScreenWidth)dayButtonWidth:(CGRectGetWidth(self.view.frame)-2)/7 dayButtonHeight:CGRectGetWidth(self.view.frame)/8 font:[UIFont fontWithName:@"ArialHebrew-Bold" size:11.f]];
    aCalendarView.delegate = self;
    self.calendarView = aCalendarView;
    [self.view addSubview:aCalendarView];
    [aCalendarView release];
}

- (void)updateNewCalendar {
    
    [self.calendarView updateCalendarView];
}

#pragma mark -
#pragma mark - CalendarViewDelegate delegate
- (void)showScheduleWithArray:(NSArray *)array
{
    if (array.count <= 0) {
        return;
    }
    else
    {
//        CalendarScheduleDetialView * detailView = nil;
//        NSArray * nib = [[NSBundle mainBundle]loadNibNamed:@"CalendarScheduleDetialView" owner:detailView options:nil];
//        detailView = [nib objectAtIndex:0];
//        [self.view addSubview:detailView];
//        detailView.mainViewController = self;
//        [detailView showDetailArray:array];
//        detailView.center = self.view.center;
//
//        [UIView animateWithDuration:0.2f animations:^{
//            detailView.transform = CGAffineTransformMakeScale(0.5, 0.5);
//            detailView.transform = CGAffineTransformMakeScale(1.0, 1.0);
//
//        }];
    }
}

- (void)updateCalendar {
    
}

@end
