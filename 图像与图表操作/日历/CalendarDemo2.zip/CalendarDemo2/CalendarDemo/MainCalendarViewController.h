//
//  MainCalendarViewController.h
//  CalendarDemo
//
//  Created by yuanshanit on 15/3/19.
//  Copyright (c) 2015年 元善科技. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CalendarViewDelegate.h"

@interface MainCalendarViewController : UIViewController<CalendarViewDelegate>

@property (nonatomic, copy) NSArray * todoList;
@property (nonatomic, retain) UITableView * todoListTableView;

@end
