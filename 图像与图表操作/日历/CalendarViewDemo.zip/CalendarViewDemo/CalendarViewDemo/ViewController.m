//
//  ViewController.m
//  CalendarViewDemo
//
//  Created by yuanshanit on 15/11/6.
//  Copyright © 2015年 yuanshanit. All rights reserved.
//

#import <EventKit/EventKit.h>
#import "ViewController.h"

#import "ABCalendarPicker.h"

@interface ViewController ()<ABCalendarPickerDelegateProtocol,ABCalendarPickerDataSourceProtocol>

@property (nonatomic, strong) ABCalendarPicker *calendarPicker;

@property (nonatomic) EKEventStore * store;

@property (nonatomic, strong) UITableView *eventsTable;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    UIButton *btnToday = [[UIButton alloc] initWithFrame:CGRectMake(self.view.center.x-25, 50, 50, 50)];
    [btnToday setTitle:@"today" forState:UIControlStateNormal];
    [btnToday addTarget:self action:@selector(todayClick) forControlEvents:UIControlEventTouchUpInside];
    [btnToday setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [self.view addSubview:btnToday];
    
    self.calendarPicker = [[ABCalendarPicker alloc] initWithFrame:CGRectMake(0, 100, self.view.frame.size.width, self.view.frame.size.width)];
    self.calendarPicker.delegate = self;
    self.calendarPicker.dataSource = self;
    [self calendarPicker:self.calendarPicker animateNewHeight:self.calendarPicker.bounds.size.height];
    [self.view addSubview:self.calendarPicker];
    
    self.eventsTable = [[UITableView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(self.calendarPicker.frame), self.view.frame.size.width, 100)];
    self.eventsTable.backgroundColor = [UIColor redColor];
    [self.view addSubview:self.eventsTable];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (EKEventStore *)store
{
    if (_store == nil)
    {
        _store = [[EKEventStore alloc] init];
        if ([[EKEventStore class] resolveClassMethod:@selector(authorizationStatusForEntityType:)])
        {
            if ([EKEventStore authorizationStatusForEntityType:(EKEntityTypeEvent)] != EKAuthorizationStatusAuthorized)
                [_store requestAccessToEntityType:(EKEntityTypeEvent) completion:^(BOOL granted, NSError *error) {
                    ;
                }];
        }
    }
    return _store;
}

- (NSArray *)eventsForDate:(NSDate *)date
{
    NSDateComponents * componentsBegin = [self.calendarPicker.calendar components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay fromDate:date];
    NSDateComponents * componentsDay = [[NSDateComponents alloc] init];
    componentsDay.day = 1;
    
    NSDate * dayBegin = [self.calendarPicker.calendar dateFromComponents:componentsBegin];
    NSDate * dayEnd = [self.calendarPicker.calendar dateByAddingComponents:componentsDay toDate:dayBegin options:0];
    
    NSPredicate * predicate = [self.store predicateForEventsWithStartDate:dayBegin endDate:dayEnd calendars:nil];
    return [self.store eventsMatchingPredicate:predicate];
}

- (void)todayClick {
    
    [self.calendarPicker setDate:[NSDate date] andState:ABCalendarPickerStateDays animated:YES];
}

#pragma mark -
#pragma mark - ABCalendarPicker delegate and dataSource

#pragma mark - dataSource
- (NSInteger)calendarPicker:(ABCalendarPicker*)calendarPicker
      numberOfEventsForDate:(NSDate*)date
                    onState:(ABCalendarPickerState)state
{
    if (state != ABCalendarPickerStateDays
        && state != ABCalendarPickerStateWeekdays)
    {
        return 0;
    }
    
    return [[self eventsForDate:date] count];
}


#pragma mark -  delegate
- (void)calendarPicker:(ABCalendarPicker *)calendarPicker
      animateNewHeight:(CGFloat)height
{
    
//     self.calendarShadow.frame = CGRectMake(0,CGRectGetMaxY(self.calendarPicker.frame),
//     self.calendarPicker.frame.size.width,
//     self.calendarShadow.frame.size.height);
     self.eventsTable.frame = CGRectMake(0, CGRectGetMaxY(self.calendarPicker.frame),self.eventsTable.bounds.size.width,100);
}


- (void)calendarPicker:(ABCalendarPicker *)calendarPicker
          dateSelected:(NSDate *)date
             withState:(ABCalendarPickerState)state
{
    //    [self.eventsTable reloadData];
}






@end
