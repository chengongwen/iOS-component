//
//  main.m
//  CalendarViewDemo
//
//  Created by yuanshanit on 15/11/6.
//  Copyright © 2015年 yuanshanit. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
