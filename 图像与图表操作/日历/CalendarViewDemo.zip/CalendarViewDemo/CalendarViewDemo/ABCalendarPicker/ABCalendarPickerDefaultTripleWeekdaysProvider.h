//
//  ABCalendarPickerDefaultTripleWeekdaysProvider.h
//  ABCalendarPicker
//
//  Created by Anton Bukov on 22.02.13.
//  Copyright (c) 2013 Anton Bukov. All rights reserved.
//

#import "ABCalendarPicker.h"

@interface ABCalendarPickerDefaultTripleWeekdaysProvider : ABCalendarPickerDefaultWeekdaysProvider

@end
