//
//  PerosonalCalendarDelegate.h
//  IpadCPOA
//
//  Created by VIKI on 13-8-31.
//  Copyright (c) 2013年 ysservice.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol CalendarViewDelegate <NSObject>

- (void)updateCalendar;

- (void)showScheduleWithArray:(NSArray *)array;

//- (void)popCreatScheduleView;
//- (void)popSingleScheduleViewWithDTO:(CalendarDTO *)dto;

@end
