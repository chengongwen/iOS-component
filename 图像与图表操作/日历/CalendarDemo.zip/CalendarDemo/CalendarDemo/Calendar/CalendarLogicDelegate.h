//
//  CalendarLogicDelegate.h
//  Calendar
//
//  Created by Lloyd Bottomley on 29/04/10.
//  Copyright 2010 Savage Media Pty Ltd. All rights reserved.
//

typedef enum{
    DirectionLeft = -1, // 左边
    DirectionRight = 1  // 右边
}Direction;  // 滑动方向


@class CalendarLogic;

@protocol CalendarLogicDelegate

@optional
- (void)calendarLogic:(CalendarLogic *)aLogic dateSelected:(NSDate *)aDate distance:(NSInteger)distance;

@optional
- (void)calendarLogic:(CalendarLogic *)aLogic monthChangeDirection:(Direction)aDirection;

@end
