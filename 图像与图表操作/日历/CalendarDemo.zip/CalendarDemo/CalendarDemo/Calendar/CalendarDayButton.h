//
//  CalendarDayButton.h
//  IphoneOA
//
//  Created by VIKI on 13-7-10.
//  Copyright (c) 2013年 ysservice.com. All rights reserved.
//

@interface CalendarDayButton : UIButton

@property (retain, nonatomic) NSDate * date;
@property (retain, nonatomic) UIColor * stringColor;
@property (retain, nonatomic) NSMutableArray * dayTodoList;
@property (retain, nonatomic) NSMutableArray * currentMonthTodoList;
@property (assign, nonatomic) BOOL shouldMark;
@property (retain, nonatomic) UIFont * font;

- (id)initWithDate:(NSDate *)dayDate color:(UIColor *)textColor font:(UIFont *)font;

/*
 传入事件列表，进行标记
 */
- (void)markDownButtonWithListArray:(NSArray *)eventList;

@end
