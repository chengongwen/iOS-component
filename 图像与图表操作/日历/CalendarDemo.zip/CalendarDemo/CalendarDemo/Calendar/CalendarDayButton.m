//
//  CalendarDayButton.m
//  IphoneOA
//
//  Created by VIKI on 13-7-10.
//  Copyright (c) 2013年 ysservice.com. All rights reserved.
//

#import "CalendarDayButton.h"

@implementation CalendarDayButton

@synthesize date = _date;
@synthesize shouldMark = _shouldMark;
@synthesize font = _font;

-(void)dealloc
{
    [_date release];
    [_font release];
    [_dayTodoList release];
    [_currentMonthTodoList release];
    [_stringColor release];
    [super dealloc];
}

-(id)initWithDate:(NSDate *)dayDate color:(UIColor *)textColor font:(UIFont *)font
{
    self = [super init];
    if (self) {
        NSMutableArray *tmpArr=[[NSMutableArray alloc]initWithCapacity:100];
        self.dayTodoList = tmpArr;
        NSMutableArray *arr=[[NSMutableArray alloc]initWithCapacity:100];
        self.currentMonthTodoList = arr;
        [tmpArr release];
        [arr release];
        
        self.date = dayDate;
        self.stringColor = textColor;
        self.backgroundColor = [UIColor clearColor];
        self.font = font;
        
        _shouldMark = NO;
    }
    return self;
}

- (void)drawRect:(CGRect)rect
{
    NSDateComponents * com = [[NSCalendar currentCalendar]components:NSDayCalendarUnit fromDate:self.date];
    [self.stringColor set];
    if ([self isToday]) {
        [[UIColor redColor]set];

    }
    NSString * str = [NSString stringWithFormat:@"%li\n%@",(long)com.day,[self getChineseCalendarWithDate:self.date]];
    NSInteger y = CGRectGetHeight(self.bounds)/3;
    CGRect stringRect = CGRectMake(0, y, CGRectGetWidth(self.bounds), CGRectGetHeight(self.bounds)-y);
    [str drawInRect:stringRect withFont:self.font lineBreakMode:NSLineBreakByClipping alignment:NSTextAlignmentCenter];
    [self addTarget:self action:@selector(showTodoList) forControlEvents:UIControlEventTouchUpInside];
    
    if (_shouldMark) {
       [self markDownButtonWithListArray:[NSArray arrayWithArray:_currentMonthTodoList]];
    }
}


-(void)setShouldMark:(BOOL)shouldMark
{
    _shouldMark = shouldMark;
    [self setNeedsDisplay];
}

#pragma mark ChineseDate metoh
- (NSString *)convertMonth:(NSInteger)intMonth
{
    NSArray *chineseDays=[NSArray arrayWithObjects:
                          @"初一", @"初二", @"初三", @"初四", @"初五", @"初六", @"初七", @"初八", @"初九", @"初十",
                          @"十一", @"十二", @"十三", @"十四", @"十五", @"十六", @"十七", @"十八", @"十九", @"二十",
                          @"廿一", @"廿二", @"廿三", @"廿四", @"廿五", @"廿六", @"廿七", @"廿八", @"廿九", @"三十",  nil];
    if (intMonth - 1 < 0 || intMonth > chineseDays.count) {
        return @"";
    }
    NSString *stringMonth = [chineseDays objectAtIndex:intMonth - 1];
    return stringMonth;
}

- (NSString*)getChineseCalendarWithDate:(NSDate *)date
{
    NSArray *chineseDays=[NSArray arrayWithObjects:
                          @"初一", @"初二", @"初三", @"初四", @"初五", @"初六", @"初七", @"初八", @"初九", @"初十",
                          @"十一", @"十二", @"十三", @"十四", @"十五", @"十六", @"十七", @"十八", @"十九", @"二十",
                          @"廿一", @"廿二", @"廿三", @"廿四", @"廿五", @"廿六", @"廿七", @"廿八", @"廿九", @"三十",  nil];
    
    NSCalendar *localeCalendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSChineseCalendar];
    
    unsigned unitFlags = NSDayCalendarUnit;
    
    NSDateComponents *localeComp = [localeCalendar components:unitFlags fromDate:date];
    
    NSString *d_str = [chineseDays objectAtIndex:localeComp.day-1];
    
    [localeCalendar release];
    
    return d_str;
}


#pragma mark button state
- (void)setSelected:(BOOL)selected
{
    if (selected) {
        self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"CalendarDaySelected"]];
        if ([self isToday]) {
            self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"CalendarDayTodaySelected" ]];
        }
    }
    else
    {
        self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"CalendarDayTitle"]];
        if ([self isToday]) {
            self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"CalendarDayToday"]];
        }
    }
}

#pragma mark -
#pragma mark markDown event
-(void)markDownButtonWithListArray:(NSArray *)eventList
{
    CGRect markRect = CGRectMake(1, 1, CGRectGetWidth(self.bounds)/2, CGRectGetHeight(self.bounds)/2);
    if (eventList.count>0) {
        NSString * markString = [NSString stringWithFormat:@"%li",eventList.count];
        CGContextRef context = UIGraphicsGetCurrentContext();
        
        CGContextSetFillColorWithColor(context, [UIColor clearColor].CGColor);
        CGContextSetRGBFillColor (context, 0, 0, 0, 0);
        CGContextFillRect (context, markRect);
        
        CGContextSetFillColorWithColor(context, [UIColor colorWithRed:231.0f/255.0f green:173.0f/255.0f blue:101.0f/255.0f alpha:1.0f].CGColor);
        CGContextMoveToPoint(context, 0, 0);
        CGContextAddLineToPoint(context,markRect.size.width+1, 0);
        CGContextAddLineToPoint(context, 0, markRect.size.height+1);
        CGContextFillPath(context);
        CGContextSetLineWidth(context,0.5);
        CGContextStrokePath(context);
        CGContextSetFillColorWithColor(context, [[UIColor blackColor] CGColor]);
        [markString drawInRect:markRect withFont:[UIFont boldSystemFontOfSize:15.f]lineBreakMode:NSLineBreakByWordWrapping alignment:NSTextAlignmentLeft];
    }
}

- (void)showTodoList
{
    
}


- (BOOL)isToday
{
    NSCalendar * calendar = [NSCalendar currentCalendar];
	NSDateComponents *components = [calendar components:(NSDayCalendarUnit | NSMonthCalendarUnit | NSYearCalendarUnit) fromDate:[NSDate date]];
	NSDate *todayDate = [calendar dateFromComponents:components];
    if ([self.date compare:todayDate]!= NSOrderedSame) {
        return NO;
    } else {
        return YES;
    }
}

@end
