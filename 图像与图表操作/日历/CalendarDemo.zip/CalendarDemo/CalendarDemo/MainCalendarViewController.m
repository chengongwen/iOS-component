//
//  MainCalendarViewController.m
//  CalendarDemo
//
//  Created by yuanshanit on 15/3/19.
//  Copyright (c) 2015年 元善科技. All rights reserved.
//

#import "MainCalendarViewController.h"

@interface MainCalendarViewController ()

@end

@implementation MainCalendarViewController
@synthesize calendarLogic = _calendarLogic;
@synthesize calendarView = _calendarView;
@synthesize calendarViewNew = _calendarViewNew;
@synthesize selectedDate = _selectedDate;

@synthesize scrollView = _scrollView;
@synthesize todoList = _todoList;
@synthesize todoListTableView = _todoListTableView;

#pragma mark -
#pragma mark Memory management

- (void)dealloc
{
    [_todoListTableView release];
    [_todoList release];
    [_scrollView release];
    
    [_calendarLogic release];
    [_calendarView release];
    [_calendarViewNew release];
    [_selectedDate release];
    [super dealloc];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    // 初始化日历视图
    [self initlizeCalenderView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/**
 初始化日历视图
 */
- (void)initlizeCalenderView
{
    self.isUpdatingCalendar = NO;
    
    // 初始化scrollView
    UIScrollView * scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, kScreenHeight/5,kScreenWidth,kScreenHeight*3/4)];
    scrollView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:scrollView];
    self.scrollView = scrollView;
    [scrollView release];
    
    NSDate *aDate = self.selectedDate;
    if (aDate == nil) {
        aDate = [CalendarLogic dateForToday];
    }
    NSDateComponents *components = [[[NSDateComponents alloc] init] autorelease];
    aDate = [[[NSCalendar currentCalendar] dateByAddingComponents:components toDate:aDate options:0] retain];
    
    // 初始化代理类
    CalendarLogic *calendarLogic = [[CalendarLogic alloc] initWithDelegate:self referenceDate:aDate];
    self.calendarLogic = calendarLogic;
    
    // 初始化日历
    CalendarMonth *aCalendarView = [[CalendarMonth alloc] initWithFrame:CGRectMake(2, 0, 0,0)
                                                                  logic:calendarLogic
                                                         dayButtonWidth:(CGRectGetWidth(self.scrollView.frame)-2)/7
                                                        dayButtonHeight:CGRectGetWidth(self.scrollView.frame)/8
                                                                   font:[UIFont fontWithName:@"ArialHebrew-Bold" size:11.f]];
    
    [aCalendarView selectButtonForDate:self.selectedDate];
    [self.scrollView addSubview:aCalendarView];
    // aCalendarView.delegate = self;
    self.calendarView = aCalendarView;
    [aCalendarView release];
    [calendarLogic release];
    
    // 显示日历标记按钮
    [self.calendarView showCalendarAndMarkDownButton];
    
    // 初始化todoListTableView
    CGFloat y = CGRectGetMaxY(aCalendarView.frame);
    UITableView * tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, y+1, CGRectGetWidth(scrollView.frame),CGRectGetHeight(self.scrollView.frame)-y-5)];
    tableView.backgroundColor = [UIColor greenColor];
    self.todoListTableView = tableView;
    [self.scrollView addSubview:tableView];
    [tableView release];
    
    // 添加左右手势进行滑动，切换日历视图
    UISwipeGestureRecognizer *swipeLeftGesture=[[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(updateCalendar:)];
    swipeLeftGesture.direction=UISwipeGestureRecognizerDirectionLeft;
    [self.calendarView addGestureRecognizer:swipeLeftGesture];
    UISwipeGestureRecognizer *swipeRightGesture=[[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(updateCalendar:)];
    swipeRightGesture.direction=UISwipeGestureRecognizerDirectionRight;
    [self.calendarView addGestureRecognizer:swipeRightGesture];
    [swipeLeftGesture release];
    [swipeRightGesture release];
}

#pragma mark -
#pragma mark - UIGestureRecognizer delegate
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch;
{
    return YES;
}

- (void)updateCalendar:(UIGestureRecognizer *)recognizer
{
    if ([recognizer isKindOfClass:[UISwipeGestureRecognizer class]])
    {
        UISwipeGestureRecognizer *swipeGesture=(UISwipeGestureRecognizer *)recognizer;
        if (swipeGesture.direction == UISwipeGestureRecognizerDirectionLeft && !self.isUpdatingCalendar)
        {
            // 左滑动
            [self.calendarLogic performSelector:@selector(selectNextMonth) withObject:nil afterDelay:0];
        }
        if (swipeGesture.direction == UISwipeGestureRecognizerDirectionRight && !self.isUpdatingCalendar)
        {
            // 右滑动
            [self.calendarLogic performSelector:@selector(selectPreviousMonth) withObject:nil afterDelay:0];
        }
    }
}

#pragma mark -
#pragma mark - CalendarLogic delegate
- (void)calendarLogic:(CalendarLogic *)aLogic dateSelected:(NSDate *)aDate distance:(NSInteger)distance
{
    [self.selectedDate autorelease];
    self.selectedDate = [aDate retain];
    
    if (distance == 0) {
        
        [self.calendarView selectButtonForDate:self.selectedDate];
    }
}

- (void)calendarLogic:(CalendarLogic *)aLogic monthChangeDirection:(Direction)aDirection
{
    CGFloat distance = CGRectGetWidth(_calendarView.frame)*aDirection;
    
    self.isUpdatingCalendar = YES;
    
    // 重新初始化日历视图
    CalendarMonth *calendarViewNew = [[CalendarMonth alloc] initWithFrame:CGRectMake(distance+2, 0, 0,0)
                                                                    logic:aLogic
                                                           dayButtonWidth:(CGRectGetWidth(self.scrollView.frame)-2)/7
                                                          dayButtonHeight:CGRectGetWidth(self.scrollView.frame)/8
                                                                     font:[UIFont fontWithName:@"ArialHebrew-Bold" size:11.f]];
    // calendarViewNew.delegate = self;
    calendarViewNew.userInteractionEnabled = NO;
    
    [calendarViewNew showCalendarAndMarkDownButton];

    if ([self.calendarLogic distanceOfDateFromCurrentMonth:_selectedDate] == 0) {
        
        [calendarViewNew selectButtonForDate:self.selectedDate];
    }
    
    [self.scrollView insertSubview:calendarViewNew belowSubview:self.calendarView];
    self.calendarViewNew = calendarViewNew;
    
    [UIView beginAnimations:NULL context:nil];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(animationMonthSlideComplete)];
    [UIView setAnimationDuration:0.5];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    
    self.calendarView.frame = CGRectOffset(self.calendarView.frame, -distance, 0);
    calendarViewNew.frame = CGRectOffset(calendarViewNew.frame, -distance, 0);
    
    [UIView commitAnimations];
    [calendarViewNew release];
}

- (void)animationMonthSlideComplete
{
    // Get rid of the old one.
    [_calendarView removeFromSuperview];
    self.calendarView = nil;
    
    // replace
    self.calendarView = _calendarViewNew;
    self.calendarViewNew = nil;
    self.calendarView.userInteractionEnabled = YES;
    self.isUpdatingCalendar = NO;
    
    // 重置todoListTableView 的Y坐标
    CGFloat y = CGRectGetMaxY(self.calendarView.frame);
    self.todoListTableView.frame = CGRectMake(0, y+1, CGRectGetWidth(self.scrollView.frame),CGRectGetHeight(self.scrollView.frame)-y-5);
    
    // 刷新按钮事件
    [self.calendarView refreshButton];
    
    //添加手势
    UISwipeGestureRecognizer *swipeLeftGesture=[[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(updateCalendar:)];
    swipeLeftGesture.direction=UISwipeGestureRecognizerDirectionLeft;
    [self.calendarView addGestureRecognizer:swipeLeftGesture];
    UISwipeGestureRecognizer *swipeRightGesture=[[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(updateCalendar:)];
    swipeRightGesture.direction=UISwipeGestureRecognizerDirectionRight;
    [self.calendarView addGestureRecognizer:swipeRightGesture];
    [swipeLeftGesture release];
    [swipeRightGesture release];
}

#pragma mark -
#pragma mark - CalendarViewDelegate delegate
- (void)showScheduleWithArray:(NSArray *)array
{
    if (array.count <= 0) {
        return;
    }
    else
    {
//        CalendarScheduleDetialView * detailView = nil;
//        NSArray * nib = [[NSBundle mainBundle]loadNibNamed:@"CalendarScheduleDetialView" owner:detailView options:nil];
//        detailView = [nib objectAtIndex:0];
//        [self.view addSubview:detailView];
//        detailView.mainViewController = self;
//        [detailView showDetailArray:array];
//        detailView.center = self.view.center;
//        
//        [UIView animateWithDuration:0.2f animations:^{
//            detailView.transform = CGAffineTransformMakeScale(0.5, 0.5);
//            detailView.transform = CGAffineTransformMakeScale(1.0, 1.0);
//            
//        }];
    }
}

- (void)updateCalendar
{
    [self.calendarView refreshButton];
}


@end
