//
//  MainCalendarViewController.h
//  CalendarDemo
//
//  Created by yuanshanit on 15/3/19.
//  Copyright (c) 2015年 元善科技. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CalendarLogicDelegate.h"
#import "CalendarLogic.h"
#import "CalendarMonth.h"
#import "CalendarDayButton.h"

#import "CalendarViewDelegate.h"

@interface MainCalendarViewController : UIViewController <CalendarLogicDelegate,CalendarViewDelegate,UIGestureRecognizerDelegate>

@property (nonatomic, retain) CalendarLogic *calendarLogic;
@property (nonatomic, retain) CalendarMonth *calendarView;
@property (nonatomic, retain) CalendarMonth *calendarViewNew;
@property (nonatomic, retain) NSDate *selectedDate;
@property (nonatomic, assign) BOOL isUpdatingCalendar; // 是否正在加载日历视图

@property (nonatomic, retain) UIScrollView * scrollView;
@property (nonatomic, copy) NSArray * todoList;
@property (nonatomic, retain) UITableView * todoListTableView;

@end
