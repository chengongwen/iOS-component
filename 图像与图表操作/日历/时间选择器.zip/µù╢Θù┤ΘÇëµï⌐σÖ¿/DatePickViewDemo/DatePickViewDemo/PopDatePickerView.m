//
//  PopDatePickerView.m
//  时间选择器
//
//  Created by yuanshanit on 14-10-31.
//  Copyright (c) 2014年 liudonggan. All rights reserved.
//

#import "PopDatePickerView.h"

#define kMinYear 1990
#define kSystemVersion [[[UIDevice currentDevice] systemVersion] floatValue]
#define kFrameHeight ((kSystemVersion >= 7.0)?[[UIScreen mainScreen] bounds].size.height:[[UIScreen mainScreen] bounds].size.height-20)

@interface PopDatePickerView ()

@property (retain, nonatomic) NSMutableArray *yearArr;
@property (retain, nonatomic) NSMutableArray *montArr;
@property (retain, nonatomic) NSMutableArray *daysArr;

@property (retain, nonatomic) NSString *currentMonthString;
@property (retain, nonatomic) NSString *currentYearString;
@property (retain, nonatomic) NSString *currentDayString;

@property (assign, nonatomic) NSUInteger selectedYearRow;
@property (assign, nonatomic) NSUInteger selectedMontRow;
@property (assign, nonatomic) NSUInteger selectedDayRow;

@property (retain, nonatomic) UIPickerView *pickerView; // 选择器
@property (assign, nonatomic) id<PopDatePickerViewDelegate> delegate;
@property (assign, nonatomic) BOOL dayHidden;

@end

@implementation PopDatePickerView
@synthesize pickerView = _pickerView;
@synthesize yearArr = _yearArr;
@synthesize montArr = _montArr;
@synthesize daysArr = _daysArr;
@synthesize currentMonthString = _currentMonthString;
@synthesize currentYearString = _currentYearString;
@synthesize currentDayString = _currentDayString;

- (void)dealloc
{
    [_pickerView release];
    [_yearArr release];
    [_montArr release];
    [_daysArr release];
    [_currentMonthString release];
    [_currentYearString release];
    [_currentDayString release];
    [super dealloc];
}

- (id)initWithFrame:(CGRect)frame dayHidden:(BOOL)dayHidden datePickerViewDelegate:(id<PopDatePickerViewDelegate>)delegate
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.delegate = delegate;
        self.dayHidden = dayHidden;
        
        /**
         *  初始化时间数据
         */
        [self initializeDateData];
        
        UIPickerView *picker = [[UIPickerView alloc] initWithFrame:CGRectMake(0, 50, frame.size.width, 246)];
        picker.showsSelectionIndicator = YES;
        picker.backgroundColor = [UIColor clearColor];
        picker.delegate = self;
        picker.dataSource = self;
        self.pickerView = picker;
        [self addSubview:picker];
        [picker release];
        self.alpha = 0.0;
        self.backgroundColor = [UIColor whiteColor];
       
        NSArray *titleArray = nil;
        if (dayHidden)
        {
            titleArray = [[NSArray alloc]initWithObjects:@"年",@"月",nil];
        }
        else
        {
            titleArray = [[NSArray alloc]initWithObjects:@"年",@"月",@"日",nil];
        }
        
        for (int i = 0; i < titleArray.count; i++) {
            
            CGFloat width = self.frame.size.width/titleArray.count;
            UILabel *lbTitle = [[UILabel alloc] initWithFrame:CGRectMake(i * width, 20.0f, width, 40.0f)];
            lbTitle.text = [titleArray objectAtIndex:i];
            lbTitle.textAlignment = NSTextAlignmentCenter;
            [self addSubview:lbTitle];
            [lbTitle release];
        }
        [titleArray release];
        
        UIView * topView = [[UIView alloc] initWithFrame:CGRectMake(0,0, frame.size.width,30.0f)];
        topView.backgroundColor = [UIColor grayColor];
        [self addSubview:topView];
        
        UIButton *btnCancel = [[UIButton alloc] initWithFrame:CGRectMake(5, 0, 40.0f, 30.0f)];
        [btnCancel setTitle:@"取消" forState:UIControlStateNormal];
        [btnCancel setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
        [btnCancel addTarget:self action:@selector(dismissKeyBoardAction) forControlEvents:UIControlEventTouchUpInside];
        [topView addSubview:btnCancel];
        [btnCancel release];
        
        UIButton *btnDone = [[UIButton alloc] initWithFrame:CGRectMake(frame.size.width-45,0, 40.0f, 30.0f)];
        [btnDone setTitle:@"完成" forState:UIControlStateNormal];
        [btnDone setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
        [btnDone addTarget:self action:@selector(doneAction) forControlEvents:UIControlEventTouchUpInside];
        [topView addSubview:btnDone];
        [btnDone release];
        [topView release];
    }
    return self;
}

/**
 *  初始化时间数据
 */
- (void)initializeDateData
{
    NSDate *date = [NSDate date];
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    
    // initialize yearArr
    [formatter setDateFormat:@"yyyy"];
    self.currentYearString = [NSString stringWithFormat:@"%@",[formatter stringFromDate:date]];
    NSMutableArray *yearArr = [[NSMutableArray alloc]init];
    self.yearArr = yearArr;
    [yearArr release];
    
    for (int i = kMinYear; i <= [_currentYearString integerValue]; i ++) {
        [_yearArr addObject:[NSString stringWithFormat:@"%i",i]];
    }
    _selectedYearRow = [_yearArr indexOfObject:_currentYearString];
    
    // initialize montArr
    [formatter setDateFormat:@"M"];
    self.currentMonthString = [NSString stringWithFormat:@"%@",[formatter stringFromDate:date]];
    NSMutableArray *montArr = [[NSMutableArray alloc]init];
    self.montArr = montArr;
    [montArr release];
    
    for (int i = 1; i <= 12; i ++) {
        [self.montArr addObject:[NSString stringWithFormat:@"%i",i]];
    }
    _selectedMontRow = [_montArr indexOfObject:_currentMonthString];
    
    // initialize daysArr
    [formatter setDateFormat:@"d"];
    self.currentDayString = [NSString stringWithFormat:@"%@",[formatter stringFromDate:date]];
    [formatter release];
    
    NSMutableArray *dayArr = [[NSMutableArray alloc]init];
    self.daysArr = dayArr;
    [dayArr release];
    
    for (int i = 1; i <= 31; i ++) {
        [_daysArr addObject:[NSString stringWithFormat:@"%i",i]];
    }
    _selectedDayRow= [_daysArr indexOfObject:_currentDayString];

}

#pragma mark - count
/**
 *  计算一个月有多少天,且只显示当天以前的日期（包括当天）
 */
- (void)countDaysWithYear:(NSInteger)year month:(NSInteger)mon
{
    NSInteger day = 30;
    if (mon == 1 || mon == 3 || mon == 5 || mon == 7 || mon == 8 || mon == 10 || mon == 12) {
        day = 31;
    }
    else if(mon == 2)
    {
        if (((year % 4 == 0 && year % 100 != 0 ))|| (year % 400 == 0)) {
            day = 29;
        }
        else
        {
            day = 28;
        }
    }
    [self calculateDays:day year:year month:mon];
}

- (void)calculateDays:(NSInteger)max year:(NSInteger)year month:(NSInteger)mon
{
    
    if ([_currentMonthString integerValue] == mon && [_currentYearString integerValue] == year) {
        max = [_currentDayString integerValue];
    }
    
    if ([_daysArr count] == max) {
        return;
    }
    else if([_daysArr count] <max)
    {
        for (NSUInteger i = [_daysArr count]; i < max; i ++) {
            [_daysArr addObject:[NSString stringWithFormat:@"%lu",i + 1 ]];
        }
    }
    else{
        for (NSUInteger i = [_daysArr count]; i > max; i --) {
            [_daysArr removeObject:[NSString stringWithFormat:@"%lu",(unsigned long)i]];
        }
    }
}

//计算月数,只显示包括当月在内以前的月分
- (void)countMonth:(NSInteger)year
{
    if (year == [_currentYearString integerValue]) {
        if ([_montArr count] > [_currentMonthString integerValue]) {
            for (NSInteger i = [_montArr count]; i > [_currentMonthString integerValue]; i --) {
                [_montArr removeObject:[NSString stringWithFormat:@"%ld",(long)i]];
            }
        }else if([_montArr count] < [_currentMonthString integerValue]){
            for (NSInteger i = [_montArr count]; i > [_currentMonthString integerValue]; i ++) {
                [_montArr addObject:[NSString stringWithFormat:@"%ld",i + 1]];
            }
        }
    }else{
        for (NSInteger i = [_montArr count]; i < 12; i ++) {
            [_montArr addObject:[NSString stringWithFormat:@"%ld", i + 1]];
        }
    }
}

#pragma mark - UIPickerViewDelegate,UIPickerViewDataSource
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    if (self.dayHidden == NO) {
        return 3;
    }
    else
    {
        return 2;
    }
    return 0;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if (component == 0) {
        return [_yearArr objectAtIndex: row];
    }
    else if (component == 1) {
        return [_montArr objectAtIndex: row];
    }
    else if (self.dayHidden == NO && component == 2) {
        
        return [_daysArr objectAtIndex: row];
    }
    
    return nil;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if (component == 0) {
        return [_yearArr count];
    }
    else if (component == 1) {
        return [_montArr count];
    }
    else if (self.dayHidden == NO && component == 2) {
        
        return [_daysArr count];
    }
    return 0;
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view
{
    UILabel *pickerLabel = (UILabel *)view;
    
    if (pickerLabel == nil) {
        pickerLabel = [[[UILabel alloc]initWithFrame:CGRectMake(0.0f, 0.0f, 50.0f, 60.0f)] autorelease];
        [pickerLabel setTextAlignment:NSTextAlignmentCenter];
        [pickerLabel setBackgroundColor:[UIColor clearColor]];
        [pickerLabel setFont:[UIFont systemFontOfSize:15.0f]];
    }
    
    switch (component) {
        case 0:
            pickerLabel.text = [_yearArr objectAtIndex:row];
            break;
        case 1:
            pickerLabel.text = [_montArr objectAtIndex:row];
            break;
        case 2:
            pickerLabel.text = [_daysArr objectAtIndex:row];
            break;
        default:
            break;
    }
    return pickerLabel;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    if (component == 0) {
        _selectedYearRow = row;
        NSInteger year = [[_yearArr objectAtIndex:row] integerValue];
        [self countMonth:year];
        NSInteger mon = [[_montArr objectAtIndex:(_selectedMontRow + 1 > [_montArr count] ? [_montArr count] - 1 : _selectedMontRow)] integerValue];
        [self countDaysWithYear:year month:mon];
        [self.pickerView reloadAllComponents];
    }
    else if(component == 1){
        _selectedMontRow = row;
        NSInteger mon = [[_montArr objectAtIndex:row]integerValue];
        NSInteger year = [[_yearArr objectAtIndex:_selectedYearRow] intValue];
        [self countDaysWithYear:year month:mon];
        [self.pickerView reloadAllComponents];
    }
    else if(component == 2 && self.dayHidden == NO){
        _selectedDayRow = row;
        [self.pickerView reloadAllComponents];
    }
}

- (NSDate *)getDateInDatePicker
{
    NSDateComponents *choose = [[NSDateComponents alloc]init];
    [choose setYear:[[_yearArr objectAtIndex:[_pickerView selectedRowInComponent:0]] integerValue]];
    [choose setMonth:[[_montArr objectAtIndex:[_pickerView selectedRowInComponent:1]] integerValue]];
    
    if (self.dayHidden == NO) {
        [choose setDay:[[_daysArr objectAtIndex:[_pickerView selectedRowInComponent:2]] integerValue]];
    }
    
    NSCalendar *gregorian = [[NSCalendar alloc]initWithCalendarIdentifier:NSGregorianCalendar];
    NSDate *chooseDate = [gregorian dateFromComponents:choose];
    [choose release];
    [gregorian release];
    return chooseDate;
}

#pragma mark - showPickerView
- (void)showPickerViewWithDate:(NSDate *)rDate
{
    NSCalendar *gregorian = [[NSCalendar alloc]initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *yearComponents = [gregorian components:NSYearCalendarUnit fromDate:rDate];
    NSInteger year = [yearComponents year];
    
    NSDateComponents *monthComponents = [gregorian components:NSMonthCalendarUnit fromDate:rDate];
    NSInteger month = [monthComponents month];
    
    NSDateComponents *dayComponents = [gregorian components:NSDayCalendarUnit fromDate:rDate];
    
    NSInteger day = [dayComponents day];
    
    [self countMonth:year];
    [self countDaysWithYear:year month:month];
    
    [_pickerView selectRow:[_yearArr indexOfObject:[NSString stringWithFormat:@"%lu",(long)year]] inComponent:0 animated:YES];
    [_pickerView selectRow:[_montArr indexOfObject:[NSString stringWithFormat:@"%lu",(long)month]] inComponent:1 animated:YES];
    
    if(self.dayHidden == NO){
        [_pickerView selectRow:[_daysArr indexOfObject:[NSString stringWithFormat:@"%lu",(long)day]] inComponent:2 animated:YES];
    }
    [gregorian release];
    
    [_pickerView reloadAllComponents];
    
    [UIView animateWithDuration:0.3 animations:^{
        
        if (self.alpha == 0.0) {
            
            self.alpha = 1.0;
            
            [self setFrame:CGRectMake(0,kFrameHeight - self.frame.size.height, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame))];
        }
    }];
}

- (void)hidePopPickerView
{
    [self dismissKeyBoardAction];
}

#pragma mark - dismissKeyBoardAction and doneAction actions
- (void)dismissKeyBoardAction
{
    [UIView animateWithDuration:0.3 animations:^{
        
        [self setFrame:CGRectMake(0, kFrameHeight, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame))];
        
    } completion:^(BOOL finished) {
        
        self.alpha = 0.0;
    }];
}

- (void)doneAction
{
    [self dismissKeyBoardAction];
    
    if (_delegate && [_delegate respondsToSelector:@selector(returnSelectedDate:)])
    {
        [self.delegate returnSelectedDate:[self getDateInDatePicker]];
    }
}

@end
