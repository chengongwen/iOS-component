//
//  ViewController.m
//  DatePickViewDemo
//
//  Created by yuanshanit on 15/3/19.
//  Copyright (c) 2015年 元善科技. All rights reserved.
//

#import "ViewController.h"

#import "ActionSheetDatePicker.h"

@interface ViewController ()

@property (nonatomic, retain) PopDatePickerView *popDatePickerView;

@end

@implementation ViewController
@synthesize popDatePickerView= _popDatePickerView;

- (void)dealloc
{
    [_popDatePickerView release];
    [super dealloc];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
//    self.view.backgroundColor = [UIColor redColor];
    
    UIButton *btn1 = [[UIButton alloc] initWithFrame:CGRectMake(CGRectGetWidth(self.view.frame)/8, CGRectGetHeight(self.view.frame)/3, 100, 40)];
    [btn1 setTitle:@"系统" forState:UIControlStateNormal];
    [btn1 setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [btn1 addTarget:self action:@selector(click2:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn1];
    [btn1 release];
    
    UIButton *btn2 = [[UIButton alloc] initWithFrame:CGRectMake(CGRectGetWidth(self.view.frame)/2, CGRectGetHeight(self.view.frame)/3, 100, 40)];
    [btn2 setTitle:@"自定义" forState:UIControlStateNormal];
    [btn2 setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [btn2 addTarget:self action:@selector(click1) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn2];
    [btn2 release];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)click1
{
    if (_popDatePickerView == nil) {
    
        PopDatePickerView *popDatePickerView = [[PopDatePickerView alloc] initWithFrame:CGRectMake(0, CGRectGetHeight(self.view.frame), CGRectGetWidth(self.view.frame), 246) dayHidden:NO datePickerViewDelegate:self targetCtrl:self];
        [self.view addSubview:popDatePickerView];
        self.popDatePickerView = popDatePickerView;
        [popDatePickerView release];
    }
    [self.popDatePickerView showPickerViewWithDate:[NSDate date]];
}

#pragma mark - PopDatePickerViewDelegate
- (void)returnSelectedDate:(NSDate *)rDate
{
    NSLog(@"date = %@",rDate);
}


- (void)click2:(id)sender
{
    
    NSDate *selectedTime = [NSDate date];
    
    NSInteger minuteInterval = 5;
    //clamp date
    NSInteger referenceTimeInterval = (NSInteger)[selectedTime timeIntervalSinceReferenceDate];
    NSInteger remainingSeconds = referenceTimeInterval % (minuteInterval *60);
    NSInteger timeRoundedTo5Minutes = referenceTimeInterval - remainingSeconds;
    if(remainingSeconds>((minuteInterval*60)/2)) {/// round up
        timeRoundedTo5Minutes = referenceTimeInterval +((minuteInterval*60)-remainingSeconds);
    }
    
    selectedTime = [NSDate dateWithTimeIntervalSinceReferenceDate:(NSTimeInterval)timeRoundedTo5Minutes];
    
    ActionSheetDatePicker *datePicker = [[ActionSheetDatePicker alloc] initWithTitle:@"Select a time" datePickerMode:UIDatePickerModeDate selectedDate:selectedTime target:self action:@selector(timeWasSelected:element:) origin:sender];
    
    datePicker.minuteInterval = minuteInterval;
    [datePicker showActionSheetPicker];
}

- (void)timeWasSelected:(NSDate *)selectedTime element:(id)element {
    
   NSLog(@"selectedTime = %@",selectedTime);
}

@end
