//
//  PopDatePickerView.h
//  时间选择器
//
//  Created by yuanshanit on 14-10-31.
//  Copyright (c) 2014年 liudonggan. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol PopDatePickerViewDelegate <NSObject>

@optional

/**
 *  返回选择日期
 *
 *  @return date
 */
- (void)returnSelectedDate:(NSDate *)rDate;

@end

@interface PopDatePickerView : UIView<UIPickerViewDelegate,UIPickerViewDataSource,PopDatePickerViewDelegate>

/**
 *  初始化日期选择器（年，月，日）
 *
 *  @param frame     frame
 *  @param dayHidden 是否显示天; yes,隐藏天数
 *  @param delegate  delegate
 *
 *  @return init
 */
- (id)initWithFrame:(CGRect)frame dayHidden:(BOOL)dayHidden datePickerViewDelegate:(id<PopDatePickerViewDelegate>)delegate;

/**
 *  显示PickerView
 *
 *  @param rDate 显示当前的天数
 */
- (void)showPickerViewWithDate:(NSDate *)rDate;

/**
 *  @brief 隐藏PickerView
 */
- (void)hidePopPickerView;


@end
