//
//  CollectionViewController.h
//  CompanionForiPhone
//
//  Created by yuanshanit on 14/12/30.
//  Copyright (c) 2014年 元善科技. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CollectionViewController : UICollectionViewController<UICollectionViewDelegate>

@end
