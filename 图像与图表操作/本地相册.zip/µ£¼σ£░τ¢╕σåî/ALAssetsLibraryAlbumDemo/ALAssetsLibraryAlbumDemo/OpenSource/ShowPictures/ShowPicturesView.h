//
//  ShowPicturesView.h
//  ShowPicturesView
//
//  Created by pantianxiang on 15/6/16.
//  Copyright (c) 2015年 元善科技. All rights reserved.
//

/**
 *  注：保存按钮内容可根据不同需求自定义。 如有其它功能不能满足需求，可修改代码的实现。
 */

#import <UIKit/UIKit.h>

@interface ShowPicturesView : UIScrollView<UIScrollViewDelegate,UIActionSheetDelegate>

/**
 *  初始化该类对象（无动画效果）。
 *
 *  @param imagesArray 将要显示图片的数组.
 *  @param minScale 缩放最小比例。
 *  @param maxScale 缩放最大比列。
 */
- (id)initWithImages:(NSArray *)imagesArray minScale:(CGFloat)minScale maxScale:(CGFloat)maxScale;

/**
 *  初始化该类对象。
 *  该方法在开始展示和结束展示的时候使用了动画效果，就像点击qq聊天框内容中的某张图片时，会出现图片位置和大小渐变的过程，结束展示也一样。
 *
 *  @param imagesArray 将要显示图片的数组。
 *  @param imageOriginalFrame 点击将要显示图片所在整个屏幕中的frame。
 *  @param index 点击将要显示图片的下标,从0开始。
 *  @param minScale 缩放最小比例。
 *  @param maxScale 缩放最大比列。
 */
- (id)initWithImages:(NSArray *)imagesArray imageOriginalFrame:(CGRect)imageOriginalFrame index:(NSInteger)index minScale:(CGFloat)minScale maxScale:(CGFloat)maxScale;
@end
