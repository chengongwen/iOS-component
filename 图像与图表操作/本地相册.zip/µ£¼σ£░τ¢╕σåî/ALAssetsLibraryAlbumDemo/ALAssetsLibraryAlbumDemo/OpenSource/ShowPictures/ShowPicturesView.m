//
//  ShowPicturesView.m
//  ShowPicturesView
//
//  Created by pantianxiang on 15/6/16.
//  Copyright (c) 2015年 元善科技. All rights reserved.
//

#import "ShowPicturesView.h"

@protocol ZoomingViewDelegate <NSObject>

- (void)hideZoomingView;

@end

@interface ImageZoomingView : UIScrollView<UIScrollViewDelegate>

@property (retain, nonatomic) UIImage *image;
@property (retain, nonatomic) UIImageView *imgvZooming; //将要缩放的图片
@property (assign, nonatomic) id<ZoomingViewDelegate>hDelegate;
@property (assign, nonatomic) CGRect imageOriginalFrame;
@property (assign, nonatomic) BOOL isFirstShow; //是否是第一次点击显示图片
@property (assign, nonatomic) BOOL isUseImageAnimation; //图片显示和消失时是否使用动画

@end

@implementation ImageZoomingView
@synthesize image = _image;
@synthesize imgvZooming = _imgvZooming;

- (void)dealloc
{
    [_image release];
    [_imgvZooming release];
    [super dealloc];
}

- (id)initWithFrame:(CGRect)frame image:(UIImage *)image imageOriginalFrame:(CGRect)imageOriginalFrame isFirstShow:(BOOL)isFirstShow minScale:(CGFloat)minScale maxScale:(CGFloat)maxScale
{
    if (self = [super initWithFrame:frame]) {
        self.delegate = self;
        self.minimumZoomScale = minScale;
        self.maximumZoomScale = maxScale;
        self.bouncesZoom = YES;
        self.backgroundColor = [UIColor blackColor];
        self.showsHorizontalScrollIndicator = NO;
        self.showsVerticalScrollIndicator = NO;
        self.image = image;
        self.imageOriginalFrame = imageOriginalFrame;
        self.isFirstShow = isFirstShow;
        
        [self initView];
        
        if (self.isFirstShow) {
            self.isFirstShow = NO;
            [self imageStartAnimation];
        }
        
    }
    return self;
}

- (void)initView
{
    CGFloat width = _image.size.width > self.frame.size.width ? self.frame.size.width : _image.size.width;
    CGFloat height = width * _image.size.height / _image.size.width;
    CGRect frame = _imgvZooming.frame = CGRectMake((self.frame.size.width - width) / 2, (self.frame.size.height - height) / 2, width, height);
    
    UIImageView *imgvZooming = [[UIImageView alloc]initWithFrame:self.isFirstShow ? self.imageOriginalFrame : frame];
    imgvZooming.clipsToBounds = YES;
    imgvZooming.image = _image;
    imgvZooming.userInteractionEnabled = YES;
    [self addSubview:imgvZooming];
    self.imgvZooming = imgvZooming;
    [imgvZooming release];
    
    UITapGestureRecognizer *tapGesture1 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(handleTapGesture:)];
    tapGesture1.numberOfTapsRequired = 1;
    [self addGestureRecognizer:tapGesture1];
    
    UITapGestureRecognizer *tapGesture2 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(handleTapGesture:)];
    tapGesture2.numberOfTapsRequired = 2;
    [self addGestureRecognizer:tapGesture2];
    [tapGesture1 requireGestureRecognizerToFail:tapGesture2];
    
    [tapGesture1 release];
    [tapGesture2 release];
}

#pragma mark - UIScrollViewDelegate
- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    return _imgvZooming;
}

- (void)scrollViewDidZoom:(UIScrollView *)aScrollView
{
    CGFloat offsetX = (self.bounds.size.width > self.contentSize.width) ?
    (self.bounds.size.width - self.contentSize.width) * 0.5 : 0.0;
    CGFloat offsetY = (self.bounds.size.height > self.contentSize.height)?
    (self.bounds.size.height - self.contentSize.height) * 0.5 : 0.0;
    _imgvZooming.center = CGPointMake(self.contentSize.width * 0.5 + offsetX,
                                      self.contentSize.height * 0.5 + offsetY);
}

#pragma mark - handle tapGesture
- (void)handleTapGesture:(UITapGestureRecognizer *)tap
{
    if (tap.numberOfTapsRequired == 2) {
        if (self.zoomScale != self.maximumZoomScale) {
            [self zoomToRect:[self calculateZoomRectWithScale:self.maximumZoomScale andClickPoint:[tap locationInView:tap.view]] animated:YES];
            
        }
        else{
            [self zoomToRect:[self calculateZoomRectWithScale:self.minimumZoomScale andClickPoint:[tap locationInView:tap.view]] animated:YES];
        }
    }
    else
    {
        if (self.isUseImageAnimation) {
            [self imageEndAnimation];
        }
        if (self.hDelegate && [self.hDelegate respondsToSelector:@selector(hideZoomingView)]) {
            [self.hDelegate hideZoomingView];
        }
    }
}

//将点击触周围区域显示到当前屏幕可视化区域
- (CGRect)calculateZoomRectWithScale:(NSInteger)scale andClickPoint:(CGPoint)center
{
    CGRect zoomRect;
    zoomRect.size.width = self.frame.size.width / scale;
    zoomRect.size.height = self.frame.size.height / scale;
    zoomRect.origin.x = center.x  - zoomRect.size.width / 2;
    zoomRect.origin.y = center.y - zoomRect.size.height / 2;
    
    return zoomRect;
}

#pragma mark - self methods
//图片开始显示动画
- (void)imageStartAnimation
{
    [UIView animateWithDuration:0.4f animations:^{
        CGFloat width = _image.size.width > self.frame.size.width ? self.frame.size.width : _image.size.width;
        CGFloat height = width * _image.size.height / _image.size.width;
        _imgvZooming.frame = CGRectMake((self.frame.size.width - width) / 2, (self.frame.size.height - height) / 2, width, height);
    }];
}

//图片结束显示动画
- (void)imageEndAnimation
{
    [UIView animateWithDuration:0.2f animations:^{
        _imageOriginalFrame.origin.x += self.contentOffset.x;
        _imageOriginalFrame.origin.y += self.contentOffset.y;
        _imgvZooming.frame = _imageOriginalFrame;
    }];
}

@end


@interface ShowPicturesView ()<ZoomingViewDelegate>

@property (retain, nonatomic) NSArray *imagesArray;
@property (retain, nonatomic) UIView *bgView;
@property (retain, nonatomic) UILabel *lbPage; //显示图片页数
@property (assign, nonatomic) NSInteger pageNum; //页数
@property (retain, nonatomic) NSMutableDictionary *zoomingviewDic;
@property (retain, nonatomic) UILabel *lbStatus; //保存图片状态
@property (retain, nonatomic) UIButton *btnSave; //保存图片
@property (retain, nonatomic) UIView *bgSave;
@property (assign, nonatomic) CGRect imageOriginalFrame; //点击开始显示图片在整个屏幕中的原始frame
@property (assign, nonatomic) BOOL isFirstShow; //是否显示第一次点击的图片
@property (assign, nonatomic) BOOL isUseImageAnimation; //图片显示和消失时是否使用动画
@property (assign, nonatomic) BOOL isShowPageLabel; //当只显示一张图片时，不显示页码。

@property (assign, nonatomic) CGFloat minScale;
@property (assign, nonatomic) CGFloat maxScale;

@end

@implementation ShowPicturesView
@synthesize imagesArray = _imagesArray;
@synthesize bgView = _bgView;
@synthesize lbPage = _lbPage;
@synthesize zoomingviewDic = _zoomingviewDic;
@synthesize lbStatus = _lbStatus;
@synthesize btnSave = _btnSave;
@synthesize bgSave = _bgSave;

- (void)dealloc
{
    [_imagesArray release];
    [_bgView release];
    [_lbPage release];
    [_zoomingviewDic release];
    [_lbStatus release];
    [_btnSave release];
    [_bgSave release];
    [super dealloc];
}

- (id)initWithImages:(NSArray *)imagesArray minScale:(CGFloat)minScale maxScale:(CGFloat)maxScale
{
    if (self == [super initWithFrame:CGRectMake(0, 0, [[UIScreen mainScreen] bounds].size.width, [[UIScreen mainScreen] bounds].size.height)]) {
        self.backgroundColor = [UIColor blackColor];
        self.alpha = 0;
        self.imagesArray = imagesArray;
        self.pagingEnabled = YES;
        self.delegate = self;
        self.showsHorizontalScrollIndicator = NO;
        self.showsVerticalScrollIndicator = NO;
        self.pageNum = 0;
        self.isFirstShow = NO;
        self.isUseImageAnimation = NO;
        self.isShowPageLabel = (!_imagesArray || _imagesArray.count == 0 || _imagesArray.count == 1)? NO : YES;
        self.minScale = minScale;
        self.maxScale = maxScale;
        self.contentSize = CGSizeMake(self.frame.size.width * imagesArray.count, self.frame.size.height);
        
        NSMutableDictionary *temp = [[NSMutableDictionary alloc]init];
        self.zoomingviewDic = temp;
        [temp release];
        
        [self showIamgeWithPage:self.pageNum];
        [self initView];
        [self show];
    }
    return self;
}

- (id)initWithImages:(NSArray *)imagesArray imageOriginalFrame:(CGRect)imageOriginalFrame index:(NSInteger)index minScale:(CGFloat)minScale maxScale:(CGFloat)maxScale
{
    if (self == [super initWithFrame:CGRectMake(0, 0, [[UIScreen mainScreen] bounds].size.width, [[UIScreen mainScreen] bounds].size.height)]) {
        self.backgroundColor = [UIColor blackColor];
        self.alpha = 0;
        self.imagesArray = imagesArray;
        self.pagingEnabled = YES;
        self.delegate = self;
        self.showsHorizontalScrollIndicator = NO;
        self.showsVerticalScrollIndicator = NO;
        self.pageNum = index;
        self.imageOriginalFrame = imageOriginalFrame;
        self.isFirstShow = YES;
        self.isUseImageAnimation = YES;
        self.isShowPageLabel = (!_imagesArray || _imagesArray.count == 0 || _imagesArray.count == 1)? NO : YES;
        self.minScale = minScale;
        self.maxScale = maxScale;
        self.contentSize = CGSizeMake(self.frame.size.width * imagesArray.count, self.frame.size.height);
        
        NSMutableDictionary *temp = [[NSMutableDictionary alloc]init];
        self.zoomingviewDic = temp;
        [temp release];
        
        self.contentOffset = CGPointMake(self.frame.size.width * self.pageNum, self.contentOffset.y);
        [self showIamgeWithPage:self.pageNum];
        [self initView];
        [self show];
    }
    return self;
}

- (void)initView
{
    if (self.isShowPageLabel) {
        UIView *bgView = [[UIView alloc]initWithFrame:CGRectMake(CGRectGetWidth(self.frame) / 2 - 40.f + self.contentOffset.x, CGRectGetHeight(self.frame) - 30.f, 80.f, 20.f)];
        bgView.layer.cornerRadius = 10.f;
        bgView.layer.backgroundColor = [UIColor blackColor].CGColor;
        bgView.alpha = 0.4f;
        [self addSubview:bgView];
        self.bgView = bgView;
        [bgView release];
        
        UILabel *lbPage = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetWidth(self.frame) / 2 - 40.f + self.contentOffset.x, CGRectGetHeight(self.frame) - 30.f, 80.f, 20.f)];
        lbPage.backgroundColor = [UIColor clearColor];
        lbPage.textColor = [UIColor whiteColor];
        lbPage.textAlignment = NSTextAlignmentCenter;
        lbPage.text = [NSString stringWithFormat:@"%ld/%lu",(long)(_pageNum + 1),(unsigned long)[_imagesArray count]];
        [lbPage setFont:[UIFont systemFontOfSize:16.f]];
        [self addSubview:lbPage];
        self.lbPage = lbPage;
        [lbPage release];
    }
   
    if (_imagesArray && _imagesArray.count > 0) {
        UIView *bgSave = [[UIView alloc]initWithFrame:CGRectMake(CGRectGetWidth(self.frame) - 50.f + self.contentOffset.x, CGRectGetHeight(self.frame) - 30.f, 40.f, 20.f)];
        bgSave.layer.cornerRadius = 3.f;
        bgSave.layer.borderWidth = 0.5f;
        bgSave.layer.borderColor = [UIColor whiteColor].CGColor;
        bgSave.layer.backgroundColor = [UIColor blackColor].CGColor;
        bgSave.alpha = 0.4f;
        [self addSubview:bgSave];
        self.bgSave = bgSave;
        [bgSave release];
        
        UIButton *btnSave = [[UIButton alloc]initWithFrame:CGRectMake(CGRectGetWidth(self.frame) - 50.f + self.contentOffset.x, CGRectGetHeight(self.frame) - 30.f, 40.f, 20.f)];
        btnSave.titleLabel.font = [UIFont systemFontOfSize:14.f];
        [btnSave setTitle:@"保存" forState:UIControlStateNormal];
        [btnSave setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [btnSave addTarget:self action:@selector(savePhoto:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:btnSave];
        self.btnSave = btnSave;
        [btnSave release];
    }
}

#pragma mark - UIScrollViewDelegate
//一些不用滑动控件相关设置
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (self.isShowPageLabel) {
        _bgView.frame = CGRectMake(CGRectGetWidth(self.frame) / 2 - 40.f + scrollView.contentOffset.x, _bgView.frame.origin.y, _bgView.frame.size.width, _bgView.frame.size.height);
        _lbPage.frame = CGRectMake(CGRectGetWidth(self.frame) / 2 - 40.f + scrollView.contentOffset.x, _lbPage.frame.origin.y, _lbPage.frame.size.width, _lbPage.frame.size.height);
    }
    if (_imagesArray && _imagesArray.count > 0) {
        _btnSave.frame = CGRectMake(CGRectGetWidth(self.frame) - 50.f + scrollView.contentOffset.x, _btnSave.frame.origin.y, _btnSave.frame.size.width, _btnSave.frame.size.height);
        _bgSave.frame = CGRectMake(CGRectGetWidth(self.frame) - 50.f + scrollView.contentOffset.x, _bgSave.frame.origin.y, _bgSave.frame.size.width, _bgSave.frame.size.height);
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    _pageNum = scrollView.contentOffset.x / scrollView.frame.size.width;
    if (self.isShowPageLabel) {
        _lbPage.text = [NSString stringWithFormat:@"%ld/%lu",(long)(_pageNum + 1),(unsigned long)[_imagesArray count]];
    }
    
    if (self.isFirstShow) {
        self.isFirstShow = NO;
    }
    [self showIamgeWithPage:_pageNum];
}

#pragma mark - self methods
//滑动显示图片
- (void)showIamgeWithPage:(NSInteger)page
{
    if (!_imagesArray || _imagesArray.count == 0) {
        return;
    }
    ImageZoomingView *existView = (ImageZoomingView *)[_zoomingviewDic objectForKey:[NSString stringWithFormat:@"%ld",(long)page]];
    if (!existView) {
        ImageZoomingView *zoomingView = [[ImageZoomingView alloc]initWithFrame:CGRectMake(page * self.frame.size.width, 0, self.frame.size.width, self.frame.size.height) image:[_imagesArray objectAtIndex:page] imageOriginalFrame:self.imageOriginalFrame isFirstShow:self.isFirstShow minScale:self.minScale maxScale:self.maxScale];
        zoomingView.hDelegate = self;
        zoomingView.isUseImageAnimation = self.isUseImageAnimation;
        [self addSubview:zoomingView];
        [self sendSubviewToBack:zoomingView];
        [_zoomingviewDic setValue:zoomingView forKey:[NSString stringWithFormat:@"%ld",(long)page]];
        [zoomingView release];
    }
}

- (void)show
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.3f];
    self.alpha = 1.f;
    [UIView commitAnimations];
}

- (void)savePhoto:(id)sender
{
    UIActionSheet *actionSheet = [[UIActionSheet alloc]initWithTitle:@"将图片保存到..."delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"当前应用",@"手机",@"同时", nil];
    [actionSheet showInView:self.superview];
    [actionSheet release];
}

- (void)showStatus
{
    if (!_lbStatus) {
        UILabel *lbStatus = [[UILabel alloc]initWithFrame:CGRectMake(self.contentOffset.x, -44.f, CGRectGetWidth(self.frame), 44.f)];
        lbStatus.backgroundColor = [UIColor blackColor];
        lbStatus.textColor= [UIColor whiteColor];
        lbStatus.font = [UIFont systemFontOfSize:18.f];
        lbStatus.textAlignment = NSTextAlignmentCenter;
        lbStatus.text = @"图片已保存";
        [self addSubview:lbStatus];
        self.lbStatus = lbStatus;
        [lbStatus release];
    }
    _lbStatus.frame = CGRectMake(self.contentOffset.x, -44.f, CGRectGetWidth(self.frame), 44.f);
    [UIView animateWithDuration:0.4f animations:^{
        _lbStatus.frame = CGRectMake(self.contentOffset.x, 0, CGRectGetWidth(_lbStatus.frame), CGRectGetHeight(_lbStatus.frame));
    }];
    [self performSelector:@selector(hideStatus) withObject:self afterDelay:1.f];
}

//隐藏图片保存完成状态
- (void)hideStatus
{
    [UIView animateWithDuration:0.5f animations:^{
        _lbStatus.frame = CGRectMake(self.contentOffset.x, -44.f, CGRectGetWidth(_lbStatus.frame), CGRectGetHeight(_lbStatus.frame));
    }];
}

#pragma mark - ZoomingViewDelegate
- (void)hideZoomingView
{
    [UIView animateWithDuration:0.6f animations:^{
        self.alpha = 0;
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
}

#pragma mark - UIActionSheetDelegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    UIImage *image = (UIImage *)[_imagesArray objectAtIndex:_pageNum];
    switch (buttonIndex) {
        case 0:
        {
            NSLog(@"保存到当前应用");
            [self showStatus];
            break;
        }
        case 1:
        {
            UIImageWriteToSavedPhotosAlbum(image, self, nil, nil);
            [self showStatus];
            break;
        }
        case 2:
        {
            UIImageWriteToSavedPhotosAlbum(image, self, nil, nil);
            NSLog(@"保存到当前应用");
            [self showStatus];
            break;
        }
        default:
            break;
    }
}

@end