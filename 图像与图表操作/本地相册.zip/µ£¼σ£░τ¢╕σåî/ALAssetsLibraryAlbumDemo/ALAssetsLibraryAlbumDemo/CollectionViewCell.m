//
//  CollectionViewCell.m
//  CompanionForiPhone
//
//  Created by yuanshanit on 14/12/30.
//  Copyright (c) 2014年 元善科技. All rights reserved.
//

#import "CollectionViewCell.h"

@implementation CollectionViewCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        _imageview=[[UIImageView alloc]initWithFrame:CGRectZero];
        [self.contentView addSubview:_imageview];
    }
    return self;
}
-(void)layoutSubviews{
    [super layoutSubviews];
    _imageview.frame=CGRectInset(self.bounds, 0, 2);
}

@end
