//
//  CollectionViewController.m
//  CompanionForiPhone
//
//  Created by yuanshanit on 14/12/30.
//  Copyright (c) 2014年 元善科技. All rights reserved.
//

#import <MobileCoreServices/MobileCoreServices.h>

#import "CollectionViewController.h"
#import "ALAssetsLibrary+CustomPhotoAlbum.h"
#import "CollectionViewCell.h"

#import "ShowPicturesView.h"

#import "HZPhotoBrowser.h"

#define ORIGINAL_MAX_WIDTH [[UIScreen mainScreen] bounds].size.height

static NSString * const reuseIdentifier = @"Cell";

@interface CollectionViewController ()<UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,HZPhotoBrowserDelegate>

@property (nonatomic, retain) NSMutableArray *items;

@property (nonatomic, retain) ALAssetsLibrary *assetsLibrary;

@end

@implementation CollectionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations
    // self.clearsSelectionOnViewWillAppear = NO;
    
    self.title = @"ALAssetsLibraryAlbumDemo";
    
    self.view.backgroundColor = [UIColor clearColor];

    UIBarButtonItem * takePhotoButton = [[UIBarButtonItem alloc ]initWithBarButtonSystemItem:UIBarButtonSystemItemCamera target:self action:@selector(takePhoto)];
    
    [takePhotoButton setStyle:UIBarButtonItemStyleBordered];
    [self.navigationItem setRightBarButtonItem:takePhotoButton];
    
    self.collectionView.frame = CGRectMake(0, 0, CGRectGetWidth(self.view.frame), CGRectGetHeight(self.view.frame) );
    self.collectionView.backgroundColor=[UIColor clearColor];

    [self.collectionView registerClass:[CollectionViewCell class] forCellWithReuseIdentifier:reuseIdentifier];
    
    [self loadlocalPhoto];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - load displayName localPhoto
/**
 *  加载某一个相册的所有图片
 */
- (void)loadlocalPhoto {
    
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    NSString *displayName = [infoDictionary objectForKey:@"CFBundleDisplayName"];
    
    [self.assetsLibrary loadImagesFromAlbum:displayName completion:^(NSMutableArray *images, NSError *error) {
        
        if (error) {
            
            //
        }
        else {
            
            [self.items removeAllObjects];
            
            self.items = [NSMutableArray arrayWithArray:images];
            
            [self.collectionView reloadData];
        }
    }];
}

#pragma mark - takePhoto and localPhoto Actions
- (void)takePhoto {
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"选择或者拍照" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"拍照" otherButtonTitles:@"从相册中选择一个", nil];
    
    actionSheet.actionSheetStyle = UIActionSheetStyleBlackOpaque;
    [actionSheet showInView:self.view];
}

// 开始拍照
- (void)takePhotoAction
{
    //判断是否有相机
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        
        //设置拍照后的图片可被编辑
        picker.allowsEditing = YES;
        
        //资源类型为照相机
        picker.sourceType = UIImagePickerControllerSourceTypeCamera;
        picker.mediaTypes = [UIImagePickerController availableMediaTypesForSourceType:UIImagePickerControllerSourceTypeCamera];
        
        //触发拍照
        [self.navigationController presentViewController:picker animated:YES completion:NULL];
    }
    else
    {
        UIAlertView *alter = [[UIAlertView alloc] initWithTitle:@"提示" message:@"该设备无摄像头!" delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil];
        [alter show];
    }
}

// 打开本地相册
- (void)localPhotoAction
{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    picker.mediaTypes = [UIImagePickerController availableMediaTypesForSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    
    [self.navigationController presentViewController:picker animated:YES completion:NULL];
}

#pragma mark - UIImagePickerController Delegate Methods

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    if ([[info objectForKey:UIImagePickerControllerMediaType] isEqual:(NSString *)kUTTypeImage])
    {
        UIImage *originalImage, *editedImage, *imageToUse;
        
        NSString *mediaType =[info objectForKey:UIImagePickerControllerMediaType];
        
        if ([mediaType isEqualToString:@"public.image"])
        {
            editedImage = (UIImage *) [info objectForKey:UIImagePickerControllerEditedImage];
            originalImage = (UIImage *) [info objectForKey:UIImagePickerControllerOriginalImage];
            
            if (editedImage) {
                imageToUse = editedImage;
            } else {
                imageToUse = originalImage;
            }
            
            // 只保存拍照相片
//            if (picker.sourceType == UIImagePickerControllerSourceTypeCamera) {
            
                // 添加到当前目录
                [self saveAlbumInPhoneAlbum:imageToUse];
//            }
        }
    }
    
    [picker dismissViewControllerAnimated:YES completion:nil];;
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissViewControllerAnimated:YES completion:NULL];
}

#pragma mark - 在手机相册中创建相册
- (ALAssetsLibrary *)assetsLibrary
{
    if (_assetsLibrary) {
        return _assetsLibrary;
    }
    
    ALAssetsLibrary *assetsLibrary = [[ALAssetsLibrary alloc] init];
    self.assetsLibrary = assetsLibrary;
    // [assetsLibrary release]; // 非ARC需要释放
    
    return _assetsLibrary;
}

- (void)saveAlbumInPhoneAlbum:(UIImage *)image
{
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    NSString *displayName = [infoDictionary objectForKey:@"CFBundleDisplayName"];
    
    [self.assetsLibrary saveImage:image
                          toAlbum:displayName
                       completion:^(NSURL *assetURL, NSError *error) {
                           
                           NSLog(@"相片添加成功");
                           
                           // 重新加载相册
                           [self loadlocalPhoto];
                   
       } failure:^(NSError *error) {
           
           //处理添加失败的方法显示alert让它回到主线程执行，不然那个框框死活不肯弹出来
           dispatch_async(dispatch_get_main_queue(), ^{
               
               //添加失败一般是由用户不允许应用访问相册造成的，这边可以取出这种情况加以判断一下
               if([error.localizedDescription rangeOfString:@"User denied access"].location != NSNotFound ||[error.localizedDescription rangeOfString:@"用户拒绝访问"].location!=NSNotFound){
                   
                   NSLog(@"相片添加失败%@",error.localizedDescription);
               }
           });
       }];
}

#pragma mark - @protocol UIActionSheetDelegate <NSObject>
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    if (buttonIndex == 0) {
        
        // 拍照
        [self takePhotoAction];
    }
    else if (buttonIndex == 1) {
        
        // 相册
        [self localPhotoAction];
    }
    else if(buttonIndex == 2) {
        NSLog(@"取消");
    }
}

#pragma mark - UICollectionViewDataSource
//定义展示的Section的个数
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

//定义展示的UICollectionViewCell的个数
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    
    return [self.items count];
}

//每个UICollectionView展示的内容
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    CollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    
    // Configure the cell
    cell.imageview.image=[self.items objectAtIndex:indexPath.row];
    
    cell.backgroundColor = [UIColor redColor];
    
    return cell;
}

#pragma mark --UICollectionViewDelegateFlowLayout

//定义每个UICollectionView 的大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(90, 90);
}

//定义每个UICollectionView 的 margin
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(5, 5, 5, 5);
}

#pragma mark <UICollectionViewDelegate>
//返回这个UICollectionView是否可以被选择
-(BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

//UICollectionView被选中时调用的方法
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    //启动图片浏览器
    /*
    HZPhotoBrowser *browserVc = [[HZPhotoBrowser alloc] init];
    
    browserVc.sourceImagesContainerView = self.collectionView; // 原图的父控件
    browserVc.imageCount = self.items.count; // 图片总数
    browserVc.currentImageIndex = indexPath.row;
    browserVc.delegate = self;
    
    [browserVc show];
    */
    CollectionViewCell * cell = (CollectionViewCell *)[collectionView cellForItemAtIndexPath:indexPath];
    CGRect imageFrame = cell.frame;
    imageFrame.origin.y += 64;
    
    ShowPicturesView *showPicturesView = [[ShowPicturesView alloc] initWithImages:self.items imageOriginalFrame:imageFrame index:indexPath.row minScale:1.0  maxScale:3.0];

    [self.view.window addSubview:showPicturesView];
//    [showPicturesView release];
    
    // 裁剪
//    UIImage *portraitImg = [self imageByScalingToMaxSize:self.items[indexPath.row]];
//    VPImageCropperViewController *imgEditorVC = [[VPImageCropperViewController alloc] initWithImage:portraitImg cropFrame:CGRectMake(0, self.view.center.y-self.view.frame.size.width/2, self.view.frame.size.width, self.view.frame.size.width) limitScaleRatio:3.0];
//    imgEditorVC.delegate = self;
//    
//    [self presentViewController:imgEditorVC animated:YES completion:^{
//        // TO DO
//    }];
}
/*
#pragma mark - photobrowser代理方法
- (UIImage *)photoBrowser:(HZPhotoBrowser *)browser placeholderImageForIndex:(NSInteger)index
{
    return self.items[index];
}

- (NSURL *)photoBrowser:(HZPhotoBrowser *)browser highQualityImageURLForIndex:(NSInteger)index
{
//    NSString *urlStr = [self.items[index] thumbnail_pic] stringByReplacingOccurrencesOfString:@"thumbnail" withString:@"bmiddle"];
//    return [NSURL URLWithString:urlStr];
    
    return nil;
}
*/
#pragma mark image scale utility
- (UIImage *)imageByScalingToMaxSize:(UIImage *)sourceImage
{
    if (sourceImage.size.width < ORIGINAL_MAX_WIDTH) return sourceImage;
    CGFloat btWidth = 0.0f;
    CGFloat btHeight = 0.0f;
    if (sourceImage.size.width > sourceImage.size.height) {
        btHeight = ORIGINAL_MAX_WIDTH;
        btWidth = sourceImage.size.width * (ORIGINAL_MAX_WIDTH / sourceImage.size.height);
    } else {
        btWidth = ORIGINAL_MAX_WIDTH;
        btHeight = sourceImage.size.height * (ORIGINAL_MAX_WIDTH / sourceImage.size.width);
    }
    CGSize targetSize = CGSizeMake(btWidth, btHeight);
    return [self imageByScalingAndCroppingForSourceImage:sourceImage targetSize:targetSize];
}

- (UIImage *)imageByScalingAndCroppingForSourceImage:(UIImage *)sourceImage targetSize:(CGSize)targetSize {
    UIImage *newImage = nil;
    CGSize imageSize = sourceImage.size;
    CGFloat width = imageSize.width;
    CGFloat height = imageSize.height;
    CGFloat targetWidth = targetSize.width;
    CGFloat targetHeight = targetSize.height;
    CGFloat scaleFactor = 0.0;
    CGFloat scaledWidth = targetWidth;
    CGFloat scaledHeight = targetHeight;
    CGPoint thumbnailPoint = CGPointMake(0.0,0.0);
    if (CGSizeEqualToSize(imageSize, targetSize) == NO)
    {
        CGFloat widthFactor = targetWidth / width;
        CGFloat heightFactor = targetHeight / height;
        
        if (widthFactor > heightFactor)
            scaleFactor = widthFactor; // scale to fit height
        else
            scaleFactor = heightFactor; // scale to fit width
        scaledWidth  = width * scaleFactor;
        scaledHeight = height * scaleFactor;
        
        // center the image
        if (widthFactor > heightFactor)
        {
            thumbnailPoint.y = (targetHeight - scaledHeight) * 0.5;
        }
        else
            if (widthFactor < heightFactor)
            {
                thumbnailPoint.x = (targetWidth - scaledWidth) * 0.5;
            }
    }
    UIGraphicsBeginImageContext(targetSize); // this will crop
    CGRect thumbnailRect = CGRectZero;
    thumbnailRect.origin = thumbnailPoint;
    thumbnailRect.size.width  = scaledWidth;
    thumbnailRect.size.height = scaledHeight;
    
    [sourceImage drawInRect:thumbnailRect];
    
    newImage = UIGraphicsGetImageFromCurrentImageContext();
    if(newImage == nil) NSLog(@"could not scale image");
    
    //pop the context to get back to the default
    UIGraphicsEndImageContext();
    return newImage;
}

/*
// Uncomment this method to specify if the specified item should be highlighted during tracking
- (BOOL)collectionView:(UICollectionView *)collectionView shouldHighlightItemAtIndexPath:(NSIndexPath *)indexPath {
	return YES;
}
*/

/*
// Uncomment this method to specify if the specified item should be selected
- (BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}
*/

/*
// Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
- (BOOL)collectionView:(UICollectionView *)collectionView shouldShowMenuForItemAtIndexPath:(NSIndexPath *)indexPath {
	return NO;
}

- (BOOL)collectionView:(UICollectionView *)collectionView canPerformAction:(SEL)action forItemAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender {
	return NO;
}

- (void)collectionView:(UICollectionView *)collectionView performAction:(SEL)action forItemAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender {
	
}
*/

@end
