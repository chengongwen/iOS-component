//
//  UUPhotoActionSheet.h
//  UUPhotoActionSheet
//
//  Created by zhangyu on 15/7/10.
//  Copyright (c) 2015年 zhangyu. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kNotificationSendPhotos @"NotificationSendPhotos"

@class UUPhotoActionSheet;

@protocol UUPhotoActionSheetDelegate < NSObject >

@optional

- (void)actionSheetDidFinished:(NSArray *)objs;

@end

@interface UUPhotoActionSheet : UIView

/**
 *  初始化UUPhotoActionSheetView
 *
 *  @param maxSelected 选择最多图片数量（maxSelected == 0,则取最大范围 LONG_MAX ）
 *  @param weakSuper   父视图
 *
 *  @return self
 */

- (instancetype)initWithMaxSelected:(NSInteger)maxSelected delegate:(id<UUPhotoActionSheetDelegate>)delegate weakSuper:(id)weakSuper;

/**
 *  显示UUPhotoActionSheetView
 */
- (void)showAnimation;

/**
 *  隐藏UUPhotoActionSheetView
 */
- (void)cancelAnimation;

@end


