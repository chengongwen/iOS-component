//
//  DemoViewController.m
//  UUPhotoActionSheet
//
//  Created by zhangyu on 15/7/10.
//  Copyright (c) 2015年 zhangyu. All rights reserved.
//

#import "DemoViewController.h"
#import "UUPhotoActionSheet.h"
#import "UUPhoto-Macros.h"
#import "UUPhoto-Import.h"

@interface DemoViewController() < UUPhotoActionSheetDelegate >

@property (nonatomic, strong) UUPhotoActionSheet *sheet;

@end

@implementation DemoViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.navigationItem.title = @"UUPhotoActionSheetDemo";
    
    _sheet = [[UUPhotoActionSheet alloc] initWithMaxSelected:0 delegate:self weakSuper:self];
    
//    [self.view addSubview:_sheet];
    [self.navigationController.view addSubview:_sheet];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Event Response

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{

    [_sheet showAnimation];
}

#pragma mark - UUPhotoActionSheetDelegate

- (void)actionSheetDidFinished:(NSArray *)objs {
    
    NSString *mesg = [NSString stringWithFormat:@"已发送 %lu 图片",(unsigned long)objs.count];

    UIAlertView *alter = [[UIAlertView alloc] initWithTitle:nil message:mesg delegate:nil cancelButtonTitle:@"ok" otherButtonTitles: nil];
    [alter show];
}

@end
