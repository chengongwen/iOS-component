//
//  ViewController.m
//  ShowPicturesView
//
//  Created by pantianxiang on 15/6/16.
//  Copyright (c) 2015年 元善科技. All rights reserved.
//

#import "ViewController.h"
#import "ShowPicturesView.h"

@interface ViewController ()

@property(nonatomic, retain) ShowPicturesView *showPictures;

@end

@implementation ViewController
@synthesize showPictures = _showPictures;

- (void)dealloc
{
    [_showPictures release];
    [super dealloc];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton *btnShow = [[UIButton alloc]initWithFrame:CGRectMake(30, 70, 60, 40)];
    [btnShow setTitle:@"Show" forState:UIControlStateNormal];
    [btnShow setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btnShow setBackgroundColor:[UIColor grayColor]];
    [btnShow addTarget:self action:@selector(show:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btnShow];
    [btnShow release];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)show:(id)sender
{
    NSArray *images = [NSArray arrayWithObjects:[UIImage imageNamed:@"6.jpg"],[UIImage imageNamed:@"1.jpg"],[UIImage imageNamed:@"2.jpg"],[UIImage imageNamed:@"3.jpg"],[UIImage imageNamed:@"4.jpg"],[UIImage imageNamed:@"5.jpg"],[UIImage imageNamed:@"0.jpg"],nil];
    
    //无动画
//    ShowPicturesView *showPictures = [[ShowPicturesView alloc]initWithImages:images minScale:1.f maxScale:3.f];
    
    //有动画
    ShowPicturesView *showPictures = [[ShowPicturesView alloc]initWithImages:images imageOriginalFrame:CGRectMake(30, 70, 60, 40) index:0 minScale:1.f maxScale:3.f];
    [self.view addSubview:showPictures];
    self.showPictures = showPictures;
    [showPictures release];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - 如果在屏幕选装的同时也要图片旋转，则需要完成下面的方法
- (BOOL)shouldAutorotate
{
    return YES;
}

- (void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
    [super willAnimateRotationToInterfaceOrientation:toInterfaceOrientation duration:duration];
    [_showPictures willRotationOrientation:toInterfaceOrientation];
}

//可以忽略此方法，应为iPhone在默认情况下也是返回UIInterfaceOrientationMaskAllButUpsideDown
- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskAllButUpsideDown;
}

@end
