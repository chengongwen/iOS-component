//
//  SZSlideSwitchManager.m
//  Lianxi
//
//  Created by admin on 15/5/14.
//  Copyright (c) 2015年 TIXA. All rights reserved.
//

#import "XYYSegmentControl.h"
#import "HMSegmentedControl.h"

static const CGFloat kHeightOfTopScrollView = 44.0f;

static BOOL _isScrolling = NO;

@interface XYYSegmentControl()

@property (nonatomic, strong) HMSegmentedControl *hmSegmentedControl;

@property (nonatomic, weak) NSTimer *corrUITimer;//纠正UI定时器

@end

@implementation XYYSegmentControl

- (void)dealloc {
    [self.corrUITimer invalidate];
}

#pragma mark - 初始化参数
- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self initValues];
        [self createRefreshUITimer];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame channelName:(NSArray *)channel source:(UIViewController *)srcController {
    return [self initWithFrame:frame channelName:channel source:srcController ableScroll:YES];;
}

- (instancetype)initWithFrame:(CGRect)frame channelName:(NSArray *)channel source:(UIViewController *)srcController ableScroll:(BOOL)ableScroll {
    self = [super initWithFrame:frame];
    if (self) {
        self.viewArray       = [[NSMutableArray alloc] init];
        
        self.channelName     = [channel copy];
        _segmentController = srcController;
        self.ableScroll = ableScroll;
        [self initValues];
        [self createRefreshUITimer];
    }
    return self;
}

- (void)createRefreshUITimer {
    NSTimer *correctUITimer = [NSTimer timerWithTimeInterval:1.0 target:self selector:@selector(correctUI) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:correctUITimer forMode:NSRunLoopCommonModes];
    self.corrUITimer = correctUITimer;
}

- (void)correctUI {
    if (_isScrolling == NO) {
        [self.rootScrollView setContentOffset:CGPointMake((_userSelectedChannelID) * self.bounds.size.width, 0) animated:YES];
    }
}

- (void)refreshTopUI{
    //下标y坐标偏移量
    self.hmSegmentedControl.selectionIndicator_Y = 4.0f;
    //下标宽度偏移量
    self.hmSegmentedControl.selectionIndicator_W_Offset = 28.f;
    //下标起始偏移量
    self.hmSegmentedControl.selectionIndicator_Index_Offset = 14.f;
    self.hmSegmentedControl.frame = CGRectMake(kScreenWidth/2-100, 4, 200, 40);
}

- (void)refreshTitles:(NSArray *)array{
    self.hmSegmentedControl.sectionTitles = array;
}

- (void)initValues
{
    [self createTopView];//创建分布式
    [self createRootView];
    _isBuildUI = NO;
}

-(void)setSegmentControlDelegate:(id<XYYSegmentControlDelegate>)segmentControlDelegate
{
    _segmentControlDelegate = segmentControlDelegate;
    [self buildUI];
}

-(void)setTabItemSelectionIndicatorColor:(UIColor *)tabItemSelectionIndicatorColor
{
    self.hmSegmentedControl.selectionIndicatorColor = tabItemSelectionIndicatorColor;
}

-(void)setTabItemNormalBackgroundColor:(UIColor *)tabItemNormalBackgroundColor
{
    self.hmSegmentedControl.backgroundColor = tabItemNormalBackgroundColor;
}

-(void)setTabItemNormalColor:(UIColor *)tabItemNormalColor
{
    self.hmSegmentedControl.titleTextAttributes = @{NSForegroundColorAttributeName : tabItemNormalColor} ;
}

-(void)setTabItemSelectedColor:(UIColor *)tabItemSelectedColor
{
    self.hmSegmentedControl.selectedTitleTextAttributes = @{NSForegroundColorAttributeName : tabItemSelectedColor};
}

-(void)setTabSelectionStyle:(XYYSegmentedControlSelectionStyle)tabSelectionStyle
{
    HMSegmentedControlSelectionStyle HMSelectionStyle;
    if (tabSelectionStyle == HMSegmentedControlSelectionStyleTextWidthStripe)
    {
        HMSelectionStyle = HMSegmentedControlSelectionStyleTextWidthStripe;
        
    }else if (tabSelectionStyle == HMSegmentedControlSelectionStyleFullWidthStripe)
    {
        HMSelectionStyle = HMSegmentedControlSelectionStyleFullWidthStripe;
        
    }else if (tabSelectionStyle == HMSegmentedControlSelectionStyleBox)
    {
        HMSelectionStyle = HMSegmentedControlSelectionStyleBox;
        
    }else {
        HMSelectionStyle = HMSegmentedControlSelectionStyleArrow;
        
    }
    self.hmSegmentedControl.selectionStyle = HMSelectionStyle;
}

-(void)setTabSelectionIndicatorLocation:(XYYSegmentedControlSelectionIndicatorLocation)tabSelectionIndicatorLocation
{
    HMSegmentedControlSelectionIndicatorLocation selectionIndicatorLocation;
    if (tabSelectionIndicatorLocation == HMSegmentedControlSelectionIndicatorLocationUp)
    {
        selectionIndicatorLocation = HMSegmentedControlSelectionIndicatorLocationUp;
        
    }else if (tabSelectionIndicatorLocation == HMSegmentedControlSelectionIndicatorLocationDown)
    {
        selectionIndicatorLocation = HMSegmentedControlSelectionIndicatorLocationDown;
        
    }else {
        selectionIndicatorLocation = HMSegmentedControlSelectionIndicatorLocationNone;
        
    }
    self.hmSegmentedControl.selectionIndicatorLocation = selectionIndicatorLocation;
}

/**
 *创建标签页
 */
-(void)createTopView
{
    CGFloat viewWidth = CGRectGetWidth(self.frame);
    self.hmSegmentedControl = [[HMSegmentedControl alloc] initWithFrame:CGRectMake(0, 0, viewWidth, kHeightOfTopScrollView)];
    self.hmSegmentedControl.sectionTitles = _channelName;
    self.hmSegmentedControl.selectedSegmentIndex = 0;
    self.hmSegmentedControl.selectionIndicatorHeight = 1.0f;
//    self.hmSegmentedControl.borderWidth = 30;
    
    //默认colors

    self.hmSegmentedControl.selectedTitleTextAttributes = @{NSForegroundColorAttributeName : kRGBColor_16BAND(0x1d1d1d)};
    self.hmSegmentedControl.titleTextAttributes = @{NSForegroundColorAttributeName : kRGBColor_16BAND(0x999999)};
    self.hmSegmentedControl.backgroundColor = [UIColor colorWithRed:0.7 green:0.7 blue:0.7 alpha:1];
    self.hmSegmentedControl.selectionIndicatorColor = kRGBColor_16BAND(0xffd44d);
    //默认style
    self.hmSegmentedControl.segmentWidthStyle = HMSegmentedControlSegmentWidthStyleFixed;
    self.hmSegmentedControl.selectionStyle = HMSegmentedControlSelectionStyleFullWidthStripe;
    self.hmSegmentedControl.selectionIndicatorLocation = HMSegmentedControlSelectionIndicatorLocationDown;
    //设置偏移
    //下标y坐标偏移量
    self.hmSegmentedControl.selectionIndicator_Y = 0;
    //下标宽度偏移量
    self.hmSegmentedControl.selectionIndicator_W_Offset = 0;
    //下标起始偏移量
    self.hmSegmentedControl.selectionIndicator_Index_Offset = 0;
    //下标高度
    self.hmSegmentedControl.selectionIndicatorHeight = 2.0;
    //title字体大小
    self.hmSegmentedControl.titleFontSize = 13;
    
    [self addSubview:self.hmSegmentedControl];
    
    __weak typeof(self) weakSelf = self;
    [self.hmSegmentedControl setIndexChangeBlock:^(NSInteger index) {
        [weakSelf segmentChanged:index];
    }];
}

/**
 *创建根视图
 */
-(void)createRootView
{
    //创建主滚动视图
    self.rootScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, kHeightOfTopScrollView , self.bounds.size.width, self.bounds.size.height - kHeightOfTopScrollView)];
    self.rootScrollView.delegate = self;
    self.rootScrollView.pagingEnabled = self.ableScroll;
    self.rootScrollView.userInteractionEnabled = YES;
    self.rootScrollView.bounces = NO;
    self.rootScrollView.showsHorizontalScrollIndicator = NO;
    self.rootScrollView.showsVerticalScrollIndicator = NO;
    self.rootScrollView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleWidth;
    [self addSubview:self.rootScrollView];
}


/**
 *  @author XuYong, 15-05-15 16:05:14
 *
 *  跳转指定segment
 *
 *  @param index 依次是当前的segmentBar
 */
-(void)changeSlideAtSegmentIndex:(NSInteger)index
{
    [self segmentChanged:index];
    [self.hmSegmentedControl setSelectedSegmentIndex:index animated:YES];
}

#pragma mark - 创建控件
/*!
 * @method 创建子视图UI
 * @abstract
 * @discussion
 * @param
 * @result
 */
- (void)buildUI
{
    NSUInteger number = [self.segmentControlDelegate numberOfTab:self];
    for (int i=0; i<number; i++) {
        UIViewController *vc = [self.segmentControlDelegate slideSwitchView:self viewOfTab:i];
        [_viewArray addObject:vc];
        [self.rootScrollView addSubview:vc.view];
        [_segmentController addChildViewController:vc];//增加子控制器
    }
    _isBuildUI = YES;
    //选中第一个view
    if (self.segmentControlDelegate && [self.segmentControlDelegate respondsToSelector:@selector(slideSwitchView:didselectTab:)]) {
        [self.segmentControlDelegate slideSwitchView:self didselectTab:_userSelectedChannelID ];
    }
    //创建完子视图UI才需要调整布局
    [self setNeedsLayout];
}



//当横竖屏切换时可通过此方法调整布局
- (void)layoutSubviews
{
    [super layoutSubviews];
    //创建完子视图UI才需要调整布局
    if (_isBuildUI) {
        //更新主视图的总宽度
        self.rootScrollView.contentSize = CGSizeMake(self.bounds.size.width * [_viewArray count], 0);
        
        //更新主视图各个子视图的宽度
        for (int i = 0; i < [_viewArray count]; i++) {
            UIViewController *listVC = _viewArray[i];
            listVC.view.frame = CGRectMake(0+self.rootScrollView.bounds.size.width*i, 0,
                                           self.rootScrollView.bounds.size.width, self.rootScrollView.bounds.size.height);
        }
        //滚动到选中的视图
        [self.rootScrollView setContentOffset:CGPointMake((_userSelectedChannelID )*self.bounds.size.width, 0) animated:YES];
    }
}


#pragma mark - 顶部滚动视图逻辑方法
- (void)segmentChanged:(NSInteger)index {
    [self.rootScrollView setContentOffset:CGPointMake(index * self.bounds.size.width, 0) animated:YES];
    if (self.segmentControlDelegate && [self.segmentControlDelegate respondsToSelector:@selector(slideSwitchView:didselectTab:)]) {
        [self.segmentControlDelegate slideSwitchView:self didselectTab:index];
    }
    _userSelectedChannelID = index;
}

- (void)segmentedControlChangedValue:(HMSegmentedControl *)segmentedControl {
    NSLog(@"Selected index %ld (via UIControlEventValueChanged)", (long)segmentedControl.selectedSegmentIndex);
}

- (void)uisegmentedControlChangedValue:(UISegmentedControl *)segmentedControl {
    NSLog(@"Selected index %ld", (long)segmentedControl.selectedSegmentIndex);
}

#pragma mark 主视图逻辑方法
//滚动视图开始时
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    if (scrollView == self.rootScrollView) {
        _userContentOffsetX = scrollView.contentOffset.x;
    }
}
//滚动视图结束
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
    [self performSelector:@selector(scrollViewDidEndScrollingAnimation:) withObject:nil afterDelay:0.3];
    _isScrolling = YES ;
    if (scrollView == self.rootScrollView) {
        //判断用户是否左滚动还是右滚动
        if (_userContentOffsetX < scrollView.contentOffset.x) {
            _isLeftScroll = YES;
        }
        else {
            _isLeftScroll = NO;
        }
    }
}
- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView {
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
    _isScrolling = NO ;
}

//滚动视图释放滚动
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    if (scrollView == self.rootScrollView && self.ableScroll) {
        //调整顶部滑条按钮状态
        NSUInteger index = (NSUInteger)scrollView.contentOffset.x/self.bounds.size.width ;
        [self segmentChanged:index];
        [self.hmSegmentedControl setSelectedSegmentIndex:index animated:YES];
    }
}

////传递滑动事件给下一层
//-(void)scrollHandlePan:(UIPanGestureRecognizer*) panParam
//{
//    //当滑道左边界时，传递滑动事件给代理
//    if(self.rootScrollView.contentOffset.x <= 0) {
//        if (self.slideSwitchViewDelegate
//            && [self.slideSwitchViewDelegate respondsToSelector:@selector(slideSwitchView:panLeftEdge:)]) {
//            [self.slideSwitchViewDelegate slideSwitchView:self panLeftEdge:panParam];
//        }
//    } else if(self.rootScrollView.contentOffset.x >= self.rootScrollView.contentSize.width - self.rootScrollView.bounds.size.width) {
//        if (self.slideSwitchViewDelegate
//            && [self.slideSwitchViewDelegate respondsToSelector:@selector(slideSwitchView:panRightEdge:)]) {
//            [self.slideSwitchViewDelegate slideSwitchView:self panRightEdge:panParam];
//        }
//    }
//}


/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */

@end
