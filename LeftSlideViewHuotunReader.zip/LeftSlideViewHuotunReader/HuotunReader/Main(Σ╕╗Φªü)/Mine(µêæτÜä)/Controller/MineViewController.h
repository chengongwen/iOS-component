//
//  MineViewController.h
//  HuotunReader
//
//  Created by huotun on 2017/10/23.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "BaseViewController.h"

@interface MineViewController : BaseViewController

@end
