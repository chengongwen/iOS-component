//
//  UserLoginInfo.m
//  HuotunReader
//
//  Created by huotun on 2017/10/26.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "UserLoginInfo.h"

@implementation UserLoginInfo

+ (instancetype)sharedObject {
    static UserLoginInfo *sharedInstance = nil;
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^(void){
        sharedInstance = [[UserLoginInfo alloc] init];
    });
    return sharedInstance;
}

@end
