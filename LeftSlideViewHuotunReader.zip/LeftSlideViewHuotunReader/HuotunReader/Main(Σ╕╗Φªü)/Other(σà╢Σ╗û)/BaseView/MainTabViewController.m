//
//  MainTabViewController.m
//  TabBarForiPhone
//
//  Created by chen on 14/7/20.
//  Copyright (c) 2014年 chen. All rights reserved.
//

// 版权属于原作者
// http://code4app.com (cn) http://code4app.net (en)
// 发布代码于最专业的源码分享网站: Code4App.com

#import "MainTabViewController.h"

#import "BookcaseViewController.h"
#import "BookstoreViewController.h"
#import "OriginatorViewController.h"
#import "MineViewController.h"

#pragma mark - Color

#define     SELECTED_TEXT_COLOR        [UIColor colorWithRed:31.0/255 green:185.0/255  blue:34.0/255 alpha:1.0f]
#define     DEFAULT_TEXT_COLOR         [UIColor grayColor]

@interface MainTabViewController ()

@end

@implementation MainTabViewController

- (void)viewDidLoad
{
    [super viewDidLoad];

    // 设置tabBar背景色
    //[self.tabBar setBackgroundImage:[UIImage imageNamed:@"tabbar_bg"]];
    [self.tabBar setBackgroundColor:[UIColor whiteColor]];
    
    //[[UITabBarItem appearance] setTitleTextAttributes:@{UITextAttributeFont : [UIFont systemFontOfSize:12],UITextAttributeTextColor : DEFAULT_TEXT_COLOR} forState:UIControlStateNormal];

    [[UITabBarItem appearance] setTitleTextAttributes:@{NSForegroundColorAttributeName : DEFAULT_TEXT_COLOR} forState:UIControlStateNormal];
    [[UITabBarItem appearance] setTitleTextAttributes:@{NSForegroundColorAttributeName : SELECTED_TEXT_COLOR} forState:UIControlStateSelected];
    
    BookcaseViewController *bookcaseCtrl = [[BookcaseViewController alloc] init];
    BookstoreViewController *bookstoreCtrl = [[BookstoreViewController alloc] init];
    OriginatorViewController *originatorCtrl = [[OriginatorViewController alloc] init];
    MineViewController *mineCtrl = [[MineViewController alloc] init];
    
    NSArray *titleList = @[@"书架",@"书城",@"原创",@"我的"];
    NSArray *imageList = @[@"tabbar_mainframe",@"tabbar_contacts",@"tabbar_discover",@"tabbar_me"];
    NSArray *selectedImageList = @[@"tabbar_mainframeHL",@"tabbar_contactsHL",@"tabbar_discoverHL",@"tabbar_meHL"];
    
    NSArray *viewControllers = @[bookcaseCtrl, bookstoreCtrl, originatorCtrl, mineCtrl];
    
    NSMutableArray *viewControllersArray = [[NSMutableArray alloc] init];
    [viewControllers enumerateObjectsUsingBlock:^(UIViewController *viewController, NSUInteger idx, BOOL *stop)
     {
         NSString *title = titleList[idx];
         UIImage *image = [[UIImage imageNamed:imageList[idx]] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
         UIImage *selectedImage = [[UIImage imageNamed:selectedImageList[idx]] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
         
         UITabBarItem *item = [[UITabBarItem alloc] initWithTitle:title image:image tag:idx];
         [item setSelectedImage:selectedImage];
         viewController.tabBarItem = item;
         
         BaseNavigationController *navCtrl = [[BaseNavigationController alloc] initWithRootViewController:viewController];
         if ([navCtrl respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
             //navCtrl.interactivePopGestureRecognizer.enabled = YES;
         }
         
         [viewControllersArray addObject:navCtrl];
     }];
    self.viewControllers = viewControllersArray;
    
    [self setSelectedIndex:0];
}

@end
