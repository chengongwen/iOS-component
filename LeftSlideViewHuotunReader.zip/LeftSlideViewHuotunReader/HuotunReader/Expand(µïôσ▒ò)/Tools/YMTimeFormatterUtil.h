//
//  YMTimeFormatterUtil.h
//  YueMao
//
//  Created by yuemao on 16/9/24.
//
//

#ifndef YMTimeFormatterUtil_h
#define YMTimeFormatterUtil_h

#ifdef __cplusplus
extern "C" {
#endif
    
const char* YMFormatTime(int millisecond) ;

#ifdef __cplusplus
}
#endif

#endif /* YMTimeFormatterUtil_h */
