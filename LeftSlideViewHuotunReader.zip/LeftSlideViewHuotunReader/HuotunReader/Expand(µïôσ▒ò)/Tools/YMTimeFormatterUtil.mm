//
//  YMTimeFormatterUtil.cpp
//  YueMao
//
//  Created by yuemao on 16/9/24.
//
//

#include "YMTimeFormatterUtil.h"
//#include <string.h>

const char* s_hourTable[] = {
    "00" ,"01" ,"02" ,"03" ,"04" ,"05" ,"06" ,"07" ,"08" ,"09" ,"10" ,"11" ,"12" ,"13" ,"14" ,"15" ,"16" ,"17" ,"18" ,"19" ,"20" ,"21" ,"22" ,"23"
} ;

const char* s_minuteSecondTable[60] = {
    "00:" ,"01:" ,"02:" ,"03:" ,"04:" ,"05:" ,"06:" ,"07:" ,"08:" ,"09:" ,"10:" ,"11:" ,"12:" ,"13:" ,"14:" ,"15:" ,"16:" ,"17:" ,"18:" ,"19:" ,
    "20:" ,"21:" ,"22:" ,"23:" ,"24:" ,"25:" ,"26:" ,"27:" ,"28:" ,"29:" ,"30:" ,"31:" ,"32:" ,"33:" ,"34:" ,"35:" ,"36:" ,"37:" ,"38:" ,"39:" ,
    "40:" ,"41:" ,"42:" ,"43:" ,"44:" ,"45:" ,"46:" ,"47:" ,"48:" ,"49:" ,"50:" ,"51:" ,"52:" ,"53:" ,"54:" ,"55:" ,"56:" ,"57:" ,"58:" ,"59:" ,
} ;
const char* s_minuteSecondTable1[60] = {
    "00" ,"01" ,"02" ,"03" ,"04" ,"05" ,"06" ,"07" ,"08" ,"09" ,"10" ,"11" ,"12" ,"13" ,"14" ,"15" ,"16" ,"17" ,"18" ,"19" ,
    "20" ,"21" ,"22" ,"23" ,"24" ,"25" ,"26" ,"27" ,"28" ,"29" ,"30" ,"31" ,"32" ,"33" ,"34" ,"35" ,"36" ,"37" ,"38" ,"39" ,
    "40" ,"41" ,"42" ,"43" ,"44" ,"45" ,"46" ,"47" ,"48" ,"49" ,"50" ,"51" ,"52" ,"53" ,"54" ,"55" ,"56" ,"57" ,"58" ,"59" ,
} ;

const char s_numberTable[] = {
    '0','1' ,'2' ,'3' ,'4' ,'5' ,'6' ,'7' ,'8' ,'9'
} ;

const char* YMFormatTime(int millisecond) {
    static char buffer[64] ;
    int hour = (millisecond % (100 * 60 * 60 * 60)) / (100 * 60 * 60);
    int minute = (millisecond % (100 * 60 * 60)) / (100 * 60);
    int second = (millisecond % (100 * 60)) / 100;
    int ms = millisecond % 100;
    int ms1 = ms/10 ;
    int ms0 = ms%10 ;
    
    //strcpy(buffer,s_minuteSecondTable[minute]) ;
    //strcat(buffer,s_minuteSecondTable[second]) ;
    if (hour > 0) {
        memcpy(buffer , s_minuteSecondTable[hour] ,3);
        memcpy(buffer + 3, s_minuteSecondTable[minute] ,6);
        memcpy(buffer + 6, s_minuteSecondTable1[second], 8);
//
////        buffer[9] = s_numberTable[ms1] ;
////        buffer[10] = s_numberTable[ms0] ;
//        buffer[9] = 0 ;
    }else{
        memcpy(buffer , s_minuteSecondTable[minute] ,3);
        memcpy(buffer +3 , s_minuteSecondTable[second], 3);
        
        buffer[6] = s_numberTable[ms1] ;
        buffer[7] = s_numberTable[ms0] ;
        buffer[8] = 0 ;
    }
    
    
    return buffer ;
}
