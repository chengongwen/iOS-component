//
//  NSString+UIUtil.m
//  YueMao
//
//  Created by HEYANG on 16/5/31.
//
//

#import "NSString+UIUtil.h"
#import <sys/utsname.h>
#import <sys/sysctl.h>
#import <net/if.h>
#import <net/if_dl.h>
                              
@implementation NSString (UIUtil)
+ (NSString *)URLEncodedString:(NSString *)str {
    NSString *encodedString = (NSString *)CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault,
                                                                                    
                                                                                    (CFStringRef)str,
                                                                                    
                                                                                    (CFStringRef)@"!$&'()*+,-./:;=?@_~%#[]",
                                                                                    
                                                                                    NULL,
                                                                                    
                                                                                    kCFStringEncodingUTF8));
    return encodedString;
}

+ (NSString *)URLDecodedString:(NSString *)str {
    NSString *decodedString = (__bridge_transfer NSString *)CFURLCreateStringByReplacingPercentEscapesUsingEncoding(NULL, (__bridge CFStringRef)str, CFSTR(""), CFStringConvertNSStringEncodingToEncoding(NSUTF8StringEncoding));
    
    return decodedString;
}

-(NSString *)changeNumberFormat
{
    if (self == nil) {
        return @"0";
    }
    int count = 0;
    long long int a = self.longLongValue;
    while (a != 0)
    {
        count++;
        a /= 10;
    }
    NSMutableString *string = [NSMutableString stringWithString:self];
    NSMutableString *newstring = [NSMutableString string];
    while (count > 3) {
        count -= 3;
        NSRange rang = NSMakeRange(string.length - 3, 3);
        NSString *str = [string substringWithRange:rang];
        [newstring insertString:str atIndex:0];
        [newstring insertString:@"," atIndex:0];
        [string deleteCharactersInRange:rang];
    }
    [newstring insertString:string atIndex:0];
    return newstring;
}

+ (NSString *)stringWithLevel:(uint16_t)level{
    NSString *imageName = nil;
    if (level == 150){
        imageName = @"icon_lv150";
    }else if (level == 149){
        imageName = @"icon_lv149";
    }else if (level == 148){
        imageName = @"icon_lv148";
    }else if (level == 147){
        imageName = @"icon_lv147";
    }else if (level == 146){
        imageName = @"icon_lv146";
    }else if (level == 145){
        imageName = @"icon_lv145";
    }else if (level == 144){
        imageName = @"icon_lv144";
    }else if (level == 143){
        imageName = @"icon_lv143";
    }else if (level == 142){
        imageName = @"icon_lv142";
    }else if (level == 141){
        imageName = @"icon_lv141";
    }else if (level >= 130){
        imageName = @"icon_lv140";
    }else if (level >= 120){
        imageName = @"icon_lv130";
    }else if (level >= 110){
        imageName = @"icon_lv120";
    }else if (level >= 100){
        imageName = @"icon_lv110";
    }else if (level >= 90){
        imageName = @"icon_lv100";
    }else if (level >= 80){
        imageName = @"icon_lv90";
    }else if (level >= 70){
        imageName = @"icon_lv80";
    }else if (level >= 60){
        imageName = @"icon_lv70";
    }else if (level >= 50){
        imageName = @"icon_lv60";
    }else if (level >= 40){
        imageName = @"icon_lv50";
    }else if (level >= 30){
        imageName = @"icon_lv40";
    }else if (level >= 20){
        imageName = @"icon_lv30";
    }else if (level >= 10){
        imageName = @"icon_lv20";
    }else if (level >= 0) {
        imageName = @"icon_lv10";
    }
    return imageName;
}
+ (NSString *)getShadowColorHexWithLevel:(uint16_t)level{
    NSString *colorHexStr = nil;
    if (level >= 141){
        colorHexStr = @"#000000";
    }else if (level >= 130){
        colorHexStr = @"#8703b4";
    }else if (level >= 120){
        colorHexStr = @"#6a2f77";
    }else if (level >= 110){
        colorHexStr = @"#9d3582";
    }else if (level >= 100){
        colorHexStr = @"#b00c52";
    }else if (level >= 90){
        colorHexStr = @"#d20713";
    }else if (level >= 80){
        colorHexStr = @"#e84702";
    }else if (level >= 70){
        colorHexStr = @"#e97b24";
    }else if (level >= 60){
        colorHexStr = @"#efa800";
    }else if (level >= 50){
        colorHexStr = @"#d9c100";
    }else if (level >= 40){
        colorHexStr = @"#32489d";
    }else if (level >= 30){
        colorHexStr = @"#165da4";
    }else if (level >= 20){
        colorHexStr = @"#0096b2";
    }else if (level >= 10){
        colorHexStr = @"#00b0a2";
    }else if (level >= 0) {
        colorHexStr = @"#29b976";
    }
    return colorHexStr;
}

+ (NSString *)getLabelColorHexWithLevel:(uint16_t)level{
    NSString *colorHexStr = nil;
    if (level >= 141){
        colorHexStr = @"#000000";
    }else if (level >= 130){
        colorHexStr = @"#ffcb00";
    }else if (level >= 120){
        colorHexStr = @"#ffcb00";
    }else if (level >= 110){
        colorHexStr = @"#ffcb00";
    }else if (level >= 0) {
        colorHexStr = @"#ffffff";
    }
    return colorHexStr;
}
-(NSInteger)getStringCharSize
{
    NSInteger strlength = 0;
    char* p = (char*)[self cStringUsingEncoding:NSUnicodeStringEncoding];
    for (int i=0 ; i<[self lengthOfBytesUsingEncoding:NSUnicodeStringEncoding] ;i++)
    {
        if (*p)
        {
            p++;
            strlength++;
        }
        else
        {
            p++;
        }
    }
    return (strlength+1)/2;
}


- (CGSize)getSizeWithFont:(UIFont *)font constrainedToSize:(CGSize)size{
    CGSize resultSize = CGSizeZero;
    if (self.length <= 0) {
        return resultSize;
    }
    resultSize = [self boundingRectWithSize:size
                                    options:(NSStringDrawingUsesFontLeading | NSStringDrawingUsesLineFragmentOrigin)
                                 attributes:@{NSFontAttributeName: font}
                                    context:nil].size;
    resultSize = CGSizeMake(MIN(size.width, ceilf(resultSize.width)), MIN(size.height, ceilf(resultSize.height)));
    return resultSize;
}

- (CGFloat)getHeightWithFont:(UIFont *)font constrainedToSize:(CGSize)size{
    return [self getSizeWithFont:font constrainedToSize:size].height;
}

- (CGFloat)getWidthWithFont:(UIFont *)font constrainedToSize:(CGSize)size{
    return [self getSizeWithFont:font constrainedToSize:size].width;
}

//识别机型
+ (NSString *)iphoneType{
    struct utsname systemInfo;
    
    uname(&systemInfo);
    
    NSString *platform = [NSString stringWithCString:systemInfo.machine encoding:NSASCIIStringEncoding];
    
    if ([platform isEqualToString:@"iPhone1,1"]) return @"iPhone 2G";
    
    if ([platform isEqualToString:@"iPhone1,2"]) return @"iPhone 3G";
    
    if ([platform isEqualToString:@"iPhone2,1"]) return @"iPhone 3GS";
    
    if ([platform isEqualToString:@"iPhone3,1"]) return @"iPhone 4";
    
    if ([platform isEqualToString:@"iPhone3,2"]) return @"iPhone 4";
    
    if ([platform isEqualToString:@"iPhone3,3"]) return @"iPhone 4";
    
    if ([platform isEqualToString:@"iPhone4,1"]) return @"iPhone 4S";
    
    if ([platform isEqualToString:@"iPhone5,1"]) return @"iPhone 5";
    
    if ([platform isEqualToString:@"iPhone5,2"]) return @"iPhone 5";
    
    if ([platform isEqualToString:@"iPhone5,3"]) return @"iPhone 5c";
    
    if ([platform isEqualToString:@"iPhone5,4"]) return @"iPhone 5c";
    
    if ([platform isEqualToString:@"iPhone6,1"]) return @"iPhone 5s";
    
    if ([platform isEqualToString:@"iPhone6,2"]) return @"iPhone 5s";
    
    if ([platform isEqualToString:@"iPhone7,1"]) return @"iPhone 6 Plus";
    
    if ([platform isEqualToString:@"iPhone7,2"]) return @"iPhone 6";
    
    if ([platform isEqualToString:@"iPhone8,1"]) return @"iPhone 6s";
    
    if ([platform isEqualToString:@"iPhone8,2"]) return @"iPhone 6s Plus";
    
    if ([platform isEqualToString:@"iPhone8,4"]) return @"iPhone SE";
    
    if ([platform isEqualToString:@"iPhone9,1"]) return @"iPhone 7";
    
    if ([platform isEqualToString:@"iPhone9,2"]) return @"iPhone 7 Plus";
    
    if ([platform isEqualToString:@"iPod1,1"]) return @"iPod Touch 1G";
    
    if ([platform isEqualToString:@"iPod2,1"]) return @"iPod Touch 2G";
    
    if ([platform isEqualToString:@"iPod3,1"]) return @"iPod Touch 3G";
    
    if ([platform isEqualToString:@"iPod4,1"]) return @"iPod Touch 4G";
    
    if ([platform isEqualToString:@"iPod5,1"]) return @"iPod Touch 5G";
    
    if ([platform isEqualToString:@"iPad1,1"]) return @"iPad 1G";
    
    if ([platform isEqualToString:@"iPad2,1"]) return @"iPad 2";
    
    if ([platform isEqualToString:@"iPad2,2"]) return @"iPad 2";
    
    if ([platform isEqualToString:@"iPad2,3"]) return @"iPad 2";
    
    if ([platform isEqualToString:@"iPad2,4"]) return @"iPad 2";
    
    if ([platform isEqualToString:@"iPad2,5"]) return @"iPad Mini 1G";
    
    if ([platform isEqualToString:@"iPad2,6"]) return @"iPad Mini 1G";
    
    if ([platform isEqualToString:@"iPad2,7"]) return @"iPad Mini 1G";
    
    if ([platform isEqualToString:@"iPad3,1"]) return @"iPad 3";
    
    if ([platform isEqualToString:@"iPad3,2"]) return @"iPad 3";
    
    if ([platform isEqualToString:@"iPad3,3"]) return @"iPad 3";
    
    if ([platform isEqualToString:@"iPad3,4"]) return @"iPad 4";
    
    if ([platform isEqualToString:@"iPad3,5"]) return @"iPad 4";
    
    if ([platform isEqualToString:@"iPad3,6"]) return @"iPad 4";
    
    if ([platform isEqualToString:@"iPad4,1"]) return @"iPad Air";
    
    if ([platform isEqualToString:@"iPad4,2"]) return @"iPad Air";
    
    if ([platform isEqualToString:@"iPad4,3"]) return @"iPad Air";
    
    if ([platform isEqualToString:@"iPad4,4"]) return @"iPad Mini 2G";
    
    if ([platform isEqualToString:@"iPad4,5"]) return @"iPad Mini 2G";
    
    if ([platform isEqualToString:@"iPad4,6"])  return @"iPad Mini 2G";
    
    if ([platform isEqualToString:@"i386"])  return @"iPhone Simulator";

    if ([platform isEqualToString:@"x86_64"])  return @"iPhone Simulator";
    
    return platform;
    
}

//mac地址
+ (NSString *)macAddress{
    int                 mib[6];
    size_t              len;
    char                *buf;
    unsigned char       *ptr;
    struct if_msghdr    *ifm;
    struct sockaddr_dl  *sdl;
    
    mib[0] = CTL_NET;
    mib[1] = AF_ROUTE;
    mib[2] = 0;
    mib[3] = AF_LINK;
    mib[4] = NET_RT_IFLIST;
    
    if ((mib[5] = if_nametoindex("en0")) == 0) {
        printf("Error: if_nametoindex error/n");
        return NULL;
    }
    
    if (sysctl(mib, 6, NULL, &len, NULL, 0) < 0) {
        printf("Error: sysctl, take 1/n");
        return NULL;
    }
    
    if ((buf = malloc(len)) == NULL) {
        printf("Could not allocate memory. error!/n");
        return NULL;
    }
    
    if (sysctl(mib, 6, buf, &len, NULL, 0) < 0) {
        printf("Error: sysctl, take 2");
        return NULL;
    }
    
    ifm = (struct if_msghdr *)buf;
    sdl = (struct sockaddr_dl *)(ifm + 1);
    ptr = (unsigned char *)LLADDR(sdl);
    NSString *outstring = [NSString stringWithFormat:@"%02x:%02x:%02x:%02x:%02x:%02x", *ptr, *(ptr+1), *(ptr+2), *(ptr+3), *(ptr+4), *(ptr+5)];
    
    NSLog(@"outString:%@", outstring);
    
    free(buf);
    
    return [outstring uppercaseString];
}

@end
