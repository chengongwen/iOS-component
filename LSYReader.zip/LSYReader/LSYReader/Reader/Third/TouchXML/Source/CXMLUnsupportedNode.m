#import "CXMLUnsupportedNode.h"

@implementation CXMLUnsupportedNode

@end
