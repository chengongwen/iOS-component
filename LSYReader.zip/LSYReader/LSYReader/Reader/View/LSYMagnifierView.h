//
//  LSYMagnifierView.h
//  LSYReader
//
//  Created by Labanotation on 16/6/12.
//  Copyright © 2016年 okwei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LSYMagnifierView : UIView
@property (nonatomic,weak) UIView *readView;
@property (nonatomic) CGPoint touchPoint;
@end
