//
//  LSYReadConfig.h
//  LSYReader
//
//  Created by Labanotation on 16/5/30.
//  Copyright © 2016年 okwei. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum : NSUInteger {
    FontNameTypeSystem,   // 系统
    FontNameTypeItalic,   //  黑体 "EuphemiaUCAS-Italic"
    FontNameTypeAmLight,  //  楷体 "AmericanTypewriter-Light"
    FontNameTypePapyrus   //  宋体 "Papyrus"
} FontNameType;

@interface LSYReadConfig : NSObject<NSCoding>
+(instancetype)shareInstance;

@property (nonatomic) CGFloat fontSize;
@property (nonatomic) CGFloat lineSpace;
@property (nonatomic,strong) UIColor *fontColor;
@property (nonatomic,strong) UIColor *theme;
@property (nonatomic,assign) FontNameType fontNameType;

- (NSString *)getFontName;

@end
