//
//  AppDelegate.h
//  HuotunReader
//
//  Created by chengongwen on 2017/10/23.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <TencentOpenAPI/TencentOAuth.h>
#import "AppConfig.h"

@class MainTabViewController;
@class ECSlidingViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) MainTabViewController *tabBarCtrl;

@property (nonatomic, strong) NSString *apiURL;
@property (nonatomic, strong) NSString *wwwURL;
@property (nonatomic, strong) NSString *imgURL;

@property (nonatomic, assign) LoginPlatform platform;    /** 平台登录方式 */
@property (nonatomic, strong) TencentOAuth *tencentOAuth;

@property (nonatomic, strong) NSString *account;

+ (AppDelegate *)shareAppDelegate;

@end

