//
//  AppDelegate.m
//  HuotunReader
//
//  Created by chengongwen on 2017/10/23.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "AppDelegate.h"
#import "MainTabViewController.h"
#import "WBApiManager.h"
#import "WXApiManager.h"
#import "QQApiManager.h"

#import "DatabaseManager.h"
#import "CatalogueObject.h"
#import "ChapterObject.h"

#import "LaunchAd.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    
    self.account = @"huotun";
    
    MainTabViewController *tabBarCtrl = [[MainTabViewController alloc] init];
    self.tabBarCtrl = tabBarCtrl;
    
    // 第一次加载模拟数据
    BOOL firstLaunch = [[NSUserDefaults standardUserDefaults] boolForKey:@"firstLaunch"];
    if (!firstLaunch) {
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"firstLaunch"];
        
        // 插入一本书籍到数据库中
        CatalogueObject *catalogueObject1 = [[CatalogueObject alloc] init];
        catalogueObject1.catalogueId = @"book1";
        catalogueObject1.author = @"(苏)尼古拉·奥斯特洛夫斯基";
        catalogueObject1.account = @"huotun";
        catalogueObject1.title = @"钢铁是怎样炼成的";
        catalogueObject1.currentProgress =  0.0;
        catalogueObject1.thumbImageURL = @"http://book.img.ireader.com/group6/M00/34/C0/CmQUN1X2y8-EHa9tAAAAAJatZXg906931823.jpg";
        catalogueObject1.updateTime = [NSDate date];
        [[DatabaseManager shareInstance] insertCatalogueTable:catalogueObject1];
        
        NSURL *fileURL = [[NSBundle mainBundle] URLForResource:@"序言" withExtension:@"txt"];
        NSData *data = [NSData dataWithContentsOfURL:fileURL];
        ChapterObject *chapterObject = [[ChapterObject alloc] init];
        chapterObject.catalogueId = @"book1";
        chapterObject.chapterNum = 0;
        chapterObject.title = @"序言";
        [[DatabaseManager shareInstance] insertChapterTable:chapterObject data:data];
        
        for (int i = 1; i <= 99; i++ ) {
            int randowIndex = i %3;
            if ( randowIndex == 1) {
                NSURL *fileURL = [[NSBundle mainBundle] URLForResource:@"第一章" withExtension:@"txt"];
                NSData *data = [NSData dataWithContentsOfURL:fileURL];
                ChapterObject *chapterObject = [[ChapterObject alloc] init];
                chapterObject.catalogueId = @"book1";
                chapterObject.chapterNum = i;
                chapterObject.title = [NSString stringWithFormat:@"%i 第一章 白发",i];
                [[DatabaseManager shareInstance] insertChapterTable:chapterObject data:data];
            }
            else if (randowIndex == 2) {
                NSURL *fileURL = [[NSBundle mainBundle] URLForResource:@"第二章" withExtension:@"txt"];
                NSData *data = [NSData dataWithContentsOfURL:fileURL];
                ChapterObject *chapterObject = [[ChapterObject alloc] init];
                chapterObject.catalogueId = @"book1";
                chapterObject.chapterNum = i;
                chapterObject.title = [NSString stringWithFormat:@"%i 第二章 三叔的故事",i];
                [[DatabaseManager shareInstance] insertChapterTable:chapterObject data:data];
            }
            else {
                NSURL *fileURL = [[NSBundle mainBundle] URLForResource:@"第三章" withExtension:@"txt"];
                NSData *data = [NSData dataWithContentsOfURL:fileURL];
                ChapterObject *chapterObject = [[ChapterObject alloc] init];
                chapterObject.catalogueId = @"book1";
                chapterObject.chapterNum = i;
                chapterObject.title = [NSString stringWithFormat:@"%i 第三章 天眼",i];
                [[DatabaseManager shareInstance] insertChapterTable:chapterObject data:data];
            }
        }
        
        // 空数据
        ChapterObject *chapterObjectOther = [[ChapterObject alloc] init];
        chapterObjectOther.catalogueId = @"book1";
        chapterObjectOther.chapterNum = 100;
        chapterObjectOther.title = @"other";
        [[DatabaseManager shareInstance] insertChapterTable:chapterObjectOther data:nil];
        
        // 插入一本书籍到数据库中
        CatalogueObject *catalogueObject2 = [[CatalogueObject alloc] init];
        catalogueObject2.catalogueId = @"book2";
        catalogueObject2.author = @"汤木";
        catalogueObject2.account = @"huotun";
        catalogueObject2.title = @"将来的你，一定会感谢现在拼命的自己";
        catalogueObject2.currentProgress =  0.0;
        catalogueObject2.thumbImageURL = @"http://book.img.ireader.com/group6/M00/50/A2/CmQUOFgArW2ENOnlAAAAADaTgWQ262611040.jpg";
        catalogueObject2.updateTime = [NSDate date];
        [[DatabaseManager shareInstance] insertCatalogueTable:catalogueObject2];
        
        for (int i = 0; i < 10; i++ ) {
            int randowIndex = i %3;
            if ( randowIndex == 0) {
                NSURL *fileURL = [[NSBundle mainBundle] URLForResource:@"第一章" withExtension:@"txt"];
                NSData *data = [NSData dataWithContentsOfURL:fileURL];
                ChapterObject *chapterObject = [[ChapterObject alloc] init];
                chapterObject.catalogueId = @"book2";
                chapterObject.chapterNum = i;
                chapterObject.title = [NSString stringWithFormat:@"%i 第一章 白发",i];
                [[DatabaseManager shareInstance] insertChapterTable:chapterObject data:data];
            }
            else if (randowIndex == 1) {
                NSURL *fileURL = [[NSBundle mainBundle] URLForResource:@"第二章" withExtension:@"txt"];
                NSData *data = [NSData dataWithContentsOfURL:fileURL];
                ChapterObject *chapterObject = [[ChapterObject alloc] init];
                chapterObject.catalogueId = @"book2";
                chapterObject.chapterNum = i;
                chapterObject.title = [NSString stringWithFormat:@"%i 第二章 三叔的故事",i];
                [[DatabaseManager shareInstance] insertChapterTable:chapterObject data:data];
            }
            else {
                NSURL *fileURL = [[NSBundle mainBundle] URLForResource:@"第三章" withExtension:@"txt"];
                NSData *data = [NSData dataWithContentsOfURL:fileURL];
                ChapterObject *chapterObject = [[ChapterObject alloc] init];
                chapterObject.catalogueId = @"book2";
                chapterObject.chapterNum = i;
                chapterObject.title = [NSString stringWithFormat:@"%i 第三章 天眼",i];
                [[DatabaseManager shareInstance] insertChapterTable:chapterObject data:data];
            }
        }
        
        // 插入一本书籍到数据库中
        CatalogueObject *catalogueObject3 = [[CatalogueObject alloc] init];
        catalogueObject3.account = @"huotun";
        catalogueObject3.catalogueId = @"book3";
        catalogueObject3.author = @"武志红";
        catalogueObject3.title = @"每一种孤独都有陪伴";
        catalogueObject3.currentProgress =  0.0;
        catalogueObject3.thumbImageURL = @"http://bookbk.img.ireader.com/group6/M00/2D/24/CmQUN1X2LVmEcTt1AAAAAOlQJyw691559714.jpg";
        catalogueObject3.updateTime = [NSDate date];
        [[DatabaseManager shareInstance] insertCatalogueTable:catalogueObject3];
        
        for (int i = 0; i < 5; i++ ) {
            int randowIndex = i %3;
            if ( randowIndex == 0) {
                NSURL *fileURL = [[NSBundle mainBundle] URLForResource:@"第一章" withExtension:@"txt"];
                NSData *data = [NSData dataWithContentsOfURL:fileURL];
                ChapterObject *chapterObject = [[ChapterObject alloc] init];
                chapterObject.catalogueId = @"book3";
                chapterObject.chapterNum = i;
                chapterObject.title = [NSString stringWithFormat:@"%i 第一章 白发",i];
                [[DatabaseManager shareInstance] insertChapterTable:chapterObject data:data];
            }
            else if (randowIndex == 1) {
                NSURL *fileURL = [[NSBundle mainBundle] URLForResource:@"第二章" withExtension:@"txt"];
                NSData *data = [NSData dataWithContentsOfURL:fileURL];
                ChapterObject *chapterObject = [[ChapterObject alloc] init];
                chapterObject.catalogueId = @"book3";
                chapterObject.chapterNum = i;
                chapterObject.title = [NSString stringWithFormat:@"%i 第二章 三叔的故事",i];
                [[DatabaseManager shareInstance] insertChapterTable:chapterObject data:data];
            }
            else {
                NSURL *fileURL = [[NSBundle mainBundle] URLForResource:@"第三章" withExtension:@"txt"];
                NSData *data = [NSData dataWithContentsOfURL:fileURL];
                ChapterObject *chapterObject = [[ChapterObject alloc] init];
                chapterObject.catalogueId = @"book3";
                chapterObject.chapterNum = i;
                chapterObject.title = [NSString stringWithFormat:@"%i 第三章 天眼",i];
                [[DatabaseManager shareInstance] insertChapterTable:chapterObject data:data];
            }
        }
    }
    
    // 加载广告
    //[[LaunchAd shareLaunchAdManager] asyncLaunchAdMesg];
    
    self.window.rootViewController = tabBarCtrl;
    [self.window makeKeyAndVisible];
    
    return YES;
}

#pragma mark - Static
+ (AppDelegate *)shareAppDelegate {
    return (AppDelegate *)([UIApplication sharedApplication].delegate);
}

- (void)officialServer {
    self.apiURL = @"http://api.i.1miaobang.com/api";
    self.wwwURL = @"http://www.i.1miaobang.com";
    self.imgURL = @"http://img.i.1miaobang.com";
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
