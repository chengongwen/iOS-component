//
//  LeftMenuViewController.h
//  HuotunReader
//
//  Created by chengongwen on 2017/11/10.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "BaseViewController.h"

@interface LeftMenuViewController : BaseViewController

@end
