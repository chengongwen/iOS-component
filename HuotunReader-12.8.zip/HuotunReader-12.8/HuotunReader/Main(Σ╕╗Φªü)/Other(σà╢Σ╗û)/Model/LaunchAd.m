//
//  LaunchAd.m
//  YueMao
//
//  Created by chengongwen on 2016/12/23.
//
//

#import "LaunchAd.h"
#import "NSString+MD5.h"
#import "MJExtension.h"
#import "NetWorkTool.h"

@implementation LaunchAdModel

MJCodingImplementation

@end

@implementation LaunchAd

+ (instancetype)shareLaunchAdManager {
    static LaunchAd *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[LaunchAd alloc] init];
        [instance reloadLaunchAdMegs];
    });
    return instance;
}

- (void)asyncLaunchAdMesg {
    if (!_timer) {
        _timer = [NSTimer scheduledTimerWithTimeInterval:5.0f target:self selector:@selector(asynDownload) userInfo:nil repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];
    }
}

- (void)stop {
    if (_timer) {
        [_timer invalidate];
        _timer = nil;
    }
}

- (void)asynDownload {
    if (self.isDownloadFinish) {
        [self stop];
    }
    else {
        if ([NetWorkTool isNetworkEnable]) {
            [self doGetLaunchAdMegs];
        }
    }
}

/**
 *  房间信息公告
 */
- (void)doGetLaunchAdMegs {
    
    self.isDownloadFinish = YES;
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSNumber *type = [NSNumber numberWithInt:0];
    NSNumber *timeStamp = [NSNumber numberWithLongLong:[[NSDate date] timeIntervalSince1970]];
    NSString *md5 = [NSString md5HexDigest:[NSString stringWithFormat:@"%@%@%@",IMAGE_SCREAT_KEY,type,timeStamp]];
    NSDictionary *params = @{
                             @"type":type,
                             @"timestamp":timeStamp,
                             @"md5":md5
                             };
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:params options:NSJSONWritingPrettyPrinted error:nil];
    NSString *param = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    
    NSString *url = KLaunchAdURL([AppDelegate shareAppDelegate].apiURL);
    
    [manager GET:url parameters:@{@"param":param} progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSString *result = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
        NSData *jsonData = [result dataUsingEncoding:NSUTF8StringEncoding];
        NSError *err;
        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&err];
        
        if ([[dic objectForKey:@"code"] intValue] == 0) {
            NSDictionary *megsDict = [dic objectForKey:@"loadingImg"];
            
            if (megsDict !=nil && megsDict != NULL) {
                [self saveLaunchAdMegs:megsDict];
            }
            self.isDownloadFinish = YES;
        }
        else {
            self.isDownloadFinish = NO;
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        DLog(@"%@",error);
        self.isDownloadFinish = NO;
    }];
}

// 默认获取保存的信息
- (void)reloadLaunchAdMegs {
    NSString *homePath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];    //获取应用Document目录路径
    NSString *fileName = [NSString stringWithFormat:@"launchAd.txt"];
    NSString *filePathName = [homePath stringByAppendingPathComponent:fileName];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL isFileExist = [fileManager fileExistsAtPath:filePathName];
    if(!isFileExist) {
        [fileManager createFileAtPath:filePathName contents:nil attributes:nil];
    }
    // 获取文件
    self.launchAdModel = [NSKeyedUnarchiver unarchiveObjectWithFile:filePathName];
}

// 保存的信息
- (void)saveLaunchAdMegs:(NSDictionary *)megsDict {
    
    self.launchAdModel = [LaunchAdModel mj_objectWithKeyValues:megsDict];
    
    NSString *homePath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];    //获取应用Document目录路径
    NSString *fileName = [NSString stringWithFormat:@"launchAd.txt"];
    NSString *filePathName = [homePath stringByAppendingPathComponent:fileName];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL isFileExist = [fileManager fileExistsAtPath:filePathName];
    if(!isFileExist) {
        [fileManager createFileAtPath:filePathName contents:nil attributes:nil];
    }
    // 写进文件
    [NSKeyedArchiver archiveRootObject:self.launchAdModel toFile:filePathName];
}

@end
