//
//  ChapterTableViewCell.h
//  HuotunReader
//
//  Created by chengongwen on 2017/11/23.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChapterTableViewCell : UITableViewCell

- (void)refreshCellWithObject:(NSString *)content;

@end
