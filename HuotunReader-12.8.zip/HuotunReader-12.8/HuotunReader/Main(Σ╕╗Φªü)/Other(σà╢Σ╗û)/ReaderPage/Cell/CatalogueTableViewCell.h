//
//  CatalogueTableViewCell.h
//  HuotunReader
//
//  Created by chengongwen on 2017/11/22.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ChapterObject;

@interface CatalogueTableViewCell : UITableViewCell

- (void)refreshCellWithObject:(ChapterObject *)model index:(NSInteger)index isSelected:(BOOL)isSelected;

@end
