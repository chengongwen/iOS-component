//
//  ReadScrollViewController.h
//  HuotunReader
//
//  Created by chengongwen on 2017/10/31.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "BaseViewController.h"

@class ReadModel;
@class CatalogueObject;

@interface ReadScrollViewController : BaseViewController

@property (nonatomic, strong) CatalogueObject *bookModel;
@property (nonatomic, assign) int selectChapter;      // 选择的阅读的章节数

@property (nonatomic, strong) ReadModel *model;

@end
