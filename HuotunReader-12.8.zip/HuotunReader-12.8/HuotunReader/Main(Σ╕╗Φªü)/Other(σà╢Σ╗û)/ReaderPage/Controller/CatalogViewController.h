//
//  CatalogViewController.h
//  HuotunReader
//
//  Created by chengongwen on 2017/10/31.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

@class ReadModel;
@class CatalogViewController;

@protocol CatalogViewControllerDelegate <NSObject>
@optional

- (void)catalog:(CatalogViewController *)catalog didSelectChapter:(NSUInteger)chapter page:(NSUInteger)page;
@end

@interface CatalogViewController : BaseViewController

@property (nonatomic, weak) id<CatalogViewControllerDelegate> catalogDelegate;

- (void)reloadData:(ReadModel *)readModel chapter:(NSInteger)chapter;

@end
