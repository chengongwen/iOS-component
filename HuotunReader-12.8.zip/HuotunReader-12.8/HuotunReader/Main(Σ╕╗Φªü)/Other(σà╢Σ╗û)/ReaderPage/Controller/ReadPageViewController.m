//
//  ReadPageViewController.m
//  HuotunReader
//
//  Created by chengongwen on 2017/10/31.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "ReadPageViewController.h"
#import "ReadViewController.h"
#import "CatalogViewController.h"
#import "ReadViewController.h"
#import "ChapterModel.h"
#import "ReadMenuView.h"
#import "CatalogViewController.h"
#import "ReadModel.h"
#import "CatalogueObject.h"

#import "BookCommentViewController.h"
#import "DatabaseManager.h"

#import <objc/runtime.h>

@interface ReadPageViewController() <UIPageViewControllerDelegate,UIPageViewControllerDataSource,UIGestureRecognizerDelegate,
                                     ReadViewControllerDelegate,MenuViewDelegate,CatalogViewControllerDelegate>
{
    NSUInteger _chapter;        // 当前显示的章节
    NSUInteger _page;           // 当前显示的页数
    NSUInteger _chapterChange;  // 将要变化的章节
    NSUInteger _pageChange;     // 将要变化的页数
    BOOL _isTransition;         // 是否开始翻页
    
    int _number; // 记录
}

@property (nonatomic, strong) UIPageViewController *pageViewController;
@property (nonatomic, strong) ReadViewController *readViewCtrl;   //当前阅读视图

@property (nonatomic, strong) ReadMenuView *menuView; //菜单栏
@property (nonatomic, strong) CatalogViewController *catalogController;   //侧边栏
@property (nonatomic, getter=isShowBar) BOOL showBar; //是否显示状态栏
@property (nonatomic, strong) BookCommentViewController *commentCtrl; // 评论视图
@property (nonatomic, strong) NSTimer *timer;
@end

@implementation ReadPageViewController

- (void)dealloc {
    _model = nil;
    _pageViewController = nil;
    _readViewCtrl = nil;
    _catalogController = nil;
    _commentCtrl = nil;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self vhl_setNavBarHidden:YES];
    [self.view setBackgroundColor:[ReadConfig shareInstance].theme];
    
    // 以下两行代码根据需要设置
    self.edgesForExtendedLayout = YES;
    self.automaticallyAdjustsScrollViewInsets=YES;
    // 设置CGRectZero从导航栏下开始计算
    if ([self respondsToSelector:@selector(setEdgesForExtendedLayout:)]) {
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }
    
    // 初始化缓存数据
    _model = [[ReadModel alloc] initWithCatalogue:self.bookModel selectChapter:self.selectChapter];
    
    // 初始化章节和页码
    _chapter = _model.record.currentChapter;
    _page = _model.record.currentPage;
    
    [self addChildViewController:self.pageViewController];
    [_pageViewController setViewControllers:@[[self readViewWithChapter:_chapter page:_page]] direction:UIPageViewControllerNavigationDirectionForward animated:YES completion:nil];
    
    [self.view addSubview:self.menuView];
    [self.view addGestureRecognizer:({
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(showToolMenu)];
        tap.delegate = self;
        tap;
    })];
    _menuView.recordModel = _model.record;
    
    _number = 1;
    [self addTimer];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    // 禁用返回手势
    if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.navigationController.interactivePopGestureRecognizer.enabled = NO;
    }
    // 异步加载所有数据
    [_model loadAllReadChapterList];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    // 开启返回手势
    if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.navigationController.interactivePopGestureRecognizer.enabled = YES;
    }
}

- (void)showToolMenu
{
    BOOL isMarked = FALSE;
    
    isMarked?(_menuView.topView.state=1): (_menuView.topView.state=0);
    [self.menuView showAnimation:YES];
}

#pragma mark - init

- (UIPageViewController *)pageViewController {
    if (!_pageViewController) {
        NSDictionary *option =[NSDictionary dictionaryWithObject:[NSNumber numberWithInteger:UIPageViewControllerSpineLocationMin] forKey:UIPageViewControllerOptionSpineLocationKey];
        _pageViewController = [[UIPageViewController alloc] initWithTransitionStyle:UIPageViewControllerTransitionStylePageCurl navigationOrientation:UIPageViewControllerNavigationOrientationHorizontal options:option];
        _pageViewController.navigationController.navigationBarHidden = YES;
        [_pageViewController vhl_setNavBarHidden:YES];
        _pageViewController.doubleSided = YES;
        _pageViewController.delegate = self;
        _pageViewController.dataSource = self;
        [self.view addSubview:_pageViewController.view];
    }
    return _pageViewController;
}

- (ReadMenuView *)menuView {
    if (!_menuView) {
        _menuView = [[ReadMenuView alloc] initWithFrame:self.view.bounds];
        _menuView.hidden = YES;
        _menuView.delegate = self;
        _menuView.recordModel = _model.record;
    }
    return _menuView;
}

- (CatalogViewController *)catalogController {
    if (!_catalogController) {
        _catalogController = [[CatalogViewController alloc] init];
        _catalogController.catalogDelegate = self;
    }
    return _catalogController;
}

- (BookCommentViewController *)commentCtrl {
    if (!_commentCtrl) {
        _commentCtrl = [[BookCommentViewController alloc] init];
    }
    return _commentCtrl;
}

#pragma mark - CatalogViewController Delegate
- (void)catalog:(CatalogViewController *)catalog didSelectChapter:(NSUInteger)chapter page:(NSUInteger)page
{
    [_menuView hiddenAnimation:NO];
    if (chapter == _chapter) {
        return;
    }
    [_pageViewController setViewControllers:@[[self readViewWithChapter:chapter page:page]] direction:UIPageViewControllerNavigationDirectionForward animated:NO completion:nil];
    
    [self updateReadModelWithChapter:chapter page:page];
}

#pragma mark -  UIGestureRecognizer Delegate
//解决TabView与Tap手势冲突
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    if ([NSStringFromClass([touch.view class]) isEqualToString:@"UITableViewCellContentView"]) {
        //return NO;
    }
    return YES;
}

- (BOOL)prefersStatusBarHidden
{
    return !_showBar;
}

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleDefault;
}

- (UIStatusBarAnimation)preferredStatusBarUpdateAnimation {
    return UIStatusBarAnimationSlide;
}

#pragma mark - Menu View Delegate
- (void)menuViewDidHidden:(ReadMenuView *)menu {
    _showBar = NO;
    [self setNeedsStatusBarAppearanceUpdate];
}

- (void)menuViewDidAppear:(ReadMenuView *)menu {
    _showBar = YES;
    [self setNeedsStatusBarAppearanceUpdate];
}

- (void)menuViewInvokeCatalog:(BottomMenuView *)bottomMenu {
    //[_menuView hiddenAnimation:NO];
    
    [self.catalogController reloadData:_model chapter:_chapter];
    [self.navigationController pushViewController:self.catalogController animated:YES];
}

- (void)menuViewJumpChapter:(NSUInteger)chapter page:(NSUInteger)page {
    [_pageViewController setViewControllers:@[[self readViewWithChapter:chapter page:page]] direction:UIPageViewControllerNavigationDirectionForward animated:NO completion:nil];
    [self updateReadModelWithChapter:chapter page:page];
}

- (void)menuViewFontSize  {
    [MBProgressHUD showMessageWindow:@"正在加载..."];
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        
        // 异步更新改变字体所有数据
        [_model allChapterListUpdateFontConfig];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            // 更新当前章节的布局
            [_model.record.chapterModel updateFontConfig];
            [_model.record.previousChapterModel updateFontConfig];
            [_model.record.nextChapterModel updateFontConfig];
            
            NSInteger page = (_model.record.currentPage > _model.record.chapterModel.pageCount-1) ? _model.record.chapterModel.pageCount-1 : _model.record.currentPage;
            
            [_pageViewController setViewControllers:@[[self readViewWithChapter:_model.record.currentChapter page:page]] direction:UIPageViewControllerNavigationDirectionForward animated:NO completion:nil];
            
            [self updateReadModelWithChapter:_model.record.currentChapter page:page];
            
            [MBProgressHUD hideHUDWindow];
        });
    });
}

- (void)menuViewMark:(TopMenuView *)topMenu {
    
}

- (void)menuViewJumpComment {
    [self.navigationController pushViewController:self.commentCtrl animated:YES];
}

- (void)menuViewJoinBookshelf:(TopMenuView *)topMenu {
    
}

- (void)menuViewBack:(TopMenuView *)topMenu {
    [self removeTimer];
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Create Read View Controller
- (ReadViewController *)readViewWithChapter:(NSUInteger)chapter page:(NSUInteger)page {
    DLog(@"chapter = %lu, page = %lu", chapter, page);
    
    // 章节与之前不一样，需要重新计算
    if (_model.record.currentChapter != chapter) {
        [_model reloadCacheDataWithChapter:chapter];
    }
    _readViewCtrl = [[ReadViewController alloc] init];
    _readViewCtrl.delegate = self;
    _readViewCtrl.recordModel = _model.record;
    _readViewCtrl.content = [_model.record.chapterModel stringOfPage:page];
    
    _readViewCtrl.title = _model.record.chapterModel.title;
    _readViewCtrl.pageCount = _model.record.chapterModel.pageCount;
    _readViewCtrl.page = page;
    
    return _readViewCtrl;
}

- (UIViewController *)readPageViewWithChapter:(NSUInteger)chapter page:(NSUInteger)page {
    DLog(@"chapterChange = %lu, pageChange = %lu", chapter, page);
    
    if (abs(_number) % 2 == 0) {
        UIViewController *tempCtrl = [[UIViewController alloc] init];
        tempCtrl.view.backgroundColor = [ReadConfig shareInstance].theme;
        tempCtrl.view.alpha = 0.95;
        return tempCtrl;
    }
    else {
        ChapterModel *chapterModel = [_model reloadDataWithChapter:chapter];
        _readViewCtrl = [[ReadViewController alloc] init];
        _readViewCtrl.delegate = self;
        _readViewCtrl.content = [chapterModel stringOfPage:page];
        _readViewCtrl.title = chapterModel.title;
        _readViewCtrl.pageCount = chapterModel.pageCount;
        _readViewCtrl.page = page;
    }
    
    return _readViewCtrl;
}

// 保存当前翻页的浏览记录
- (void)updateReadModelWithChapter:(NSUInteger)chapter page:(NSUInteger)page {
    _chapter = chapter;
    _page = page;
    
    _model.record.currentChapter = chapter;
    _model.record.currentPage = page;
    
    // 保存当前翻页的浏览记录
    [_model archivierChapter];
}

#pragma mark - Read View Controller Delegate
- (void)readViewEndEdit:(ReadViewController *)readView {
    for (UIGestureRecognizer *ges in self.pageViewController.view.gestureRecognizers) {
        if ([ges isKindOfClass:[UIPanGestureRecognizer class]]) {
            ges.enabled = YES;
            break;
        }
    }
}

- (void)readViewEditeding:(ReadViewController *)readView {
    for (UIGestureRecognizer *ges in self.pageViewController.view.gestureRecognizers) {
        if ([ges isKindOfClass:[UIPanGestureRecognizer class]]) {
            ges.enabled = NO;
            break;
        }
    }
}

#pragma mark - PageViewController DataSource
- (nullable UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(UIViewController *)viewController {
    
    if (_isTransition) {
        return nil;
    }
    _pageChange = _page;
    _chapterChange = _chapter;
    
    // 第一页
    if (_chapterChange == 0 && _pageChange == 0) {
        [MBProgressHUD showError:@"已经是第一章了"];
        return nil;
    }
    
    _number -= 1;
    
    if (_pageChange == 0) {
        _chapterChange--;
        _pageChange = _model.record.previousChapterModel.pageCount-1;
    }
    else {
        _pageChange--;
    }
    
    return [self readPageViewWithChapter:_chapterChange page:_pageChange];
}

- (nullable UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(UIViewController *)viewController {
    
    if (_isTransition) {
        return nil;
    }
    _pageChange = _page;
    _chapterChange = _chapter;
    
    // 最后一页,判断最后的一章是否为空
    if (_model.record.nextChapterModel.pageCount == 0) {
        if (_pageChange == _model.record.chapterModel.pageCount-1 && _chapterChange == _model.record.chapterCount-1) {
            [MBProgressHUD showError:@"已经是最后一章了"];
            return nil;
        }
    }
    else {
        if (_pageChange == _model.record.nextChapterModel.pageCount-1 && _chapterChange == _model.record.chapterCount-1) {
            return nil;
        }
    }
    
    _number += 1;
    
    if (_pageChange == _model.record.chapterModel.pageCount-1) {
        _chapterChange++;
        _pageChange = 0;
    }
    else {
        _pageChange++;
    }
    
    return [self readPageViewWithChapter:_chapterChange page:_pageChange];
}

#pragma mark - PageViewController Delegate
- (void)pageViewController:(UIPageViewController *)pageViewController didFinishAnimating:(BOOL)finished previousViewControllers:(NSArray *)previousViewControllers transitionCompleted:(BOOL)completed {
    
    _isTransition = !finished;
    
    // 没有翻页完成
    if (!completed) {
        ReadViewController *readView = previousViewControllers.firstObject;
        _readViewCtrl = readView;
        _page = readView.recordModel.currentPage;
        _chapter = readView.recordModel.currentChapter;
        _pageChange = _page;
        _chapterChange = _chapter;
    }
    else {
        // 章节与之前不一样，需要重新计算
        if (_model.record.currentChapter != _chapter) {
            [_model reloadCacheDataWithChapter:_chapterChange];
        }
        _chapter = _chapterChange;
        _page = _pageChange;
        _model.record.currentChapter = _chapter;
        _model.record.currentPage = _page;
        _readViewCtrl.recordModel = _model.record;
    }
    DLog(@"_chapter = %lu, _page = %lu", _chapter, _page);
    
    [self updateReadModelWithChapter:_chapter page:_page];
}

- (void)pageViewController:(UIPageViewController *)pageViewController willTransitionToViewControllers:(NSArray<UIViewController *> *)pendingViewControllers {
    _chapter = _chapterChange;
    _page = _pageChange;
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    _pageViewController.view.frame = self.view.frame;
    _menuView.frame = self.view.frame;
}

- (void)addTimer {
    if (!_timer) {
        _timer = [NSTimer timerWithTimeInterval:15.0f target:self selector:@selector(didChangeTime) userInfo:nil repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];
    }
}

- (void)didChangeTime {
    if (_readViewCtrl && [_readViewCtrl respondsToSelector:@selector(didChangeTime)]) {
        [_readViewCtrl didChangeTime];
    }
}

- (void)removeTimer {
    if (_timer) {
        [_timer invalidate];
        _timer = nil;
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
