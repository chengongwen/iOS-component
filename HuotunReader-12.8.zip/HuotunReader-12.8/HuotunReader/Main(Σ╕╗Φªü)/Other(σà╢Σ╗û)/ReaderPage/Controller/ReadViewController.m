//
//  ReadViewController.m
//  HuotunReader
//
//  Created by chengongwen on 2017/10/31.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "ReadViewController.h"
#import "ReadParser.h"
#import "ReadConfig.h"
#import "StatusTopView.h"
#import "StatusBottomView.h"

@interface ReadViewController ()

@property (nonatomic, strong) StatusTopView *statusTopView;         // 顶部栏
@property (nonatomic, strong) StatusBottomView *statusBottomView;   // 底部栏
@end

@implementation ReadViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self vhl_setNavBarHidden:YES];
    
    [self.view setBackgroundColor:[ReadConfig shareInstance].theme];
    [self.view addSubview:self.readView];
    [self.view addSubview:self.statusTopView];
    [self.view addSubview:self.statusBottomView];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeTheme:) name:kThemeNotification object:nil];
}

- (void)changeTheme:(NSNotification *)notifi {
    [ReadConfig shareInstance].theme = notifi.object;
    [self.view setBackgroundColor:[ReadConfig shareInstance].theme];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (ReadView *)readView {
    if (!_readView) {
        _readView = [[ReadView alloc] initWithFrame:GetReadTableViewFrame];
        ReadConfig *config = [ReadConfig shareInstance];
        _readView.frameRef = [ReadParser parserContent:_content config:config bouds:CGRectMake(0,0, _readView.frame.size.width, _readView.frame.size.height)];
        _readView.content = _content;
        _readView.delegate = self;
    }
    return _readView;
}

- (StatusTopView *)statusTopView {
    if (!_statusTopView) {
        _statusTopView = [[StatusTopView alloc] initWithFrame:CGRectMake(0, 10 + kNaviBarPostionY, ViewSize(self.view).width, TopSpacing)];
        
        // 顶部章节标题
        [_statusTopView updateTitle:self.title];
    }
    return _statusTopView;
}

- (StatusBottomView *)statusBottomView {
    if (!_statusBottomView) {
        _statusBottomView = [[StatusBottomView alloc] initWithFrame:CGRectMake(0, ViewSize(self.view).height - BottomSpacing, ViewSize(self.view).width, BottomSpacing)];
        
        // 底部栏页数
        [_statusBottomView updatePageCount:_pageCount page:_page];
    }
    return _statusBottomView;
}

- (void)readViewEditeding:(ReadViewController *)readView {
    if ([self.delegate respondsToSelector:@selector(readViewEditeding:)]) {
        [self.delegate readViewEditeding:self];
    }
}

- (void)readViewEndEdit:(ReadViewController *)readView {
    if ([self.delegate respondsToSelector:@selector(readViewEndEdit:)]) {
        [self.delegate readViewEndEdit:self];
    }
}

- (void)didChangeTime {
    if (_statusBottomView && [_statusBottomView respondsToSelector:@selector(didChangeTime)]) {
        [_statusBottomView didChangeTime];
    }
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
