//
//   BottomStatusView.h
//  HuotunReader
//
//  Created by chengongwen on 2017/11/3.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StatusBottomView : UIView

- (instancetype)initWithFrame:(CGRect)frame;

- (void)updatePageCount:(NSInteger)pageCount page:(NSInteger)page;

- (void)didChangeTime;

@end
