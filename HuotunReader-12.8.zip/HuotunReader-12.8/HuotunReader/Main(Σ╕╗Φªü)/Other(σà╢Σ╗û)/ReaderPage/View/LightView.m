//
//  LightView.m
//  HuotunReader
//
//  Created by chengongwen on 2017/11/20.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "LightView.h"
#import "ReadConfig.h"

@implementation LightView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self setBackgroundColor:kRGBColor(255, 255, 255)];
        [self setup];
    }
    return self;
}

//MARK: - ABOUT UI UI相关
- (void)setup {
    [self addSubview:self.titleLabel];
    [self addSubview:self.slider];
}

- (UILabel *)titleLabel {
    if (!_titleLabel) {
        _titleLabel = [UILabel labelWithTextColor:[UIColor blackColor] fontSize:kDESGIN_TRANSFORM_iPhone6(18)];
        _titleLabel.text = @"亮度";
    }
    return _titleLabel;
}

- (UISlider *)slider {
    if (!_slider) {
        _slider = [[UISlider alloc] init];
        _slider.value = [UIScreen mainScreen].brightness;
        _slider.minimumValue = 0.0;
        _slider.maximumValue = 1.0;
        _slider.minimumTrackTintColor = kRGBColor(227, 0, 0);
        _slider.maximumTrackTintColor = kRGBColor(225, 225, 225);
        //[_slider setThumbImage:[UIImage imageNamed:@"read_slider_circle"] forState:UIControlStateNormal];
        //[_slider setThumbImage:[UIImage imageNamed:@"read_slider_circle"] forState:UIControlStateHighlighted];
        [_slider addTarget:self action:@selector(sliderValueChanged:) forControlEvents:UIControlEventValueChanged];
    }
    return _slider;
}

//MARK: - ABOUT EVENTS 事件响应
- (void)sliderValueChanged:(UISlider *)slider{
    [UIScreen mainScreen].brightness = slider.value;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    _titleLabel.frame = CGRectMake(10, (ViewSize(self).height - 30) *0.5, 40, 30);
    _slider.frame = CGRectMake(DistanceFromLeftGuiden(_titleLabel), (ViewSize(self).height - 30) *0.5, ViewSize(self).width-60, 30);
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
