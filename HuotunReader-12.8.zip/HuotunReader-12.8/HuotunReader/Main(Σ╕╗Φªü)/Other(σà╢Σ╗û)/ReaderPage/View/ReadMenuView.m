//
//   ReadMenuView.m
//   Reader
//
//  Created by chengongwen on 2017/11/20.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "ReadMenuView.h"
#import "ReadConfig.h"
#import "BottomMenuView.h"
#import "ReadSettingView.h"
#import "ProgressView.h"


// 阅读页面动画的时间
CGFloat const kReadMenuAnimateDuration = 0.3f;

// TopView 高
//CGFloat const kReadMenuTopViewHeight = 64?88;
#define kReadMenuTopViewHeight  kNaviBarHeight

// BottomView 高
//CGFloat const kReadMenuBottomViewHeight = 112.f;
CGFloat const kReadMenuBottomViewHeight = 64.f;

// LightButton 高
CGFloat const kReadMenuProgressButtonWH = 64.f;

// SettingView 高
CGFloat const kReadMenuSettingViewHeight = 168.f;

@interface  ReadMenuView () 

@end

@implementation  ReadMenuView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setup];
    }
    return self;
}

- (void)setup {
    [self addSubview:self.backgroundView];
    [self addSubview:self.topView];
    [self addSubview:self.bottomView];
    [self addSubview:self.progressView];
    [self addSubview:self.settingView];
    [self addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hiddenSelf)]];
}

- (UIView *)backgroundView {
    if (!_backgroundView) {
        _backgroundView = [[UIView alloc] init];
        [_backgroundView setBackgroundColor:kRGBColorA(0, 0, 0, 0.05)];
    }
    return _backgroundView;
}

- (TopMenuView *)topView {
    if (!_topView) {
        _topView = [[TopMenuView alloc] init];
        _topView.delegate = self;
    }
    return _topView;
}

- (BottomMenuView *)bottomView {
    if (!_bottomView) {
        _bottomView = [[BottomMenuView alloc] init];
        _bottomView.delegate = self;
        _bottomView.readDelegate = self;
    }
    return _bottomView;
}

- (ProgressView *)progressView {
    if (!_progressView) {
        _progressView = [[ProgressView alloc] init];
        _progressView.delegate = self;
    }
    return _progressView;
}

- (ReadSettingView *)settingView {
    if (!_settingView) {
        _settingView = [[ReadSettingView alloc] init];
        _settingView.delegate = self;
    }
    return _settingView;
}

- (void)setRecordModel:(RecordModel *)recordModel {
    _recordModel = recordModel;
    _bottomView.readModel = recordModel;
}

#pragma mark -
#pragma mark -  ReadMenuViewDelegate
- (void)menuLightViewDidAppear {
    [self hiddenTopAnimation:YES];
    [self hiddenBottomAnimation:NO];
    [self showLightAnimation:YES];
    
    if ([self.delegate respondsToSelector:@selector(menuViewDidHidden:)]) {
        [self.delegate menuViewDidHidden:self];
    }
}

- (void)menuSettingViewDidAppear {
    [self hiddenTopAnimation:YES];
    [self hiddenBottomAnimation:NO];
    [self showSettingAnimation:YES];
    
    if ([self.delegate respondsToSelector:@selector(menuViewDidHidden:)]) {
        [self.delegate menuViewDidHidden:self];
    }
}

#pragma mark - 
#pragma mark -  MenuViewDelegate

- (void)menuViewInvokeCatalog:(BottomMenuView *)bottomMenu
{
    if ([self.delegate respondsToSelector:@selector(menuViewInvokeCatalog:)]) {
        [self.delegate menuViewInvokeCatalog:bottomMenu];
    }
}

- (void)menuViewJumpChapter:(NSUInteger)chapter page:(NSUInteger)page
{
    if ([self.delegate respondsToSelector:@selector(menuViewJumpChapter:page:)]) {
        [self.delegate menuViewJumpChapter:chapter page:page];
    }
}

-(void)menuViewFontSize
{
    if ([self.delegate respondsToSelector:@selector(menuViewFontSize)]) {
        [self.delegate menuViewFontSize];
    }
}

- (void)menuViewMark:(TopMenuView *)topMenu
{
    if ([self.delegate respondsToSelector:@selector(menuViewMark:)]) {
        [self.delegate menuViewMark:topMenu];
    }
}

- (void)menuViewBack:(TopMenuView *)topMenu
{
    if ([self.delegate respondsToSelector:@selector(menuViewBack:)]) {
        [self.delegate menuViewBack:topMenu];
    }
}

- (void)menuViewJoinBookshelf:(TopMenuView *)topMenu {
    if ([self.delegate respondsToSelector:@selector(menuViewJoinBookshelf:)]) {
        [self.delegate menuViewJoinBookshelf:topMenu];
    }
}

- (void)menuViewJumpComment {
    if ([self.delegate respondsToSelector:@selector(menuViewJumpComment)]) {
        [self.delegate menuViewJumpComment];
    }
}

#pragma mark -
- (void)hiddenSelf
{
    [self hiddenAnimation:YES];
}

- (void)showTopAnimation:(BOOL)animation {
    [UIView animateWithDuration:animation?kReadMenuAnimateDuration:0 animations:^{
        _topView.frame = CGRectMake(0, 0, ViewSize(self).width, kReadMenuTopViewHeight);
    } completion:^(BOOL finished) {
        
    }];
}

- (void)hiddenTopAnimation:(BOOL)animation
{
    [UIView animateWithDuration:animation?kReadMenuAnimateDuration:0 animations:^{
        _topView.frame = CGRectMake(0, -kReadMenuTopViewHeight, ViewSize(self).width, kReadMenuTopViewHeight);
    } completion:^(BOOL finished) {
        
    }];
}

- (void)showBottomAnimation:(BOOL)animation {
    [UIView animateWithDuration:animation?kReadMenuAnimateDuration:0 animations:^{
        _bottomView.frame = CGRectMake(0, ViewSize(self).height-kReadMenuBottomViewHeight, ViewSize(self).width,kReadMenuBottomViewHeight);
    } completion:^(BOOL finished) {
        
    }];
}

- (void)hiddenBottomAnimation:(BOOL)animation
{
    [UIView animateWithDuration:animation?kReadMenuAnimateDuration:0 animations:^{
        _bottomView.frame = CGRectMake(0, ViewSize(self).height, ViewSize(self).width,kReadMenuBottomViewHeight);
    } completion:^(BOOL finished) {
        
    }];
}

- (void)showLightAnimation:(BOOL)animation {
    _progressView.readModel = _recordModel;
    
    [UIView animateWithDuration:animation?kReadMenuAnimateDuration:0 animations:^{
        _progressView.frame = CGRectMake(0, ViewSize(self).height-kReadMenuProgressButtonWH, ViewSize(self).width,kReadMenuProgressButtonWH);
    } completion:^(BOOL finished) {
        
    }];
}

- (void)hiddenLightAnimation:(BOOL)animation
{
    [UIView animateWithDuration:animation?kReadMenuAnimateDuration:0 animations:^{
        _progressView.frame = CGRectMake(0, ViewSize(self).height, ViewSize(self).width, kReadMenuProgressButtonWH);
    } completion:^(BOOL finished) {
        
    }];
}

- (void)showSettingAnimation:(BOOL)animation {
    [UIView animateWithDuration:animation?kReadMenuAnimateDuration:0 animations:^{
        _settingView.frame = CGRectMake(0, ViewSize(self).height-kReadMenuSettingViewHeight, ViewSize(self).width,kReadMenuSettingViewHeight);
    } completion:^(BOOL finished) {
        
    }];
}

- (void)hiddenSettingAnimation:(BOOL)animation
{
    [UIView animateWithDuration:animation?kReadMenuAnimateDuration:0 animations:^{
        _settingView.frame = CGRectMake(0,ViewSize(self).height, ViewSize(self).width,kReadMenuSettingViewHeight);
    } completion:^(BOOL finished) {
        
    }];
}

- (void)showAnimation:(BOOL)animation
{
    self.hidden = NO;
    
    [self showTopAnimation:animation];
    [self showBottomAnimation:animation];
    
    if ([self.delegate respondsToSelector:@selector(menuViewDidAppear:)]) {
        [self.delegate menuViewDidAppear:self];
    }
}

- (void)hiddenAnimation:(BOOL)animation
{
    [UIView animateWithDuration:animation?kReadMenuAnimateDuration:0 animations:^{
        _topView.frame = CGRectMake(0, -kReadMenuTopViewHeight, ViewSize(self).width, kReadMenuTopViewHeight);
        _bottomView.frame = CGRectMake(0, ViewSize(self).height, ViewSize(self).width,kReadMenuBottomViewHeight);
        _progressView.frame = CGRectMake(0, ViewSize(self).height, ViewSize(self).width, kReadMenuProgressButtonWH);
        _settingView.frame = CGRectMake(0,ViewSize(self).height, ViewSize(self).width,kReadMenuSettingViewHeight);
        
    } completion:^(BOOL finished) {
        self.hidden = YES;
    }];
    if ([self.delegate respondsToSelector:@selector(menuViewDidHidden:)]) {
        [self.delegate menuViewDidHidden:self];
    }
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
//    if (@available(iOS 11.0, *)){
//        // do nothing.
//        // looks the layout of view in iOS 11 is different with iOS 10.
//    }
//    else {
        _backgroundView.frame = self.bounds;
        _topView.frame = CGRectMake(0, -kReadMenuTopViewHeight, ViewSize(self).width, kReadMenuTopViewHeight);
        _bottomView.frame = CGRectMake(0, ViewSize(self).height, ViewSize(self).width,kReadMenuBottomViewHeight);
        _progressView.frame = CGRectMake(0, ViewSize(self).height, ViewSize(self).width, kReadMenuProgressButtonWH);
        _settingView.frame = CGRectMake(0,ViewSize(self).height, ViewSize(self).width,kReadMenuSettingViewHeight);
//    }
}
@end
