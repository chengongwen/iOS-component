//
//  LightView.h
//  HuotunReader
//
//  Created by chengongwen on 2017/11/20.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LightView : UIView

@property (nonatomic, strong) UILabel *titleLabel;  // 标题
@property (nonatomic, strong) UISlider *slider;     // 进度条
@end
