//
//  ProgressView.m
//  HuotunReader
//
//  Created by chengongwen on 2017/12/2.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "ProgressView.h"
#import "ReadModel.h"
#import "ReadConfig.h"
#import "ReadUtilites.h"
#import "MenuViewDelegate.h"

@interface ProgressView()

@property (nonatomic, strong) ReadProgressView *progressView;
@property (nonatomic, strong) UIButton *minSpacing;
@property (nonatomic, strong) UIButton *mediuSpacing;
@property (nonatomic, strong) UIButton *maxSpacing;
@property (nonatomic, strong) UISlider *slider;
@property (nonatomic, strong) UIButton *lastChapter;
@property (nonatomic, strong) UIButton *nextChapter;
@end

@implementation ProgressView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setBackgroundColor:kRGBColor(255, 255, 255)];
        [self setup];
        
        // dealloc 移除监听  readModel.currentChapter,readModel.currentPage
        [self addObserver:self forKeyPath:@"readModel.currentChapter" options:NSKeyValueObservingOptionNew context:NULL];
        [self addObserver:self forKeyPath:@"readModel.currentPage" options:NSKeyValueObservingOptionNew context:NULL];
    }
    return self;
}

- (void)setup {
    [self addSubview:self.slider];
    [self addSubview:self.progressView];
    [self addSubview:self.lastChapter];
    [self addSubview:self.nextChapter];
}

- (void)setReadModel:(RecordModel *)readModel {
    _readModel = readModel;
    
    double chapterProgress = _readModel.currentChapter * 1.0/(_readModel.chapterCount *1.0);
    double pageProgress = _readModel.currentPage * 1.0/_readModel.chapterModel.pageCount *1.0;
    double progress = chapterProgress + pageProgress*1.0/ (_readModel.chapterCount *1.0);
    
    if (readModel.chapterCount == 1) {
        progress = pageProgress;
    }
    progress = progress*100;
    _slider.value = progress;
}

- (ReadProgressView *)progressView {
    if (!_progressView) {
        _progressView = [[ReadProgressView alloc] init];
        _progressView.hidden = YES;
    }
    return _progressView;
}

- (UISlider *)slider
{
    if (!_slider) {
        _slider = [[UISlider alloc] init];
        _slider.minimumValue = 0;
        _slider.maximumValue = 100;
        _slider.minimumTrackTintColor = kRGBColor(227, 0, 0);
        _slider.maximumTrackTintColor = kRGBColor(225, 225, 225);
        //[_slider setThumbImage:[UIImage imageNamed:@"read_slider_circle"] forState:UIControlStateNormal];
        [_slider addTarget:self action:@selector(sliderValueChanged:) forControlEvents:UIControlEventValueChanged];
        [_slider addObserver:self forKeyPath:@"highlighted" options:NSKeyValueObservingOptionNew|NSKeyValueObservingOptionOld context:NULL];
    }
    return _slider;
}

- (UIButton *)nextChapter
{
    if (!_nextChapter) {
        _nextChapter = [ReadUtilites commonButtonSEL:@selector(jumpChapter:) target:self];
        [_nextChapter setTitle:@"下一章" forState:UIControlStateNormal];
    }
    return _nextChapter;
}

- (UIButton *)lastChapter
{
    if (!_lastChapter) {
        _lastChapter = [ReadUtilites commonButtonSEL:@selector(jumpChapter:) target:self];
        [_lastChapter setTitle:@"上一章" forState:UIControlStateNormal];
    }
    return _lastChapter;
}

#pragma mark - Button Click
- (void)jumpChapter:(UIButton *)sender {
    if (sender == _nextChapter) {
        if (_readModel.currentChapter == _readModel.chapterCount-1) {
            [MBProgressHUD showTipsWindow:@"已经是最后一章了"];
            return;
        }
        if ([self.delegate respondsToSelector:@selector(menuViewJumpChapter:page:)]) {
            [self.delegate menuViewJumpChapter:(_readModel.currentChapter == _readModel.chapterCount-1)?_readModel.currentChapter:_readModel.currentChapter+1 page:0];
        }
    }
    else {
        if (_readModel.currentChapter == 0) {
            [MBProgressHUD showTipsWindow:@"现在是第一章了"];
            return;
        }
        if ([self.delegate respondsToSelector:@selector(menuViewJumpChapter:page:)]) {
            [self.delegate menuViewJumpChapter:_readModel.currentChapter?_readModel.currentChapter-1:0 page:0];
        }
    }
}

#pragma mark -  sliderValueChanged
- (void)sliderValueChanged:(UISlider *)sender {
    NSUInteger chapter = ceil((_readModel.chapterCount)*sender.value/100.00);
    if (chapter == _readModel.chapterCount) {
        chapter = chapter - 1;
    }
    
    if ([self.delegate respondsToSelector:@selector(menuViewJumpChapter:page:)]) {
        [self.delegate menuViewJumpChapter:chapter page:0];
    }
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context {
    if ([keyPath isEqualToString:@"readModel.currentChapter"] || [keyPath isEqualToString:@"readModel.currentPage"]) {
        
        double chapterProgress = _readModel.currentChapter * 1.0/(_readModel.chapterCount *1.0);
        double pageProgress = _readModel.currentPage * 1.0/_readModel.chapterModel.pageCount *1.0;
        double progress = chapterProgress + pageProgress*1.0/ (_readModel.chapterCount *1.0);
        
        if (_readModel.chapterCount == 1) {
            progress = pageProgress;
        }
        progress = progress*100;
        _slider.value = progress;
        
        NSString *title = [NSString stringWithFormat:@"第%li章 %@",_readModel.currentChapter + 1,_readModel.chapterModel.title];
        [_progressView title:title progress:[NSString stringWithFormat:@"%.1f%%",_slider.value]];
    }
    else if ([keyPath isEqualToString:@"fontSize"] || [keyPath isEqualToString:@"fontNameType"]) {
        if ([self.delegate respondsToSelector:@selector(menuViewFontSize)]) {
            [self.delegate menuViewFontSize];
        }
    }
    else {
        
        if (_slider.state == UIControlStateNormal) {
            _progressView.hidden = YES;
        }
        else if(_slider.state == UIControlStateHighlighted){
            _progressView.hidden = NO;
        }
    }
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    _slider.frame = CGRectMake(50, (ViewSize(self).height - 30 )/2, ViewSize(self).width-100, 30);
    _lastChapter.frame = CGRectMake(5, (ViewSize(self).height - 30 )/2, 40, 30);
    _nextChapter.frame = CGRectMake(DistanceFromLeftGuiden(_slider)+5, (ViewSize(self).height - 30 )/2, 40, 30);
    _progressView.frame = CGRectMake(0, -50, ViewSize(self).width, 44);
}

// 移除监听
- (void)dealloc
{
    [_slider removeObserver:self forKeyPath:@"highlighted"];
    [self removeObserver:self forKeyPath:@"readModel.currentChapter"];
    [self removeObserver:self forKeyPath:@"readModel.currentPage"];
}

@end

@interface  ReadProgressView ()

@property (nonatomic, strong) UILabel *label;
@end

@implementation  ReadProgressView

- (instancetype)init {
    self = [super init];
    if (self) {
        [self addSubview:self.label];
        self.backgroundColor = kWhiteColor;
    }
    return self;
}
- (UILabel *)label {
    if (!_label) {
        _label = [[UILabel alloc] init];
        _label.font = [UIFont systemFontOfSize:[ReadConfig shareInstance].fontSize];
        _label.textColor = [UIColor blackColor];
        _label.textAlignment = NSTextAlignmentCenter;
        _label.numberOfLines = 0;
    }
    return _label;
}

- (void)title:(NSString *)title progress:(NSString *)progress {
    _label.text = [NSString stringWithFormat:@"%@\n%@",title,progress];
}

-(void)layoutSubviews {
    [super layoutSubviews];
    _label.frame = self.bounds;
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
