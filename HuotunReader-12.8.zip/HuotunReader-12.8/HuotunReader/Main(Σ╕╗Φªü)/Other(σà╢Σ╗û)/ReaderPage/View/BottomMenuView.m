//
//   BottomMenuView.m
//   Reader
//
//  Created by chengongwen on 2017/11/20.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "BottomMenuView.h"
#import "ReadConfig.h"
#import "ReadUtilites.h"

@interface  BottomMenuView ()

@property (nonatomic, strong) UIButton *catalogBtn;
@property (nonatomic, strong) UILabel *catalogLabel;
@property (nonatomic, strong) UIButton *settingBtn;
@property (nonatomic, strong) UILabel *settingLabel;
@property (nonatomic, strong) UIButton *lightBtn;
@property (nonatomic, strong) UILabel *lightLabel;

@property (nonatomic, strong) UIButton *downloadBtn;
@property (nonatomic, strong) UILabel *downloadLabel;
@property (nonatomic, strong) UILabel *commentLabel;
@end

@implementation  BottomMenuView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setBackgroundColor:kRGBColor(255, 255, 255)];
        [self setup];
    
        [[ReadConfig shareInstance] addObserver:self forKeyPath:@"fontSize" options:NSKeyValueObservingOptionNew context:NULL];
    }
    return self;
}

- (void)setup {
    [self addSubview:self.catalogBtn];
    [self addSubview:self.catalogLabel];
    [self addSubview:self.lightBtn];
    [self addSubview:self.lightLabel];
    [self addSubview:self.settingBtn];
    [self addSubview:self.settingLabel];
    [self addSubview:self.downloadBtn];
    [self addSubview:self.downloadLabel];
    [self addSubview:self.commentLabel];
}

// 移除监听
- (void)dealloc
{
    [[ReadConfig shareInstance] removeObserver:self forKeyPath:@"fontSize"];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context {
    if ([keyPath isEqualToString:@"fontSize"]) {
        if ([self.delegate respondsToSelector:@selector(menuViewFontSize)]) {
            [self.delegate menuViewFontSize];
        }
    }
}

- (UIButton *)catalogBtn {
    if (!_catalogBtn) {
        _catalogBtn = [ReadUtilites commonButtonSEL:@selector(showCatalogView) target:self];
        [_catalogBtn setImage:[UIImage imageNamed:@"read_bar_0"] forState:UIControlStateNormal];
    }
    return _catalogBtn;
}

- (UILabel *)catalogLabel {
    if (!_catalogLabel) {
        _catalogLabel = [UILabel labelWithTextColor:[UIColor blackColor] fontSize:kDESGIN_TRANSFORM_iPhone6(16)];
        _catalogLabel.text = @"目录";
        _catalogLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _catalogLabel;
}

- (UIButton *)settingBtn {
    if (!_settingBtn) {
        _settingBtn = [ReadUtilites commonButtonSEL:@selector(showSettingView) target:self];
        [_settingBtn setImage:[UIImage imageNamed:@"read_bar_1"] forState:UIControlStateNormal];
    }
    return _settingBtn;
}

- (UILabel *)settingLabel {
    if (!_settingLabel) {
        _settingLabel = [UILabel labelWithTextColor:[UIColor blackColor] fontSize:kDESGIN_TRANSFORM_iPhone6(16)];
        _settingLabel.text = @"设置";
        _settingLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _settingLabel;
}

- (UIButton *)lightBtn {
    if (!_lightBtn) {
        _lightBtn = [ReadUtilites commonButtonSEL:@selector(showLightView) target:self];
        [_lightBtn setImage:[UIImage imageNamed:@"read_bar_2"] forState:UIControlStateNormal];
    }
    return _lightBtn;
}

- (UILabel *)lightLabel {
    if (!_lightLabel) {
        _lightLabel = [UILabel labelWithTextColor:[UIColor blackColor] fontSize:kDESGIN_TRANSFORM_iPhone6(16)];
        _lightLabel.text = @"进度";
        _lightLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _lightLabel;
}

- (UIButton *)downloadBtn {
    if (!_downloadBtn) {
        _downloadBtn = [ReadUtilites commonButtonSEL:@selector(showDownload) target:self];
        [_downloadBtn setImage:[UIImage imageNamed:@"read_comment"] forState:UIControlStateNormal];
    }
    return _downloadBtn;
}

- (UILabel *)downloadLabel {
    if (!_downloadLabel) {
        _downloadLabel = [UILabel labelWithTextColor:[UIColor blackColor] fontSize:kDESGIN_TRANSFORM_iPhone6(16)];
        _downloadLabel.text = @"评论";
        _downloadLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _downloadLabel;
}

- (UILabel *)commentLabel {
    if (!_commentLabel) {
        _commentLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0x222222) fontSize:kScaleFrom_iPhone6_Desgin_X(12)];
        _commentLabel.text = @"123";
    }
    return _commentLabel;
}

#pragma mark - Button Click

- (void)showCatalogView
{
    if ([self.delegate respondsToSelector:@selector(menuViewInvokeCatalog:)]) {
        [self.delegate menuViewInvokeCatalog:self];
    }
}

- (void)showSettingView
{
    if ([self.readDelegate respondsToSelector:@selector(menuSettingViewDidAppear)]) {
        [self.readDelegate menuSettingViewDidAppear];
    }
}

- (void)showLightView
{
    if ([self.readDelegate respondsToSelector:@selector(menuLightViewDidAppear)]) {
        [self.readDelegate menuLightViewDidAppear];
    }
}

- (void)showDownload
{
    if ([self.delegate respondsToSelector:@selector(menuViewJumpComment)]) {
        [self.delegate menuViewJumpComment];
    }
}

- (void)layoutSubviews
{
    [super layoutSubviews];

    CGFloat buttonY = 10;
    CGFloat labelY = 2;
    CGFloat buttonH = CGRectGetHeight(self.frame)/2 - buttonY;
    CGFloat buttonW = CGRectGetWidth(self.frame) / 4;
    
    _catalogBtn.frame = CGRectMake(buttonW * 0, buttonY, buttonW, buttonH);
    _catalogLabel.frame = CGRectMake(buttonW * 0, DistanceFromTopGuiden(_catalogBtn) + labelY, buttonW, buttonH);
    
    _settingBtn.frame = CGRectMake(buttonW * 1, buttonY, buttonW, buttonH);
    _settingLabel.frame = CGRectMake(buttonW * 1, DistanceFromTopGuiden(_settingBtn) + labelY, buttonW, buttonH);
    
    _lightBtn.frame = CGRectMake(buttonW * 2, buttonY, buttonW, buttonH);
    _lightLabel.frame = CGRectMake(buttonW * 2, DistanceFromTopGuiden(_lightBtn) + labelY, buttonW, buttonH);
    
    _downloadBtn.frame = CGRectMake(buttonW * 3, buttonY, buttonW, buttonH);
    _downloadLabel.frame = CGRectMake(buttonW * 3, DistanceFromTopGuiden(_downloadBtn) + labelY, buttonW, buttonH);
    _commentLabel.frame = CGRectMake(buttonW * 3 + buttonW/2, buttonY - 15, 40, 40);
}

@end
