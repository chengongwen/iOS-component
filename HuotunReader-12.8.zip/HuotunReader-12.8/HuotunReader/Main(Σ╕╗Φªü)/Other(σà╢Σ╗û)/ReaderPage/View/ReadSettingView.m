//
//  ReadSettingView.m
//  HuotunReader
//
//  Created by chengongwen on 2017/11/20.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "ReadSettingView.h"
#import "LightView.h"
#import "ReadConfig.h"
#import "ReadUtilites.h"

@interface ReadSettingView ()

@property (nonatomic, strong) LightView *lightView;
@property (nonatomic, strong) ThemeView *themeView;
@property (nonatomic, strong) ReadFontView *fontView;
@end

@implementation ReadSettingView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setBackgroundColor:kRGBColor(255, 255, 255)];
        [self setup];
    }
    return self;
}

- (void)setup {
    [self addSubview:self.lightView];
    [self addSubview:self.themeView];
    [self addSubview:self.fontView];
}

- (LightView *)lightView {
    if (!_lightView) {
        _lightView = [[LightView alloc] init];
        _lightView.backgroundColor = [UIColor clearColor];
    }
    return _lightView;
}

- (ThemeView *)themeView {
    if (!_themeView) {
        _themeView = [[ThemeView alloc] init];
    }
    return _themeView;
}

- (ReadFontView *)fontView {
    if (!_fontView) {
        (_fontView) = [[ReadFontView alloc] init];
    }
    return _fontView;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    _lightView.frame = CGRectMake(0, 10, ViewSize(self).width, 40);
    _themeView.frame = CGRectMake(0, DistanceFromTopGuiden(_lightView)+10, ViewSize(self).width, 40);
    _fontView.frame = CGRectMake(0, DistanceFromTopGuiden(_themeView)+10, ViewSize(self).width, 40);
}

@end

@interface ThemeView ()

@property (nonatomic, strong) UILabel *titleLabel;  // 标题
@property (nonatomic, strong) UIView *theme1;
@property (nonatomic, strong) UIView *theme2;
@property (nonatomic, strong) UIView *theme3;
@property (nonatomic, strong) UIView *theme4;
@property (nonatomic, strong) UIView *theme5;
@end

@implementation ThemeView
- (instancetype)init
{
    self = [super init];
    if (self) {
        [self setBackgroundColor:[UIColor clearColor]];
        [self setup];
    }
    return self;
}

- (void)setup {
    [self addSubview:self.titleLabel];
    [self addSubview:self.theme1];
    [self addSubview:self.theme1];
    [self addSubview:self.theme2];
    [self addSubview:self.theme3];
    [self addSubview:self.theme4];
    [self addSubview:self.theme5];
}

- (UILabel *)titleLabel {
    if (!_titleLabel) {
        _titleLabel = [UILabel labelWithTextColor:[UIColor blackColor] fontSize:kDESGIN_TRANSFORM_iPhone6(18)];
        _titleLabel.text = @"背景";
    }
    return _titleLabel;
}

- (UIView *)theme1 {
    if (!_theme1) {
        _theme1 = [[UIView alloc] init];
        _theme1.layer.cornerRadius = 20;
        _theme1.backgroundColor = READ_BACKGROUND_COLOC_1;
        [_theme1 addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(changeTheme:)]];
    }
    return _theme1;
}

- (UIView *)theme2
{
    if (!_theme2) {
        _theme2 = [[UIView alloc] init];
        _theme2.layer.cornerRadius = 20;
        _theme2.backgroundColor = READ_BACKGROUND_COLOC_2;
        [_theme2 addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(changeTheme:)]];
    }
    return _theme2;
}

- (UIView *)theme3 {
    if (!_theme3) {
        _theme3 = [[UIView alloc] init];
        _theme3.layer.cornerRadius = 20;
        _theme3.backgroundColor = READ_BACKGROUND_COLOC_3;
        [_theme3 addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(changeTheme:)]];
    }
    return _theme3;
}

- (UIView *)theme4 {
    if (!_theme4) {
        _theme4 = [[UIView alloc] init];
        _theme4.layer.cornerRadius = 20;
        _theme4.backgroundColor = READ_BACKGROUND_COLOC_4;
        _theme4.layer.borderColor = READ_BACKGROUND_COLOC_1.CGColor;
        _theme4.layer.borderWidth = 1.0;
        [_theme4 addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(changeTheme:)]];
    }
    return _theme4;
}

- (UIView *)theme5 {
    if (!_theme5) {
        _theme5 = [[UIView alloc] init];
        _theme5.layer.cornerRadius = 20;
        _theme5.backgroundColor = READ_BACKGROUND_COLOC_5;
        [_theme5 addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(changeTheme:)]];
    }
    return _theme5;
}

- (void)changeTheme:(UITapGestureRecognizer *)tap {
    [[NSNotificationCenter defaultCenter] postNotificationName:kThemeNotification object:tap.view.backgroundColor];
}

- (void)layoutSubviews
{
    _titleLabel.frame = CGRectMake(10, (ViewSize(self).height - 30) *0.5, 40, 30);
    
    CGFloat spacing = (ViewSize(self).width - 50 -40*5)/6;
    _theme1.frame = CGRectMake(DistanceFromLeftGuiden(_titleLabel)+spacing, 0, 40, 40);
    _theme2.frame = CGRectMake(DistanceFromLeftGuiden(_theme1)+spacing, 0, 40, 40);
    _theme3.frame = CGRectMake(DistanceFromLeftGuiden(_theme2)+spacing, 0, 40, 40);
    _theme4.frame = CGRectMake(DistanceFromLeftGuiden(_theme3)+spacing, 0, 40, 40);
    _theme5.frame = CGRectMake(DistanceFromLeftGuiden(_theme4)+spacing, 0, 40, 40);
}

@end

@interface ReadFontView ()

@property (nonatomic, strong) UILabel *titleLabel;  // 标题
@property (nonatomic, strong) UIButton *increaseFont;
@property (nonatomic, strong) UIButton *decreaseFont;
@end

@implementation ReadFontView
- (instancetype)init
{
    self = [super init];
    if (self) {
        [self setup];
    }
    return self;
}

- (void)setup {
    [self addSubview:self.titleLabel];
    [self addSubview:self.increaseFont];
    [self addSubview:self.decreaseFont];
}

- (UILabel *)titleLabel {
    if (!_titleLabel) {
        _titleLabel = [UILabel labelWithTextColor:[UIColor blackColor] fontSize:kDESGIN_TRANSFORM_iPhone6(18)];
        _titleLabel.text = @"字体";
        _titleLabel.textAlignment = NSTextAlignmentLeft;
    }
    return _titleLabel;
}

- (UIButton *)increaseFont
{
    if (!_increaseFont) {
        _increaseFont = [ReadUtilites commonButtonSEL:@selector(changeFont:) target:self];
        [_increaseFont setImage:[UIImage imageNamed:@"read_font_inc"]  forState:UIControlStateNormal];
        [_increaseFont setImage:[UIImage imageNamed:@"read_font_inc"]  forState:UIControlStateHighlighted];
    }
    return _increaseFont;
}

- (UIButton *)decreaseFont
{
    if (!_decreaseFont) {
        _decreaseFont = [ReadUtilites commonButtonSEL:@selector(changeFont:) target:self];
        [_decreaseFont setImage:[UIImage imageNamed:@"read_font_dec"]  forState:UIControlStateNormal];
        [_decreaseFont setImage:[UIImage imageNamed:@"read_font_dec"]  forState:UIControlStateHighlighted];
    }
    return _decreaseFont;
}

- (void)changeFont:(UIButton *)sender {
    if (sender == _increaseFont) {
        
        if (floor([ReadConfig shareInstance].fontSize) == floor(kMaxFontSize)) {
            [MBProgressHUD showTipsWindow:@"已经是最大字体了"];
            return;
        }
        [ReadConfig shareInstance].fontSize++;
    }
    else {
        if (floor([ReadConfig shareInstance].fontSize) == floor(kMinFontSize)) {
            [MBProgressHUD showTipsWindow:@"已经是最小字体了"];
            return;
        }
        [ReadConfig shareInstance].fontSize--;
    }
}

- (void)layoutSubviews
{
    _titleLabel.frame = CGRectMake(10, (ViewSize(self).height - 30) *0.5, 40, 30);
    
    CGFloat spacing = (ViewSize(self).width - 50 - 15*3)/2;
    _decreaseFont.frame = CGRectMake(DistanceFromLeftGuiden(_titleLabel) + 15, (ViewSize(self).height - spacing *58.0/277.0) *0.5,spacing,spacing *58.0/277.0);
    _increaseFont.frame = CGRectMake(DistanceFromLeftGuiden(_decreaseFont) + 15, (ViewSize(self).height - spacing *58.0/277.0) *0.5, spacing, spacing *58.0/277.0);
}

@end

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

