//
//  ProgressView.h
//  HuotunReader
//
//  Created by chengongwen on 2017/12/2.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RecordModel.h"

@protocol MenuViewDelegate;

@interface ProgressView : UIView

@property (nonatomic, weak) id<MenuViewDelegate> delegate;
@property (nonatomic, strong) RecordModel *readModel;
@end

@interface ReadProgressView : UIView

- (void)title:(NSString *)title progress:(NSString *)progress;
@end
