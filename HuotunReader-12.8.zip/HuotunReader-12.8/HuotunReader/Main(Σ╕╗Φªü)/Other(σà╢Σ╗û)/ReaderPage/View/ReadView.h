//
//   ReadView.h
//   Reader
//
//  Created by chengongwen on 2017/11/20.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ChapterModel.h"

@protocol ReadViewControllerDelegate;

@interface  ReadView : UIView

@property (nonatomic,assign) CTFrameRef frameRef;
@property (nonatomic,strong) NSString *content;
@property (nonatomic,strong) NSArray *imageArray;

@property (nonatomic,strong) id<ReadViewControllerDelegate>delegate; 

- (void)cancelSelected;

@end
