//
//  ReadSettingView.h
//  HuotunReader
//
//  Created by chengongwen on 2017/11/20.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol MenuViewDelegate;

@interface ReadSettingView : UIView

@property (nonatomic, weak) id <MenuViewDelegate> delegate;
@end

@interface ThemeView : UIView

@end

@interface ReadFontView : UIView

@end
