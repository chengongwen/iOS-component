//
//  ReadModel.h
//  HuotunReader
//
//  Created by chengongwen on 2017/10/31.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CatalogueObject.h"
#import "ChapterModel.h"
#import "ReadConfig.h"
#import "RecordModel.h"

#define kChapterForKey(chapterNum) [NSString stringWithFormat:@"%lu",chapterNum]

@interface ReadModel : NSObject <NSCoding>

@property (nonatomic, strong) RecordModel *record;  // 当前阅读历史

@property (nonatomic, strong) NSArray *catalogueList;               // 当前书籍的目录列表
@property (nonatomic, strong) NSMutableDictionary *chaptersList;    // 所有章节数据列表

// 初始化数据
- (instancetype)initWithCatalogue:(CatalogueObject *)catalogueObject selectChapter:(int)selectChapter;

// 保存当前翻页的浏览记录
- (void)archivierChapter;

// 异步加载所有章节
- (void)loadAllReadChapterList;

// 获得当前的章节数据
- (ChapterModel *)reloadDataWithChapter:(NSUInteger)chapter;

// 加载章节并缓存章节数据
- (void)reloadCacheDataWithChapter:(NSUInteger)chapter;

// 更新改变字体所有数据
- (void)allChapterListUpdateFontConfig;

@end
