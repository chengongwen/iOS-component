//
//  RecordModel.m
//  HuotunReader
//
//  Created by chengongwen on 2017/10/31.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "RecordModel.h"
#import "ReadConfig.h"

#define kFontSize       @"fontSize"         // 当前的保存的字体大小
#define kPage           @"page"             // 记录浏览记录页码
#define kChapter        @"chapter"          // 保存浏览记录章节
#define kChapterModel   @"chapterModel"     // 记录浏览记录页码
#define kPreChapterModel    @"previousChapterModel"     // 记录浏览记录页码
#define kNextChapterModel   @"nextChapterModel"     // 记录浏览记录页码

@implementation RecordModel

- (void)encodeWithCoder:(NSCoder *)aCoder {
    [aCoder encodeFloat:self.fontSize forKey:kFontSize];
    [aCoder encodeInteger:self.currentPage forKey:kPage];
    [aCoder encodeInteger:self.currentChapter forKey:kChapter];
    [aCoder encodeObject:self.chapterModel forKey:kChapterModel];
    [aCoder encodeObject:self.previousChapterModel forKey:kPreChapterModel];
    [aCoder encodeObject:self.nextChapterModel forKey:kNextChapterModel];
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];
    if (self) {
        self.fontSize = [aDecoder decodeFloatForKey:kFontSize];
        self.currentPage = [aDecoder decodeIntegerForKey:kPage];
        self.currentChapter = [aDecoder decodeIntegerForKey:kChapter];
        self.chapterModel = [aDecoder decodeObjectForKey:kChapterModel];
        self.previousChapterModel = [aDecoder decodeObjectForKey:kPreChapterModel];
        self.nextChapterModel = [aDecoder decodeObjectForKey:kNextChapterModel];
    }
    return self;
}

@end
