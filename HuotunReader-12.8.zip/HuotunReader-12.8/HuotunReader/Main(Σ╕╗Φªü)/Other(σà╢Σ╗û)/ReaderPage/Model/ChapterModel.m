//
//  ChapterModel.m
//  HuotunReader
//
//  Created by chengongwen on 2017/10/31.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "ChapterModel.h"
#import "GTMBase64.h"
#import "ReadConfig.h"
#import "ReadParser.h"

NSString *const kXDSChapterModelChapterIdEncodeKey = @"catalogueId";
NSString *const kXDSChapterModelChapterNumEncodeKey = @"chapterNum";
NSString *const kXDSChapterModelChapterContentEncodeKey = @"content";
NSString *const kXDSChapterModelChapterNameEncodeKey = @"title";
NSString *const kXDSChapterModelPageCountIdEncodeKey = @"pageCount";
NSString *const kXDSChapterModelPageListEncodeKey = @"pageArray";

@interface ChapterModel ()

@end

@implementation ChapterModel

- (void)encodeWithCoder:(NSCoder *)aCoder {
    [aCoder encodeObject:self.catalogueId forKey:kXDSChapterModelChapterIdEncodeKey];
    [aCoder encodeInteger:self.chapterNum forKey:kXDSChapterModelChapterNumEncodeKey];
    [aCoder encodeObject:self.content forKey:kXDSChapterModelChapterContentEncodeKey];
    [aCoder encodeObject:self.title forKey:kXDSChapterModelChapterNameEncodeKey];
    [aCoder encodeInteger:self.pageCount forKey:kXDSChapterModelPageCountIdEncodeKey];
    [aCoder encodeObject:self.pageArray forKey:kXDSChapterModelPageListEncodeKey];
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];
    if (self) {
        self.catalogueId = [aDecoder decodeObjectForKey:kXDSChapterModelChapterIdEncodeKey];
        self.chapterNum = [aDecoder decodeIntegerForKey:kXDSChapterModelChapterNumEncodeKey];
        self.content = [aDecoder decodeObjectForKey:kXDSChapterModelChapterContentEncodeKey];
        self.title = [aDecoder decodeObjectForKey:kXDSChapterModelChapterNameEncodeKey];
        self.pageCount = [aDecoder decodeIntegerForKey:kXDSChapterModelPageCountIdEncodeKey];
        self.pageArray = [aDecoder decodeObjectForKey:kXDSChapterModelPageListEncodeKey];
    }
    return self;
}

- (instancetype)initWithChapter:(ChapterObject *)chapterObject {
    self = [super init];
    if (self) {
        _pageArray = [NSMutableArray array];
        
        self.catalogueId = chapterObject.catalogueId;
        self.title = chapterObject.title;
        self.chapterNum = chapterObject.chapterNum;
        
        // Now convert back from Base64 解密base64EncodedData
        NSData *base64EncodedData = [NSData dataWithContentsOfFile:chapterObject.path];
        
        if (base64EncodedData != nil) {
            
            // 当前文件保存在本地，直接获取文件
            NSData *data = [GTMBase64 decodeData:base64EncodedData];
            NSString *content = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            
            if (!content) {
                content = [[NSString alloc] initWithData:data encoding:0x80000632];
            }
            if (!content) {
                content = [[NSString alloc] initWithData:data encoding:0x80000631];
            }
            _content = content;
        }
        else {
            // 本地文件没有，网络下载
            
        }
        
        // 计算当前文字大小的篇幅的页数
        [self updateFontConfig];
    }
    return self;
}

- (void)setContent:(NSString *)content {
    _content = content;
    [self updateFontConfig];
}

// 计算当前文字大小的篇幅的页数
- (void)updateFontConfig {
    [self paginateWithBounds:CGRectMake(LeftSpacing, TopSpacing, [UIScreen mainScreen].bounds.size.width-LeftSpacing-RightSpacing, [UIScreen mainScreen].bounds.size.height-TopSpacing-BottomSpacing)];
}

// 计算篇幅的页数
- (void)paginateWithBounds:(CGRect)bounds {
    if (self.content.length <= 0) {
        return ;
    }
    [_pageArray removeAllObjects];
    NSAttributedString *attrString;
    CTFramesetterRef frameSetter;
    CGPathRef path;
    NSMutableAttributedString *attrStr;
    attrStr = [[NSMutableAttributedString  alloc] initWithString:self.content];
    NSDictionary *attribute = [ReadParser parserAttribute:[ReadConfig shareInstance]];
    [attrStr setAttributes:attribute range:NSMakeRange(0, attrStr.length)];
    attrString = [attrStr copy];
    frameSetter = CTFramesetterCreateWithAttributedString((__bridge CFAttributedStringRef) attrString);
    path = CGPathCreateWithRect(bounds, NULL);
    int currentOffset = 0;
    int currentInnerOffset = 0;
    BOOL hasMorePages = YES;
    // 防止死循环，如果在同一个位置获取CTFrame超过2次，则跳出循环
    int preventDeadLoopSign = currentOffset;
    int samePlaceRepeatCount = 0;
    
    while (hasMorePages) {
        if (preventDeadLoopSign == currentOffset) {
            
            ++samePlaceRepeatCount;
            
        } else {
            
            samePlaceRepeatCount = 0;
        }
        
        if (samePlaceRepeatCount > 1) {
            // 退出循环前检查一下最后一页是否已经加上
            if (_pageArray.count == 0) {
                [_pageArray addObject:@(currentOffset)];
            }
            else {
                
                NSUInteger lastOffset = [[_pageArray lastObject] integerValue];
                
                if (lastOffset != currentOffset) {
                    [_pageArray addObject:@(currentOffset)];
                }
            }
            break;
        }
        
        [_pageArray addObject:@(currentOffset)];
        
        CTFrameRef frame = CTFramesetterCreateFrame(frameSetter, CFRangeMake(currentInnerOffset, 0), path, NULL);
        CFRange range = CTFrameGetVisibleStringRange(frame);
        if ((range.location + range.length) != attrString.length) {
            
            currentOffset += range.length;
            currentInnerOffset += range.length;
            
        } else {
            // 已经分完，提示跳出循环
            hasMorePages = NO;
        }
        if (frame) CFRelease(frame);
    }
    
    CGPathRelease(path);
    CFRelease(frameSetter);
    _pageCount = _pageArray.count;
}

- (NSString *)stringOfPage:(NSUInteger)index {
    if (_pageArray.count <= index) {
        return @"";
    }
    
    NSUInteger local = [_pageArray[index] integerValue];
    NSUInteger length;
    if (index<self.pageCount-1) {
        length = [_pageArray[index+1] integerValue] - [_pageArray[index] integerValue];
    }
    else {
        length = _content.length - [_pageArray[index] integerValue];
    }
    NSString *tempContent = [_content substringWithRange:NSMakeRange(local, length)];
    return tempContent;
}


@end
