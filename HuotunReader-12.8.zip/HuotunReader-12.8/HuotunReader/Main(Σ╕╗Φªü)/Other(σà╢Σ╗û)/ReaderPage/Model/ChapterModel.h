//
//  ChapterModel.h
//  HuotunReader
//
//  Created by chengongwen on 2017/10/31.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ChapterObject.h"

@interface ChapterModel : NSObject

@property (nonatomic, strong) NSString *catalogueId;
@property (nonatomic, assign) NSUInteger chapterNum; // 第几章节
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *content;
@property (nonatomic, assign) NSUInteger pageCount;
@property (nonatomic, strong) NSMutableArray *pageArray;

// 初始化数据
- (instancetype)initWithChapter:(ChapterObject *)chapterObject;

- (NSString *)stringOfPage:(NSUInteger)index;

// 计算当前文字大小的篇幅的页数
- (void)updateFontConfig;

@end
