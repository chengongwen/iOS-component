//
//  ReadModel.m
//  HuotunReader
//
//  Created by chengongwen on 2017/10/31.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "ReadModel.h"
#import "DatabaseManager.h"
#import "ReadGlobalMethod.h"

#define kRecordChapter     @"record"           // 记录浏览记录页码
#define kChaptersList      @"chaptersList"     // 记录保存历史

@interface ReadModel()

@property (nonatomic, strong) CatalogueObject *catalogueObject;
@end

@implementation ReadModel

- (void)encodeWithCoder:(NSCoder *)aCoder {
    [aCoder encodeObject:self.chaptersList forKey:kChaptersList];
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];
    if (self) {
        self.chaptersList = [aDecoder decodeObjectForKey:kChaptersList];
    }
    return self;
}

- (instancetype)initWithCatalogue:(CatalogueObject *)catalogueObject selectChapter:(int)selectChapter {
    self = [super init];
    if (self) {
        self.catalogueObject = catalogueObject;
        
        _catalogueList = [[NSArray alloc] init];
        _chaptersList = [[NSMutableDictionary alloc] init];
        
        // 初始化一个模型数据
        self.record = [[RecordModel alloc] init];
        
        // 获取本地保存数据
        [self unarchiverChapter];
        
        // 当前书籍的目录列表
        _catalogueList = [[DatabaseManager shareInstance] reloadChapterTableList:_catalogueObject.catalogueId];
        _record.chapterCount = _catalogueList.count;
        
        // 如果是选择章节跳转阅读，则selectChapter = -1，currentPage = 0
        if (selectChapter != -1) {
            [self archivierChapter];
            _record.currentChapter = selectChapter;
            _record.currentPage = 0;
        }
        
        // 加载前后3章数据
        [self loadDataWithChapter:_record.currentChapter];
        
        // 更新字体大小
        if (_record.fontSize != [ReadConfig shareInstance].fontSize) {
            [self allChapterListUpdateFontConfig];
        }
    }
    return self;
}

// 异步加载所有章节数据
- (void)loadAllReadChapterList {
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        @try {
            
            // 获取本地保存数据
            ReadModel *model = [[ReadGlobalMethod shareInstance] readKeyedUnarchiver:_catalogueObject.catalogueId];
            if (model.chaptersList.allKeys.count) {
                _chaptersList = model.chaptersList;
            }
            
            NSMutableDictionary *allChapterList = [[NSMutableDictionary alloc] init];
            for (ChapterObject *chapterObject in _catalogueList) {
                ChapterModel *chapterModel = [_chaptersList objectForKey:kChapterForKey(chapterObject.chapterNum)];
                
                // 说明数据已经成功加载内存中
                if (chapterModel.pageCount) {
                    
                }
                else {
                    chapterModel = [[ChapterModel alloc] initWithChapter:chapterObject];
                }
                
                if (chapterModel) {
                    [allChapterList setValue:chapterModel forKey:kChapterForKey(chapterObject.chapterNum)];
                }
            }
            self.chaptersList = [allChapterList copy];
            
            // 归档保存
            [self archivierChapter];
            
            [[ReadGlobalMethod shareInstance] readKeyedArchiver:_catalogueObject.catalogueId readModel:self];
            
        } @catch (NSException *exception) {
            DLog(@"加载所有章节数据更新异常,%@",exception);
        }
    });
}

// 更新改变字体所有数据
- (void)allChapterListUpdateFontConfig {
    // 使用枚举器
    NSEnumerator * enumerator = [self.chaptersList objectEnumerator];
    ChapterModel * chapterModel;
    while (chapterModel = [enumerator nextObject]) {
        @try {
            [chapterModel updateFontConfig];
        } @catch (NSException *exception) {
            DLog(@"遍历改变字体异步数据更新异常,%@",exception);
        }
    }
    
    @try {
        // 归档保存
        [self archivierChapter];
        
        [[ReadGlobalMethod shareInstance] readKeyedArchiver:_catalogueObject.catalogueId readModel:self];
        
    } @catch (NSException *exception) {
        DLog(@"加载所有章节数据更新异常,%@",exception);
    }
}

// 加载章节
- (void)reloadCacheDataWithChapter:(NSUInteger)chapter {
    // 根据当前的章节，重新布局和计算页码
    [self loadDataWithChapter:chapter];
}

// 获得当前的章节数据
- (ChapterModel *)reloadDataWithChapter:(NSUInteger)chapter {
    ChapterModel *chapterModel = [_chaptersList objectForKey:kChapterForKey(chapter)];
    if (!chapterModel) {
        ChapterObject *chapterObj = [[DatabaseManager shareInstance] getChapterObject:_catalogueObject.catalogueId chapterNum:chapter];
        chapterModel = [[ChapterModel alloc] initWithChapter:chapterObj];
        if (chapterModel.pageCount) {
            @try {
                [self.chaptersList setValue:chapterModel forKey:kChapterForKey(chapter)];
            } @catch (NSException *exception) {
                DLog(@"加载章节数据异常,%li exception = %@,",chapter,exception);
            }
        }
    }
    return chapterModel;
}

// 初始化 init 加载章节
- (void)loadDataWithChapter:(NSInteger)chapterNum {
    DLog(@"chapterNum = %lu",chapterNum);
    
    NSInteger preChapter = chapterNum - 1;
    NSInteger nextChapter = chapterNum + 1;
    
    // 获得当前的章节数据
    ChapterModel *chapterModel = [_chaptersList objectForKey:kChapterForKey(chapterNum)];
    if (!chapterModel) {
        ChapterObject *chapterObj = [[DatabaseManager shareInstance] getChapterObject:_catalogueObject.catalogueId chapterNum:chapterNum];
        chapterModel = [[ChapterModel alloc] initWithChapter:chapterObj];
        if (chapterModel.pageCount) {
            @try {
                [self.chaptersList setValue:chapterModel forKey:kChapterForKey(chapterNum)];
            } @catch (NSException *exception) {
                DLog(@"加载章节数据异常,%li exception = %@,",chapterNum,exception);
            }
        }
    }
    _record.chapterModel = chapterModel;
    
    // 缓存前一章数据
    ChapterModel *preChapteModel = [_chaptersList objectForKey:kChapterForKey(preChapter)];
    if (!preChapteModel) {
        ChapterObject *preChapterObj = [[DatabaseManager shareInstance] getChapterObject:_catalogueObject.catalogueId chapterNum:preChapter];
        preChapteModel = [[ChapterModel alloc] initWithChapter:preChapterObj];
        if (preChapteModel.pageCount) {
            @try {
                [self.chaptersList setValue:preChapteModel forKey:kChapterForKey(preChapter)];
            } @catch (NSException *exception) {
                DLog(@"加载章节数据异常, %li exception = %@,",preChapter,exception);
            }
        }
    }
    _record.previousChapterModel = preChapteModel;
    
    // 缓存后一章数据
    ChapterModel *nextChapteModel = [_chaptersList objectForKey:kChapterForKey(nextChapter)];;
    if (!nextChapteModel) {
        ChapterObject *nextChapterObj = [[DatabaseManager shareInstance] getChapterObject:_catalogueObject.catalogueId chapterNum:nextChapter];
        nextChapteModel = [[ChapterModel alloc] initWithChapter:nextChapterObj];
        if (nextChapteModel.pageCount) {
            @try {
                 [self.chaptersList setValue:nextChapteModel forKey:kChapterForKey(nextChapter)];
            } @catch (NSException *exception) {
                DLog(@"加载章节数据异常, %li exception = %@,",nextChapter,exception);
            }
        }
    }
    _record.nextChapterModel = nextChapteModel;
}

#pragma mark -
#pragma mark - 归档和反归档，获取和保存最后一次的浏览章节和页码
- (void)archivierChapter {
    // 保存当前翻页的浏览记录
    @try {
        // 保存对象转化为二进制数据（一定是可变对象）
        NSMutableData *data = [[NSMutableData alloc] init];
        // 1.初始化
        NSKeyedArchiver *archivier = [[NSKeyedArchiver alloc] initForWritingWithMutableData:data];
        // 2.归档
        [archivier encodeObject:_record forKey:kRecordChapter];
        //3.完成归档
        [archivier finishEncoding];
        // 4.保存
        [[NSUserDefaults standardUserDefaults] setObject:data forKey:_catalogueObject.catalogueId];
        
        // 更新数据库的档案
        double chapterProgress = _record.currentChapter * 1.0/(_record.chapterCount *1.0);
        double pageProgress = _record.currentPage * 1.0/_record.chapterModel.pageCount *1.0;
        double progress = chapterProgress + pageProgress*1.0/ (_record.chapterCount *1.0);
        
        if (_record.chapterCount == 1) {
            progress = pageProgress;
        }
        progress = progress*100;
        
        self.catalogueObject.currentProgress = progress;
        [[DatabaseManager shareInstance] updateCatalogueTable:self.catalogueObject];
        
    } @catch (NSException *exception) {
        DLog(@"保存当前的浏览记录节数据异, %@",exception);
    }
}

- (void)unarchiverChapter {
    // 1.获取保存的数据
    NSData *data = [[NSUserDefaults standardUserDefaults] objectForKey:_catalogueObject.catalogueId];
    
    if (data) {
        // 2.初始化解归档对象
        NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:data];
        // 3.解归档
        _record = [unarchiver decodeObjectForKey:kRecordChapter];
        // 4.完成解归档
        [unarchiver finishDecoding];
        
        // 当前的数据是否为空
        if (_record.chapterModel.pageCount) {
            [self.chaptersList setValue:_record.chapterModel forKey:kChapterForKey(_record.currentChapter)];
        }
    }
    else {
        _record.currentChapter = 0;
        _record.currentPage = 0;
        _record.fontSize = [ReadConfig shareInstance].fontSize;
    }
}

- (void)deleteArchivierReadModel {
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:_catalogueObject.catalogueId];
}

@end
