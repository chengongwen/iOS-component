//
//  ReadGlobalMethod.m
//  HuotunReader
//
//  Created by chengongwen on 2017/12/2.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "ReadGlobalMethod.h"

//获取应用Document目录路径
#define kReadFolderPath [NSMutableString stringWithFormat:@"%@/%@",kAppDocumentPath,@"ReadFolder"]

@implementation ReadGlobalMethod

+ (instancetype)shareInstance {
    static ReadGlobalMethod *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[ReadGlobalMethod alloc] init];
    });
    return instance;
}

// 归档阅读文件
- (void)readKeyedArchiver:(NSString *)folerName readModel:(ReadModel *)readModel {
    NSString *fileName = [NSString stringWithFormat:@"%@.txt",folerName];
    NSString *filePathName = [kReadFolderPath stringByAppendingPathComponent:fileName];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL isFileExist = [fileManager fileExistsAtPath:filePathName];
    if(!isFileExist) {
        [fileManager createDirectoryAtPath:kReadFolderPath withIntermediateDirectories:YES attributes:nil error:nil];
        [fileManager createFileAtPath:filePathName contents:nil attributes:nil];
    }
    //DLog(@"归档阅读文件: %@",filePathName);
    
    // 1:准备存储数据的对象
    NSMutableData *data = [NSMutableData data];
    // 2:创建归档对象
    NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:data];
    
    // 3:开始归档
    [archiver encodeObject:readModel forKey:folerName];
    
    // 4:完成归档
    [archiver finishEncoding];
    
    // 5.写入文件当中
    BOOL result = [data writeToFile:filePathName atomically:YES];
    if (result) {
        DLog(@"归档阅读文件 %@ 成功",folerName);
    }
    else {
        DLog(@"归档阅读文件 %@ 失败",folerName);
    }
}

// 解档阅读文件文件
- (ReadModel *)readKeyedUnarchiver:(NSString *)folerName {
    NSString *fileName = [NSString stringWithFormat:@"%@.txt",folerName];
    NSString *filePathName = [kReadFolderPath stringByAppendingPathComponent:fileName];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL isFileExist = [fileManager fileExistsAtPath:filePathName];
    if(!isFileExist) {
        [fileManager createDirectoryAtPath:kReadFolderPath withIntermediateDirectories:YES attributes:nil error:nil];
        [fileManager createFileAtPath:filePathName contents:nil attributes:nil];
    }
    
    // 准备解档路径
    NSData *myData = [NSData dataWithContentsOfFile:filePathName];
    
    // 创建反归档对象
    NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:myData];
    
    // 反归档
    ReadModel *readModel = [unarchiver decodeObjectForKey:folerName];
    
    // 完成反归档
    [unarchiver finishDecoding];
    
    return readModel;
}

- (void)deleteArchivierReadModel:(NSString *)folerName {
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:folerName];
}

@end

