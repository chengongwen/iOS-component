//
//  ReadGlobalMethod.h
//  HuotunReader
//
//  Created by chengongwen on 2017/12/2.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ReadModel.h"

@interface ReadGlobalMethod : NSObject

+ (instancetype)shareInstance;

// 归档阅读文件文件
- (void)readKeyedArchiver:(NSString *)folerName readModel:(ReadModel *)readModel;

// 解档阅读文件文件
- (ReadModel *)readKeyedUnarchiver:(NSString *)folerName;

@end

