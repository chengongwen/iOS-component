//
//  ShareActionView.m
//  CheckIn
//
//  Created by kule on 16/1/13.
//  Copyright © 2016年 zhiye. All rights reserved.
//


#import "ShareActionView.h"
#define SHAREBUTTONWIDTH 40

@implementation ShareActionButtonView

- (instancetype)initWithFrame:(CGRect)frame WithImageName:(NSString *)iconImageName WithTitle:(NSString *)title {
    self = [super initWithFrame:frame];
    if (self) {
        UIImageView *iconImageview = [[UIImageView alloc]initWithFrame:CGRectMake(0,0 ,self.frame.size.width,self.frame.size.width)];
        iconImageview.image = [UIImage imageNamed:iconImageName];
        [self addSubview:iconImageview];
        
        UILabel *label = [[UILabel alloc]init];
        label.text = title;
        label.textAlignment = NSTextAlignmentCenter;
        label.font = [UIFont systemFontOfSize:kDESGIN_TRANSFORM_iPhone6(13)];
        label.textColor = [UIColor lightGrayColor];
        [self addSubview:label];
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(self);
            make.top.equalTo(iconImageview.mas_bottom).offset(kDESGIN_TRANSFORM_iPhone6(5));
            make.height.equalTo(@kDESGIN_TRANSFORM_iPhone6(15));
        }];
    }
    return self;
}

@end

#import "AppDelegate.h"

@interface ShareActionView ()

@property (nonatomic, strong)UIButton * QQButton;

@end

#define RGBCOLOR(RED,GREEN,BLUE) [UIColor colorWithRed:RED/255.0 green:GREEN/255.0 blue:BLUE/255.0 alpha:1.0]

@implementation ShareActionView

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */

- (id)initWithFrame:(CGRect)frame WithSourceArray:(NSArray *)array WithIconArray:(NSArray *)iconArray isFriend:(BOOL)choose
{
    self = [super initWithFrame:frame];
    if (self) {
        [self createShareAcitonViewWithFrame:frame WithSourceArray:array WithIconArray:iconArray isFriend:choose];
    }
    return self;
}

- (void)createShareAcitonViewWithFrame:(CGRect)frame WithSourceArray:(NSArray *)arr WithIconArray:(NSArray *)iconArray isFriend:(BOOL)choose
{
    if (arr == nil && iconArray == nil) {
        arr = @[@"QQ",NSLocalizedString(@"空间", @"空间"),NSLocalizedString(@"微信", @"微信"),NSLocalizedString(@"朋友圈", @"朋友圈"),NSLocalizedString(@"微博", @"微博")];
        iconArray = @[@"share_icon_qq",@"share_icon_qqZone" ,@"share_icon_wxSession",@"share_icon_wxTimeline",@"share_icon_weibo"];
    }
    
    CGFloat nH = kDESGIN_TRANSFORM_iPhone6(138);
    
    CGRect nFrame = CGRectMake(frame.origin.x, frame.origin.y, frame.size.width, nH);
    self.frame = nFrame;
    self.backgroundColor = RGBCOLOR(242, 245, 247);
    self.backgroundColor = [UIColor whiteColor];
    
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 3, self.frame.size.width, kDESGIN_TRANSFORM_iPhone6(30))];
    titleLabel.font = [UIFont systemFontOfSize:kDESGIN_TRANSFORM_iPhone6(14)];
    
    titleLabel.backgroundColor = RGBCOLOR(242, 245, 247);
    titleLabel.backgroundColor = [UIColor whiteColor];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:titleLabel];
    
    
    NSInteger count = arr.count;
    NSInteger page = 0;
    page = count/5;
    if ( count%5 != 0) {
        page = page + 1;
    }
    NSInteger row = 1;
    if (count > 6) {
        row = 2;
    }
    
//    CGFloat nH = DESGIN_TRANSFORM_3X(120);
//
//    CGRect nFrame = CGRectMake(frame.origin.x, frame.origin.y, frame.size.width, nH);
//    self.height = 30 + 80 * row;
//    self.frame = nFrame;
    UIScrollView *bgScrollerView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(titleLabel.frame), self.frame.size.width, self.frame.size.height)];
    bgScrollerView.backgroundColor = RGBCOLOR(242, 245, 247);
    bgScrollerView.backgroundColor = kWhiteColor;
    bgScrollerView.pagingEnabled = YES;
    bgScrollerView.delegate = self;
    bgScrollerView.bounces = NO;
    bgScrollerView.contentSize = CGSizeMake(self.frame.size.width * page, self.frame.size.height);
    [self addSubview:bgScrollerView];
    
    UIView *backgView = [[UIView alloc] initWithFrame:CGRectMake(0, self.frame.size.height - kDESGIN_TRANSFORM_iPhone6(38), self.frame.size.width, kDESGIN_TRANSFORM_iPhone6(38))];
    backgView.backgroundColor = [UIColor whiteColor];
    [self addSubview:backgView];
    
    UIButton *cancelButton = [UIButton buttonWithType:UIButtonTypeCustom];
    cancelButton.frame = CGRectMake(0, self.frame.size.height - kDESGIN_TRANSFORM_iPhone6(38), self.frame.size.width, kDESGIN_TRANSFORM_iPhone6(38));
    cancelButton.titleLabel.font = [UIFont systemFontOfSize:kDESGIN_TRANSFORM_iPhone6(17)];
    [cancelButton setTitleColor:kRGBColor_16BAND(0x1d1d1d) forState:UIControlStateNormal];
    [cancelButton setTitle:NSLocalizedString(@"取消", @"取消") forState:UIControlStateNormal];
    [cancelButton addTarget:self action:@selector(cancelClick) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:cancelButton];
    
    if (choose) {
        
        titleLabel.text = NSLocalizedString(@"可分享到", @"可分享到");
        titleLabel.textColor = kRGBColor_16BAND(0x808080);
        cancelButton.hidden = YES;
        
    }else{
        
        titleLabel.text = NSLocalizedString(@"分享到", @"分享到");
        titleLabel.textColor = kRGBColor_16BAND(0x1d1d1d);
        cancelButton.hidden = NO;
    }
    
    _pageControl = [[UIPageControl alloc]initWithFrame:CGRectMake((self.frame.size.width - 100)/2.0, self.frame.size.height - 15, 100, 15)];
    _pageControl.pageIndicatorTintColor = [UIColor whiteColor];
    _pageControl.currentPageIndicatorTintColor = [UIColor lightGrayColor];
    _pageControl.currentPage = 0;
    _pageControl.numberOfPages = page;
    if (page <= 1) {
        _pageControl.hidden = YES;
    }
    [self addSubview:_pageControl];
    
    float horizeSpace = (self.frame.size.width - kDESGIN_TRANSFORM_iPhone6(SHAREBUTTONWIDTH) *5)/(5 + 1);
    float verticalSpace = 10;
    
    if (arr.count == 1) {
        
        UIView *multView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, bgScrollerView.frame.size.width, bgScrollerView.frame.size.height)];
        multView.backgroundColor = RGBCOLOR(242, 245, 247);
        [bgScrollerView addSubview:multView];
        ShareActionButtonView *buttonView = [[ShareActionButtonView alloc]initWithFrame:CGRectMake((bgScrollerView.frame.size.width - kDESGIN_TRANSFORM_iPhone6(SHAREBUTTONWIDTH))/2.0, 0, kDESGIN_TRANSFORM_iPhone6(SHAREBUTTONWIDTH), kDESGIN_TRANSFORM_iPhone6(SHAREBUTTONWIDTH)) WithImageName:iconArray[0] WithTitle:arr[0]];
        [buttonView addTarget:self action:@selector(shareToMultPlat:) forControlEvents:UIControlEventTouchUpInside];
        buttonView.tag = 0;
        buttonView.backgroundColor = RGBCOLOR(242, 245, 247);
        [multView addSubview:buttonView];
        
    }else{
        
        for (NSInteger p = 0; p < page; p ++) {
            UIView *multView = [[UIView alloc]initWithFrame:CGRectMake(bgScrollerView.frame.size.width *p, 0, bgScrollerView.frame.size.width, bgScrollerView.frame.size.height)];
            multView.backgroundColor = [UIColor whiteColor];
            [bgScrollerView addSubview:multView];
            for (NSInteger i = p*5; i < arr.count; i ++) {
                if (i < (p+1)*5) {
                    NSInteger column = (i%5)%5;
                    NSInteger r = (i%5)/5;
                    ShareActionButtonView *buttonView = [[ShareActionButtonView alloc]initWithFrame:CGRectMake(horizeSpace + (horizeSpace + kDESGIN_TRANSFORM_iPhone6(SHAREBUTTONWIDTH))*column, (verticalSpace + kDESGIN_TRANSFORM_iPhone6(SHAREBUTTONWIDTH))*r, kDESGIN_TRANSFORM_iPhone6(SHAREBUTTONWIDTH), kDESGIN_TRANSFORM_iPhone6(SHAREBUTTONWIDTH)) WithImageName:iconArray[i] WithTitle:arr[i]];
                    [buttonView addTarget:self action:@selector(shareToMultPlat:) forControlEvents:UIControlEventTouchUpInside];
                    buttonView.tag = i;
                    buttonView.backgroundColor = [UIColor whiteColor];
                    [multView addSubview:buttonView];
                }
            }
        }
        
    }
    
}


- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    NSInteger page = scrollView.contentOffset.x/self.frame.size.width;
    _pageControl.currentPage = page;
}

- (void)shareToMultPlat:(UIButton *)btn {
    if (self.delegate != nil && [self.delegate respondsToSelector:@selector(shareToPlatWithIndex:)]) {
        [self actionViewDissmiss];
        [self.delegate shareToPlatWithIndex:btn.tag];
    }
}

- (void)actionViewShow {
    AppDelegate *delegare = (AppDelegate *)[UIApplication sharedApplication].delegate;
    
    _bgview = [[UIView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
    [_bgview setBackgroundColor:[UIColor colorWithRed:0 green:0 blue:0 alpha:0.2]];
    [delegare.window addSubview:_bgview];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapBgviewClick:)];
    tap.numberOfTapsRequired = 1;
    _bgview.userInteractionEnabled = YES;
    [_bgview addGestureRecognizer:tap];
    
    [delegare.window addSubview:self];
    
    [UIView animateWithDuration:0.35 animations:^{
        self.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height - self.frame.size.height , self.frame.size.width, self.frame.size.height);
    }];
}

- (void)tapBgviewClick:(UITapGestureRecognizer *)tap {
    [self actionViewDissmiss];
}

- (void)cancelClick {
    [self actionViewDissmiss];
}

- (void)actionViewDissmiss {
    AppDelegate *delegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    delegate.window.backgroundColor = [UIColor whiteColor];
    [UIView animateWithDuration:0.358 animations:^{
        self.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height , self.frame.size.width, self.frame.size.height);
    } completion:^(BOOL finished) {
        [_bgview removeFromSuperview];
    }];
}

@end
