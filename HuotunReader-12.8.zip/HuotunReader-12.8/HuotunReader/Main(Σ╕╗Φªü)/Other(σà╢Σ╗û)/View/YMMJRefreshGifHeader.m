//
//  YMMJRefreshGifHeader.m
//  HuotunReader
//
//  Created by chengongwen on 2017/11/24.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "YMMJRefreshGifHeader.h"

@interface YMMJRefreshGifHeader ()

@property (weak, nonatomic) UILabel *label;

@end

@implementation YMMJRefreshGifHeader

#pragma mark - 重写方法
#pragma mark 基本设置
- (void)prepare {
    
    [super prepare];
    
    // 设置控件的高度
    self.mj_h = kDESGIN_TRANSFORM_iPhone6(100);
    
    // 隐藏时间
    self.lastUpdatedTimeLabel.hidden = YES;
    
    // 隐藏状态
    self.stateLabel.hidden = YES;
    
    // 设置普通状态的动画图片
    NSMutableArray *idleImages = [NSMutableArray array];
    for (NSUInteger i = 10; i<= 10; i++) {
        UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"loading_%zd", i]];
        [idleImages addObject:image];
    }
    [self setImages:idleImages forState:MJRefreshStateIdle];
    
    // 设置即将刷新状态的动画图片（一松开就会刷新的状态）
    NSMutableArray *refreshingImages = [NSMutableArray array];
    for (NSUInteger i = 0; i<=9; i++) {
        UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"loading_%zd", i]];
        [refreshingImages addObject:image];
    }
    [self setImages:refreshingImages duration:0.7 forState:MJRefreshStatePulling];
    
    // 设置正在刷新状态的动画图片
//    [self setImages:refreshingImages forState:MJRefreshStateRefreshing];
    [self setImages:refreshingImages duration:0.7 forState:MJRefreshStateRefreshing];
    
    // 添加label
    UILabel *label = [[UILabel alloc] init];
    label.textColor = [UIColor grayColor];
    label.font = [UIFont boldSystemFontOfSize:kDESGIN_TRANSFORM_iPhone6(14)];
    label.textAlignment = NSTextAlignmentCenter;
    [self addSubview:label];
    self.label = label;
}

#pragma mark 在这里设置子控件的位置和尺寸
- (void)placeSubviews {
    [super placeSubviews];
    
    if (self.gifView.constraints.count) return;
    
    CGRect frame = self.bounds;
    self.gifView.mj_y = 15;
    self.gifView.mj_h = frame.size.height*2/3 - 15;
    self.gifView.contentMode = UIViewContentModeCenter;
    
    frame = self.bounds;
    frame.origin.y = frame.size.height*1/3;
    self.label.frame = frame;
}

// 重写开始刷新
- (void)beginRefreshing{
    [super beginRefreshing];
    if ([self.scrollView isKindOfClass:[UICollectionView class]] || [self.scrollView isKindOfClass:[UIScrollView class]] || [self.scrollView isKindOfClass:[UITableView class]]) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [super endRefreshing];
        });
    } else {
        [super endRefreshing];
    }
}

#pragma mark 监听scrollView的contentOffset改变
- (void)scrollViewContentOffsetDidChange:(NSDictionary *)change
{
    [super scrollViewContentOffsetDidChange:change];
}

#pragma mark 监听scrollView的contentSize改变
- (void)scrollViewContentSizeDidChange:(NSDictionary *)change
{
    [super scrollViewContentSizeDidChange:change];
}

#pragma mark 监听scrollView的拖拽状态改变
- (void)scrollViewPanStateDidChange:(NSDictionary *)change
{
    [super scrollViewPanStateDidChange:change];
    
}

#pragma mark 监听控件的刷新状态
- (void)setState:(MJRefreshState)state {
    MJRefreshCheckState;
    
    NSString *const MJRefreshHeaderIdleText = NSLocalizedString(@"下拉可以刷新", @"下拉可以刷新");
    NSString *const MJRefreshHeaderPullingText = NSLocalizedString(@"松开立即刷新", @"松开立即刷新");
    NSString *const MJRefreshHeaderRefreshingText = NSLocalizedString(@"正在加载数据...", @"正在加载数据...");
    NSString *const MJRefreshHeaderNoMoreDataText = NSLocalizedString(@"内容已加载完", @"内容已加载完");
    
    switch (state) {
        case MJRefreshStateIdle:
            self.label.text =  MJRefreshHeaderIdleText;
            break;
        case MJRefreshStatePulling:
            self.label.text = MJRefreshHeaderPullingText;
            break;
        case MJRefreshStateRefreshing:
            self.label.text = MJRefreshHeaderRefreshingText;
            break;
        case MJRefreshStateNoMoreData:
            self.label.text = MJRefreshHeaderNoMoreDataText;
            break;
        default:
            break;
    }
}

#pragma mark 监听拖拽比例（控件被拖出来的比例）
- (void)setPullingPercent:(CGFloat)pullingPercent {
    [super setPullingPercent:pullingPercent];
    
    // 1.0 0.5 0.0
    // 0.5 0.0 0.5
//    CGFloat red = 1.0 - pullingPercent * 0.5;
//    CGFloat green = 0.5 - 0.5 * pullingPercent;
//    CGFloat blue = 0.5 * pullingPercent;
//    self.label.textColor = [UIColor colorWithRed:red green:green blue:blue alpha:1.0];
}

@end
