//
//  YMMJRefreshGifHeader.h
//  HuotunReader
//
//  Created by chengongwen on 2017/11/24.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <MJRefresh/MJRefresh.h>

static const CGFloat MJDuration = 3.0;

@interface YMMJRefreshGifHeader : MJRefreshGifHeader


@end
