//
//  BookChoiceViewController.h
//  HuotunReader
//
//  Created by chengongwen on 2017/10/23.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "RxWebViewController.h"

@interface BookChoiceViewController : RxWebViewController

@end
