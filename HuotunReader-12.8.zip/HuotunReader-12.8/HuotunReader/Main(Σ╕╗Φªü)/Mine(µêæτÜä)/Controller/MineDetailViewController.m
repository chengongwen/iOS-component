//
//  MineDetailViewController.m
//  HuotunReader
//
//  Created by chengongwen on 2017/10/24.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "MineDetailViewController.h"
#import "AppDelegate.h"

#define IMAGE_HEIGHT 260
#define NAVBAR_COLORCHANGE_POINT (IMAGE_HEIGHT - kNaviBarHeight*2)

@interface MineDetailViewController () <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) UIView *topView;
@property (nonatomic, strong) UIImageView *imgView;
@end

@implementation MineDetailViewController

- (void)dealloc {
    
}

- (instancetype)init{
    if (self = [super init]) {
        self.isShowBackBtn = YES;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.navigationItem.title = @"个人中心";
    [self vhl_setNavBarBackgroundAlpha:0];
   
    [self.view addSubview:self.tableView];
    [self.topView addSubview:self.imgView];
    self.imgView.center = self.topView.center;
    self.tableView.tableHeaderView = self.topView;
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    self.tableView.frame = self.view.bounds;
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat offsetY = scrollView.contentOffset.y;
    
    if (offsetY > NAVBAR_COLORCHANGE_POINT)
    {
        CGFloat alpha = (offsetY - NAVBAR_COLORCHANGE_POINT) / kNaviBarHeight;
        [self vhl_setNavBarBackgroundAlpha:alpha];
    }
    else
    {
        [self vhl_setNavBarBackgroundAlpha:0];
    }
}

#pragma mark - tableview delegate / dataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 10;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                                   reuseIdentifier:nil];
    NSString *str = [NSString stringWithFormat:@"WRNavigationBar %zd",indexPath.row];
    cell.textLabel.text = str;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - getter / setter
- (UITableView *)tableView
{
    if (!_tableView) {
        CGRect frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.bounds.size.height);
        _tableView = [[UITableView alloc] initWithFrame:frame style:UITableViewStylePlain];
        _tableView.contentInset = UIEdgeInsetsMake(-kNaviBarHeight, 0, 0, 0);
        _tableView.delegate = self;
        _tableView.dataSource = self;
    }
    return _tableView;
}

- (UIView *)topView
{
    if (_topView == nil) {
        _topView = [[UIView alloc] initWithFrame:CGRectMake(0, kNaviBarPostionY, self.view.frame.size.width, IMAGE_HEIGHT)];
        _topView.backgroundColor = [UIColor orangeColor];
    }
    return _topView;
}

- (UIImageView *)imgView
{
    if (_imgView == nil) {
        _imgView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"wbBG"]];
        _imgView.bounds = CGRectMake(0, 0, 100, 100);
        _imgView.layer.cornerRadius = 50;
        _imgView.layer.masksToBounds = YES;
    }
    return _imgView;
}


@end
