//
//  MineViewController.m
//  HuotunReader
//
//  Created by chengongwen on 2017/10/23.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "MineViewController.h"
#import "MineDetailViewController.h"

@interface MineViewController ()

@end

@implementation MineViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.navigationItem.title = @"我的";
    
    // 按钮图片
    UIButton *rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
    rightButton.frame = CGRectMake(0, 0, 30, 30);
    [rightButton setImage:[UIImage imageNamed:@"setting"]  forState:UIControlStateNormal];
    [rightButton setImage:[UIImage imageNamed:@"setting"]  forState:UIControlStateHighlighted];
    [rightButton addTarget:self action:@selector(pushAction) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithCustomView:rightButton];
    [self.navigationItem setRightBarButtonItem:rightItem];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)pushAction {
    MineDetailViewController *customNavBarVC = [[MineDetailViewController alloc] init];
    [self.navigationController pushViewController:customNavBarVC animated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
