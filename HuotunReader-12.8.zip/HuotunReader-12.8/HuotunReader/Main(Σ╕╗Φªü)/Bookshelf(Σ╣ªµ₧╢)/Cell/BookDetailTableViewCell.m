//
//  BookDetailTableViewCell.m
//  HuotunReader
//
//  Created by chengongwen on 2017/11/28.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "BookDetailTableViewCell.h"
#import "UIView+SDAutoLayout.h"
#import "UITableView+SDAutoTableViewCellHeight.h"
#import "BookDetailModel.h"
#import "WclEmitterButton.h"

@implementation BookDetailTableViewCell
{
    UIImageView *_headView;
    UILabel *_titleLabel;
    UILabel *_timeLabel;
    UILabel *_contentLabel;
    
    WclEmitterButton *_priasesButton;
    UILabel *_priasesLabel;
    
    UIImageView *_view3;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self setup];
    }
    return self;
}

- (void)setup
{
    // 头像
    UIImageView *headView = [[UIImageView alloc] init];
    headView.backgroundColor = [UIColor redColor];
    _headView = headView;
    
    // 用户昵称
    UILabel *titleLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0x2D0504) fontSize:kDESGIN_TRANSFORM_iPhone6(15)];
    _titleLabel = titleLabel;
    
    // 时间
    UILabel *timeLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0x999999) fontSize:kDESGIN_TRANSFORM_iPhone6(12)];
    _timeLabel = timeLabel;
    
    // 内容
    UILabel *contentLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0x666666) fontSize:kDESGIN_TRANSFORM_iPhone6(13)];
    contentLabel.numberOfLines = 0;
    _contentLabel = contentLabel;
    
    // 点赞数
    UILabel *priasesLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0x999999) fontSize:kDESGIN_TRANSFORM_iPhone6(15)];
//    priasesLabel.backgroundColor = kBlueColor;
    priasesLabel.textAlignment = NSTextAlignmentRight;
    _priasesLabel = priasesLabel;
    
    // 点赞
    WclEmitterButton *priaseButton = [[WclEmitterButton alloc] initWithFrame:CGRectMake(10, 10, kDESGIN_TRANSFORM_iPhone6(40), kDESGIN_TRANSFORM_iPhone6(40))];
    [priaseButton setImage:[UIImage imageNamed:@"detail_priase"] forState:UIControlStateNormal];
    [priaseButton setImage:[UIImage imageNamed:@"detail_priaseHL"] forState:UIControlStateHighlighted];
    [priaseButton setImage:[UIImage imageNamed:@"detail_priaseHL"] forState:UIControlStateSelected];
    [priaseButton addTarget:self action:@selector(priaseClicked:) forControlEvents:UIControlEventTouchUpInside];
    _priasesButton = priaseButton;
    
    UIImageView *view3 = [UIImageView new];
    view3.backgroundColor = [UIColor orangeColor];
    _view3 = view3;
    [self.contentView sd_addSubviews:@[headView, titleLabel, timeLabel ,priasesLabel,contentLabel, priaseButton,view3]];
    
    _headView.sd_layout
    .widthIs(kDESGIN_TRANSFORM_iPhone6(40))
    .heightIs(kDESGIN_TRANSFORM_iPhone6(40))
    .topSpaceToView(self.contentView, 10)
    .leftSpaceToView(self.contentView, 10);
    
    _titleLabel.sd_layout
    .topEqualToView(_headView)
    .leftSpaceToView(_headView, 10)
    .heightRatioToView(_headView, 0.4);
    
    _priasesLabel.sd_layout
    .topEqualToView(_titleLabel)
    .leftSpaceToView(self.contentView, kScreenWidth*7/10.0)
    .heightRatioToView(_headView, 0.5)
    .minWidthIs(kDESGIN_TRANSFORM_iPhone6(60));
    
    _priasesButton.sd_layout
    .widthIs(kDESGIN_TRANSFORM_iPhone6(24))
    .heightIs(kDESGIN_TRANSFORM_iPhone6(25))
    .centerYEqualToView(_priasesLabel)
    .leftSpaceToView(_priasesLabel, 10);
    
    _timeLabel.sd_layout
    .heightRatioToView(_headView, 0.4)
    .leftEqualToView(_titleLabel)
    .topSpaceToView(_titleLabel, 3);
    
    _contentLabel.sd_layout
    .topSpaceToView(_timeLabel,3)
    .rightSpaceToView(self.contentView, 10)
    .leftEqualToView(_titleLabel)
    .autoHeightRatio(0);
    
    _view3.sd_layout
    .topSpaceToView(_contentLabel, 10)
    .leftEqualToView(_contentLabel)
    .widthRatioToView(_contentLabel, 0.7);
    
    _headView.sd_cornerRadiusFromWidthRatio = @(0.5);
    
    [_titleLabel setSingleLineAutoResizeWithMaxWidth:200];
    
    [_timeLabel setSingleLineAutoResizeWithMaxWidth:200];
    
    [_priasesLabel setSingleLineAutoResizeWithMaxWidth:100];
}

- (void)setModel:(BookDetailModel *)model {
    _model = model;
    
    [_headView sd_setImageWithURL:[NSURL URLWithString:model.iconName] placeholderImage:[UIImage imageNamed:@"logo"]];
    
    _titleLabel.text = model.name;
    
    _contentLabel.text = model.content;
    
    _timeLabel.text = @"09月28日 08:28";
    
    int priases = arc4random_uniform(1000);
    _priasesLabel.text = [NSString stringWithFormat:@"%u",priases];
    
    if (priases%2) {
        [_priasesButton setSelected:YES animated:NO];
    }
    else {
        [_priasesButton setSelected:NO animated:NO];
    }
    
    CGFloat bottomMargin = 0;
    
    // 在实际的开发中，网络图片的宽高应由图片服务器返回然后计算宽高比。
//    UIImage *pic = [UIImage imageNamed:model.picName];
//    if (pic.size.width > 0) {
//        CGFloat scale = pic.size.height / pic.size.width;
//        _view3.sd_layout.autoHeightRatio(scale);
//        _view3.image = pic;
//        bottomMargin = 10;
//    }
//    else {
//        _view3.sd_layout.autoHeightRatio(0);
//    }
    
    _view3.sd_layout.autoHeightRatio(0);
    
    // ***********************高度自适应cell设置步骤************************
    [self setupAutoHeightWithBottomView:_view3 bottomMargin:bottomMargin];
}

// 点赞
- (void)priaseClicked:(UIButton *)button {
    [_priasesButton setSelected:!button.selected animated:YES];
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    self.selectionStyle = UITableViewCellSelectionStyleNone;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
