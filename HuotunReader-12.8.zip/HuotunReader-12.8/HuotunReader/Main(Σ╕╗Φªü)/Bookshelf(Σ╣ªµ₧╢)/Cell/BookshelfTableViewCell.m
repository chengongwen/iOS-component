//
//  BookshelfTableViewCell.m
//  HuotunReader
//
//  Created by chengongwen on 2017/11/21.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "BookshelfTableViewCell.h"
#import "CatalogueObject.h"

@interface BookshelfTableViewCell ()

@property (nonatomic, strong) UIImageView *avatarImageView; // 头像
@property (nonatomic, strong) UILabel *titleLabel;           // 名称
@property (nonatomic, strong) UILabel *nameLabel;           // 名称
@property (nonatomic, strong) UILabel *timeLabel;           // 记录
@end

@implementation BookshelfTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        self.backgroundColor = kWhiteColor;
        self.contentView.backgroundColor = kWhiteColor;
        
        // 背景图
        UIView *backgroundView = [[UIView alloc] init];
        backgroundView.backgroundColor = kWhiteColor;
        [[backgroundView layer] setBorderWidth:2.0];//画线的宽度
        [[backgroundView layer] setBorderColor:kClearColor.CGColor];//颜色
        [[backgroundView layer] setCornerRadius:6.0]; //圆角
        [self.contentView addSubview:backgroundView];
        [backgroundView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(@3);
            make.left.equalTo(@3);
            make.right.equalTo(@(-3));
            make.bottom.equalTo(@0);
        }];
        
        // 左边头像
        self.avatarImageView = [[UIImageView alloc] init];
        self.avatarImageView.layer.masksToBounds = YES;
        self.avatarImageView.layer.cornerRadius = kDESGIN_TRANSFORM_iPhone6(2);
        [self.contentView addSubview:self.avatarImageView];
        [self.avatarImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(self.contentView);
            make.left.equalTo(@(kScaleFrom_iPhone6_Desgin_X(15)));
            make.width.equalTo(@(kDESGIN_TRANSFORM_iPhone6(57.5)));
            make.height.equalTo(@(kDESGIN_TRANSFORM_iPhone6(81)));
        }];
        
        // 用户名称
        self.titleLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0x050402) fontSize:kDESGIN_TRANSFORM_iPhone6(15)];
        [self.contentView addSubview:self.titleLabel];
        [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.avatarImageView.mas_top);
            make.left.equalTo(self.avatarImageView.mas_right).offset(kScaleFrom_iPhone6_Desgin_Y(20));
        }];
        
        self.nameLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0x999999) fontSize:kDESGIN_TRANSFORM_iPhone6(12)];
        [self.contentView addSubview:self.nameLabel];
        [self.nameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.titleLabel.mas_bottom).offset(kScaleFrom_iPhone6_Desgin_Y(10));
            make.left.equalTo(self.titleLabel.mas_left);
        }];
        
        self.timeLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0x666666) fontSize:kDESGIN_TRANSFORM_iPhone6(14)];
        [self.contentView addSubview:self.timeLabel];
        [self.timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.nameLabel.mas_bottom).offset(kScaleFrom_iPhone6_Desgin_Y(20));
            make.left.equalTo(self.titleLabel.mas_left);
        }];
        
//        UIView *seperator = [[UIView alloc] init];
//        seperator.backgroundColor = [UIColor grayColor];
//        seperator.alpha = 0.3;
//        [self.contentView addSubview:seperator];
//        [seperator mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.left.equalTo(@5);
//            make.right.equalTo(@-5);
//            make.bottom.equalTo(self.contentView);
//            make.height.equalTo(@(0.5));
//        }];
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


- (void)refreshCellWithObject:(CatalogueObject *)model {
    [self.avatarImageView sd_setImageWithURL:[NSURL URLWithString:model.thumbImageURL] placeholderImage:[UIImage imageNamed:@"book_default"]];
    
    self.titleLabel.text = model.title;
    self.nameLabel.text = model.author;
    self.timeLabel.text = [NSString stringWithFormat:@"读到 %0.1f%@",model.currentProgress,@"%"];
}

@end
