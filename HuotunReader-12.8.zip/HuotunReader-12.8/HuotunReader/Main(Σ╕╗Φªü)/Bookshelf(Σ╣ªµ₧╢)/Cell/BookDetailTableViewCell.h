//
//  BookDetailTableViewCell.h
//  HuotunReader
//
//  Created by chengongwen on 2017/11/28.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BookDetailModel;

@interface BookDetailTableViewCell : UITableViewCell

@property (nonatomic, strong) BookDetailModel *model;

@end
