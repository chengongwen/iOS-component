//
//  BookshelfTableViewCell.h
//  HuotunReader
//
//  Created by chengongwen on 2017/11/21.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CatalogueObject;

@interface BookshelfTableViewCell : UITableViewCell

- (void)refreshCellWithObject:(CatalogueObject *)model;

@end
