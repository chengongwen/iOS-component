//
//  DetailBottomView.h
//  HuotunReader
//
//  Created by chengongwen on 2017/11/27.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol BookshelfViewControllerDelegate;

@interface DetailBottomView : UIView

@property (nonatomic, assign) id<BookshelfViewControllerDelegate> delegate;
@end
