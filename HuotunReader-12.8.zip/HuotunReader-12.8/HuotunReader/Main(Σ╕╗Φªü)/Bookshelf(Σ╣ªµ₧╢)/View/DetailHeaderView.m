//
//  DetailHeaderView.m
//  HuotunReader
//
//  Created by chengongwen on 2017/11/27.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "DetailHeaderView.h"
#import "BookDetailViewController.h"
#import "CatalogueObject.h"

@interface DetailHeaderView()

@property (nonatomic, strong) UIImageView *avatarImageView; // 头像
@property (nonatomic, strong) UILabel *titleLabel;          // 书籍名称
@property (nonatomic, strong) UILabel *autherLabel;         // 作者
@property (nonatomic, strong) UILabel *totalWordsLabel;     // 总字数
@property (nonatomic, strong) UILabel *totalPriasesLabel;     // 总点赞数
@property (nonatomic, strong) UILabel *despLabel;           // 简介
@property (nonatomic, strong) UIButton *catagButton;        // 目录

@property (nonatomic, strong) UILabel *totalVoteLabel;      // 投票
@property (nonatomic, strong) UILabel *totalRecommendLabel; // 推荐
@property (nonatomic, strong) UILabel *totalRewordLabel;    // 打赏

@property (nonatomic, strong) UILabel *totalCommentLable;  // 评论数
@end

@implementation DetailHeaderView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = kWhiteColor;
        
        // 背景图
        UIView *backgroundView = [[UIView alloc] init];
        backgroundView.backgroundColor = kClearColor;
        [[backgroundView layer] setBorderWidth:2.0];//画线的宽度
        [[backgroundView layer] setBorderColor:kClearColor.CGColor];//颜色
        [[backgroundView layer] setCornerRadius:3.0]; //圆角
        [self addSubview:backgroundView];
        [backgroundView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(@0);
            make.left.equalTo(@0);
            make.right.equalTo(@(0));
            make.bottom.equalTo(@0);
        }];
        
        // 左边头像
        self.avatarImageView = [[UIImageView alloc] init];
        self.avatarImageView.image = [UIImage imageNamed:@"book_default"];
        self.avatarImageView.layer.masksToBounds = YES;
        self.avatarImageView.layer.cornerRadius = kDESGIN_TRANSFORM_iPhone6(2);
        [self addSubview:self.avatarImageView];
        [self.avatarImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(@(kScaleFrom_iPhone6_Desgin_Y(10)));
            make.left.equalTo(@(kScaleFrom_iPhone6_Desgin_X(15)));
            make.width.equalTo(@(kDESGIN_TRANSFORM_iPhone6(97)));
            make.height.equalTo(@(kDESGIN_TRANSFORM_iPhone6(136)));
        }];
        
        // 书籍名称
        self.titleLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0x2D0504) fontSize:kDESGIN_TRANSFORM_iPhone6(15)];
        self.titleLabel.text = @"书名";
        [self addSubview:self.titleLabel];
        [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.avatarImageView.mas_top).offset(kScaleFrom_iPhone6_Desgin_Y(5));
            make.left.equalTo(self.avatarImageView.mas_right).offset(kScaleFrom_iPhone6_Desgin_X(15));
        }];
        
        // 字数
        UIImageView *totalWordsImageView = [[UIImageView alloc] init];
        totalWordsImageView.image = [UIImage imageNamed:@"detail_total_words"];
        [self addSubview:totalWordsImageView];
        [totalWordsImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.titleLabel.mas_bottom).offset(kScaleFrom_iPhone6_Desgin_Y(35));
            make.left.equalTo(self.titleLabel.mas_left);
        }];
        
        self.totalWordsLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0x999999) fontSize:kDESGIN_TRANSFORM_iPhone6(13)];
        self.totalWordsLabel.text = @"0字";
        [self addSubview:self.totalWordsLabel];
        [self.totalWordsLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(totalWordsImageView);
            make.left.equalTo(totalWordsImageView.mas_right).offset(kScaleFrom_iPhone6_Desgin_X(5));
//            make.width.greaterThanOrEqualTo(@(40));
        }];
        
        UIView *separeline1 = [[UIView alloc] init];
        separeline1.backgroundColor = kRGBColor_16BAND(0xDBDAE0);
        [self addSubview:separeline1];
        [separeline1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(totalWordsImageView);
            make.left.equalTo(self.totalWordsLabel.mas_right).offset(kScaleFrom_iPhone6_Desgin_X(10));
            make.width.equalTo(@1);
            make.height.equalTo(@10);
        }];
        
        // 点赞数
        UIImageView *totalPriasesImageView = [[UIImageView alloc] init];
        totalPriasesImageView.image = [UIImage imageNamed:@"detail_total_priases"];
        [self addSubview:totalPriasesImageView];
        [totalPriasesImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.titleLabel.mas_bottom).offset(kScaleFrom_iPhone6_Desgin_Y(35));
            make.left.equalTo(separeline1.mas_right).offset(kScaleFrom_iPhone6_Desgin_X(10));
        }];
        
        self.totalPriasesLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0x999999) fontSize:kDESGIN_TRANSFORM_iPhone6(13)];
        self.totalPriasesLabel.text = @"0";
        [self addSubview:self.totalPriasesLabel];
        [self.totalPriasesLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(totalPriasesImageView);
            make.left.equalTo(totalPriasesImageView.mas_right).offset(kScaleFrom_iPhone6_Desgin_X(5));
        }];
        
        // 作者
        UIImageView *autherImageView = [[UIImageView alloc] init];
        autherImageView.image = [UIImage imageNamed:@"detail_author"];
        [self addSubview:autherImageView];
        [autherImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(totalWordsImageView.mas_bottom).offset(kScaleFrom_iPhone6_Desgin_Y(20));
            make.left.equalTo(self.titleLabel.mas_left);
        }];
        
        self.autherLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0x392324) fontSize:kDESGIN_TRANSFORM_iPhone6(12)];
        self.autherLabel.text = @"作者";
        [self addSubview:self.autherLabel];
        [self.autherLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(autherImageView);
            make.left.equalTo(autherImageView.mas_right).offset(kScaleFrom_iPhone6_Desgin_X(5));
        }];
        
        UIView *separeline2 = [[UIView alloc] init];
        separeline2.backgroundColor = kRGBColor_16BAND(0xDBDAE0);
        [self addSubview:separeline2];
        [separeline2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(@(kScaleFrom_iPhone6_Desgin_Y(160)));
            make.left.equalTo(@(kScaleFrom_iPhone6_Desgin_X(15)));
            make.right.equalTo(@(-kScaleFrom_iPhone6_Desgin_X(15)));
            make.height.equalTo(@1);
        }];
        
        // 书籍简介
        self.despLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0x666666) fontSize:kDESGIN_TRANSFORM_iPhone6(12)];
        self.despLabel.text = @"书籍简介...";
        self.despLabel.numberOfLines = 0;
        [self addSubview:self.despLabel];
        [self.despLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(separeline2.mas_bottom).offset(kScaleFrom_iPhone6_Desgin_Y(10));
            make.left.equalTo(@(kScaleFrom_iPhone6_Desgin_X(15)));
            make.right.equalTo(@(-kScaleFrom_iPhone6_Desgin_X(15)));
            make.height.lessThanOrEqualTo(@kDESGIN_TRANSFORM_iPhone6(52));
        }];
        
        UIView *separeline3 = [[UIView alloc] init];
        separeline3.backgroundColor = kRGBColor_16BAND(0xDBDAE0);
        [self addSubview:separeline3];
        [separeline3 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(@(kScaleFrom_iPhone6_Desgin_Y(238)));
            make.left.equalTo(@(0));
            make.right.equalTo(@(0));
            make.height.equalTo(@1.5);
        }];
        
        // 目录
        UIView *catagView = [[UIView alloc] init];
        catagView.backgroundColor = kWhiteColor;
        [self addSubview:catagView];
        [catagView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(separeline3.mas_bottom);
            make.left.equalTo(@(0));
            make.right.equalTo(@(0));
            make.height.equalTo(@kDESGIN_TRANSFORM_iPhone6(44));
        }];
        
        UIImageView *catagImageView = [[UIImageView alloc] init];
        catagImageView.image = [UIImage imageNamed:@"detail_catag"];
        [catagView addSubview:catagImageView];
        [catagImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(catagView);
            make.left.equalTo(@(kScaleFrom_iPhone6_Desgin_X(15)));
        }];
        
        UILabel *catagLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0x2D0504) fontSize:kDESGIN_TRANSFORM_iPhone6(15)];
        catagLabel.text = @"目录";
        [catagView addSubview:catagLabel];
        [catagLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(catagImageView);
            make.left.equalTo(catagImageView.mas_right).offset(kScaleFrom_iPhone6_Desgin_X(5));
        }];
        
        
        UIButton *catagMoreButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [catagMoreButton setImage:[UIImage imageNamed:@"detail_more"] forState:UIControlStateNormal];
        [catagView addSubview:catagMoreButton];
        [catagMoreButton addTarget:self action:@selector(jumpToCatalogClicked) forControlEvents:UIControlEventTouchUpInside];
        [catagMoreButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(catagView);
            make.right.equalTo(@(-kScaleFrom_iPhone6_Desgin_X(15)));
            make.height.equalTo(@(kDESGIN_TRANSFORM_iPhone6(15)));
            make.width.equalTo(@(kDESGIN_TRANSFORM_iPhone6(8)));
        }];
        
        self.catagButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.catagButton setTitleColor:kRGBColor_16BAND(0x3DC67A) forState:UIControlStateNormal];
        [self.catagButton.titleLabel setFont:[UIFont boldSystemFontOfSize:kDESGIN_TRANSFORM_iPhone6(13)]];
        [catagView addSubview:self.catagButton];
        [self.catagButton sizeToFit];
        [self.catagButton addTarget:self action:@selector(jumpToCatalogClicked) forControlEvents:UIControlEventTouchUpInside];
        [self.catagButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(catagView);
            make.right.equalTo(@(-kScaleFrom_iPhone6_Desgin_X(20)));
            make.height.equalTo(@(kDESGIN_TRANSFORM_iPhone6(15)));
            make.width.equalTo(@(kDESGIN_TRANSFORM_iPhone6(100)));
        }];
//        self.catagButton.titleLabel.backgroundColor = self.catagButton.backgroundColor;
//        self.catagButton.imageView.backgroundColor = self.catagButton.backgroundColor;
//        //在使用一次titleLabel和imageView后才能正确获取titleSize
//        CGSize titleSize = self.catagButton.titleLabel.bounds.size;
//        CGSize imageSize = self.catagButton.imageView.bounds.size;
//        CGFloat interval = 1.0;
//        CGFloat positionY = 5; // 偏移量
//        self.catagButton.imageEdgeInsets = UIEdgeInsetsMake(0,titleSize.width + interval + positionY, 0, -(titleSize.width + interval));
//        self.catagButton.titleEdgeInsets = UIEdgeInsetsMake(0, -(imageSize.width + interval) - positionY, 0, imageSize.width + interval);
        
        UIView *separeline4 = [[UIView alloc] init];
        separeline4.backgroundColor = kRGBColor_16BAND(0xDBDAE0);
        [self addSubview:separeline4];
        [separeline4 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(catagView.mas_bottom);
            make.left.equalTo(@(0));
            make.right.equalTo(@(0));
            make.height.equalTo(@2);
        }];
        
        // 背景图
        UIView *backgroundView1 = [[UIView alloc] init];
        backgroundView1.backgroundColor = kWhiteColor;
        [[backgroundView1 layer] setBorderWidth:2.0];//画线的宽度
        [[backgroundView1 layer] setBorderColor:kWhiteColor.CGColor];//颜色
        [[backgroundView1 layer] setCornerRadius:3.0]; //圆角
        [self addSubview:backgroundView1];
        [backgroundView1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(separeline4.mas_bottom);
            make.left.equalTo(@0);
            make.right.equalTo(@(0));
            make.height.equalTo(@kDESGIN_TRANSFORM_iPhone6(56));
        }];
        
        // 投票
        UIView *view1 = [[UIView alloc] init];
        view1.backgroundColor = kWhiteColor;
        [backgroundView1 addSubview:view1];
        [view1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(@kDESGIN_TRANSFORM_iPhone6(3));
            make.left.equalTo(@0);
            make.width.equalTo(@(kScreenWidth/3));
            make.height.equalTo(@kDESGIN_TRANSFORM_iPhone6(50));
        }];
        
        self.totalVoteLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0xD6A464) fontSize:kDESGIN_TRANSFORM_iPhone6(12)];
        self.totalVoteLabel.text = @"0";
        self.totalVoteLabel.textAlignment = NSTextAlignmentCenter;
        [view1 addSubview:self.totalVoteLabel];
        [self.totalVoteLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(@(kScaleFrom_iPhone6_Desgin_Y(5)));
            make.centerX.equalTo(view1);
            make.width.equalTo(@(kScreenWidth/3));
            make.height.equalTo(@kDESGIN_TRANSFORM_iPhone6(20));
        }];
        
        UILabel *voteTitleLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0x2D0504) fontSize:kDESGIN_TRANSFORM_iPhone6(12)];
        voteTitleLabel.text = @"投票";
        voteTitleLabel.textAlignment = NSTextAlignmentCenter;
        [view1 addSubview:voteTitleLabel];
        [voteTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(@(kScaleFrom_iPhone6_Desgin_Y(25)));
            make.centerX.equalTo(view1);
            make.width.equalTo(@(kScreenWidth/3));
            make.height.equalTo(@kDESGIN_TRANSFORM_iPhone6(20));
        }];
        
        UIButton *voteButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [view1 addSubview:voteButton];
        [voteButton addTarget:self action:@selector(voteClicked) forControlEvents:UIControlEventTouchUpInside];
        [voteButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(view1);
            make.width.equalTo(@(kScreenWidth/3));
            make.height.equalTo(@kDESGIN_TRANSFORM_iPhone6(54));
        }];
        
        // 推荐
        UIView *view2 = [[UIView alloc] init];
        view2.backgroundColor = kWhiteColor;
        [backgroundView1 addSubview:view2];
        [view2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(view1.mas_top);
            make.left.equalTo(@(kScreenWidth/3));
            make.width.equalTo(@(kScreenWidth/3));
            make.height.equalTo(@kDESGIN_TRANSFORM_iPhone6(50));
        }];
        
        self.totalRecommendLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0xD6A464) fontSize:kDESGIN_TRANSFORM_iPhone6(12)];
        self.totalRecommendLabel.text = @"0";
        self.totalRecommendLabel.textAlignment = NSTextAlignmentCenter;
        [view2 addSubview:self.totalRecommendLabel];
        [self.totalRecommendLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(@(kScaleFrom_iPhone6_Desgin_Y(5)));
            make.centerX.equalTo(view2);
            make.width.equalTo(@(kScreenWidth/3));
            make.height.equalTo(@kDESGIN_TRANSFORM_iPhone6(20));
        }];
        
        UILabel *recommendTitleLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0x2D0504) fontSize:kDESGIN_TRANSFORM_iPhone6(12)];
        recommendTitleLabel.text = @"推荐";
        recommendTitleLabel.textAlignment = NSTextAlignmentCenter;
        [view2 addSubview:recommendTitleLabel];
        [recommendTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(@(kScaleFrom_iPhone6_Desgin_Y(25)));
            make.centerX.equalTo(view2);
            make.width.equalTo(@(kScreenWidth/3));
            make.height.equalTo(@kDESGIN_TRANSFORM_iPhone6(20));
        }];
        
        UIButton *recommendButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [view2 addSubview:recommendButton];
        [recommendButton addTarget:self action:@selector(recommendClicked) forControlEvents:UIControlEventTouchUpInside];
        [recommendButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(view2);
            make.width.equalTo(@(kScreenWidth/3));
            make.height.equalTo(@kDESGIN_TRANSFORM_iPhone6(54));
        }];
        
        
        // 金币
        UIView *view3 = [[UIView alloc] init];
        view3.backgroundColor = kWhiteColor;
        [backgroundView1 addSubview:view3];
        [view3 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(view1.mas_top);
            make.left.equalTo(@(2*kScreenWidth/3.0));
            make.width.equalTo(@(kScreenWidth/3));
            make.height.equalTo(@kDESGIN_TRANSFORM_iPhone6(50));
        }];
        
        self.totalRewordLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0xD6A464) fontSize:kDESGIN_TRANSFORM_iPhone6(12)];
        self.totalRewordLabel.text = @"0";
        self.totalRewordLabel.textAlignment = NSTextAlignmentCenter;
        [view3 addSubview:self.totalRewordLabel];
        [self.totalRewordLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(@(kScaleFrom_iPhone6_Desgin_Y(5)));
            make.centerX.equalTo(view3);
            make.width.equalTo(@(kScreenWidth/3));
            make.height.equalTo(@kDESGIN_TRANSFORM_iPhone6(20));
        }];
        
        UILabel *rewardTitleLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0x2D0504) fontSize:kDESGIN_TRANSFORM_iPhone6(12)];
        rewardTitleLabel.text = @"打赏";
        rewardTitleLabel.textAlignment = NSTextAlignmentCenter;
        [view3 addSubview:rewardTitleLabel];
        [rewardTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(@(kScaleFrom_iPhone6_Desgin_Y(25)));
            make.centerX.equalTo(view3);
            make.width.equalTo(@(kScreenWidth/3));
            make.height.equalTo(@kDESGIN_TRANSFORM_iPhone6(20));
        }];
        
        UIButton *rewardButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [view3 addSubview:rewardButton];
        [rewardButton addTarget:self action:@selector(rewardClicked) forControlEvents:UIControlEventTouchUpInside];
        [rewardButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(view3);
            make.width.equalTo(@(kScreenWidth/3));
            make.height.equalTo(@kDESGIN_TRANSFORM_iPhone6(54));
        }];
        
        UIView *separelineV1 = [[UIView alloc] init];
        separelineV1.backgroundColor = kRGBColor_16BAND(0xEEEBEB);
        [backgroundView1 addSubview:separelineV1];
        [separelineV1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(@(kScreenWidth/3.0));
            make.centerY.equalTo(backgroundView1);
            make.width.equalTo(@1);
            make.height.equalTo(@kDESGIN_TRANSFORM_iPhone6(30));
        }];
        
        UIView *separelineV2 = [[UIView alloc] init];
        separelineV2.backgroundColor = kRGBColor_16BAND(0xEEEBEB);
        [backgroundView1 addSubview:separelineV2];
        [separelineV2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(@(kScreenWidth*2.0/3.0));
            make.centerY.equalTo(backgroundView1);
            make.width.equalTo(@1);
            make.height.equalTo(@kDESGIN_TRANSFORM_iPhone6(30));
        }];
        
        UIView *separeline6 = [[UIView alloc] init];
        separeline6.backgroundColor = kRGBColor_16BAND(0xDBDAE0);
        [backgroundView1 addSubview:separeline6];
        [separeline6 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(backgroundView1.mas_bottom);
            make.left.equalTo(@(0));
            make.right.equalTo(@(0));
            make.height.equalTo(@2);
        }];
        
        // 评论区
        UIView *backgroundView2 = [[UIView alloc] init];
        backgroundView2.backgroundColor = kWhiteColor;
        [[backgroundView2 layer] setBorderWidth:2.0];//画线的宽度
        [[backgroundView2 layer] setBorderColor:kWhiteColor.CGColor];//颜色
        [[backgroundView2 layer] setCornerRadius:3.0]; //圆角
        [self addSubview:backgroundView2];
        [backgroundView2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(separeline6.mas_bottom);
            make.left.equalTo(@0);
            make.right.equalTo(@(0));
            make.height.equalTo(@kDESGIN_TRANSFORM_iPhone6(50));
        }];
        
        UILabel *commentTitle = [UILabel labelWithTextColor:kRGBColor_16BAND(0x666666) fontSize:kDESGIN_TRANSFORM_iPhone6(15)];
        commentTitle.text = @"评书区";
        commentTitle.textAlignment = NSTextAlignmentCenter;
        [backgroundView2 addSubview:commentTitle];
        [commentTitle mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(@(kScaleFrom_iPhone6_Desgin_X(15)));
            make.centerY.equalTo(backgroundView2);
        }];

        self.totalCommentLable = [UILabel labelWithTextColor:kRGBColor_16BAND(0x999999) fontSize:kDESGIN_TRANSFORM_iPhone6(13)];
        [backgroundView2 addSubview:self.totalCommentLable];
        [self.totalCommentLable mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(commentTitle.mas_right).offset(5);
            make.centerY.equalTo(backgroundView2);
        }];
        
        UIButton *commentButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [commentButton setTitle:@"写评论" forState:UIControlStateNormal];
        [commentButton setTitleColor:kRGBColor_16BAND(0x2D0504) forState:UIControlStateNormal];
        [commentButton.titleLabel setFont:[UIFont boldSystemFontOfSize:kDESGIN_TRANSFORM_iPhone6(13)]];
        [commentButton setBackgroundImage:[UIImage imageNamed:@"detail_comment"] forState:UIControlStateNormal];
        [commentButton sizeToFit];
        [backgroundView2 addSubview:commentButton];
        [commentButton addTarget:self action:@selector(commentClicked) forControlEvents:UIControlEventTouchUpInside];
        [commentButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(backgroundView2);
            make.right.equalTo(@(-kScaleFrom_iPhone6_Desgin_X(15)));
            make.height.equalTo(@(kDESGIN_TRANSFORM_iPhone6(24)));
            make.width.equalTo(@(kDESGIN_TRANSFORM_iPhone6(67)));
        }];
        commentButton.titleEdgeInsets = UIEdgeInsetsMake(0, 3, 0, -3);     // 图片和字体靠近一点，根据实际情况调整
        
        UIView *separeline7 = [[UIView alloc] init];
        separeline7.backgroundColor = kRGBColor_16BAND(0xEEEBEB);
        [self addSubview:separeline7];
        [separeline7 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(backgroundView2.mas_bottom);
            make.left.right.equalTo(@0);
            make.height.equalTo(@(1));
        }];
    }
    return self;
}

- (void)jumpToCatalogClicked {
    if ([self.delegate respondsToSelector:@selector(jumpToCatalog)]) {
        [self.delegate jumpToCatalog];
    }
}

- (void)voteClicked {
    if ([self.delegate respondsToSelector:@selector(actionVoteView)]) {
        [self.delegate actionVoteView];
    }
}

- (void)rewardClicked {
    if ([self.delegate respondsToSelector:@selector(actionRewardView)]) {
        [self.delegate actionRewardView];
    }
}

- (void)recommendClicked {
    if ([self.delegate respondsToSelector:@selector(actionRecommendView)]) {
        [self.delegate actionRecommendView];
    }
}

- (void)commentClicked {
    if ([self.delegate respondsToSelector:@selector(writeCommentActon)]) {
        [self.delegate writeCommentActon];
    }
}

- (void)refreshHeaderView:(CatalogueObject *)model {
    [self.avatarImageView sd_setImageWithURL:[NSURL URLWithString:model.thumbImageURL] placeholderImage:[UIImage imageNamed:@"book_default"]];

    self.titleLabel.text = model.title;
 
    self.autherLabel.text = model.author;
    
    self.totalWordsLabel.text = @"15000字";
    
    self.totalPriasesLabel.text = @"10000";

    self.despLabel.text = @"简介：饕餮馆的拍卖盛宴上，拥有绝佳炉鼎体质的少女被开出天价，人人哄抢。 陡然间，金色牢笼中的少女睁开眼，寒芒四射，懦没有修炼天赋？怕什么，她...,饕餮馆的拍卖盛宴上，拥有绝佳炉鼎体质的少女被开出天价，人人哄抢。饕餮馆的拍卖盛宴上，拥有绝佳炉鼎体质的少女被开出天价，人人哄抢。饕餮馆的拍卖盛宴上，拥有绝佳炉鼎体质的少女被开出天价，人人哄抢。";
    
    [self.catagButton setTitle:@"连载至68章" forState:UIControlStateNormal];
  
    self.totalVoteLabel.text = @"10000";
    self.totalRecommendLabel.text = @"100";
    self.totalRewordLabel.text = @"500";
    
    self.totalCommentLable.text = @"14万评论 3.4万人评论";
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
