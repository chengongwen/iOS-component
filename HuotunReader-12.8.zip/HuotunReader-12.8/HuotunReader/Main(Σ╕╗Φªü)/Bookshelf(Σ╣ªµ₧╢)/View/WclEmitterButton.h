//
//  WclEmitterButton.h
//  WclEmitterButton
//
//  Created by 王崇磊 on 16/4/26.
//  Copyright © 2016年 王崇磊. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WclEmitterButton : UIButton

/**
 执行动画

 @param selected UIButton
 @param animated 动画执行
 */
- (void)setSelected:(BOOL)selected animated:(BOOL)animated;

@end
