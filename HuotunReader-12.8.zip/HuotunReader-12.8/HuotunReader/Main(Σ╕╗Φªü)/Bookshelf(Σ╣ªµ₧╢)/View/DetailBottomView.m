//
//  DetailBottomView.m
//  HuotunReader
//
//  Created by chengongwen on 2017/11/27.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "DetailBottomView.h"
#import "BookDetailViewController.h"

@implementation DetailBottomView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = kWhiteColor;
        
        // view 1
        UIView *view1 = [[UIView alloc] init];
        view1.backgroundColor = kWhiteColor;
        [self addSubview:view1];
        [view1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(@(0));
            make.left.equalTo(@0);
            make.width.equalTo(@(kScreenWidth/2 - 1));
            make.height.equalTo(@kDESGIN_TRANSFORM_iPhone6(48));
        }];
        
        UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
        [button1 setTitle:@"收藏本书" forState:UIControlStateNormal];
        [button1 setTitleColor:kRGBColor_16BAND(0x333333) forState:UIControlStateNormal];
        [button1.titleLabel setFont:[UIFont boldSystemFontOfSize:kDESGIN_TRANSFORM_iPhone6(15)]];
        [button1 sizeToFit];
        [view1 addSubview:button1];
        [button1 addTarget:self action:@selector(jionBookshelfClicked) forControlEvents:UIControlEventTouchUpInside];
        [button1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(view1);
            make.width.equalTo(@(kScreenWidth/2 - 1));
            make.height.equalTo(@kDESGIN_TRANSFORM_iPhone6(48));
        }];
        
        UIView *separeline1 = [[UIView alloc] init];
        separeline1.backgroundColor = kRGBColor_16BAND(0xEEEBEB);
        [self addSubview:separeline1];
        [separeline1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(self);
            make.left.equalTo(@(kScreenWidth/2));
            make.width.equalTo(@(1));
            make.height.equalTo(@kDESGIN_TRANSFORM_iPhone6(30));
        }];
        
//        // view 2
//        UIView *view2 = [[UIView alloc] init];
//        view2.backgroundColor = kClearColor;
//        [self addSubview:view2];
//        [view2 mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.top.equalTo(@(0));
//            make.left.equalTo(@(kScreenWidth/3.0 + 1));
//            make.width.equalTo(@(kScreenWidth/3 - 1));
//            make.height.equalTo(@kDESGIN_TRANSFORM_iPhone6(48));
//        }];
//
//        UIButton *button2 = [UIButton buttonWithType:UIButtonTypeCustom];
//        [button2 setTitle:@"打赏" forState:UIControlStateNormal];
//        [button2 setTitleColor:kRGBColor_16BAND(0x333333) forState:UIControlStateNormal];
//        [button2 setImage:[UIImage imageNamed:@"detail_reward"] forState:UIControlStateNormal];
//        [button2.titleLabel setFont:[UIFont boldSystemFontOfSize:kDESGIN_TRANSFORM_iPhone6(13)]];
//        [button2 sizeToFit];
//        [view2 addSubview:button2];
//        [button2 addTarget:self action:@selector(rewardClicked) forControlEvents:UIControlEventTouchUpInside];
//        [button2 mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.center.equalTo(view2);
//            make.width.equalTo(@(kScreenWidth/3 - 1));
//            make.height.equalTo(@kDESGIN_TRANSFORM_iPhone6(48));
//        }];
//        button2.titleEdgeInsets = UIEdgeInsetsMake(0, 3, 0, -3);     // 图片和字体靠近一点，根据实际情况调整

//        UIView *separeline2 = [[UIView alloc] init];
//        separeline2.backgroundColor = kRGBColor_16BAND(0xEEEBEB);
//        [self addSubview:separeline2];
//        [separeline2 mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.centerY.equalTo(self);
//            make.left.equalTo(@(2.0*kScreenWidth/3.0));
//            make.width.equalTo(@(1));
//            make.height.equalTo(@kDESGIN_TRANSFORM_iPhone6(30));
//        }];
        
        
        // view 3
        UIView *view3 = [[UIView alloc] init];
        view3.backgroundColor = kRGBColor_16BAND(0xD6A464);
        [self addSubview:view3];
        [view3 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(@(0));
            make.left.equalTo(@(kScreenWidth/2 + 1));
            make.width.equalTo(@(kScreenWidth/2 - 1));
            make.height.equalTo(@kDESGIN_TRANSFORM_iPhone6(48));
        }];
        
        UIButton *button3 = [UIButton buttonWithType:UIButtonTypeCustom];
        [button3 setTitle:@"开始阅读" forState:UIControlStateNormal];
        [button3 setTitleColor:kRGBColor_16BAND(0xFFFFFF) forState:UIControlStateNormal];
        [button3.titleLabel setFont:[UIFont boldSystemFontOfSize:kDESGIN_TRANSFORM_iPhone6(13)]];
        [button3 sizeToFit];
        [view3 addSubview:button3];
        [button3 addTarget:self action:@selector(readClicked) forControlEvents:UIControlEventTouchUpInside];
        [button3 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(view3);
            make.width.equalTo(@(kScreenWidth/2 - 1));
            make.height.equalTo(@kDESGIN_TRANSFORM_iPhone6(48));
        }];
        
        UIView *separeline3 = [[UIView alloc] init];
        separeline3.backgroundColor = [UIColor grayColor];
        separeline3.alpha = 0.5;
        [self addSubview:separeline3];
        [separeline3 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(@(0));
            make.left.equalTo(@(0));
            make.right.equalTo(@(0));
            make.height.equalTo(@0.5);
        }];
    }
    
    return self;
}

- (void)jionBookshelfClicked {
    if ([self.delegate respondsToSelector:@selector(jionBookshelfActon)]) {
        [self.delegate jionBookshelfActon];
    }
}

- (void)rewardClicked {
    if ([self.delegate respondsToSelector:@selector(actionRewardView)]) {
        [self.delegate actionRewardView];
    }
}

- (void)readClicked {
    if ([self.delegate respondsToSelector:@selector(startReadBookActon)]) {
        [self.delegate startReadBookActon];
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
