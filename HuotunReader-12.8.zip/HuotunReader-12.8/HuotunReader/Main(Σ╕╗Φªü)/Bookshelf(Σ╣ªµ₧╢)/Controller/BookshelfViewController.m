//
//  BookshelfViewController.m
//  HuotunReader
//
//  Created by chengongwen on 2017/11/24.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "BookshelfViewController.h"
#import "PlaceholderView.h"
#import "BookshelfTableViewCell.h"
#import "BaseWebViewController.h"
#import "BookDetailViewController.h"
#import "CatalogueObject.h"
#import "DatabaseManager.h"

@interface BookshelfViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) PlaceholderView *placeholderView;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, assign) BOOL isPullUp;
@property (nonatomic, strong) NSMutableArray *bookshelfDataList;
@end

@implementation BookshelfViewController

static NSString *kBookshelfTableViewCellId = @"kBookshelfTableViewCellId";


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.navigationItem.title = @"书架";
    
    UIButton * editButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [editButton setTitleColor:kRGBColor_16BAND(0x666666) forState:UIControlStateNormal];
    [editButton setTitle:@"编辑" forState:UIControlStateNormal];
    [editButton.titleLabel setFont:[UIFont systemFontOfSize:16]];
    [editButton addTarget:self action:@selector(editButtonClicked) forControlEvents:UIControlEventTouchUpInside];
    [editButton sizeToFit];
    UIBarButtonItem * rightBarButton = [[UIBarButtonItem alloc] initWithCustomView:editButton];
    self.navigationItem.rightBarButtonItem = rightBarButton;

    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.backgroundColor = [UIColor whiteColor];
    self.tableView.tableHeaderView = [[UIView alloc] init];
    self.tableView.tableFooterView = [[UIView alloc] init];
//    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
//    self.tableView.contentInset = UIEdgeInsetsMake(0, 0, 64 + 44 + 44 + 10, 0);
    self.tableView.alwaysBounceVertical = YES;
    [self.tableView registerClass:[BookshelfTableViewCell class] forCellReuseIdentifier:kBookshelfTableViewCellId];
    [self.view addSubview:self.tableView];
    
    self.bookshelfDataList = [[NSMutableArray alloc] init];
    
    // 添加下拉刷新控件
    [self addpullRefresh];
    
    /**
     *  集成上拉刷新控件
     */
    //[self addfooterRefresh];
    
    self.placeholderView = [[PlaceholderView alloc] initWithFrame:self.view.bounds type:PlaceholderRecord imageName:nil title:nil];
    self.placeholderView.hidden = YES;
    [self.view addSubview:self.placeholderView];
    
    // 加载数据库书架
    [self reloadBookCataguleData];
}

// 加载数据库书架
- (void)reloadBookCataguleData {
     __weak typeof(self) weakSelf = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [weakSelf stopHeaderRefresh];
        [weakSelf stopfootRefresh];
        
        weakSelf.bookshelfDataList = [[DatabaseManager shareInstance] reloadCatalogueTableList];
        [weakSelf.tableView reloadData];
    });
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - init  初始化
//下拉刷新
- (void)addpullRefresh {
    __weak __typeof(self) weakSelf = self;
    self.tableView.mj_header = [YMMJRefreshGifHeader headerWithRefreshingBlock:^{
        [weakSelf reloadBookCataguleData];
    }];
}

//停止下拉刷新
- (void)stopHeaderRefresh{
    [self.tableView.mj_header endRefreshing];
}

//上拉刷新
- (void)addfooterRefresh {
    __weak __typeof(self) weakSelf = self;
    self.tableView.mj_footer = [YMMJRefreshNormalFooter footerWithRefreshingBlock:^{
         [weakSelf reloadBookCataguleData];
    }];
}

//停止上拉刷新
- (void)stopfootRefresh{
    [self.tableView.mj_footer endRefreshing];
}

- (void)editButtonClicked {
    self.tableView.editing = !self.tableView.editing;
    
    UIButton *rigthButton = self.navigationItem.rightBarButtonItem.customView;
    if (self.tableView.editing) {
        [rigthButton setTitle:@"完成" forState:UIControlStateNormal];
    }
    else {
        [rigthButton setTitle:@"编辑" forState:UIControlStateNormal];
    }
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.bookshelfDataList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"BookshelfCellId";
    id cell = nil;
    if(cell == nil){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    if (indexPath.row >= self.bookshelfDataList.count) {
        return cell;
    }
    
    id bookModel = self.bookshelfDataList[indexPath.row];
    if ([bookModel isKindOfClass:[CatalogueObject class]]) {
        cell = (BookshelfTableViewCell *)[tableView dequeueReusableCellWithIdentifier:kBookshelfTableViewCellId];
        [cell refreshCellWithObject:bookModel];
    }
    
    UIView *bgColorView = [[UIView alloc] init];
    bgColorView.backgroundColor = kRGBColor_16BAND(0xe5e5e5);
    [cell setSelectedBackgroundView:bgColorView];
    
    return cell;
}

#pragma mark - UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return kDESGIN_TRANSFORM_iPhone6(111.5);
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}

/**
 *  修改Delete按钮文字为“删除”
 */
- (NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath {
    return @"删除";
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewCellEditingStyleDelete;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        [tableView beginUpdates];
        [self.bookshelfDataList removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        [tableView endUpdates];
        // 注意：不要在这个块中调用reloadData这个方法，它会使动画失效。
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    /**
     *  跳转到详细个人页面
     */
    if (indexPath.row >= self.bookshelfDataList.count) {
        return ;
    }
    CatalogueObject *bookModel = self.bookshelfDataList[indexPath.row];
    
    BookDetailViewController *detailCtrl= [[BookDetailViewController alloc] init];
    detailCtrl.catalogueObject = bookModel;
    [self.navigationController pushViewController:detailCtrl animated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
