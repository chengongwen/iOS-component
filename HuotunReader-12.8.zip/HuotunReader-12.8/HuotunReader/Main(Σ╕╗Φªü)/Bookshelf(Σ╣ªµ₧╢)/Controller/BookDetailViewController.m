//
//  BookDetailViewController.m
//  HuotunReader
//
//  Created by chengongwen on 2017/11/27.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "BookDetailViewController.h"
#import "CatalogueObject.h"
#import "ShareActionView.h"
#import "DetailHeaderView.h"
#import "DetailBottomView.h"

#import "ReadPageViewController.h"
//#import "ReadScrollViewController.h"
#import "BookCommentViewController.h"
#import "BookCatalogViewController.h"

#import "SDAutoLayout.h"
#import "BookDetailTableViewCell.h"
#import "BookDetailModel.h"

#import "QZTopTextView.h"

#import "YMShareSDKManager.h"

#define kHeadViewHeight     kDESGIN_TRANSFORM_iPhone6(400)
#define kBottomViewHeight   kDESGIN_TRANSFORM_iPhone6(49)

#define kBookDetailTableViewCellId @"kBookDetailTableViewCell"

@interface BookDetailViewController () <ShareActionViewDelegate,QZTopTextViewDelegate,UITableViewDelegate,UITableViewDataSource>

// 分享视图
@property (nonatomic, strong) ShareActionView *actionView;
@property (nonatomic, strong) QZTopTextView * textView;

@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) DetailHeaderView *headerView;
@property (nonatomic, strong) DetailBottomView *bottomView;
@property (nonatomic, strong) UITableView *commentTableView;
@property (nonatomic, strong) NSMutableArray *modelsArray;
@end

@implementation BookDetailViewController

- (instancetype)init {
    if (self = [super init]) {
        self.isShowBackBtn = YES;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.navigationItem.title = @"书本详情";
    if (self.catalogueObject && self.catalogueObject.title.length) {
        self.navigationItem.title = self.catalogueObject.title;
    }
    
    // 按钮图片
    UIButton *rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
    rightButton.frame = CGRectMake(0, 0, 30, 30);
    [rightButton setImage:[UIImage imageNamed:@"detail_share"]  forState:UIControlStateNormal];
    [rightButton setImage:[UIImage imageNamed:@"detail_shareHL"]  forState:UIControlStateHighlighted];
    [rightButton addTarget:self action:@selector(shareButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithCustomView:rightButton];
    [self.navigationItem setRightBarButtonItem:rightItem];
    
    self.bottomView = [[DetailBottomView alloc] initWithFrame:CGRectMake(0, kScreenHeight - kBottomViewHeight, self.view.frame.size.width, kBottomViewHeight)];
    self.bottomView.delegate = (id <BookshelfViewControllerDelegate>)self;
    [self.view addSubview:self.bottomView];
    
    // scrollview
    self.scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, kNaviBarHeight, self.view.frame.size.width, self.view.frame.size.height - kDESGIN_TRANSFORM_iPhone6(49) - kNaviBarHeight)];
    self.scrollView.alwaysBounceVertical = YES;
    self.scrollView.showsVerticalScrollIndicator = YES;
    self.scrollView.showsHorizontalScrollIndicator = NO;
    self.scrollView.backgroundColor = kClearColor;
    [self.view addSubview:self.scrollView];
    
    self.headerView = [[DetailHeaderView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width,kHeadViewHeight)];
    self.headerView.delegate = (id <BookshelfViewControllerDelegate>)self;
    [self.scrollView addSubview:self.headerView];

    self.commentTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, kHeadViewHeight, self.view.frame.size.width, self.view.frame.size.height - kHeadViewHeight - kBottomViewHeight)];
    self.commentTableView.dataSource = self;
    self.commentTableView.delegate = self;
    self.commentTableView.backgroundColor = [UIColor clearColor];
    self.commentTableView.alwaysBounceVertical = YES;
    self.commentTableView.allowsSelection = NO;
    [self.commentTableView registerClass:[BookDetailTableViewCell class] forCellReuseIdentifier:kBookDetailTableViewCellId];
    [self.scrollView addSubview:self.commentTableView];
    
    if (@available(iOS 11.0, *)) {
        self.commentTableView.frame = CGRectMake(0,kHeadViewHeight, self.view.frame.size.width, self.view.frame.size.height - kHeadViewHeight - kBottomViewHeight);
        self.scrollView.contentSize = CGSizeMake(self.view.frame.size.width,self.view.frame.size.height - kDESGIN_TRANSFORM_iPhone6(49));
    }
    else {
        self.commentTableView.frame = CGRectMake(0,kHeadViewHeight, self.view.frame.size.width, [self.commentTableView cellsTotalHeight]);
        self.scrollView.contentSize = CGSizeMake(self.view.frame.size.width,kHeadViewHeight + [self.commentTableView cellsTotalHeight]);
    }
    
    // 添加下拉刷新控件
    [self addpullRefresh];
    
    // 评论输入框
    _textView =[QZTopTextView topTextView];
    _textView.delegate = self;
    [self.view addSubview:_textView];
    
    self.modelsArray = [NSMutableArray array];
    
    // 请求数据
    [self reloadBookDetailsData];
    
    [MBProgressHUD showMessage:nil toView:self.view];
}

#pragma mark - init  初始化
//下拉刷新
- (void)addpullRefresh {
    __weak __typeof(self) weakSelf = self;
    self.scrollView.mj_header = [YMMJRefreshGifHeader headerWithRefreshingBlock:^{
        [weakSelf reloadBookDetailsData];
    }];
}

//停止下拉刷新
- (void)stopHeaderRefresh {
    [self.scrollView.mj_header endRefreshing];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)reloadBookDetailsData {
    __weak typeof(self) weakSelf = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
        [MBProgressHUD hideHUDForView:weakSelf.view];
        [weakSelf stopHeaderRefresh];
        
        [weakSelf.headerView refreshHeaderView:_catalogueObject];
        
        weakSelf.modelsArray = [BookDetailModel creatModelsWithCount:5];
        [weakSelf.commentTableView reloadData];
        
        if (@available(iOS 11.0, *)) {
            
        }
        else {
            weakSelf.commentTableView.frame = CGRectMake(0,kHeadViewHeight, self.view.frame.size.width, [weakSelf.commentTableView cellsTotalHeight] + 44.0f);
            weakSelf.scrollView.contentSize = CGSizeMake(self.view.frame.size.width,kHeadViewHeight + [weakSelf.commentTableView cellsTotalHeight] + 44.0f);
        }
    });
}


- (void)shareButtonClicked:(UIButton *)button {
    [self.actionView actionViewShow];
}

#pragma mak - init ShareActionView
- (ShareActionView *)actionView {
    if (!_actionView) {
        _actionView = [[ShareActionView alloc] initWithFrame:CGRectMake(0,[UIScreen mainScreen].bounds.size.height , [UIScreen mainScreen].bounds.size.width, 0) WithSourceArray:nil WithIconArray:nil isFriend:NO];
        _actionView.delegate = self;
        
    }
    return _actionView;
}

#pragma mark - 点击分享平台
- (void)shareToPlatWithIndex:(NSInteger)index {
    DLog(@"index = %lu",index);
    [YMShareSDKManager shareSDKManager].shareSenceType = index + 1;
    
    NSString *title = NSLocalizedString(@"主播正在免费送车，兄弟快来", @"主播正在免费送车，兄弟快来");
    NSString *description = NSLocalizedString(@"邀请好友就免费拿大众朗逸噢", @"邀请好友就免费拿大众朗逸噢");
    NSString *thumbImage = @"http://bookbk.img.ireader.com/group6/M00/D7/C9/CmQUN1jdPgaEJaL8AAAAAERhiWg148316621.jpg";
    NSString *linkURL =  @"http://douniu.yf.huotun.com/";
    
    [[YMShareSDKManager shareSDKManager] shareMesgWithTitle:title message:description thumbImage:thumbImage linkURL:linkURL];
}

#pragma mark -  BookshelfViewControllerDelegate
/**
 跳转到目录类别视图
 */
- (void)jumpToCatalog {
    DLog(@"jumpToCatalog");
    
    BookCatalogViewController *catalogCtrl= [[BookCatalogViewController alloc] init];
    catalogCtrl.catalogueObject = self.catalogueObject;
    [self.navigationController pushViewController:catalogCtrl animated:YES];
}

/**
 投票
 */
- (void)actionVoteView {
    DLog(@"actionVoteView");
}

/**
 推荐
 */
- (void)actionRecommendView {
    DLog(@"actionRecommendView");
}

/**
 赞赏
 */
- (void)actionRewardView {
    DLog(@"actionRewardView");
}

/**
 加入书架
 */
- (void)jionBookshelfActon {
    DLog(@"jionBookshelf");
}

/**
 跳转目录
 */
- (void)startReadBookActon {
    DLog(@"startReadBook");
    
    ReadPageViewController *pageCtrl= [[ReadPageViewController alloc] init];
//    ReadScrollViewController *pageCtrl= [[ReadScrollViewController alloc] init];
    pageCtrl.bookModel = self.catalogueObject;
    pageCtrl.selectChapter = -1;
    [self.navigationController pushViewController:pageCtrl animated:YES];
}

/**
 发表评论
 */
- (void)writeCommentActon {
    DLog(@"writeCommentActon");
    // hardware keyboard
    [_textView.countNumTextView becomeFirstResponder];
}

#pragma mark - QZTopTextViewDelegate
- (void)sendComment {
    DLog(@"%@",_textView.countNumTextView.text);
    
    
}

- (void)jumpToCommentClicked {
    BookCommentViewController *commentCtrl = [[BookCommentViewController alloc] init];
    [self.navigationController pushViewController:commentCtrl animated:YES];
}

#pragma mark -
#pragma mark - UITableViewDataSource

// 返回有多少个Sections
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (self.modelsArray.count >= 2) {
        return 2;
    }
    return self.modelsArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    BookDetailTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kBookDetailTableViewCellId];
    if (!cell) {
        cell = [[BookDetailTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kBookDetailTableViewCellId];
        // 无色
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    cell.model = self.modelsArray[indexPath.row];

    // 此步设置用于实现cell的frame缓存，可以让tableview滑动更加流畅
    [cell useCellFrameCacheWithIndexPath:indexPath tableView:tableView];

    return cell;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    UIButton *moreButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [moreButton setTitle:@"查看全部评论" forState:UIControlStateNormal];
    [moreButton setTitleColor:kRGBColor_16BAND(0x2D0504) forState:UIControlStateNormal];
    [moreButton.titleLabel setFont:[UIFont boldSystemFontOfSize:kDESGIN_TRANSFORM_iPhone6(13)]];
    [moreButton sizeToFit];
    [moreButton addTarget:self action:@selector(jumpToCommentClicked) forControlEvents:UIControlEventTouchUpInside];
    return moreButton;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 44.0f;
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // 颜色消失
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    // >>>>>>>>>>>>>>>>>>>>> * cell自适应 * >>>>>>>>>>>>>>>>>>>>>>>>
    id model = self.modelsArray[indexPath.row];
    CGFloat  height = [self.commentTableView cellHeightForIndexPath:indexPath model:model keyPath:@"model" cellClass:[BookDetailTableViewCell class] contentViewWidth:[self cellContentViewWith]];
    DLog(@"height = %f",height);
    return height;
}

- (CGFloat)cellContentViewWith
{
    CGFloat width = [UIScreen mainScreen].bounds.size.width;
    
    // 适配ios7横屏
    if ([UIApplication sharedApplication].statusBarOrientation != UIInterfaceOrientationPortrait && [[UIDevice currentDevice].systemVersion floatValue] < 8) {
        width = [UIScreen mainScreen].bounds.size.height;
    }
    return width;
}

@end

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

