//
//  BookCatalogViewController.m
//  HuotunReader
//
//  Created by chengongwen on 2017/11/29.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "BookCatalogViewController.h"
#import "CatalogueObject.h"
#import "CatalogueTableViewCell.h"
#import "DatabaseManager.h"
//#import "ReadScrollViewController.h"
#import "ReadPageViewController.h"
#import "CatalogueObject.h"

static  NSString *kBookCatalogListCell = @"kBookCatalogListCell";

@interface BookCatalogViewController () <UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) UILabel *chapterLabel;
@property (nonatomic, strong) UIButton *sortButton;
@property (nonatomic, strong) UIButton *sortCaseButton;
@property (nonatomic, assign) BOOL isOpen;
@end

@implementation BookCatalogViewController

- (instancetype)init {
    self = [super init];
    if (self) {
        self.isShowBackBtn = YES;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.navigationItem.title = @"书籍目录";
    
    // 设置目录降序和升序
    UIView *sortView = [[UIView alloc] init];
    sortView.backgroundColor = kWhiteColor;
    [self.view addSubview:sortView];
    [sortView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(@(kNaviBarHeight));
        make.left.width.equalTo(self.view);
        make.height.equalTo(@(64));
    }];
    [self initSortView:sortView];
    
    // tableview
    self.tableView = [[UITableView alloc] init];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.backgroundColor = kWhiteColor;
    self.tableView.tableHeaderView = [[UIView alloc] init];
    self.tableView.tableFooterView = [[UIView alloc] init];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.tableView registerClass:[CatalogueTableViewCell class] forCellReuseIdentifier:kBookCatalogListCell];
    self.tableView.alwaysBounceVertical = YES;
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(sortView.mas_bottom);
        make.left.width.bottom.equalTo(self.view);
    }];
    
    [MBProgressHUD showMessageWindow:@"正在加载..."];
}

// 设置排序边框
- (void)initSortView:(UIView *)sortView {
    self.chapterLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0x222222) fontSize:kDESGIN_TRANSFORM_iPhone6(16)];
    [sortView addSubview:self.chapterLabel];
    self.chapterLabel.text = @"共0章";
    [self.chapterLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(sortView);
        make.left.equalTo(@(kScaleFrom_iPhone6_Desgin_X(24)));
        make.width.equalTo(@(kDESGIN_TRANSFORM_iPhone6(120)));
    }];
    
    // 设置sortCaseButton
    self.sortCaseButton = [UIButton buttonWithType:UIButtonTypeCustom];
    NSString *title = [NSString stringWithFormat:@"0 - 0章"];
    [self.sortCaseButton  setTitle:title forState:UIControlStateNormal];
    [self.sortCaseButton.titleLabel setFont:[UIFont systemFontOfSize:12]];
    [self.sortCaseButton  setImage:[UIImage imageNamed:@"icon_sort_case_arrow"] forState:UIControlStateNormal];
    [self.sortCaseButton  setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.sortCaseButton  addTarget:self action:@selector(sortButtonClicked) forControlEvents:UIControlEventTouchUpInside];
    [sortView addSubview:self.sortCaseButton];
    
    //设置边框颜色
    self.sortCaseButton.layer.borderColor = [kRGBColor_16BAND(0xD6A464) CGColor];
    //设置边框宽度
    self.sortCaseButton.layer.borderWidth = 1.0f;
    //给按钮设置角的弧度
    self.sortCaseButton.layer.cornerRadius = 4.0f;
    self.sortCaseButton.layer.masksToBounds = YES;
    [self.sortCaseButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(sortView);
        make.right.equalTo(@(-kScaleFrom_iPhone6_Desgin_X(15)));
        make.height.equalTo(@(kDESGIN_TRANSFORM_iPhone6(31)));
        make.width.equalTo(@(kDESGIN_TRANSFORM_iPhone6(100)));
    }];
    
    self.sortCaseButton.titleLabel.backgroundColor = self.sortCaseButton.backgroundColor;
    self.sortCaseButton.imageView.backgroundColor = self.sortCaseButton.backgroundColor;
    //在使用一次titleLabel和imageView后才能正确获取titleSize
    CGSize titleSize = self.sortCaseButton.titleLabel.bounds.size;
    CGSize imageSize = self.sortCaseButton.imageView.bounds.size;
    CGFloat interval = 1.0;
    CGFloat positionY = kDESGIN_TRANSFORM_iPhone6(15); // 偏移量
    self.sortCaseButton.imageEdgeInsets = UIEdgeInsetsMake(0,titleSize.width + interval + positionY, 0, -(titleSize.width + interval));
    self.sortCaseButton.titleEdgeInsets = UIEdgeInsetsMake(0, -(imageSize.width + interval) - positionY, 0, imageSize.width + interval);
    
    
    // 设置sortButton
    self.sortButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.sortButton  setTitle:@"升序" forState:UIControlStateNormal];
    [self.sortButton.titleLabel setFont:[UIFont systemFontOfSize:12]];
    [self.sortButton  setImage:[UIImage imageNamed:@"icon_sort_arrow"] forState:UIControlStateNormal];
    [self.sortButton  setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.sortButton  addTarget:self action:@selector(sortButtonClicked) forControlEvents:UIControlEventTouchUpInside];
    [sortView addSubview:self.sortButton];
    [self.sortButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(sortView);
        make.right.equalTo(self.sortCaseButton.mas_left).offset(-kDESGIN_TRANSFORM_iPhone6(5));
        make.height.equalTo(@(kDESGIN_TRANSFORM_iPhone6(31)));
        make.width.equalTo(@(kDESGIN_TRANSFORM_iPhone6(60)));
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        
        // 初始化缓存数据
        self.bookCatalogueList = [[DatabaseManager shareInstance] reloadChapterTableList:_catalogueObject.catalogueId];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [MBProgressHUD hideHUDWindow];
            
            if (_bookCatalogueList.count) {
                self.chapterLabel.text = [NSString stringWithFormat:@"共%lu章",_bookCatalogueList.count];
                NSString *title = [NSString stringWithFormat:@"1-%lu章",_bookCatalogueList.count];
                [self.sortCaseButton  setTitle:title forState:UIControlStateNormal];
            }
            // 更新顶部和底部栏
            [self.tableView reloadData];
        });
    });
}

// 设置小三角旋转的事件
- (void)sortButtonClicked {
    if (!self.isOpen) {
        [UIView animateWithDuration:0.5 animations:^{
            self.sortButton.imageView.transform = CGAffineTransformMakeRotation(M_PI);
            [self.sortButton setTitle:@"降序" forState:UIControlStateNormal];
            
            self.sortCaseButton.imageView.transform = CGAffineTransformMakeRotation(M_PI);
            NSString *title = [NSString stringWithFormat:@"%lu-1章",_bookCatalogueList.count];
            [self.sortCaseButton setTitle:title forState:UIControlStateNormal];
        }];
        self.isOpen = YES;
    }
    else
    {
        [UIView animateWithDuration:0.5 animations:^{
            self.sortButton.imageView.transform = CGAffineTransformIdentity;
            [self.sortButton setTitle:@"升序" forState:UIControlStateNormal];
            
            self.sortCaseButton.imageView.transform = CGAffineTransformIdentity;
            NSString *title = [NSString stringWithFormat:@"1-%lu章",_bookCatalogueList.count];
            [self.sortCaseButton setTitle:title forState:UIControlStateNormal];
        }];
        self.isOpen = NO;
    }
    [self.tableView reloadData];
}

#pragma mark - UITableView Delagete DataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _bookCatalogueList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"chapterCellId";
    id cell = nil;
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    if (indexPath.row >= _bookCatalogueList.count) {
        return cell;
    }
    
    NSInteger index = indexPath.row;
    if (self.isOpen) {
        index = _bookCatalogueList.count - 1 - indexPath.row;
    }
    
    ChapterObject *chapterModel = _bookCatalogueList[index];
    
    BOOL isSelected = NO;
    
    cell = (CatalogueTableViewCell *)[tableView dequeueReusableCellWithIdentifier:kBookCatalogListCell];
    [cell refreshCellWithObject:chapterModel index:index isSelected:isSelected];
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return kDESGIN_TRANSFORM_iPhone6(51);
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSInteger index = indexPath.row;
    if (self.isOpen) {
        index = _bookCatalogueList.count - 1 - indexPath.row;
    }
    
    ReadPageViewController *pageCtrl= [[ReadPageViewController alloc] init];
//    ReadScrollViewController *pageCtrl= [[ReadScrollViewController alloc] init];
    pageCtrl.bookModel = self.catalogueObject;
    pageCtrl.selectChapter = (int)index;
    [self.navigationController pushViewController:pageCtrl animated:YES];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
