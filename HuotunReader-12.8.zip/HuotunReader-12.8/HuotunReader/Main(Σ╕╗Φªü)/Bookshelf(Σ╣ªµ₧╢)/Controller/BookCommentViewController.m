//
//  BookCommentViewController.m
//  HuotunReader
//
//  Created by chengongwen on 2017/11/28.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "BookCommentViewController.h"
#import "BookDetailTableViewCell.h"
#import "BookDetailModel.h"

#import "SDAutoLayout.h"
#import "QZTopTextView.h"

#define kCommentDetailTableViewCellId @"kCommentDetailTableViewCellId"

@interface BookCommentViewController ()<QZTopTextViewDelegate,UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) QZTopTextView * textView;

@property (nonatomic, strong) UITableView *commentTableView;
@property (nonatomic, strong) NSMutableArray *modelsArray;
@end

@implementation BookCommentViewController

- (instancetype)init {
    if (self = [super init]) {
        self.isShowBackBtn = YES;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.navigationItem.title = @"书评详情";
    
    self.commentTableView = [[UITableView alloc] initWithFrame:self.view.bounds];
    self.commentTableView.dataSource = self;
    self.commentTableView.delegate = self;
    self.commentTableView.backgroundColor = [UIColor whiteColor];
//    self.commentTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.commentTableView.alwaysBounceVertical = YES;
    self.commentTableView.allowsSelection = NO;
    [self.commentTableView registerClass:[BookDetailTableViewCell class] forCellReuseIdentifier:kCommentDetailTableViewCellId];
    [self.view addSubview:self.commentTableView];
    
    self.modelsArray = [NSMutableArray array];
    
    // 添加下拉刷新控件
    [self addpullRefresh];
    
    /**
     *  集成上拉刷新控件
     */
    [self addfooterRefresh];
    
    // 评论输入框
    _textView =[QZTopTextView topTextView];
    _textView.delegate = self;
    [self.view addSubview:_textView];
    
    // 请求数据
    [self.commentTableView.mj_header beginRefreshing];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)reloadBookDetailsData {
    [self.modelsArray removeAllObjects];
    
    __weak typeof(self) weakSelf = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
        [weakSelf stopHeaderRefresh];
        
        [weakSelf.modelsArray addObjectsFromArray:[BookDetailModel creatModelsWithCount:5]];
        [weakSelf.commentTableView reloadData];
    });
}

- (void)reloadBookDetailsMoreData {
    __weak typeof(self) weakSelf = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
        [weakSelf stopfootRefresh];
        
        [weakSelf.modelsArray addObjectsFromArray:[BookDetailModel creatModelsWithCount:5]];
        [weakSelf.commentTableView reloadData];
    });
}

#pragma mark - init  初始化
//下拉刷新
- (void)addpullRefresh {
    __weak __typeof(self) weakSelf = self;
    self.commentTableView.mj_header = [YMMJRefreshGifHeader headerWithRefreshingBlock:^{
        [weakSelf reloadBookDetailsData];
    }];
}

//停止下拉刷新
- (void)stopHeaderRefresh {
    [self.commentTableView.mj_header endRefreshing];
}

//上拉刷新
- (void)addfooterRefresh {
    __weak __typeof(self) weakSelf = self;
    self.commentTableView.mj_footer = [YMMJRefreshNormalFooter footerWithRefreshingBlock:^{
        [weakSelf reloadBookDetailsMoreData];
    }];
}

//停止上拉刷新
- (void)stopfootRefresh{
    [self.commentTableView.mj_footer endRefreshing];
}

#pragma mark -
#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.modelsArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    BookDetailTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kCommentDetailTableViewCellId];
    if (!cell) {
        cell = [[BookDetailTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kCommentDetailTableViewCellId];
        // 无色
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    cell.model = self.modelsArray[indexPath.row];
    
    // 此步设置用于实现cell的frame缓存，可以让tableview滑动更加流畅
    [cell useCellFrameCacheWithIndexPath:indexPath tableView:tableView];
    
    return cell;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UIView *headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kDESGIN_TRANSFORM_iPhone6(50))];
    UILabel *commentTitle = [UILabel labelWithTextColor:kRGBColor_16BAND(0x666666) fontSize:kDESGIN_TRANSFORM_iPhone6(15)];
    commentTitle.text = @"评书区";
    commentTitle.textAlignment = NSTextAlignmentCenter;
    [headView addSubview:commentTitle];
    [commentTitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(@(kScaleFrom_iPhone6_Desgin_X(15)));
        make.centerY.equalTo(headView);
    }];
    
    UILabel *totalCommentLable = [UILabel labelWithTextColor:kRGBColor_16BAND(0x999999) fontSize:kDESGIN_TRANSFORM_iPhone6(13)];
    totalCommentLable.text = @"14万评论 3.4万人评论";
    [headView addSubview:totalCommentLable];
    [totalCommentLable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(commentTitle.mas_right).offset(5);
        make.centerY.equalTo(headView);
    }];
    
    UIButton *commentButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [commentButton setTitle:@"写评论" forState:UIControlStateNormal];
    [commentButton setTitleColor:kRGBColor_16BAND(0x2D0504) forState:UIControlStateNormal];
    [commentButton.titleLabel setFont:[UIFont boldSystemFontOfSize:kDESGIN_TRANSFORM_iPhone6(13)]];
    [commentButton setBackgroundImage:[UIImage imageNamed:@"detail_comment"] forState:UIControlStateNormal];
    [commentButton sizeToFit];
    [headView addSubview:commentButton];
    [commentButton addTarget:self action:@selector(commentClicked) forControlEvents:UIControlEventTouchUpInside];
    [commentButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(headView);
        make.right.equalTo(@(-kScaleFrom_iPhone6_Desgin_X(15)));
        make.height.equalTo(@(kDESGIN_TRANSFORM_iPhone6(24)));
        make.width.equalTo(@(kDESGIN_TRANSFORM_iPhone6(67)));
    }];
    commentButton.titleEdgeInsets = UIEdgeInsetsMake(0, 3, 0, -3);     // 图片和字体靠近一点，根据实际情况调整
    
    UIView *separeline = [[UIView alloc] init];
    separeline.backgroundColor = kRGBColor_16BAND(0xEEEBEB);
    [headView addSubview:separeline];
    [separeline mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(@(-1));
        make.left.equalTo(@(0));
        make.right.equalTo(@(0));
        make.height.equalTo(@1);
    }];
    
    headView.backgroundColor = kWhiteColor;
    return headView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return kDESGIN_TRANSFORM_iPhone6(50);
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    // >>>>>>>>>>>>>>>>>>>>> * cell自适应 * >>>>>>>>>>>>>>>>>>>>>>>>
    id model = self.modelsArray[indexPath.row];
    CGFloat  height = [self.commentTableView cellHeightForIndexPath:indexPath model:model keyPath:@"model" cellClass:[BookDetailTableViewCell class] contentViewWidth:[self cellContentViewWith]];
    return height;
}

- (CGFloat)cellContentViewWith
{
    CGFloat width = [UIScreen mainScreen].bounds.size.width;
    
    // 适配ios7横屏
    if ([UIApplication sharedApplication].statusBarOrientation != UIInterfaceOrientationPortrait && [[UIDevice currentDevice].systemVersion floatValue] < 8) {
        width = [UIScreen mainScreen].bounds.size.height;
    }
    return width;
}


- (void)commentClicked {
    // hardware keyboard
    [_textView.countNumTextView becomeFirstResponder];
}

#pragma mark - QZTopTextViewDelegate
- (void)sendComment {
    DLog(@"%@",_textView.countNumTextView.text);
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
