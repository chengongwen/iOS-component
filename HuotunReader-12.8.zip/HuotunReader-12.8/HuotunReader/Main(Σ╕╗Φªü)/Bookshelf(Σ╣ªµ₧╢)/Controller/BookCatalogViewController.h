//
//  BookCatalogViewController.h
//  HuotunReader
//
//  Created by chengongwen on 2017/11/29.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "BaseViewController.h"

@class CatalogueObject;

@interface BookCatalogViewController : BaseViewController

@property (nonatomic, strong) CatalogueObject *catalogueObject;            // 书籍的
@property (nonatomic, strong) NSArray *bookCatalogueList;               // 当前书籍的目录列表

@end
