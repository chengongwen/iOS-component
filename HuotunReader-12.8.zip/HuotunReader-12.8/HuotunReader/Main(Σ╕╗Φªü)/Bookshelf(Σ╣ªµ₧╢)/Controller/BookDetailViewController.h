//
//  BookDetailViewController.h
//  HuotunReader
//
//  Created by chengongwen on 2017/11/27.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "BaseViewController.h"

@class CatalogueObject;


@protocol BookshelfViewControllerDelegate <NSObject>

@optional

/**
 跳转到目录类别视图
 */
- (void)jumpToCatalog;

/**
 投票
 */
- (void)actionVoteView;

/**
 推荐
 */
- (void)actionRecommendView;

/**
 赞赏
 */
- (void)actionRewardView;

/**
 加入书架
 */
- (void)jionBookshelfActon;

/**
 跳转目录
 */
- (void)startReadBookActon;


/**
 发表评论
 */
- (void)writeCommentActon;

@end


@interface BookDetailViewController : BaseViewController

@property (nonatomic, strong) CatalogueObject *catalogueObject;

@end
