//
//  BookDetailModel.h
//  HuotunReader
//
//  Created by chengongwen on 2017/11/28.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BookDetailModel : NSObject

@property (nonatomic, copy) NSString *iconName;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *content;
@property (nonatomic, copy) NSString *picName;

// 模拟数据
+ (NSMutableArray *)creatModelsWithCount:(NSInteger)count;

@end
