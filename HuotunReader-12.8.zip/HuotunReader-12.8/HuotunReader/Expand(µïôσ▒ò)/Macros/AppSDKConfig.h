//
//  AppSDKConfig.h
//  HuotunReader
//
//  Created by chengongwen on 2017/10/23.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#ifndef AppSDKConfig_h
#define AppSDKConfig_h

// 第三方登录消息通知
#define kLoginSuccessed @"kLoginSuccessed"
#define kLoginCancel @"kLoginCancel"
#define kLoginFail @"kLoginFail"

//头像上传

#define kUpImageSuccessed @"UpImageSuccessed"
#define kUpImageFail @"UpImageFail"
#define kLoginOut @"loginOut"

#define kExitLogin @"ExitLogin"

#define kShareSuccessedNotification         @"kShareSuccessedNotification"      // 分享成功
#define kTencentShareMessageNotification    @"kTencentShareMessageNotification" // QQ分享腾讯
#define kWXShareMessageNotification         @"kWXShareMessageNotification"      // 微信分享腾讯
#define kWeiboShareMessageNotification      @"kWeiboShareMessageNotification"   // 新浪微博分享腾讯

//上传服务器密钥
#define IMAGE_SCREAT_KEY  @"O3GkxurNY4lUEdD0"

#define kRedirectURL        @"http://www.1miaobang.com"

// 友盟统计
#define UMENG_KEY           @"57eb8f8a67e58ef712003958"

// 新浪微博
#define kSinaAppKey          @"84145793"
#define kSinaAppSecret       @"6535a9ad68f8994e9a402d2161883e56"
#define kSinaAuthCallback    kRedirectURL

// QQConnect
#define kQQConnectAppKey     @"1105666348"
#define kQQConnectAppSecret  @"tBrxUdUGd8JHdT5H"

//微信登录
#define kWechatAppKey        @"wxd6e03aff875acde6"
#define kWechatAppSecret     @"9a76a9328953aed2b9c7c720a9b592ab"

//// ShareSDK 短信SDK
//#define kSMSAppkey @"34c844f8dfaf"
//#define kSMSAppSecret @"4d6b01f3dc9151cb967108f39ea5cb9b"

//#define CHARM_HELP_URL @"http://diange.fm/help_treasure"
//#define WEALTH_HELP_URL @"http://diange.fm/help_charming"


#endif /* AppSDKConfig_h */
