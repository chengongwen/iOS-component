//
//  AppURLConfig.h
//  HuotunReader
//
//  Created by chengongwen on 2017/10/23.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#ifndef AppURLConfig_h
#define AppURLConfig_h

// 获取分享标题内容信息服务器
#define KShareMegsURL(apiURL)     [NSString stringWithFormat:@"%@/goods/findShareContent",apiURL]

// 获取广告图片
#define KLaunchAdURL(apiURL)     [NSString stringWithFormat:@"%@/img/findLoadingImg.do",apiURL]

// 获取banner
#define KBannerMesgURL(apiURL)     [NSString stringWithFormat:@"%@/img/findBanner.do",apiURL]


#endif /* AppURLConfig_h */
