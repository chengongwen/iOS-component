//
//  YMShareSDKManager.h
//  HuotunReader
//
//  Created by chengongwen on 2017/10/23.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum : NSUInteger {
    YMShareSDKSenceNone = 0,
    YMShareSDKSenceQQ,         /**< QQ聊天界面   */
    YMShareSDKSenceQQZone,     /**< QQ空间      */
    YMShareSDKSenceWXSession,  /**< 微信聊天界面 */
    YMShareSDKSenceWXTimeline, /**< 朋友圈      */
    YMShareSDKSenceWeibo       /**< 微博        */
} YMShareSDKSenceType;

@interface YMShareSDKManager : NSObject

+ (instancetype)shareSDKManager;

@property (nonatomic, assign) YMShareSDKSenceType shareSenceType; // 分享类型
@property (nonatomic, assign) BOOL isSharing; // 判断是否在分享

@property (nonatomic, strong) NSArray *messageList; //  分享标题信息

/**
 异步获取分享信息
 */
- (void)asynDownloadShareMessage;

/**
 第三方登录
 
 * @param senceTpye （YMShareSDKSenceQQ,YMShareSDKSenceWXSession,YMShareSDKSenceWeibo）
 * @param viewController 当前界面对象。
 */
- (void)loginWithSenceType:(YMShareSDKSenceType)senceTpye viewController:(UIViewController*)viewController;


/**
 分享第三方平台

 @param title 分享标题
 @param message 分享内容
 @param thumbImage 分享图片url
 @param linkURL 分享链接
 */
- (void)shareMesgWithTitle:(NSString *)title message:(NSString *)message thumbImage:(NSString *)thumbImage linkURL:(NSString *)linkURL;

- (void)shareMessageSuccess;
- (void)shareMessageFailure;
- (void)shareMessageCancel;

@end
