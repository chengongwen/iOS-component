//
//  YMTabBar.m
//  huotun
//
//  Created by HEYANG on 16/4/23.
//  Copyright © 2016年 YUEMAO. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AddressManager : NSObject

+ (AddressManager *)sharedManager;
+ (NSArray *)firstLevelArray;
+ (NSDictionary *)secondLevelMap;
+ (NSArray *)secondLevelArrayInFirst:(NSString *)firstLevelName;
+ (NSNumber *)indexOfFirst:(NSString *)firstLevelName;
+ (NSNumber *)indexOfSecond:(NSString *)secondLevelName inFirst:(NSString *)firstLevelName;

@end
