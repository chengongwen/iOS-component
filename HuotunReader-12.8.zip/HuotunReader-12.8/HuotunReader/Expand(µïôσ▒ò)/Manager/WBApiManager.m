//
//  WBApiManager.m
//  HuotunReader
//
//  Created by chengongwen on 2017/10/23.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "WBApiManager.h"
#import "YMShareSDKManager.h"
#import "UserLoginInfo.h"

@implementation WBApiManager
+(instancetype)sharedManager {
    static dispatch_once_t onceToken;
    static WBApiManager *instance;
    dispatch_once(&onceToken, ^{
        instance = [[WBApiManager alloc] init];
    });
    return instance;
}

- (void)didReceiveWeiboRequest:(WBBaseRequest *)request{

}

- (void)didReceiveWeiboResponse:(WBBaseResponse *)response{
    if ([response isKindOfClass:WBAuthorizeResponse.class]) {
        DLog(@"%@",response.userInfo);
        
        if (response.statusCode == WeiboSDKResponseStatusCodeSuccess) {
            WBAuthorizeResponse *resp = (WBAuthorizeResponse*)response;
            
            if ([UserLoginInfo sharedObject].operation == OperationTypeLogin) {
                
                // 登陆成功后，再次调用接口获取用户的个人信息
                NSDictionary *parameters = @{@"access_token": resp.accessToken,
                                             @"uid":  resp.userID
                                             };
                [UserLoginInfo sharedObject].token = resp.accessToken;
                
                [WBHttpRequest requestWithURL:@"https://api.weibo.com/2/users/show.json"
                                   httpMethod:@"GET"
                                       params:parameters
                                        queue:nil
                        withCompletionHandler:^(WBHttpRequest *httpRequest, id result, NSError *error) {
                    
                            if (error) {
                                DLog(@"%@",error);
                                [[NSNotificationCenter defaultCenter] postNotificationName:kLoginFail object:error];
                            }
                            else {
                                
                                NSDictionary *userInfo = (NSDictionary *)result;
                                DLog(@"userinfo: %@", userInfo);
                                
                                [UserLoginInfo sharedObject].platform = LoginPlatformWB;
                                [UserLoginInfo sharedObject].platformAccount = resp.userID;
                                [UserLoginInfo sharedObject].headimgurl = [userInfo objectForKey:@"avatar_hd"];
                                [UserLoginInfo sharedObject].nickName = [userInfo objectForKey:@"screen_name"];
                                [UserLoginInfo sharedObject].sex = [[userInfo objectForKey:@"gender"] isEqual:@"m"]? 1 : 2;
                                
                                NSString *location = [userInfo objectForKey:@"location"];
                                if (location.length > 0) {
                                    
                                    NSArray *locationArray = [location componentsSeparatedByString:@" "];
                                    if (locationArray.count == 2) {
                                        [UserLoginInfo sharedObject].location_1 = locationArray[0];
                                        [UserLoginInfo sharedObject].location_2 = locationArray[1];
                                    }
                                    else {
                                        [UserLoginInfo sharedObject].location_1 = location;
                                    }
                                }
                                [[NSNotificationCenter defaultCenter] postNotificationName:kLoginSuccessed object:userInfo];
                            }
                }];
            }
            else if ([UserLoginInfo sharedObject].operation == OperationTypeBinding) {
                
                DLog(@"绑定微成功,发送微博绑定成功的协议");
                //[YMBingdingTool bindingPlatformRq:4 paltformAccount:resp.userID verifiedInfo:@"" token:resp.accessToken];
            }
        }
        else if (response.statusCode == WeiboSDKResponseStatusCodeUserCancel) {
            [[NSNotificationCenter defaultCenter] postNotificationName:kLoginCancel object:nil];
        }
        else {
            [[NSNotificationCenter defaultCenter] postNotificationName:kLoginFail object:nil];
        }
    }
    else if ([response isKindOfClass:[WBSendMessageToWeiboResponse class]]) {
        DLog(@"%@",response.userInfo);
        
        NSString *sendMessageFrom = [response.requestUserInfo objectForKey:@"SendMessageFrom"];
        // SendMessageFrom标志发送微博分享
        if ([sendMessageFrom isEqualToString: @"ShareMessageWithWeiBo"]) {
            
            if (response.statusCode == WeiboSDKResponseStatusCodeSuccess ) {
                
                [[YMShareSDKManager shareSDKManager] shareMessageSuccess];
            }
            else if (response.statusCode == WeiboSDKResponseStatusCodeUserCancel) {
            
                [[YMShareSDKManager shareSDKManager] shareMessageCancel];
            }
            else if (response.statusCode == WeiboSDKResponseStatusCodeSentFail) {
             
                [[YMShareSDKManager shareSDKManager] shareMessageFailure];
            }
            else if (response.statusCode == WeiboSDKResponseStatusCodeUserCancelInstall) {
                // [AlertUtil alertWithMessage:NSLocalizedString(@"用户取消安装微博客户端", @"用户取消安装微博客户端")];
            }
        }
    }
}


#pragma mark - 分享
- (void)shareMesgWithTitle:(NSString *)title message:(NSString *)message thumbImage:(NSString *)thumbImage linkURL:(NSString *)linkURL {
    
    WBMessageObject *wbmessage = [WBMessageObject message];
    wbmessage.text = [NSString stringWithFormat:@"%@%@ %@",title, message,linkURL];
    
    WBImageObject *imageObject = [WBImageObject object];
    if (thumbImage) {
        NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:thumbImage]];
        
        if ((imageData.length / 1024.0 /1024.0 ) > 10 || imageData == nil ) {
            imageObject.imageData = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"logo" ofType:@"png"]];
        }
        else {
            imageObject.imageData = imageData;
        }
    }
    else {
        imageObject.imageData = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"logo" ofType:@"png"]];
    }
    wbmessage.imageObject = imageObject;
    
    WBSendMessageToWeiboRequest *request = [WBSendMessageToWeiboRequest requestWithMessage:wbmessage];
    request.userInfo = @{@"SendMessageFrom": @"ShareMessageWithWeiBo"};
    [WeiboSDK sendRequest:request];
}

@end
