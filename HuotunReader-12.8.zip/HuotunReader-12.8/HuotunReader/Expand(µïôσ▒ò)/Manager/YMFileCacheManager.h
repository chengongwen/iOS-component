//
//  YMFileCacheManager.h
//  YueMao
//
//  Created by HEYANG on 16/6/2.
//
//

#import <Foundation/Foundation.h>

/**
 *  文件缓存处理工具类
 */

@interface YMFileCacheManager : NSObject

+ (void)removeDirectoriesPath:(NSString *)directoriesPath complement:(void(^)(void))complement;
/**
 *  计算文件夹的尺寸
 *
 *  @param directoriesPath 文件路径
 *  @param completeBlock   计算完之后回调
 */
+ (void)getCacheSizeOfDirectoriesPath:(NSString *)directoriesPath completeBlock:(void(^)(NSInteger))completeBlock;

@end
