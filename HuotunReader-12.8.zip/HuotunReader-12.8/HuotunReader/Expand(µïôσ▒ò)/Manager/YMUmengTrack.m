//
//  YMUmengTrack.m
//  HuotunReader
//
//  Created by chengongwen on 2017/10/23.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "YMUmengTrack.h"
#import "UMMobClick/MobClick.h"

@implementation YMUmengTrack

static YMUmengTrack *instance;

+ (instancetype)sharedManager {
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        instance = [[YMUmengTrack alloc] init];
    });
    return instance;
}

/**
 *  注册友盟统计
 */
- (void)initUmengTrack {
    [self performSelector:@selector(detachNewThreadUmengTrack) withObject:self afterDelay:15.0f];
}

- (void)detachNewThreadUmengTrack {
    // 注册友盟统计
    [NSThread detachNewThreadSelector:@selector(asynInitUmeng) toTarget:self withObject:nil];
}

- (void)asynInitUmeng {
    [MobClick setAppVersion:XcodeAppVersion]; //参数为NSString * 类型,自定义app版本信息，如果不设置，默认从CFBundleVersion里取
    [MobClick setLogEnabled:YES];
    UMConfigInstance.appKey = UMENG_KEY;
    UMConfigInstance.secret = @"App Store";
    [MobClick startWithConfigure:UMConfigInstance];
}


@end
