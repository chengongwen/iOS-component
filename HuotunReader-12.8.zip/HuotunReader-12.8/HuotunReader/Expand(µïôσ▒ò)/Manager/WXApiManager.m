//
//  WXApiManager.m
//  HuotunReader
//
//  Created by chengongwen on 2017/10/23.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "WXApiManager.h"
#import "YMShareSDKManager.h"
#import "UserLoginInfo.h"

@implementation WXApiManager

#pragma mark - LifeCycle
+(instancetype)sharedManager {
    static dispatch_once_t onceToken;
    static WXApiManager *instance = nil;
    dispatch_once(&onceToken, ^{
        instance = [[WXApiManager alloc] init];
    });
    return instance;
}

#pragma mark - WXApiDelegate
- (void)onReq:(BaseReq*)req {
    
}

- (void)onResp:(BaseResp *)resp {
    // 微信处理完第三方程序的认证和权限申
    if ([resp isKindOfClass:[SendAuthResp class]]) {
        SendAuthResp *response = (SendAuthResp *)resp;
        if (response.errCode == WXSuccess) {
            //用户允许授权登录
            //第二步通过code获取access_token
            AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
            
            NSString *wxAppKey = kWechatAppKey;
            NSString *wxAppSecret = kWechatAppSecret;
            
            NSString * tokenUrl = [NSString stringWithFormat:@"https://api.weixin.qq.com/sns/oauth2/access_token?appid=%@&secret=%@&code=%@&grant_type=authorization_code",wxAppKey,wxAppSecret,response.code];
            
                manager.responseSerializer.acceptableContentTypes =  [manager.responseSerializer.acceptableContentTypes setByAddingObjectsFromSet:[NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript",@"text/html", @"text/plain",@"application/atom+xml",@"application/xml",@"text/xml",@"image/png",@"image/jpeg",nil]];
            
            [manager GET:tokenUrl parameters:nil progress:nil success:^(NSURLSessionTask *task, id responseObject) {
                
                DLog(@"access_token: %@", responseObject);
                NSString *access_token = [responseObject objectForKey:@"access_token"];
                //[UserLoginInfo sharedObject].token = access_token;
                
                NSString *openid = [responseObject objectForKey:@"openid"];
                NSString *userInfo = [NSString stringWithFormat:@"https://api.weixin.qq.com/sns/userinfo?access_token=%@&openid=%@&lang=zh_CN",access_token,openid];
                
                [manager GET:userInfo parameters:nil progress:nil success:^(NSURLSessionTask *task, id responseObject) {
                    DLog(@"userinfo: %@", responseObject);
                    
                    NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithDictionary:responseObject];
                    if ([UserLoginInfo sharedObject].operation == OperationTypeLogin) {
                        [UserLoginInfo sharedObject].platform = LoginPlatformWX;
                        [UserLoginInfo sharedObject].platformAccount = [userInfo objectForKey:@"openid"];
                        [UserLoginInfo sharedObject].headimgurl = [userInfo objectForKey:@"headimgurl"];
                        [UserLoginInfo sharedObject].nickName = [userInfo objectForKey:@"nickname"];
                        [UserLoginInfo sharedObject].sex = [[userInfo objectForKey:@"sex"] intValue];
                        [UserLoginInfo sharedObject].token = access_token;
                        [UserLoginInfo sharedObject].location_1 = [userInfo objectForKey:@"province"];
                        [UserLoginInfo sharedObject].location_2 = [userInfo objectForKey:@"city"];
                        
                        // 保存是否是微信登录
                        NSUserDefaults *useDefault = [NSUserDefaults standardUserDefaults];
                        [useDefault setObject:[userInfo objectForKey:@"unionid"] forKey:@"unionid"];
                        [useDefault synchronize];
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:kLoginSuccessed object:userInfo];
                    }
                    else if ([UserLoginInfo sharedObject].operation == OperationTypeBinding) {
                        DLog(@"发送微信绑定成功的协议");
                        //[YMBingdingTool bindingPlatformRq:3 paltformAccount:[userInfo objectForKey:@"openid"] verifiedInfo:@"" token:access_token];
                        // 用第三方唯一表示暂时作为绑定成功的平台名称
                        // [UserLoginInfo sharedObject].myInfo.Weixin = [userInfo objectForKey:@"openid"];
                    }
                    
                }failure:^(NSURLSessionTask *operation, NSError *error) {
                    DLog(@"Error: %@", error);
                    [[NSNotificationCenter defaultCenter] postNotificationName:kLoginFail object:error];
                }];
            
            } failure:^(NSURLSessionTask *operation, NSError *error) {
                DLog(@"Error: %@", error);
                [[NSNotificationCenter defaultCenter] postNotificationName:kLoginFail object:error];
            }];
        }
        else if (response.errCode == WXErrCodeUserCancel) {
            [[NSNotificationCenter defaultCenter] postNotificationName:kLoginCancel object:response];
        }
        else {
            [[NSNotificationCenter defaultCenter] postNotificationName:kLoginFail object:response];
        }
    }
    // 第三方程序发送消息至微信终端程序的消息结构体
    else if ([resp isKindOfClass:[SendMessageToWXResp class]]) {
        
        SendMessageToWXResp *response = (SendMessageToWXResp *)resp;
        if (response.errCode == WXSuccess) {
            
            [[YMShareSDKManager shareSDKManager] shareMessageSuccess];
        }
        else if (response.errCode == WXErrCodeUserCancel) {
            
            [[YMShareSDKManager shareSDKManager] shareMessageCancel];
        }
        else if (response.errCode == WXErrCodeSentFail) {

            [[YMShareSDKManager shareSDKManager] shareMessageFailure];
        }
    }
    else if ([resp isKindOfClass:[PayResp class]]){
        //支付返回结果，实际支付结果需要去微信服务器端查询
        if (resp.errCode == 0) {
            DLog(@"支付成功－PaySuccess，retcode = %d", resp.errCode);
        }
        else{
            DLog(@"错误，retcode = %d, retstr = %@", resp.errCode,resp.errStr);
        }
    }
}

#pragma mark - 分享
- (void)shareMesgWithTitle:(NSString *)title message:(NSString *)message thumbImage:(NSString *)thumbImage linkURL:(NSString *)linkURL scene:(enum WXScene)scene {
    
    NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:thumbImage]];
    
    WXWebpageObject *mediaObject = [WXWebpageObject object];
    mediaObject.webpageUrl = linkURL;
    
    WXMediaMessage *wxmessage = [WXMediaMessage message];
    wxmessage.title = title;
    wxmessage.description = message;
    wxmessage.mediaObject = mediaObject;
    wxmessage.messageExt = nil;
    wxmessage.messageAction = nil;
    wxmessage.mediaTagName = nil;
    
    /** 缩略图数据
     * @note 大小不能超过32K
     */
    if (thumbImage && (imageData.length / 1024.0) < 32 && imageData != nil) {
        wxmessage.thumbData = imageData;  // 缩略图数据大小不能超过32K
    }
    else {
        UIImage *shareImage = [UIImage imageNamed:@"logo"];
        wxmessage.thumbData = UIImagePNGRepresentation(shareImage);
    }
    SendMessageToWXReq *req = [[SendMessageToWXReq alloc] init];
    req.bText = NO;
    req.scene = scene;
//    req.text = NO;
    req.message = wxmessage;
    
    [WXApi sendReq:req];
}

@end
