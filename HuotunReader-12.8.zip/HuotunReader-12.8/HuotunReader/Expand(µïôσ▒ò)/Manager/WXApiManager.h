//
//  WXApiManager.h
//  HuotunReader
//
//  Created by chengongwen on 2017/10/23.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WXApi.h"
#import "YMShareSDKManager.h"

@protocol WXApiManagerDelegate <NSObject>

@optional
//
//- (void)managerDidRecvGetMessageReq:(GetMessageFromWXReq *)request;
//
//- (void)managerDidRecvShowMessageReq:(ShowMessageFromWXReq *)request;
//
//- (void)managerDidRecvLaunchFromWXReq:(LaunchFromWXReq *)request;
//
//- (void)managerDidRecvMessageResponse:(SendMessageToWXResp *)response;
//
//- (void)managerDidRecvAuthResponse:(SendAuthResp *)response;
//
//- (void)managerDidRecvAddCardResponse:(AddCardToWXCardPackageResp *)response;

@end

@interface WXApiManager : NSObject<WXApiDelegate>

//@property (nonatomic, assign) id<WXApiManagerDelegate> delegate;

+ (instancetype)sharedManager;

/**
 *  分享第三方平台
 *
 *  @param title        分享标题
 *  @param message      分享内容
 *  @param thumbImage   分享图片url
 *  @param linkURL      分享链接
 *  @param scene        聊天/朋友圈
 */
- (void)shareMesgWithTitle:(NSString *)title message:(NSString *)message thumbImage:(NSString *)thumbImage linkURL:(NSString *)linkURL scene:(enum WXScene)scene;

@end
