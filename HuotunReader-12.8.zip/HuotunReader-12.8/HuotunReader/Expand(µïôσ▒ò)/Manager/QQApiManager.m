//
//  QQApiManager.m
//  HuotunReader
//
//  Created by chengongwen on 2017/10/23.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "QQApiManager.h"
#import <TencentOpenAPI/TencentOAuth.h>
#import <TencentOpenAPI/TencentOAuthObject.h>
#import <TencentOpenAPI/QQApiInterface.h>
#import <TencentOpenAPI/QQApiInterfaceObject.h>
#import "YMShareSDKManager.h"
#import "UserLoginInfo.h"

@implementation QQApiManager
+(instancetype)sharedManager {
    static dispatch_once_t onceToken;
    static QQApiManager *instance;
    dispatch_once(&onceToken, ^{
        instance = [[QQApiManager alloc] init];
    });
    return instance;
}

#pragma mark - TencentLoginDelegate
- (void)tencentDidLogin {
    DLog(@"用户使用QQConnect成功登录");
    [[AppDelegate shareAppDelegate].tencentOAuth getUserInfo];
}

- (void)tencentDidNotLogin:(BOOL)cancelled {
    DLog(@"用户使用QQConnect登录失败, 是否用户主动取消: %d", cancelled);
    if (cancelled) {
        [[NSNotificationCenter defaultCenter] postNotificationName:kLoginCancel object:nil];
    }
}

- (void)tencentDidNotNetWork {
    [[NSNotificationCenter defaultCenter] postNotificationName:kLoginFail object:nil];
}

- (void)getUserInfoResponse:(APIResponse *)response {
    if (response.retCode == URLREQUEST_SUCCEED && [(response.jsonResponse)[@"ret"] integerValue] == 0) {
        DLog(@"QQ登陆成功...服务器响应: %@", response.message);
        
        NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithDictionary:response.jsonResponse];
        if ([UserLoginInfo sharedObject].operation == OperationTypeLogin) {
            DLog(@"userinfo: %@", userInfo);
            
            [UserLoginInfo sharedObject].token = [AppDelegate shareAppDelegate].tencentOAuth.accessToken;
            [UserLoginInfo sharedObject].platform = LoginPlatformQQ;
            [UserLoginInfo sharedObject].platformAccount = [AppDelegate shareAppDelegate].tencentOAuth.openId;
            [UserLoginInfo sharedObject].headimgurl = [userInfo objectForKey:@"figureurl_qq_2"];
            [UserLoginInfo sharedObject].nickName = [userInfo objectForKey:@"nickname"];
            [UserLoginInfo sharedObject].sex = [[userInfo objectForKey:@"gender"] isEqual:NSLocalizedString(@"男", @"男")]? 1 : 2;
            [UserLoginInfo sharedObject].location_1 = [userInfo objectForKey:@"province"];
            [UserLoginInfo sharedObject].location_2 = [userInfo objectForKey:@"city"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:kLoginSuccessed object:userInfo];
        }
        if ([UserLoginInfo sharedObject].operation == OperationTypeBinding) {
            // 发送QQ绑定成功
            DLog(@"发送QQ绑定成功的协议");
            //[YMBingdingTool bindingPlatformRq:2 paltformAccount:[YMAppDelegate sharedObject].oauth.openId verifiedInfo:@"" token:[YMAppDelegate sharedObject].oauth.accessToken];
        }
    }
    else {
        DLog(@"QQ登录失败...服务器响应: %@", response.message);
        [[AppDelegate shareAppDelegate].tencentOAuth logout:nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:kLoginFail object:nil];
    }
}

#pragma mark - QQApiInterfaceDelegate
/**
 处理来至QQ的请求
 */
- (void)onReq:(QQBaseReq *)req {
    
}

/**
 处理来至QQ的响应
 */
- (void)onResp:(QQBaseResp *)resp {
    switch (resp.type) {
        case ESENDMESSAGETOQQRESPTYPE:{
            
            SendMessageToQQResp* sendResp = (SendMessageToQQResp*)resp;
            
            if (sendResp.result.integerValue == 0) {
                
                // 分享成功
                [[YMShareSDKManager shareSDKManager] shareMessageSuccess];
            }
            else {
                // 取消分享
                [[YMShareSDKManager shareSDKManager] shareMessageCancel];
            }
            break;
        }
        default: {
            break;
        }
    }
}
/**
 处理QQ在线状态的回调
 */
- (void)isOnlineResponse:(NSDictionary *)response {
    
}

#pragma mark - 分享
- (void)shareMesgWithTitle:(NSString *)title message:(NSString *)message thumbImage:(NSString *)thumbImage linkURL:(NSString *)linkURL scene:(TecnentPlatformType)scene {
    
    QQApiNewsObject *newsObj = nil;
    NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:thumbImage]];
    
    if (thumbImage && (imageData.length / 1024.0 /1024.0 ) < 10 && imageData != nil) {
        
        newsObj = [QQApiNewsObject objectWithURL:[NSURL URLWithString:linkURL] title:title description:message previewImageURL:[NSURL URLWithString:thumbImage]];
    }
    else {
        UIImage *shareImage = [UIImage imageNamed:@"logo"];
        imageData = UIImagePNGRepresentation(shareImage);
        newsObj = [QQApiNewsObject objectWithURL:[NSURL URLWithString:linkURL] title:title description:message previewImageData:imageData];
    }
    
    SendMessageToQQReq *req = [SendMessageToQQReq reqWithContent:newsObj];
    if (scene == kIphoneQQ) {
        [QQApiInterface sendReq:req]; // 分享到QQ
    }
    else {
        [QQApiInterface SendReqToQZone:req]; // 分享到QQ空间
    }
}

@end
