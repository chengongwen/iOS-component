//
//  AlertUtil.m
//  消息提醒
//
//  Created by chengongwen on 13-6-4.
//  Copyright (c) 2013年 ysservice.com. All rights reserved.
//

#import "AlertUtil.h"

@implementation AlertUtil

+ (void)alertWithTitle:(NSString *)titles message:(NSString *)messages cancelTitle:(NSString *)btnTitle {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:titles
                                                   message:messages
                                                  delegate:nil
                                         cancelButtonTitle:btnTitle
                                         otherButtonTitles:nil ];
    [alert show];
}

+ (void)alertWithMessage:(NSString *)message {
    
    [AlertUtil alertWithTitle:nil message:message cancelTitle:NSLocalizedString(@"确定", @"确定")];
}

@end
