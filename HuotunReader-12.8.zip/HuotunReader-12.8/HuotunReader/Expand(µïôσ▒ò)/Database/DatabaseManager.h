//
//  DatabaseManager.h
//  HuotunReader
//
//  Created by chengongwen on 2017/10/30.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDB.h"

@class CatalogueObject;
@class ChapterObject;

@interface DatabaseManager : NSObject

+ (DatabaseManager *)shareInstance;

#pragma mark - 书架
// 创建一个书架的table
- (void)initCatalogueTable;

// 获取所以书架书籍
- (NSMutableArray *)reloadCatalogueTableList;

// 插入一本书到书架
- (void)insertCatalogueTable:(CatalogueObject *)catalogueObject;

// 更新书架
- (void)updateCatalogueTable:(CatalogueObject *)catalogueObject;

// 从书架删除一本书
- (void)deleteCatalogueTable:(CatalogueObject *)catalogueObject;


#pragma mark -
#pragma mark - 本书的目录 (创建，插入、删除)

// 创建一本书的目录的table
- (void)initChapterTable:(NSString *)tableName;

// 插入一章节到书本,并且数据加密写进本地文件
- (void)insertChapterTable:(ChapterObject *)chapterObject data:(NSData *)data;

// 获取所以书架书籍
- (NSMutableArray *)reloadChapterTableList:(NSString *)catalogueId;

// 获取单个章节数据信息
- (ChapterObject *)getChapterObject:(NSString *)catalogueId chapterNum:(NSUInteger)chapterNum;

// 删除章节表数据
- (void)deleteChapterTable:(NSString *)tableName;

@end
