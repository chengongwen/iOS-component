//
//  CatalogueObject.h
//  HuotunReader
//
//  Created by chengongwen on 2017/10/30.
//  Copyright © 2017年 huotunyule. All rights reserved.
//
// 图书架的图书目录列表
//

#import <Foundation/Foundation.h>

@interface CatalogueObject : NSObject

@property (nonatomic, assign) NSInteger resourceId;
@property (nonatomic, copy) NSString *catalogueId;  // key
@property (nonatomic, copy) NSString *account;      // 账号
@property (nonatomic, copy) NSString *title;        // 图书标题
@property (nonatomic, copy) NSString *author;       // 图书作者
@property (nonatomic, copy) NSString *thumbImageURL;   // 图书的封面
@property (nonatomic, assign) double currentProgress; // 当前进度
@property (nonatomic, strong) NSDate *updateTime;      //  更新时间

@end
