//
//  ChapterObject.h
//  HuotunReader
//
//  Created by chengongwen on 2017/10/30.
//  Copyright © 2017年 huotunyule. All rights reserved.
//
// 一本书的目录列表的数据结构
//

#import <Foundation/Foundation.h>

@interface ChapterObject : NSObject

@property (nonatomic, assign) NSUInteger resourceId;
@property (nonatomic, copy) NSString *catalogueId;      // key
@property (nonatomic, copy) NSString *title;            // 章节标题
@property (nonatomic, copy) NSString *path;             // 文件路径
@property (nonatomic, assign) NSUInteger chapterNum;    // 第几章节

@end
