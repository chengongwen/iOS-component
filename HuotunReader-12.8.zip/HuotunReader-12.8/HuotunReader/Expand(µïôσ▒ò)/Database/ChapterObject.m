//
//  ChapterObject.m
//  HuotunReader
//
//  Created by chengongwen on 2017/10/30.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "ChapterObject.h"

@implementation ChapterObject

@end
