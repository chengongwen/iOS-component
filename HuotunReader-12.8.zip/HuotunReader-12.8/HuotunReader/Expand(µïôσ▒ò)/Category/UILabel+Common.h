//
//  UILabel+Common.h
//  YueMao
//
//  Created by HEYANG on 16/5/13.
//
//

#import <UIKit/UIKit.h>

@interface UILabel (Common)

+ (instancetype)label;

+ (instancetype)labelWithTitle:(NSString *)title;
+ (UILabel *)labelWithTextColor:(UIColor *)color fontSize:(CGFloat)size;

- (void)setColor:(UIColor*)color font:(UIFont*)font;
- (void)setText:(NSString *)text textColor:(UIColor*)color font:(UIFont*)font;
- (void)setTextWithLYM:(NSString *)text textColor:(UIColor*)color font:(UIFont*)font;

// 已知区域重新调整
- (CGSize)contentSize;

// 不知区域，通过其设置区域
- (CGSize)textSizeIn:(CGSize)size;

//- (void)layoutInContent;

@end


@interface InsetLabel : UILabel

@property (nonatomic, assign) UIEdgeInsets contentInset;

@end

