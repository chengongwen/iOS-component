//
//  YMAppDelegate+Remote.h
//  YueMao
//
//  Created by chengongwen on 2017/3/27.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "AppDelegate.h"

#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 100000
#import <UserNotifications/UserNotifications.h>
#endif

@interface AppDelegate (Remote)<UNUserNotificationCenterDelegate>

// 处理后台点击通知
- (void)handleAPSEnterBackgroundInfo;


@end
