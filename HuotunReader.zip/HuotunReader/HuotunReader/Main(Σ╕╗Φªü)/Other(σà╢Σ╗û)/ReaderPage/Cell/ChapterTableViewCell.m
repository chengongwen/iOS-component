//
//  ChapterTableViewCell.m
//  HuotunReader
//
//  Created by huotun on 2017/11/23.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "ChapterTableViewCell.h"
#import "ReadView.h"
#import "ReadParser.h"
#import "ReadConfig.h"

@interface ChapterTableViewCell ()

@property (nonatomic, strong) UILabel *content;
@end

@implementation ChapterTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.backgroundColor = kClearColor;
        self.contentView.backgroundColor = kClearColor;
        
        self.content = [[UILabel alloc] init];
        self.content.backgroundColor = kClearColor;
        self.content.numberOfLines = 0;
        [self.contentView addSubview:self.content];
        [self.content mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(@5);
            make.left.equalTo(@5);
            make.right.equalTo(@(-5));
            make.bottom.equalTo(@-5);
        }];
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)refreshCellWithObject:(NSString *)content {
    // 解析文本
    NSDictionary *attr = [ReadParser parserAttribute:[ReadConfig shareInstance]];
    NSMutableAttributedString *subString = [[NSMutableAttributedString alloc] initWithString:content attributes:attr];
    
    self.content.attributedText = subString;
}

@end
