//
//  CatalogueTableViewCell.h
//  HuotunReader
//
//  Created by huotun on 2017/11/22.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CatalogueObject;

@interface CatalogueTableViewCell : UITableViewCell

- (void)refreshCellWithObject:(CatalogueObject *)model index:(NSInteger)index isSelected:(BOOL)isSelected;

@end
