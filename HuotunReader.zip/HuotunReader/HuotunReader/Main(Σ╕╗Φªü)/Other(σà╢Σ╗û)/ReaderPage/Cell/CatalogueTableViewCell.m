//
//  CatalogueTableViewCell.m
//  HuotunReader
//
//  Created by huotun on 2017/11/22.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "CatalogueTableViewCell.h"
#import "CatalogueObject.h"

@interface CatalogueTableViewCell ()

@property (nonatomic, strong) UILabel *titleLabel;  // 名称
@property (nonatomic, strong) UILabel *despLabel;   // 描述
@end

@implementation CatalogueTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        self.backgroundColor = kWhiteColor;
        self.contentView.backgroundColor = kWhiteColor;
        
        // 背景图
        UIView *backgroundView = [[UIView alloc] init];
        backgroundView.backgroundColor = kWhiteColor;
        [[backgroundView layer] setBorderWidth:2.0];//画线的宽度
        [[backgroundView layer] setBorderColor:kClearColor.CGColor];//颜色
        [[backgroundView layer] setCornerRadius:6.0]; //圆角
        [self.contentView addSubview:backgroundView];
        [backgroundView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(@3);
            make.left.equalTo(@3);
            make.right.equalTo(@(-3));
            make.bottom.equalTo(@0);
        }];
        
        // 用户名称
        self.titleLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0x222222) fontSize:kDESGIN_TRANSFORM_iPhone6(17)];
        [self.contentView addSubview:self.titleLabel];
        [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(self.contentView);
            make.left.equalTo(@(kScaleFrom_iPhone6_Desgin_X(24)));
            make.width.lessThanOrEqualTo(@(kScreenWidth*4.0/5.0));
        }];
        
        self.despLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0xCFA972) fontSize:kDESGIN_TRANSFORM_iPhone6(15)];
        [self.contentView addSubview:self.despLabel];
        [self.despLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(self.contentView);
            make.right.equalTo(@(-kScaleFrom_iPhone6_Desgin_X(15)));
        }];
        
        UIView *seperator = [[UIView alloc] init];
        seperator.backgroundColor = kClearColor;
        seperator.alpha = 0.3;
        [self.contentView addSubview:seperator];
        [seperator mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(@3);
            make.right.equalTo(@-3);
            make.bottom.equalTo(self.contentView);
            make.height.equalTo(@(0.5));
        }];
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)refreshCellWithObject:(CatalogueObject *)model index:(NSInteger)index isSelected:(BOOL)isSelected {
    self.titleLabel.text = [NSString stringWithFormat:@"第%lu章 %@",index + 1,model.title];
    if (isSelected) {
        self.titleLabel.textColor = kRedColor;
    }
    else {
        self.titleLabel.textColor = kRGBColor_16BAND(0x222222);
    }
    self.despLabel.text = @"免费";
}

@end
