//
//  StatusTopView.h
//  HuotunReader
//
//  Created by huotun on 2017/11/24.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StatusTopView : UIView

- (void)updateTitle:(NSString *)title;

@end
