//
//   BottomMenuView.m
//   Reader
//
//  Created by huotun on 2017/11/20.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "BottomMenuView.h"
#import "ReadConfig.h"
#import "ReadUtilites.h"

@interface  BottomMenuView ()

@property (nonatomic, strong) ReadProgressView *progressView;
@property (nonatomic, strong) UIButton *minSpacing;
@property (nonatomic, strong) UIButton *mediuSpacing;
@property (nonatomic, strong) UIButton *maxSpacing;
@property (nonatomic, strong) UISlider *slider;
@property (nonatomic, strong) UIButton *lastChapter;
@property (nonatomic, strong) UIButton *nextChapter;

@property (nonatomic, strong) UIButton *catalogBtn;
@property (nonatomic, strong) UILabel *catalogLabel;
@property (nonatomic, strong) UIButton *settingBtn;
@property (nonatomic, strong) UILabel *settingLabel;
@property (nonatomic, strong) UIButton *lightBtn;
@property (nonatomic, strong) UILabel *lightLabel;
@property (nonatomic, strong) UIButton *downloadBtn;
@property (nonatomic, strong) UILabel *downloadLabel;
@end

@implementation  BottomMenuView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setBackgroundColor:kRGBColor(255, 255, 255)];
        [self setup];
    
        // dealloc 移除监听
        [self addObserver:self forKeyPath:@"readModel.chapter" options:NSKeyValueObservingOptionNew context:NULL];
        [self addObserver:self forKeyPath:@"readModel.page" options:NSKeyValueObservingOptionNew context:NULL];
        
        [[ReadConfig shareInstance] addObserver:self forKeyPath:@"fontSize" options:NSKeyValueObservingOptionNew context:NULL];
        [[ReadConfig shareInstance] addObserver:self forKeyPath:@"fontNameType" options:NSKeyValueObservingOptionNew context:NULL];
    }
    return self;
}

- (void)setup {
//    [self addSubview:self.slider];
//    [self addSubview:self.progressView];
//    [self addSubview:self.lastChapter];
//    [self addSubview:self.nextChapter];
    
    [self addSubview:self.catalogBtn];
    [self addSubview:self.catalogLabel];
    [self addSubview:self.lightBtn];
    [self addSubview:self.lightLabel];
    [self addSubview:self.settingBtn];
    [self addSubview:self.settingLabel];
    [self addSubview:self.downloadBtn];
    [self addSubview:self.downloadLabel];
}

- (ReadProgressView *)progressView {
    if (!_progressView) {
        _progressView = [[ReadProgressView alloc] init];
        _progressView.hidden = YES;
    }
    return _progressView;
}

- (UISlider *)slider
{
    if (!_slider) {
        _slider = [[UISlider alloc] init];
        _slider.minimumValue = 0;
        _slider.maximumValue = 100;
        _slider.minimumTrackTintColor = kRGBColor(227, 0, 0);
        _slider.maximumTrackTintColor = kRGBColor(225, 225, 225);
        //[_slider setThumbImage:[UIImage imageNamed:@"read_slider_circle"] forState:UIControlStateNormal];
        [_slider addTarget:self action:@selector(sliderValueChanged:) forControlEvents:UIControlEventValueChanged];
        [_slider addObserver:self forKeyPath:@"highlighted" options:NSKeyValueObservingOptionNew|NSKeyValueObservingOptionOld context:NULL];
    }
    return _slider;
}

- (UIButton *)nextChapter
{
    if (!_nextChapter) {
        _nextChapter = [ReadUtilites commonButtonSEL:@selector(jumpChapter:) target:self];
        [_nextChapter setTitle:@"下一章" forState:UIControlStateNormal];
    }
    return _nextChapter;
}

- (UIButton *)lastChapter
{
    if (!_lastChapter) {
        _lastChapter = [ReadUtilites commonButtonSEL:@selector(jumpChapter:) target:self];
        [_lastChapter setTitle:@"上一章" forState:UIControlStateNormal];
    }
    return _lastChapter;
}

- (UIButton *)catalogBtn {
    if (!_catalogBtn) {
        _catalogBtn = [ReadUtilites commonButtonSEL:@selector(showCatalogView) target:self];
        [_catalogBtn setImage:[UIImage imageNamed:@"read_bar_0"] forState:UIControlStateNormal];
    }
    return _catalogBtn;
}

- (UILabel *)catalogLabel {
    if (!_catalogLabel) {
        _catalogLabel = [UILabel labelWithTextColor:[UIColor blackColor] fontSize:kDESGIN_TRANSFORM_iPhone6(16)];
        _catalogLabel.text = @"目录";
        _catalogLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _catalogLabel;
}

- (UIButton *)settingBtn {
    if (!_settingBtn) {
        _settingBtn = [ReadUtilites commonButtonSEL:@selector(showSettingView) target:self];
        [_settingBtn setImage:[UIImage imageNamed:@"read_bar_1"] forState:UIControlStateNormal];
    }
    return _settingBtn;
}

- (UILabel *)settingLabel {
    if (!_settingLabel) {
        _settingLabel = [UILabel labelWithTextColor:[UIColor blackColor] fontSize:kDESGIN_TRANSFORM_iPhone6(16)];
        _settingLabel.text = @"设置";
        _settingLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _settingLabel;
}

- (UIButton *)lightBtn {
    if (!_lightBtn) {
        _lightBtn = [ReadUtilites commonButtonSEL:@selector(showLightView) target:self];
        [_lightBtn setImage:[UIImage imageNamed:@"read_bar_2"] forState:UIControlStateNormal];
    }
    return _lightBtn;
}

- (UILabel *)lightLabel {
    if (!_lightLabel) {
        _lightLabel = [UILabel labelWithTextColor:[UIColor blackColor] fontSize:kDESGIN_TRANSFORM_iPhone6(16)];
        _lightLabel.text = @"亮度";
        _lightLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _lightLabel;
}

- (UIButton *)downloadBtn {
    if (!_downloadBtn) {
        _downloadBtn = [ReadUtilites commonButtonSEL:@selector(showDownload) target:self];
        [_downloadBtn setImage:[UIImage imageNamed:@"read_bar_3"] forState:UIControlStateNormal];
    }
    return _downloadBtn;
}

- (UILabel *)downloadLabel {
    if (!_downloadLabel) {
        _downloadLabel = [UILabel labelWithTextColor:[UIColor blackColor] fontSize:kDESGIN_TRANSFORM_iPhone6(16)];
        _downloadLabel.text = @"下载";
        _downloadLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _downloadLabel;
}

#pragma mark - Button Click
- (void)jumpChapter:(UIButton *)sender {
    if (sender == _nextChapter) {
        if (_readModel.chapter == _readModel.chapterCount-1) {
            [MBProgressHUD showTipsWindow:@"已经是最后一章了"];
            return;
        }
        if ([self.delegate respondsToSelector:@selector(menuViewJumpChapter:page:)]) {
            [self.delegate menuViewJumpChapter:(_readModel.chapter == _readModel.chapterCount-1)?_readModel.chapter:_readModel.chapter+1 page:0];
        }
    }
    else {
        if (_readModel.chapter == 0) {
            [MBProgressHUD showTipsWindow:@"现在是第一章了"];
            return;
        }
        if ([self.delegate respondsToSelector:@selector(menuViewJumpChapter:page:)]) {
            [self.delegate menuViewJumpChapter:_readModel.chapter?_readModel.chapter-1:0 page:0];
        }
    }
}

#pragma mark -  sliderValueChanged
- (void)sliderValueChanged:(UISlider *)sender {
    NSUInteger page = ceil((_readModel.chapterModel.pageCount-1)*sender.value/100.00);
    
    if ([self.delegate respondsToSelector:@selector(menuViewJumpChapter:page:)]) {
        [self.delegate menuViewJumpChapter:_readModel.chapter page:page];
    }
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context {
    if ([keyPath isEqualToString:@"readModel.chapter"] || [keyPath isEqualToString:@"readModel.page"]) {
        _slider.value = _readModel.page/((float)(_readModel.chapterModel.pageCount-1))*100;
        [_progressView title:_readModel.chapterModel.title progress:[NSString stringWithFormat:@"%.1f%%",_slider.value]];
    }
    else if ([keyPath isEqualToString:@"fontSize"] || [keyPath isEqualToString:@"fontNameType"]) {
        if ([self.delegate respondsToSelector:@selector(menuViewFontSize)]) {
            [self.delegate menuViewFontSize];
        }
    }
    else {
        if (_slider.state == UIControlStateNormal) {
            _progressView.hidden = YES;
        }
        else if(_slider.state == UIControlStateHighlighted){
            _progressView.hidden = NO;
        }
    }
}

- (void)showCatalogView
{
    if ([self.delegate respondsToSelector:@selector(menuViewInvokeCatalog:)]) {
        [self.delegate menuViewInvokeCatalog:self];
    }
}

- (void)showSettingView
{
    if ([self.readDelegate respondsToSelector:@selector(menuSettingViewDidAppear)]) {
        [self.readDelegate menuSettingViewDidAppear];
    }
}

- (void)showLightView
{
    if ([self.readDelegate respondsToSelector:@selector(menuLightViewDidAppear)]) {
        [self.readDelegate menuLightViewDidAppear];
    }
}

- (void)showDownload
{
    if ([self.delegate respondsToSelector:@selector(menuDownload)]) {
        [self.delegate menuDownload];
    }
}

- (void)layoutSubviews
{
    [super layoutSubviews];
//    _slider.frame = CGRectMake(50, 10, ViewSize(self).width-100, 30);
//    _lastChapter.frame = CGRectMake(5, 10, 40, 30);
//    _nextChapter.frame = CGRectMake(DistanceFromLeftGuiden(_slider)+5, 10, 40, 30);
//    _progressView.frame = CGRectMake(60, -40, ViewSize(self).width-120, 50);
//    CGFloat buttonY = DistanceFromTopGuiden(_slider) + 10;
//    CGFloat buttonH = CGRectGetHeight(self.frame)/2 - buttonY/2;
    
    CGFloat buttonY = 10;
    CGFloat labelY = 2;
    CGFloat buttonH = CGRectGetHeight(self.frame)/2 - buttonY;
    CGFloat buttonW = CGRectGetWidth(self.frame) / 4;
    
    _catalogBtn.frame = CGRectMake(buttonW * 0, buttonY, buttonW, buttonH);
    _catalogLabel.frame = CGRectMake(buttonW * 0, DistanceFromTopGuiden(_catalogBtn) + labelY, buttonW, buttonH);
    
    _settingBtn.frame = CGRectMake(buttonW * 1, buttonY, buttonW, buttonH);
    _settingLabel.frame = CGRectMake(buttonW * 1, DistanceFromTopGuiden(_settingBtn) + labelY, buttonW, buttonH);
    
    _lightBtn.frame = CGRectMake(buttonW * 2, buttonY, buttonW, buttonH);
    _lightLabel.frame = CGRectMake(buttonW * 2, DistanceFromTopGuiden(_lightBtn) + labelY, buttonW, buttonH);
    
    _downloadBtn.frame = CGRectMake(buttonW * 3, buttonY, buttonW, buttonH);
    _downloadLabel.frame = CGRectMake(buttonW * 3, DistanceFromTopGuiden(_downloadBtn) + labelY, buttonW, buttonH);
}

// 移除监听
- (void)dealloc
{
    [_slider removeObserver:self forKeyPath:@"highlighted"];
    [self removeObserver:self forKeyPath:@"readModel.chapter"];
    [self removeObserver:self forKeyPath:@"readModel.page"];
    [[ReadConfig shareInstance] removeObserver:self forKeyPath:@"fontSize"];
    [[ReadConfig shareInstance] removeObserver:self forKeyPath:@"fontNameType"];
}

@end

@interface  ReadProgressView ()

@property (nonatomic, strong) UILabel *label;
@end

@implementation  ReadProgressView

- (instancetype)init {
    self = [super init];
    if (self) {
        [self addSubview:self.label];
    }
    return self;
}
- (UILabel *)label {
    if (!_label) {
        _label = [[UILabel alloc] init];
        _label.font = [UIFont systemFontOfSize:[ReadConfig shareInstance].fontSize];
        _label.textColor = [UIColor whiteColor];
        _label.textAlignment = NSTextAlignmentCenter;
        _label.numberOfLines = 0;
    }
    return _label;
}

- (void)title:(NSString *)title progress:(NSString *)progress {
    _label.text = [NSString stringWithFormat:@"%@\n%@",title,progress];
}

-(void)layoutSubviews {
    [super layoutSubviews];
    _label.frame = self.bounds;
}


@end
