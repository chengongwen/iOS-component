//
//   BottomMenuView.h
//   Reader
//
//  Created by huotun on 2017/11/20.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RecordModel.h"
#import "ReadMenuView.h"

@protocol MenuViewDelegate;

@interface BottomMenuView : UIView <ReadMenuViewDelegate>

@property (nonatomic, weak) id<ReadMenuViewDelegate> readDelegate;
@property (nonatomic, weak) id<MenuViewDelegate> delegate;
@property (nonatomic, strong) RecordModel *readModel;
@end

@interface ReadProgressView : UIView

- (void)title:(NSString *)title progress:(NSString *)progress;
@end
