//
//   TopMenuView.m
//   Reader
//
//  Created by huotun on 2017/11/20.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "TopMenuView.h"
#import "ReadMenuView.h"
#import "ReadConfig.h"
#import "ReadUtilites.h"

@interface  TopMenuView ()

@property (nonatomic, strong) UIButton *backButton;
@property (nonatomic, strong) UIButton *bookcaseButton;
@property (nonatomic, strong) UIButton *commentButton;
@property (nonatomic, strong) UILabel *commentLabel;
@end

@implementation  TopMenuView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setBackgroundColor:kWhiteColor];
        [self setup];
    }
    return self;
}

- (void)setup
{
    [self addSubview:self.backButton];
    [self addSubview:self.bookcaseButton];
    [self addSubview:self.commentButton];
    [self addSubview:self.commentLabel];
}

- (UIButton *)backButton {
    if (!_backButton) {
        _backButton = [ReadUtilites commonButtonSEL:@selector(backView) target:self];
        [_backButton setImage:[UIImage imageNamed:@"nav_back"] forState:UIControlStateNormal];
        [_backButton setImage:[UIImage imageNamed:@"nav_backHL"] forState:UIControlStateHighlighted];
    }
    return _backButton;
}

- (UIButton *)bookcaseButton {
    if (!_bookcaseButton) {
        _bookcaseButton = [ReadUtilites commonButtonSEL:@selector(moreBookcaseOption) target:self];
        [_bookcaseButton setImage:[[UIImage imageNamed:@"read_icon_bookcase"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forState:UIControlStateNormal];
    }
    return _bookcaseButton;
}

- (UIButton *)commentButton {
    if (!_commentButton) {
        _commentButton = [ReadUtilites commonButtonSEL:@selector(moreCommentOption) target:self];
        [_commentButton setImage:[[UIImage imageNamed:@"read_icon_comment"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] forState:UIControlStateNormal];
    }
    return _commentButton;
}

- (UILabel *)commentLabel {
    if (!_commentLabel) {
        _commentLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0x222222) fontSize:kScaleFrom_iPhone6_Desgin_X(12)];
        _commentLabel.text = @"123";
    }
    return _commentLabel;
}

- (void)moreBookcaseOption {
    if ([self.delegate respondsToSelector:@selector(menuViewJoinBookcase:)]) {
        [self.delegate menuViewJoinBookcase:self];
    }
}

- (void)moreCommentOption {
    if ([self.delegate respondsToSelector:@selector(menuViewJumpComment:)]) {
        [self.delegate menuViewJumpComment:self];
    }
}

- (void)backView {
    [[ReadUtilites getCurrentVC] dismissViewControllerAnimated:YES completion:nil];
    if ([self.delegate respondsToSelector:@selector(menuViewBack:)]) {
        [self.delegate menuViewBack:self];
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    _backButton.frame = CGRectMake(0, 24 + kNaviBarPostionY, 44, 44);
    _bookcaseButton.frame = CGRectMake(ViewSize(self).width-85, 24 + kNaviBarPostionY, 40, 40);
    _commentButton.frame = CGRectMake(ViewSize(self).width-50, 24 + kNaviBarPostionY, 40, 40);
    _commentLabel.frame = CGRectMake(ViewSize(self).width-30, 24 + kNaviBarPostionY - 5, 40, 40);
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
