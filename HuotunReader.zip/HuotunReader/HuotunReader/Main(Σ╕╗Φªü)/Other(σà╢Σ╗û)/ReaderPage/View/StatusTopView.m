//
//  StatusTopView.m
//  HuotunReader
//
//  Created by huotun on 2017/11/24.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "StatusTopView.h"
#import "ReadConfig.h"

@interface StatusTopView ()

@property (nonatomic, strong) UILabel *titleLabel;
@end

@implementation StatusTopView

- (instancetype)initWithFrame:(CGRect)frame  {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = kClearColor;
        [self addSubview:self.titleLabel];
    }
    return self;
}

- (UILabel *)titleLabel {
    if (!_titleLabel) {
        _titleLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0x999999) fontSize:kDESGIN_TRANSFORM_iPhone6(18)];
        _titleLabel.frame = CGRectMake(10, 0, ViewSize(self).width, ViewSize(self).height);
    }
    return _titleLabel;
}

- (void)updateTitle:(NSString *)title {
    _titleLabel.text = title;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
