//
//   TopMenuView.h
//   Reader
//
//  Created by huotun on 2017/11/20.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol MenuViewDelegate;

@interface TopMenuView : UIView

@property (nonatomic, assign) BOOL state; //(0--未保存过，1-－保存过)
@property (nonatomic, weak) id< MenuViewDelegate>delegate;
@end
