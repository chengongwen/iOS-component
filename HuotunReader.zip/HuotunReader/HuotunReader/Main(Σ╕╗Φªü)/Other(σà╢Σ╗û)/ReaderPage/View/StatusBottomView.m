//
//  StatusBottomView.m
//  HuotunReader
//
//  Created by huotun on 2017/11/3.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "StatusBottomView.h"
#import "ReadConfig.h"
#import "YMDateTool.h"

// 电池宽推荐使用宽高
#define DZMBatterySize  CGSizeMake(25,10)
#define DZMBatteryViewWidth 22

@interface StatusBottomView ()

@property (nonatomic, strong) UIImageView *batteryImageView;
@property (nonatomic, strong) UIView *batteryView;
@property (nonatomic, strong) UILabel *timeLabel;
@property (nonatomic, strong) UILabel *pageLabel;
@property (nonatomic, strong) NSTimer *timer;
@end

@implementation StatusBottomView

- (instancetype)initWithFrame:(CGRect)frame  {
    self = [super initWithFrame:frame];
    if (self) {
        // 通过UIDevice类，可以取得电池剩余量以及充电状态的信息，首先需要设置batteryMonitoringEnabled为YES
        UIDevice * device = [UIDevice currentDevice];
        device.batteryMonitoringEnabled = YES;
        // 0.0-1.0取得失败的适合为-1.0
        DLog(@"batteryLevel = %f", device.batteryLevel);
        
        [self addSubview:self.pageLabel];
        [self addSubview:self.batteryImageView];
        [self addSubview:self.batteryView];
        [self addSubview:self.timeLabel];
        [self addTimer];
    }
    return self;
}

- (void)addTimer {
    if (!_timer) {
        _timer = [NSTimer timerWithTimeInterval:15.0f target:self selector:@selector(didChangeTime) userInfo:nil repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];
    }
}

- (void)removeTimer {
    if (_timer) {
        [_timer invalidate];
        _timer = nil;
    }
}

- (UIImageView *)batteryImageView {
    if (!_batteryImageView) {
        _batteryImageView = [[UIImageView alloc] init];
        _batteryImageView.image = [UIImage imageNamed:@"battery_Black"];
        _batteryImageView.frame = CGRectMake(30,(ViewSize(self).height - DZMBatterySize.height)/2, DZMBatterySize.width, DZMBatterySize.height);
    }
    return _batteryImageView;
}

- (UIView *)batteryView {
    if (!_batteryView) {
        _batteryView = [[UIView alloc] init];
        _batteryView.layer.masksToBounds = YES;
        _batteryView.layer.cornerRadius = DZMBatterySize.height * 0.125;

        float batteryLevel =  [UIDevice currentDevice].batteryLevel;
        _batteryView.frame = CGRectMake(30,(ViewSize(self).height - 9)/2, batteryLevel * DZMBatteryViewWidth, 9);
        if (batteryLevel > 0.2) {
            _batteryView.backgroundColor = kRGBColor_16BAND(0x666666);
        }
        else {
            _batteryView.backgroundColor = kRedColor;
        }
    }
    return _batteryView;
}

- (UILabel *)timeLabel {
    if (!_timeLabel) {
        _timeLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0x666666) fontSize:kDESGIN_TRANSFORM_iPhone6(18)];
        _timeLabel.frame = CGRectMake(60, 0, 100, ViewSize(self).height);
        _timeLabel.text = [YMDateTool getDateStrWithFormat:@"HH:mm" date:[NSDate date]];
    }
    return _timeLabel;
}

- (UILabel *)pageLabel {
    if (!_pageLabel) {
        _pageLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0x666666) fontSize:kDESGIN_TRANSFORM_iPhone6(18)];
        _pageLabel.frame = CGRectMake(ViewSize(self).width - 100, 0, 100, ViewSize(self).height);
        _pageLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _pageLabel;
}

- (void)updatePageCount:(NSInteger)pageCount page:(NSInteger)page {
    _pageLabel.text = [NSString stringWithFormat:@"%lu/%lu",page + 1,pageCount];
}

- (void)didChangeTime {
    _timeLabel.text = [YMDateTool getDateStrWithFormat:@"HH:mm" date:[NSDate date]];
    
    float batteryLevel =  [UIDevice currentDevice].batteryLevel;
    _batteryView.frame = CGRectMake(30,(ViewSize(self).height - 9)/2, batteryLevel * DZMBatteryViewWidth, 9);
    if (batteryLevel > 0.2) {
        _batteryView.backgroundColor = kRGBColor_16BAND(0x666666);
    }
    else {
        _batteryView.backgroundColor = kRedColor;
    }
}

- (void)dealloc {
    [self removeTimer];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
