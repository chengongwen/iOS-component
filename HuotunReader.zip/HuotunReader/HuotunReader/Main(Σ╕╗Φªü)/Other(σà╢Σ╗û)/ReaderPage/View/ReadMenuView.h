//
//   ReadMenuView.h
//   Reader
//
//  Created by huotun on 2017/11/20.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RecordModel.h"
#import "TopMenuView.h"
#import "MenuViewDelegate.h"

@class BottomMenuView;
@class LightView;
@class ReadSettingView;

@protocol ReadMenuViewDelegate <NSObject>
@optional

- (void)menuLightViewDidAppear;
- (void)menuSettingViewDidAppear;

@end

@interface  ReadMenuView : UIView <MenuViewDelegate>

@property (nonatomic, weak) id<MenuViewDelegate> delegate;

@property (nonatomic, strong) RecordModel *recordModel;
@property (nonatomic, strong) TopMenuView *topView;
@property (nonatomic, strong) BottomMenuView *bottomView;
@property (nonatomic, strong) LightView *lightView;
@property (nonatomic, strong) ReadSettingView *settingView;
@property (nonatomic, strong) UIView *backgroundView;

- (void)showAnimation:(BOOL)animation;
- (void)hiddenAnimation:(BOOL)animation;

@end
