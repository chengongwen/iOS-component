//
//  ReadModel.h
//  HuotunReader
//
//  Created by chengongwen on 2017/10/31.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CatalogueObject.h"
#import "ChapterModel.h"
#import "ReadConfig.h"
#import "RecordModel.h"

#define kChapterKey(chapterNum) [NSString stringWithFormat:@"%lu",chapterNum]

@interface ReadModel : NSObject

@property (nonatomic, strong) RecordModel *record;

@property (nonatomic, strong) NSArray *catalogueList;               // 当前书籍的目录列表
@property (nonatomic, strong) NSMutableDictionary *chaptersList;    // 所有章节数据列表

// 初始化数据
- (instancetype)initWithCatalogue:(CatalogueObject *)catalogueObject;

// 保存当前翻页的浏览记录
- (void)archivierChapter;

// 异步加载所有章节
- (void)loadAllReadChapterList;

// 加载章节
- (void)reloadDataWithChapter:(NSUInteger)chapter;

// 更新改变字体所有数据
- (void)allChapterListUpdateFontConfig;

@end
