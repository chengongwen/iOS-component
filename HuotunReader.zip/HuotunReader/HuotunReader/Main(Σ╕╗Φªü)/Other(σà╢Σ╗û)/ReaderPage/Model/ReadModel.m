//
//  ReadModel.m
//  HuotunReader
//
//  Created by chengongwen on 2017/10/31.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "ReadModel.h"
#import "DatabaseManager.h"

#define kFontSize       @"fontSize"     // 当前的保存的字体大小
#define kChapterNum     @"chapterNum"   // 保存浏览记录章节
#define kPageIndex      @"pageIndex"    // 记录浏览记录页码
#define kChaptersList   @"chaptersList" // 记录保存历史

@interface ReadModel()

@property (nonatomic, assign) CGFloat fontSize;
@property (nonatomic, strong) CatalogueObject *catalogueObject;
@end

@implementation ReadModel

- (instancetype)initWithCatalogue:(CatalogueObject *)catalogueObject {
    self = [super init];
    if (self) {
        self.catalogueObject = catalogueObject;
        
        _catalogueList = [[NSArray alloc] init];
        _chaptersList = [[NSMutableDictionary alloc] init];
        
        // 初始化一个模型数据
        self.record = [[RecordModel alloc] init];
        
        // 当前书籍的目录列表
        _catalogueList = [[DatabaseManager shareInstance] reloadChapterDBList:_catalogueObject.catalogueId];
        _record.chapterCount = _catalogueList.count;
        
        // 获取本地保存数据
        [self unarchiverChapter];

        // 加载前后3章数据
        [self loadDataWithChapter:_record.chapter];
        
        // 更新字体大小
        if (self.fontSize != [ReadConfig shareInstance].fontSize) {
            [self allChapterListUpdateFontConfig];
        }
    }
    return self;
}

// 异步加载所有章节数据
- (void)loadAllReadChapterList {
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        @try {
            NSMutableDictionary *allChapterList = [[NSMutableDictionary alloc] init];
            for (ChapterObject *chapterObject in _catalogueList) {
                
                ChapterModel *chapterModel = [_chaptersList objectForKey:kChapterKey((unsigned long)chapterObject.chapterNum)];
                
                if (chapterModel) {
                    // 说明数据已经成功加载
                }
                else {
                    chapterModel = [[ChapterModel alloc] initWithChapter:chapterObject];
                }
                [allChapterList setValue:chapterModel forKey:kChapterKey((unsigned long)chapterObject.chapterNum)];
            }
            self.chaptersList = [allChapterList copy];
            
        } @catch (NSException *exception) {
            DLog(@"加载所有章节数据更新异常，%@",exception);
        }
        // 归档保存
        [self archivierChapter];
    });
}

// 更新改变字体所有数据
- (void)allChapterListUpdateFontConfig {
    // 使用枚举器
    NSEnumerator * enumerator = [self.chaptersList objectEnumerator];
    ChapterModel * chapterModel;
    while (chapterModel = [enumerator nextObject]) {
        @try {
            [chapterModel updateFontConfig];
        } @catch (NSException *exception) {
            DLog(@"遍历改变字体异步数据更新异常，%@",exception);
        }
    }
    
    // 归档保存
    [self archivierChapter];
}

// 加载章节
- (void)reloadDataWithChapter:(NSUInteger)chapter {
    // 根据当前的章节，重新布局和计算页码
    [self loadDataWithChapter:chapter];
}

// 初始化 init 加载章节
- (void)loadDataWithChapter:(NSInteger)chapterNum {
    DLog(@"chapterNum = %lu",chapterNum);
    
    NSInteger preChapter = chapterNum - 1;
    NSInteger nextChapter = chapterNum + 1;
    
    // 获得当前的章节数据
    ChapterModel *chapterModel = [_chaptersList objectForKey:kChapterKey(chapterNum)];
    if (!chapterModel) {
        ChapterObject *chapterObj = [[DatabaseManager shareInstance] getChapterObject:_catalogueObject.catalogueId chapterNum:chapterNum];
        chapterModel = [[ChapterModel alloc] initWithChapter:chapterObj];
        if (chapterModel.pageCount) {
            [self.chaptersList setValue:chapterModel forKey:kChapterKey(chapterNum)];
        }
    }
    
    // 缓存前一章数据
    ChapterModel *preChapteModel = [_chaptersList objectForKey:kChapterKey(preChapter)];
    if (!preChapteModel) {
        ChapterObject *preChapterObj = [[DatabaseManager shareInstance] getChapterObject:_catalogueObject.catalogueId chapterNum:preChapter];
        preChapteModel = [[ChapterModel alloc] initWithChapter:preChapterObj];
        if (preChapteModel.pageCount) {
            [self.chaptersList setValue:preChapteModel forKey:kChapterKey(preChapter)];
        }
    }
    
    // 缓存后一章数据
    ChapterModel *nextChapteModel = [_chaptersList objectForKey:kChapterKey(nextChapter)];;
    if (!nextChapteModel) {
        ChapterObject *nextChapterObj = [[DatabaseManager shareInstance] getChapterObject:_catalogueObject.catalogueId chapterNum:nextChapter];
        nextChapteModel = [[ChapterModel alloc] initWithChapter:nextChapterObj];
        if (nextChapteModel.pageCount) {
            [self.chaptersList setValue:nextChapteModel forKey:kChapterKey(nextChapter)];
        }
    }
    
    _record.chapterModel = chapterModel;
    _record.previousChapterModel = preChapteModel;
    _record.nextChapterModel = nextChapteModel;
}

#pragma mark -
#pragma mark - 归档和反归档，获取和保存最后一次的浏览章节和页码
- (void)archivierChapter {
    NSDictionary *readDict  = @{kChapterNum:    [NSNumber numberWithInteger:_record.chapter],
                                kPageIndex:     [NSNumber numberWithInteger:_record.page],
                                kFontSize:      [NSNumber numberWithFloat:[ReadConfig shareInstance].fontSize],
                                // kChaptersList:  _chaptersList
                                };
    
    // 保存对象转化为二进制数据（一定是可变对象）
    NSMutableData *data = [[NSMutableData alloc] init];
    // 1.初始化
    NSKeyedArchiver *archivier = [[NSKeyedArchiver alloc] initForWritingWithMutableData:data];
    // 2.归档
    [archivier encodeObject:readDict forKey:_catalogueObject.catalogueId];
    //3.完成归档
    [archivier finishEncoding];
    // 4.保存
    [[NSUserDefaults standardUserDefaults] setObject:data forKey:_catalogueObject.catalogueId];
}

- (void)unarchiverChapter {
    // 1.获取保存的数据
    NSData *data = [[NSUserDefaults standardUserDefaults] objectForKey:_catalogueObject.catalogueId];
    
    if (data) {
        // 2.初始化解归档对象
        NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:data];
        // 3.解归档
        NSDictionary *readDict = [unarchiver decodeObjectForKey:_catalogueObject.catalogueId];
    
        _record.chapter = [readDict[kChapterNum] integerValue];
        _record.page = [readDict[kPageIndex] integerValue];
        self.fontSize = [readDict[kFontSize] floatValue];
        //self.chaptersList = readDict[kChaptersList];
        
        // 4.完成解归档
        [unarchiver finishDecoding];
    }
    else {
        _record.chapter = 0;
        _record.page = 0;
        self.fontSize = [ReadConfig shareInstance].fontSize;
    }
}

- (void)deleteArchivierReadModel {
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:_catalogueObject.catalogueId];
}

@end
