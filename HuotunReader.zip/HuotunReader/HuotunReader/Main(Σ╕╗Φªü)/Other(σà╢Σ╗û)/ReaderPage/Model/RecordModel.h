//
//  RecordModel.h
//  HuotunReader
//
//  Created by chengongwen on 2017/10/31.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ChapterModel.h"

@interface RecordModel : NSObject

@property (nonatomic, assign) NSUInteger page;          // 阅读的页数
@property (nonatomic, assign) NSUInteger chapter;       // 阅读的章节数
@property (nonatomic, assign) NSUInteger chapterCount;  // 总章节数

@property (nonatomic, strong) ChapterModel *previousChapterModel;   // 前一章数据
@property (nonatomic, strong) ChapterModel *chapterModel;           // 阅读的章节
@property (nonatomic, strong) ChapterModel *nextChapterModel;       // 后一章数据

@end
