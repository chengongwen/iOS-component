//
//  MenuViewDelegate.h
//  HuotunReader
//
//  Created by huotun on 2017/11/20.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#ifndef MenuViewDelegate_h
#define MenuViewDelegate_h

@class ReadMenuView;
@class TopMenuView;
@class BottomMenuView;

@protocol MenuViewDelegate <NSObject>

@optional

- (void)menuViewDidHidden:(ReadMenuView *)menu;
- (void)menuViewDidAppear:(ReadMenuView *)menu;

/**
 跳转到目录类别视图
 */
- (void)menuViewInvokeCatalog:(BottomMenuView *)bottomMenu;


/**
 跳转到制定的章节
 */
- (void)menuViewJumpChapter:(NSUInteger)chapter page:(NSUInteger)page;

/**
 更新和下载章节
 */
- (void)menuViewFontSize;
- (void)menuDownload;

/**
 返回
 */
- (void)menuViewBack:(TopMenuView *)topMenu;
- (void)menuViewMark:(TopMenuView *)topMenu;

/**
 加入到书架
 */
- (void)menuViewJoinBookcase:(TopMenuView *)topMenu;

/**
 跳转到评论
 */
- (void)menuViewJumpComment:(TopMenuView *)topMenu;

@end

#endif /* MenuViewDelegate_h */
