//
//  ReadConfig.h
//  HuotunReader
//
//  Created by chengongwen on 2017/10/31.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <Foundation/Foundation.h>

#define TopSpacing      44.0f
#define BottomSpacing   40.0f
#define LeftSpacing     10.0f
#define RightSpacing    10.0f

#define GetReadTableViewFrame CGRectMake(LeftSpacing,10 + TopSpacing + kNaviBarPostionY, kScreenWidth - LeftSpacing - RightSpacing, kScreenHeight- (10 +  TopSpacing + kNaviBarPostionY)-BottomSpacing)

#define ViewOrigin(view)   (view.frame.origin)
#define ViewSize(view)  (view.frame.size)
#define DistanceFromTopGuiden(view) (view.frame.origin.y + view.frame.size.height)
#define DistanceFromLeftGuiden(view) (view.frame.origin.x + view.frame.size.width)

#define READ_BACKGROUND_COLOC_1 kRGBColor(252, 245, 237)
#define READ_BACKGROUND_COLOC_2 kRGBColor(255, 238, 238)
#define READ_BACKGROUND_COLOC_3 kRGBColor(220, 246, 250)
#define READ_BACKGROUND_COLOC_4 kRGBColor(255, 255, 255)
#define READ_BACKGROUND_COLOC_5 kRGBColor(51,   51,  51)


@interface ReadConfig : NSObject<NSCoding>

+ (instancetype)shareInstance;

@property (nonatomic, assign) CGFloat fontSize;
@property (nonatomic, assign) CGFloat lineSpace;
@property (nonatomic, strong) UIColor *fontColor;
@property (nonatomic, strong) UIColor *theme;

@end
