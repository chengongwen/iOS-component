//
//  ReadScrollViewController.m
//  HuotunReader
//
//  Created by chengongwen on 2017/10/31.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "ReadScrollViewController.h"
#import "ReadViewController.h"
#import "ChapterModel.h"
#import "ReadMenuView.h"
#import "CatalogViewController.h"
#import "ChapterTableViewCell.h"
#import "StatusTopView.h"
#import "StatusBottomView.h"
#import "ReadModel.h"
#import "CatalogueObject.h"

#import <objc/runtime.h>
#define AnimationDelay 0.3

static  NSString *chapterTableViewCell = @"chapterTableViewCell";

@interface ReadScrollViewController() <UITableViewDataSource,UITableViewDelegate,UIGestureRecognizerDelegate,ReadViewControllerDelegate,
                                        MenuViewDelegate,CatalogViewControllerDelegate>
{
    NSUInteger _chapter;        // 当前显示的章节
    NSUInteger _page;           // 当前显示的页数
    NSUInteger _chapterChange;  // 将要变化的章节
    NSUInteger _pageChange;     // 将要变化的页数
    BOOL _isTransition;         // 是否开始翻页
}

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) ReadViewController *readView;   //当前阅读视图

@property (nonatomic, strong) ReadMenuView *menuView; //菜单栏
@property (nonatomic, strong) CatalogViewController *catalogController;   //侧边栏
@property (nonatomic, getter=isShowBar) BOOL showBar; //是否显示状态栏
@property (nonatomic, strong) StatusTopView *statusTopView;         // 顶部栏
@property (nonatomic, strong) StatusBottomView *statusBottomView;   // 底部栏

@end

@implementation ReadScrollViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self vhl_setNavBarHidden:YES];
    [self.view setBackgroundColor:[ReadConfig shareInstance].theme];
    
    // 以下两行代码根据需要设置
    self.edgesForExtendedLayout = YES;
    self.automaticallyAdjustsScrollViewInsets=YES;
    // 设置CGRectZero从导航栏下开始计算
    if ([self respondsToSelector:@selector(setEdgesForExtendedLayout:)]) {
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }
    
    [self.view addSubview:self.tableView];
    [self.view addSubview:self.statusTopView];
    [self.view addSubview:self.statusBottomView];
    
    [self.view addSubview:self.menuView];
    [self.view addGestureRecognizer:({
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(showToolMenu)];
        tap.delegate = self;
        tap;
    })];
    
    // 加载数据
    [self loadDefaultData];
    
    // 监听设置背景
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeTheme:) name:kThemeNotification object:nil];
}

- (void)loadDefaultData {
    [MBProgressHUD showMessageWindow:@"正在加载..."];
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        
        // 初始化缓存数据
        _model = [[ReadModel alloc] initWithCatalogue:self.bookModel];
        _menuView.recordModel = _model.record;
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            // 初始化章节和页码
            _chapter = _model.record.chapter;
            _page = _model.record.page;
            [self.tableView reloadData];
            
            // 滚动到指定的cell
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:_page inSection:_chapter];
            [self.tableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionMiddle];
            [self.tableView deselectRowAtIndexPath:indexPath animated:NO];
        
            // 更新顶部和底部栏
            [self updateStatusView];
            
            [MBProgressHUD hideHUDWindow];
        });
    });
}

- (void)changeTheme:(NSNotification *)notifi {
    [ReadConfig shareInstance].theme = notifi.object;
    
    [self.view setBackgroundColor:[ReadConfig shareInstance].theme];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    // 禁用返回手势
    if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.navigationController.interactivePopGestureRecognizer.enabled = NO;
    }
    // 异步加载所有数据
    [_model loadAllReadChapterList];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    // 开启返回手势
    if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.navigationController.interactivePopGestureRecognizer.enabled = YES;
    }
}

- (void)showToolMenu
{
    BOOL isMarked = FALSE;
    isMarked?(_menuView.topView.state=1): (_menuView.topView.state=0);
    
    [self.menuView showAnimation:YES];
}

#pragma mark - init
- (void)viewDidLayoutSubviews {
    
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:GetReadTableViewFrame style:UITableViewStylePlain];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.backgroundColor = kClearColor;
        _tableView.tableHeaderView = [[UIView alloc] init];
        _tableView.tableFooterView = [[UIView alloc] init];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.showsHorizontalScrollIndicator = NO;
        [_tableView registerClass:[ChapterTableViewCell class] forCellReuseIdentifier:chapterTableViewCell];
    }
    return _tableView;
}

- (ReadMenuView *)menuView {
    if (!_menuView) {
        _menuView = [[ReadMenuView alloc] initWithFrame:self.view.bounds];
        _menuView.hidden = YES;
        _menuView.delegate = self;
        _menuView.recordModel = _model.record;
    }
    return _menuView;
}

- (StatusTopView *)statusTopView {
    if (!_statusTopView) {
        _statusTopView = [[StatusTopView alloc] initWithFrame:CGRectMake(0, 10 + kNaviBarPostionY, ViewSize(self.view).width, TopSpacing)];
    }
    return _statusTopView;
}

- (StatusBottomView *)statusBottomView {
    if (!_statusBottomView) {
        _statusBottomView = [[StatusBottomView alloc] initWithFrame:CGRectMake(0, ViewSize(self.view).height - BottomSpacing, ViewSize(self.view).width, BottomSpacing)];
    }
    return _statusBottomView;
}

- (CatalogViewController *)catalogController {
    if (!_catalogController) {
        _catalogController = [[CatalogViewController alloc] init];
        _catalogController.catalogDelegate = self;
    }
    return _catalogController;
}

#pragma mark - CatalogViewController Delegate
- (void)catalog:(CatalogViewController *)catalog didSelectChapter:(NSUInteger)chapter page:(NSUInteger)page {
    [_menuView hiddenAnimation:NO];
    
    if (chapter == _chapter) {
        return;
    }
    
    [self updateReadModelWithChapter:chapter page:page];
    [self.tableView reloadData];
    
    // 滚动到指定的cell
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:page inSection:chapter];
    [self.tableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionMiddle];
    [self.tableView deselectRowAtIndexPath:indexPath animated:NO];
}

#pragma mark -  UIGestureRecognizer Delegate
//解决TabView与Tap手势冲突
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    if ([NSStringFromClass([touch.view class]) isEqualToString:@"UITableViewCellContentView"]) {
        //return NO;
    }
    return YES;
}

- (BOOL)prefersStatusBarHidden
{
    return !_showBar;
}

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleDefault;
}

- (UIStatusBarAnimation)preferredStatusBarUpdateAnimation {
    return UIStatusBarAnimationSlide;
}

#pragma mark - Menu View Delegate
- (void)menuViewDidHidden:(ReadMenuView *)menu {
    _showBar = NO;
    [self setNeedsStatusBarAppearanceUpdate];
}

- (void)menuViewDidAppear:(ReadMenuView *)menu {
    _showBar = YES;
    [self setNeedsStatusBarAppearanceUpdate];
}

- (void)menuViewInvokeCatalog:(BottomMenuView *)bottomMenu {
    //[_menuView hiddenAnimation:NO];
    
    [self.catalogController reloadData:_model chapter:_chapter];
    [self.navigationController pushViewController:self.catalogController animated:YES];
}

- (void)menuViewJumpChapter:(NSUInteger)chapter page:(NSUInteger)page {
    [self updateReadModelWithChapter:chapter page:page];
    [self.tableView reloadData];
    
    // 滚动到指定的cell
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:page inSection:chapter];
    [self.tableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionMiddle];
    [self.tableView deselectRowAtIndexPath:indexPath animated:NO];
}

- (void)menuViewFontSize  {
    [MBProgressHUD showMessageWindow:@""];
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        
        // 异步更新改变字体所有数据
        [_model allChapterListUpdateFontConfig];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            // 更新当前章节的布局
            [_model.record.chapterModel updateFontConfig];
            
            NSInteger page = (_model.record.page > _model.record.chapterModel.pageCount-1) ? _model.record.chapterModel.pageCount-1 : _model.record.page;
            [self updateReadModelWithChapter:_model.record.chapter page:page];
            [self.tableView reloadData];
            
            // 滚动到指定的cell
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:page inSection:_chapter];
            [self.tableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionMiddle];
            [self.tableView deselectRowAtIndexPath:indexPath animated:NO];
            
            [MBProgressHUD hideHUDWindow];
        });
    });
}

- (void)menuViewMark:(TopMenuView *)topMenu {
    
}

- (void)menuViewJumpComment:(TopMenuView *)topMenu {
    [self.catalogController reloadData:_model chapter:_chapter];
    [self.navigationController pushViewController:self.catalogController animated:YES];
}

- (void)menuViewJoinBookcase:(TopMenuView *)topMenu {
    
}

- (void)menuViewBack:(TopMenuView *)topMenu {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Create Read View Controller
// 保存当前翻页的浏览记录
- (void)updateReadModelWithChapter:(NSUInteger)chapter page:(NSUInteger)page {
    DLog(@"_chapter = %lu, _page = %lu", _chapter, _page);
    
    DLog(@"chapter = %lu, page = %lu", chapter, page);
    
    // 章节与之前不一样，需要重新计算
    if (_chapter != chapter) {
        [_model reloadDataWithChapter:chapter];
    }
    
    if (chapter != _chapter || page != _page) {
        _chapter = chapter;
        _page = page;
        
        _model.record.chapter = chapter;
        _model.record.page = page;
        
        // 每次保存当前翻页的浏览记录
        [_model archivierChapter];
    }
    
    // 更新顶部和底部栏
    [self updateStatusView];
}

#pragma mark - Read View Controller Delegate
- (void)readViewEndEdit:(ReadViewController *)readView {
    for (UIGestureRecognizer *ges in self.tableView.gestureRecognizers) {
        if ([ges isKindOfClass:[UIPanGestureRecognizer class]]) {
            ges.enabled = YES;
            break;
        }
    }
}

- (void)readViewEditeding:(ReadViewController *)readView {
    for (UIGestureRecognizer *ges in self.tableView.gestureRecognizers) {
        if ([ges isKindOfClass:[UIPanGestureRecognizer class]]) {
            ges.enabled = NO;
            break;
        }
    }
}

#pragma mark - UITableView
#pragma mark - UITableView Delagete DataSource
-  (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return _model.record.chapterCount;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    ChapterModel *chapterModel = [_model.chaptersList objectForKey:kChapterKey(section)];
    if (chapterModel) {
        if (chapterModel.pageCount) {
            return chapterModel.pageCount;
        }
    }
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *chapterCellIdentifier = @"chapterCellIdentifier";
    UITableViewCell *cell = nil;
    if (!cell) {
        cell = (UITableViewCell *)[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:chapterCellIdentifier];
        cell.backgroundColor = kClearColor;
    }
    if (indexPath.section >= _model.record.chapterCount) {
        return cell;
    }
    
    ChapterModel *chapterModel = [_model.chaptersList objectForKey:kChapterKey(indexPath.section)];
    if (!chapterModel) {
        cell.textLabel.text = @"未加载到当前章节内容";
        return cell;
    }
    if (indexPath.row >= chapterModel.pageCount || chapterModel.pageCount == 0) {
        cell.textLabel.text = @"未加载到当前章节内容";
        return cell;
    }
    
    NSString *content = [chapterModel stringOfPage:indexPath.row];
    if (content.length) {
        cell = (ChapterTableViewCell *)[tableView dequeueReusableCellWithIdentifier:chapterTableViewCell];
        [(ChapterTableViewCell *)cell refreshCellWithObject:content];
        
        // 无色
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return GetReadTableViewFrame.size.height;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}

#pragma mark - UIScrollViewDelegate
static bool isDragging = NO;

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    isDragging = YES;
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    isDragging = NO;
    
    // 保存当前记录
    [self updateReadModelWithChapter:_chapterChange page:_pageChange];
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    if (!decelerate) {
        // 保存当前记录
        [self updateReadModelWithChapter:_chapterChange page:_pageChange];
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    // 刷新记录
    if (isDragging) {
        [self updateReadRecordModel];
    }
}

// 记录当前tableview的滑动位置
- (void)updateReadRecordModel {
    if (self.tableView.indexPathsForVisibleRows != nil && self.tableView.indexPathsForVisibleRows.count) {
        
        // 范围
        CGRect rect = GetReadTableViewFrame;
        
        // 显示章节Cell IndexPath
        NSIndexPath *indexPath = [[self.tableView indexPathsForRowsInRect:CGRectMake(0, self.tableView.contentOffset.y, rect.size.width,rect.size.height)] firstObject];
        
        DLog(@"section = %lu,row = %lu",indexPath.section,indexPath.row);
        
        // 当前章节
        _chapterChange = indexPath.section;
        
        // 页码
        _pageChange = indexPath.row;
    }
}

// 更新顶部和底部栏
- (void)updateStatusView {
    ChapterModel *chapter = [_model.chaptersList objectForKey:kChapterKey(_chapter)];
    
    NSString *title = [NSString stringWithFormat:@"第%lu章 %@",_chapter +1,chapter.title];
    [self.statusTopView updateTitle:title];
    
    if (chapter.pageCount) {
        [self.statusBottomView updatePageCount:chapter.pageCount page:_page];
    }
    else {
        [self.statusBottomView updatePageCount:1 page:0];
    }
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end

