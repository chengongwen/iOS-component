//
//  ReadViewController.h
//  HuotunReader
//
//  Created by chengongwen on 2017/10/31.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "BaseViewController.h"
#import "ReadView.h"
#import "RecordModel.h"
#import "StatusBottomView.h"

@class ReadViewController;

@protocol ReadViewControllerDelegate <NSObject>

- (void)readViewEditeding:(ReadViewController *)readView;
- (void)readViewEndEdit:(ReadViewController *)readView;

@end

@interface ReadViewController : BaseViewController<ReadViewControllerDelegate>

@property (nonatomic, weak) id<ReadViewControllerDelegate>delegate;

@property (nonatomic, strong) RecordModel *recordModel;   //阅读进度

@property (nonatomic, strong) NSString *content; //显示的内容
@property (nonatomic, strong) ReadView *readView;

@property (nonatomic, strong) StatusBottomView *statusView;
@property (nonatomic, assign) NSInteger pageCount;
@property (nonatomic, assign) NSInteger page;

@end
