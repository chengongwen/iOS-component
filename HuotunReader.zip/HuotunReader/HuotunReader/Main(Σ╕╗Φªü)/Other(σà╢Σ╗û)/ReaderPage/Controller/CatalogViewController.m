//
//  CatalogViewController.m
//  HuotunReader
//
//  Created by chengongwen on 2017/10/31.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "CatalogViewController.h"
#import "ReadModel.h"
#import "CatalogueObject.h"
#import "CatalogueTableViewCell.h"

static  NSString *chapterListCell = @"chapterListCell";

@interface CatalogViewController ()<UITableViewDelegate,UITableViewDataSource,CatalogViewControllerDelegate>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) ReadModel *readModel;
@property (nonatomic, assign) NSInteger chapter;

@property (nonatomic, strong) UILabel *chapterLabel;
@property (nonatomic, strong) UIButton *sortButton;
@property (nonatomic, strong) UIButton *sortCaseButton;
@property (nonatomic, assign) BOOL isOpen;

@end

@implementation CatalogViewController

- (void)dealloc {
    [self removeObserver:self forKeyPath:@"readModel.record.chapter"];
}

- (instancetype)init {
    self = [super init];
    if (self) {
        self.isShowBackBtn = YES;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"书籍目录";
    
    /*
     [self vhl_setNavBarHidden:YES];
    // 设置一个自定义导航
    UILabel *titleLable = [UILabel labelWithTextColor:kBlackColor fontSize:kDESGIN_TRANSFORM_iPhone6(17)];
    titleLable.font = [UIFont boldSystemFontOfSize:kDESGIN_TRANSFORM_iPhone6(21)];
    titleLable.text = @"书籍目录";
    titleLable.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:titleLable];
    [titleLable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(@(24 + kNaviBarPostionY));
        make.centerX.equalTo(self.view);
        make.width.equalTo(@(kScreenWidth/2));
        make.height.equalTo(@(44));
    }];
    
    UIButton *back = [UIButton buttonWithType:UIButtonTypeCustom];
    [back setImage:[UIImage imageNamed:@"nav_back"] forState:UIControlStateNormal];
    [back setImage:[UIImage imageNamed:@"nav_backHL"] forState:UIControlStateHighlighted];
    [back addTarget:self action:@selector(backView) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:back];
    [back mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(@(24 + kNaviBarPostionY));
        make.left.equalTo(@(kScaleFrom_iPhone6_Desgin_X(24)));
        make.height.equalTo(@(44));
    }];
    
    UIView *seperator = [[UIView alloc] init];
    seperator.backgroundColor = [UIColor grayColor];
    seperator.alpha = 0.3;
    [self.view addSubview:seperator];
    [seperator mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(@(kNaviBarHeight));
        make.left.width.equalTo(self.view);
        make.height.equalTo(@(0.5));
    }];
    */
    
    // 设置目录降序和升序
    UIView *sortView = [[UIView alloc] init];
    sortView.backgroundColor = kWhiteColor;
    [self.view addSubview:sortView];
    [sortView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(@(kNaviBarHeight));
        make.left.width.equalTo(self.view);
        make.height.equalTo(@(64));
    }];
    [self initSortView:sortView];
    
    // tableview
    self.tableView = [[UITableView alloc] init];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.backgroundColor = kWhiteColor;
    self.tableView.tableHeaderView = [[UIView alloc] init];
    self.tableView.tableFooterView = [[UIView alloc] init];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.tableView registerClass:[CatalogueTableViewCell class] forCellReuseIdentifier:chapterListCell];
    self.tableView.alwaysBounceVertical = YES;
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(sortView.mas_bottom);
        make.left.width.bottom.equalTo(self.view);
    }];
    
    // 滚动到指定的cell
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:_chapter inSection:0];
    [self.tableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionTop];
    [self.tableView deselectRowAtIndexPath:indexPath animated:NO];
    
    [self addObserver:self forKeyPath:@"readModel.record.chapter" options:NSKeyValueObservingOptionNew context:NULL];
}

// 设置排序边框
- (void)initSortView:(UIView *)sortView {
    self.chapterLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0x222222) fontSize:kDESGIN_TRANSFORM_iPhone6(16)];
    [sortView addSubview:self.chapterLabel];
    self.chapterLabel.text = [NSString stringWithFormat:@"共%lu章",_readModel.catalogueList.count];
    [self.chapterLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(sortView);
        make.left.equalTo(@(kScaleFrom_iPhone6_Desgin_X(24)));
        make.width.equalTo(@(kDESGIN_TRANSFORM_iPhone6(120)));
    }];
    
    // 设置sortCaseButton
    self.sortCaseButton = [UIButton buttonWithType:UIButtonTypeCustom];
    NSString *title = [NSString stringWithFormat:@"1-%lu章",_readModel.catalogueList.count];
    [self.sortCaseButton  setTitle:title forState:UIControlStateNormal];
    [self.sortCaseButton.titleLabel setFont:[UIFont systemFontOfSize:12]];
    [self.sortCaseButton  setImage:[UIImage imageNamed:@"icon_sort_case_arrow"] forState:UIControlStateNormal];
    [self.sortCaseButton  setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.sortCaseButton  addTarget:self action:@selector(sortButtonClicked) forControlEvents:UIControlEventTouchUpInside];
    [sortView addSubview:self.sortCaseButton];
    
    //设置边框颜色
    self.sortCaseButton.layer.borderColor = [kRGBColor_16BAND(0xD6A464) CGColor];
    //设置边框宽度
    self.sortCaseButton.layer.borderWidth = 1.0f;
    //给按钮设置角的弧度
    self.sortCaseButton.layer.cornerRadius = 4.0f;
    self.sortCaseButton.layer.masksToBounds = YES;
    [self.sortCaseButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(sortView);
        make.right.equalTo(@(-kScaleFrom_iPhone6_Desgin_X(15)));
        make.height.equalTo(@(kDESGIN_TRANSFORM_iPhone6(31)));
        make.width.equalTo(@(kDESGIN_TRANSFORM_iPhone6(100)));
    }];
    
    self.sortCaseButton.titleLabel.backgroundColor = self.sortCaseButton.backgroundColor;
    self.sortCaseButton.imageView.backgroundColor = self.sortCaseButton.backgroundColor;
    //在使用一次titleLabel和imageView后才能正确获取titleSize
    CGSize titleSize = self.sortCaseButton.titleLabel.bounds.size;
    CGSize imageSize = self.sortCaseButton.imageView.bounds.size;
    CGFloat interval = 1.0;
    CGFloat positionY = kDESGIN_TRANSFORM_iPhone6(15); // 偏移量
    self.sortCaseButton.imageEdgeInsets = UIEdgeInsetsMake(0,titleSize.width + interval + positionY, 0, -(titleSize.width + interval));
    self.sortCaseButton.titleEdgeInsets = UIEdgeInsetsMake(0, -(imageSize.width + interval) - positionY, 0, imageSize.width + interval);
    
    
    // 设置sortButton
    self.sortButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.sortButton  setTitle:@"升序" forState:UIControlStateNormal];
    [self.sortButton.titleLabel setFont:[UIFont systemFontOfSize:12]];
    [self.sortButton  setImage:[UIImage imageNamed:@"icon_sort_arrow"] forState:UIControlStateNormal];
    [self.sortButton  setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.sortButton  addTarget:self action:@selector(sortButtonClicked) forControlEvents:UIControlEventTouchUpInside];
    [sortView addSubview:self.sortButton];
    [self.sortButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(sortView);
        make.right.equalTo(self.sortCaseButton.mas_left).offset(-kDESGIN_TRANSFORM_iPhone6(5));
        make.height.equalTo(@(kDESGIN_TRANSFORM_iPhone6(31)));
        make.width.equalTo(@(kDESGIN_TRANSFORM_iPhone6(60)));
    }];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context
{
    [self.tableView reloadData];
}

- (void)reloadData:(ReadModel *)readModel chapter:(NSInteger)chapter {
    self.chapter = chapter;
    self.readModel = readModel;
    [self.tableView reloadData];
    
    if (self.isOpen) {
        chapter = readModel.catalogueList.count - 1 - chapter;
    }
    
    // 滚动到指定的cell
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:chapter inSection:0];
    [self.tableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionMiddle];
    [self.tableView deselectRowAtIndexPath:indexPath animated:NO];
}

- (void)backView {
    [self.navigationController popViewControllerAnimated:YES];
}

// 设置小三角旋转的事件
- (void)sortButtonClicked {
    if (!self.isOpen) {
        [UIView animateWithDuration:0.5 animations:^{
            self.sortButton.imageView.transform = CGAffineTransformMakeRotation(M_PI);
            [self.sortButton setTitle:@"降序" forState:UIControlStateNormal];
            
            self.sortCaseButton.imageView.transform = CGAffineTransformMakeRotation(M_PI);
            NSString *title = [NSString stringWithFormat:@"%lu-1章",self.readModel.catalogueList.count];
            [self.sortCaseButton setTitle:title forState:UIControlStateNormal];
        }];
        self.isOpen = YES;
    }
    else
    {
        [UIView animateWithDuration:0.5 animations:^{
            self.sortButton.imageView.transform = CGAffineTransformIdentity;
            [self.sortButton setTitle:@"升序" forState:UIControlStateNormal];
            
            self.sortCaseButton.imageView.transform = CGAffineTransformIdentity;
            NSString *title = [NSString stringWithFormat:@"1-%lu章",self.readModel.catalogueList.count];
            [self.sortCaseButton setTitle:title forState:UIControlStateNormal];
        }];
        self.isOpen = NO;
    }
    [self.tableView reloadData];
}

#pragma mark - UITableView Delagete DataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
   return _readModel.catalogueList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"chapterCellId";
    id cell = nil;
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    if (indexPath.row >= _readModel.catalogueList.count) {
        return cell;
    }
    
    NSInteger index = indexPath.row;
    if (self.isOpen) {
        index = _readModel.catalogueList.count - 1 - indexPath.row;
    }
    
    CatalogueObject *catalogueModel = _readModel.catalogueList[index];
   
    BOOL isSelected = NO;
    if (index == _chapter) {
        isSelected = YES;
    }
    
    cell = (CatalogueTableViewCell *)[tableView dequeueReusableCellWithIdentifier:chapterListCell];
    [cell refreshCellWithObject:catalogueModel index:index isSelected:isSelected];
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return kDESGIN_TRANSFORM_iPhone6(51);
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self backView];
    
    if ([self.catalogDelegate respondsToSelector:@selector(catalog:didSelectChapter:page:)]) {
        if (self.isOpen) {
            [self.catalogDelegate catalog:nil didSelectChapter:(_readModel.catalogueList.count - 1 - indexPath.row) page:0];
        }
        else {
            [self.catalogDelegate catalog:nil didSelectChapter:indexPath.row page:0];
        }
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
