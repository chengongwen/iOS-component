//
//  ReadPageViewController.h
//  HuotunReader
//
//  Created by chengongwen on 2017/10/31.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "BaseViewController.h"
#import "ReadModel.h"

@interface ReadPageViewController : BaseViewController

@property (nonatomic, strong) ReadModel *model;

@end
