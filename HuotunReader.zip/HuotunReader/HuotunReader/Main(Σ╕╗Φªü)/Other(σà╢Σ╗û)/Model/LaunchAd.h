//
//  LaunchAd.h
//  YueMao
//
//  Created by huotun on 2016/12/23.
//
//  广告页model

#import <Foundation/Foundation.h>

@interface LaunchAdModel : NSObject

@property (nonatomic, strong) NSString *title;  // 页面标题
@property (nonatomic, strong) NSString *content; // 详情图片url
@property (nonatomic, strong) NSString *openUrl;   // 广告链接URL
@property (nonatomic, assign) NSInteger duration;  // 广告跳过时间
@property (nonatomic, assign) NSInteger tar_type;   // 链接类型1:不可点击2：图片3：详细链接地址

@property (nonatomic, assign) NSInteger state;      // 状态：0停用1启用

@property (nonatomic, assign) NSInteger is_banner;	//	是否banner: 0否 1是
@property (nonatomic, strong) NSString *share_icon; //	分享图标地址
@property (nonatomic, strong) NSString *share_title;//  分享标题
@property (nonatomic, strong) NSString *share_content;// 分享内容
@end

@interface LaunchAd : NSObject

@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, assign) BOOL isDownloadFinish;

@property (nonatomic, strong) LaunchAdModel *launchAdModel;

+ (instancetype)shareLaunchAdManager;

// 异步获取广告资源
- (void)asyncLaunchAdMesg;

@end
