//
//  UserLoginInfo.h
//  HuotunReader
//
//  Created by huotun on 2017/10/26.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserLoginInfo : NSObject

@property (nonatomic, assign) OperationType operation;          /** 操作类型：绑定、分享、登录 */
@property (nonatomic, assign) LoginPlatform platform;           /**第三方平台*/

@property (nonatomic, strong) NSString *token;                  /**第三方token*/
@property (nonatomic, strong) NSString *platformAccount;        /**第三方平台唯一标示*/
@property (nonatomic, strong) NSString *nickName;               /**第三方昵称*/
@property (nonatomic, strong) NSString *headimgurl;             /**第三方头像*/
@property (nonatomic, assign) int sex;                          /**第三方性别*/
@property (nonatomic, strong) NSString *birthday;   // 出生日期YYYYMMDD
@property (nonatomic, strong) NSString *location_1; // 所在地 省
@property (nonatomic, strong) NSString *location_2; // 所在地 地级市

+ (instancetype)sharedObject;

@end
