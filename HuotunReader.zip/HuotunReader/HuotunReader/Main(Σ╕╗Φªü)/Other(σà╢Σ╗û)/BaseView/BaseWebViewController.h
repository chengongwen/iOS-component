//
//  BaseWebViewController.h
//  HuotunReader
//
//  Created by huotun on 2017/11/23.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "BaseViewController.h"

@interface BaseWebViewController : BaseViewController

/**
 *  origin url
 */
@property (nonatomic)NSURL* url;

/**
 *  embed webView
 */
@property (nonatomic)UIWebView* webView;

/**
 *  tint color of progress view
 */
@property (nonatomic)UIColor* progressViewColor;

/**
 *  get instance with url
 *
 *  @param url url
 *
 *  @return instance
 */
- (instancetype)initWithUrl:(NSString*)url;

- (void)reloadWebView;


@end
