//
//  NextTableViewCell.h
//  ViewControllerTransition
//
//  Created by 陈旺 on 2017/7/8.
//  Copyright © 2017年 chavez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NextTableViewCell : UITableViewCell

@property (nonatomic,copy)NSString *imageName;
@property (nonatomic,copy)NSString *title;


@end
