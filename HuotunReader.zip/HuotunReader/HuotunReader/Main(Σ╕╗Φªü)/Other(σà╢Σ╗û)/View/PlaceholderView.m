//
//  PlaceholderView.m
//  HuotunReader
//
//  Created by chengongwen on 2017/11/24.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "PlaceholderView.h"

@interface PlaceholderView ()

@property(nonatomic, strong) UIImageView *placeholderImageView;
@property(nonatomic, strong) UILabel *titleLabel;

@end

@implementation PlaceholderView

- (instancetype)initWithFrame:(CGRect)frame type:(PlaceholderType)type {
    self = [super initWithFrame:frame];
    if (self) {
        
        NSString *placeholderName = placeholderName = @"placeholder_network";
        NSString *title = NSLocalizedString(@"好像找不到网路了~", @"好像找不到网路了~");
        
        switch (type) {
            case PlaceholderNetwork:
                break;
            
            case PlaceholderRecord:
                placeholderName = @"placeholder_record";
                title = NSLocalizedString(@"暂无记录哦~", @"暂无记录哦~");
                break;
            
            case PlaceholderCollect:
                placeholderName = @"placeholder_collect";
                title = NSLocalizedString(@"暂无收藏哦~", @"暂无收藏哦~");
                break;
            
            case PlaceholderComment:
                placeholderName = @"placeholder_comment";
                title = NSLocalizedString(@"暂无评论哦~", @"暂无评论哦~");
                break;
            default:
                break;
        }
        self.placeholderImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:placeholderName]];
        [self addSubview:self.placeholderImageView];
        
        self.titleLabel = [UILabel labelWithTextColor:kRGBColor_16BAND(0x999999) fontSize:kDESGIN_TRANSFORM_iPhone6(18)];
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        self.titleLabel.text = title;
        self.titleLabel.numberOfLines = 0;
        [self addSubview:self.titleLabel];
        
        [self.placeholderImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(self);
            make.top.equalTo(@kScaleFrom_iPhone6_Desgin_Y(100));
            make.width.height.equalTo(@kDESGIN_TRANSFORM_iPhone6(325*0.5));
        }];
    
        [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.placeholderImageView.mas_bottom).offset(kScaleFrom_iPhone6_Desgin_Y(20));
            make.centerX.equalTo(self.placeholderImageView);
            make.width.equalTo(@(kScreenHeight - kDESGIN_TRANSFORM_iPhone6(20)));
        }];
        
    }
    return self;
}

- (void)setTitleStr:(NSString *)title {
    self.titleLabel.text = title;
}


@end
