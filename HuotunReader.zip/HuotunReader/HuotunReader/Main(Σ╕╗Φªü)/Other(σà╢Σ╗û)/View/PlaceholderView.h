//
//  PlaceholderView.h
//  HuotunReader
//
//  Created by chengongwen on 2017/11/24.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum : NSUInteger {
    PlaceholderNetwork,     // 无网络
    PlaceholderRecord,      // 无记录
    PlaceholderCollect,     // 无收藏
    PlaceholderComment      // 无评论
} PlaceholderType;

@interface PlaceholderView : UIView


/**
 空视图

 @param frame 坐标
 @param type PlaceholderType
 @return 初始化
 */
- (instancetype)initWithFrame:(CGRect)frame type:(PlaceholderType)type;

// 提示的内容
@property (nonatomic, strong) NSString *titleStr;

@end
