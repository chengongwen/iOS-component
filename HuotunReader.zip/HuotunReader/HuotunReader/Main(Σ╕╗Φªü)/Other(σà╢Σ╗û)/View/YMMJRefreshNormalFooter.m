//
//  YMMJRefreshNormalFooter.m
//  HuotunReader
//
//  Created by chengongwen on 2017/11/24.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "YMMJRefreshNormalFooter.h"

@implementation YMMJRefreshNormalFooter

// 重写开始刷新
- (void)beginRefreshing {
    [super beginRefreshing];
    if ([self.scrollView isKindOfClass:[UICollectionView class]] || [self.scrollView isKindOfClass:[UIScrollView class]] || [self.scrollView isKindOfClass:[UITableView class]]) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [super endRefreshing];
        });
    } else {
        [super endRefreshing];
    }
}


- (void)setState:(MJRefreshState)state {
    MJRefreshCheckState;
    
    NSString *const MJRefreshBackFooterIdleText = NSLocalizedString(@"上拉可以加载更多", @"上拉可以加载更多");
    NSString *const MJRefreshBackFooterPullingText = NSLocalizedString(@"松开立即加载更多", @"松开立即加载更多");
    NSString *const MJRefreshBackFooterRefreshingText = NSLocalizedString(@"正在加载更多的数据...", @"正在加载更多的数据...");
    NSString *const MJRefreshBackFooterNoMoreDataText = NSLocalizedString(@"已经全部加载完毕", @"已经全部加载完毕");
    
    switch (state) {
        case MJRefreshStateIdle:
            self.stateLabel.text =  MJRefreshBackFooterIdleText;
            break;
        case MJRefreshStatePulling:
            self.stateLabel.text = MJRefreshBackFooterPullingText;
            break;
        case MJRefreshStateRefreshing:
            self.stateLabel.text = MJRefreshBackFooterRefreshingText;
            break;
        case MJRefreshStateNoMoreData:
            self.stateLabel.text = MJRefreshBackFooterNoMoreDataText;
            break;
        default:
            break;
    }
    
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/


@end
