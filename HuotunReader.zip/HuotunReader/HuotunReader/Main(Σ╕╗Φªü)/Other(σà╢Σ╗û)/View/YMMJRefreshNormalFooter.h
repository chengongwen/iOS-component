//
//  YMMJRefreshNormalFooter.h
//  HuotunReader
//
//  Created by chengongwen on 2017/11/24.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <MJRefresh/MJRefresh.h>

@interface YMMJRefreshNormalFooter : MJRefreshBackNormalFooter

@end
