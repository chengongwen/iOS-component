//
//  ReadView.h
//  HuotunReader
//
//  Created by chengongwen on 2017/10/31.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BookIconView : UIView

@property (nonatomic, copy) NSString *catalogueId;
@property (nonatomic, copy) NSString *title;      // 图书标题
@property (nonatomic, copy) NSString *displayName;// 图书显示名称
@property (nonatomic, copy) NSString *thumbImageURL;   // 图书的封面

@end
