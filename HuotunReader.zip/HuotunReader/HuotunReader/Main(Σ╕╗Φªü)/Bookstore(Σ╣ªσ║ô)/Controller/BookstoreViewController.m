//
//  BookstoreViewController.m
//  HuotunReader
//
//  Created by huotun on 2017/10/23.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "BookstoreViewController.h"

@interface BookstoreViewController ()

@end

@implementation BookstoreViewController

- (instancetype)init {
    self = [super init];
    if (self) {
        self.url = [NSURL URLWithString:@"http://www.ireader.com/"];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"书库";
    
    [self.webView loadRequest:[NSURLRequest requestWithURL:self.url]];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
