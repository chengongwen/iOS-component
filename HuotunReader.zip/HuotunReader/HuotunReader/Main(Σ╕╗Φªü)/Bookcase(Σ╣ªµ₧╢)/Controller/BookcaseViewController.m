//
//  BookcaseViewController.m
//  HuotunReader
//
//  Created by huotun on 2017/11/24.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "BookcaseViewController.h"
#import "ReadPageViewController.h"
#import "ReadScrollViewController.h"
#import "ReadModel.h"
#import "CatalogueObject.h"
#import "DatabaseManager.h"
#import "PlaceholderView.h"
#import "BookcaseTableViewCell.h"
#import "BaseWebViewController.h"

@interface BookcaseViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) PlaceholderView *placeholderView;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, assign) BOOL isPullUp;
@property (nonatomic, strong) NSMutableArray *bookcaseDataList;
@end

@implementation BookcaseViewController

static NSString *bookcaseTableViewCellId = @"bookcaseTableViewCellId";


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.navigationItem.title = @"书架";
    
    UIButton * editButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [editButton setTitleColor:kRGBColor_16BAND(0x666666) forState:UIControlStateNormal];
    [editButton setTitle:@"编辑" forState:UIControlStateNormal];
    [editButton.titleLabel setFont:[UIFont systemFontOfSize:kDESGIN_TRANSFORM_iPhone6(20)]];
    [editButton addTarget:self action:@selector(editButtonClicked) forControlEvents:UIControlEventTouchUpInside];
    [editButton sizeToFit];
    UIBarButtonItem * rightBarButton = [[UIBarButtonItem alloc] initWithCustomView:editButton];
    self.navigationItem.rightBarButtonItem = rightBarButton;

    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.backgroundColor = [UIColor whiteColor];
    self.tableView.tableHeaderView = [[UIView alloc] init];
    self.tableView.tableFooterView = [[UIView alloc] init];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
//    self.tableView.contentInset = UIEdgeInsetsMake(0, 0, 64 + 44 + 44 + 10, 0);
    self.tableView.alwaysBounceVertical = YES;
    [self.tableView registerClass:[BookcaseTableViewCell class] forCellReuseIdentifier:bookcaseTableViewCellId];
    [self.view addSubview:self.tableView];
    
    self.bookcaseDataList = [[NSMutableArray alloc] init];
    
    // 添加下拉刷新控件
    [self addpullRefresh];
    
    /**
     *  集成上拉刷新控件
     */
    [self addfooterRefresh];
    
    self.placeholderView = [[PlaceholderView alloc] initWithFrame:self.view.bounds type:PlaceholderRecord];
    self.placeholderView.hidden = YES;
    [self.tableView addSubview:self.placeholderView];
    
    for (int i = 0; i< 10; i++) {
        CatalogueObject *catalogueObject = [[CatalogueObject alloc] init];
        catalogueObject.catalogueId = @"book1";
        catalogueObject.author = @"作者--路遥";
        catalogueObject.account = @"huotun";
        catalogueObject.title = @"书名--平凡的世界";
        catalogueObject.currentProgress =  i*1.0 / 11.0 *100;
        catalogueObject.thumbImageURL = @"http://bookbk.img.ireader.com/group6/M00/D7/C9/CmQUN1jdPgaEJaL8AAAAAERhiWg148316621.jpg";
        [self.bookcaseDataList addObject:catalogueObject];
    }
    [self.tableView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - init  初始化
//下拉刷新
- (void)addpullRefresh {
    __weak __typeof(self) weakSelf = self;
    self.tableView.mj_header = [YMMJRefreshGifHeader headerWithRefreshingBlock:^{
        weakSelf.isPullUp = NO;
        //[weakSelf postNotificationWithPage:1];
    }];
}

//停止下拉刷新
- (void)stopHeaderRefresh{
    [self.tableView.mj_header endRefreshing];
}

//上拉刷新
- (void)addfooterRefresh {
    __weak __typeof(self) weakSelf = self;
    self.tableView.mj_footer = [YMMJRefreshNormalFooter footerWithRefreshingBlock:^{
        weakSelf.isPullUp = YES;
        //[weakSelf postNotificationWithPage:(int)weakSelf.page];
    }];
}

//停止上拉刷新
- (void)stopfootRefresh{
    [self.tableView.mj_footer endRefreshing];
}

- (void)editButtonClicked {
    self.tableView.editing = !self.tableView.editing;
    
    UIButton *rigthButton = self.navigationItem.rightBarButtonItem.customView;
    if (self.tableView.editing) {
        [rigthButton setTitle:@"完成" forState:UIControlStateNormal];
    }
    else {
        [rigthButton setTitle:@"编辑" forState:UIControlStateNormal];
    }
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.bookcaseDataList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"bookcaseCellId";
    id cell = nil;
    if(cell == nil){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    if (indexPath.row >= self.bookcaseDataList.count) {
        return cell;
    }
    
    id bookModel = self.bookcaseDataList[indexPath.row];
    if ([bookModel isKindOfClass:[CatalogueObject class]]) {
        cell = (BookcaseTableViewCell *)[tableView dequeueReusableCellWithIdentifier:bookcaseTableViewCellId];
        [cell refreshCellWithObject:bookModel];
    }
    
    UIView *bgColorView = [[UIView alloc] init];
    bgColorView.backgroundColor = kRGBColor_16BAND(0xe5e5e5);
    [cell setSelectedBackgroundView:bgColorView];
    
    return cell;
}

#pragma mark - UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return kDESGIN_TRANSFORM_iPhone6(111.5);
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}

/**
 *  修改Delete按钮文字为“删除”
 */
- (NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath {
    return @"删除";
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewCellEditingStyleDelete;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        [self.bookcaseDataList removeObjectAtIndex:indexPath.row];
        [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        [self.tableView reloadData];
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    /**
     *  跳转到详细个人页面
     */
    if (indexPath.row >= self.bookcaseDataList.count) {
        return ;
    }
    CatalogueObject *bookModel = self.bookcaseDataList[indexPath.row];
    
    ReadScrollViewController *pageView = [[ReadScrollViewController alloc] init];
    pageView.bookModel = bookModel;
    [self.navigationController pushViewController:pageView animated:YES];
    
//    [MBProgressHUD showMessageWindow:@"正在加载..."];
//    dispatch_async(dispatch_get_global_queue(0, 0), ^{
//
//        // 初始化缓存数据
//        pageView.model = [[ReadModel alloc] initWithCatalogue:bookModel];
//
//        dispatch_async(dispatch_get_main_queue(), ^{
//
//            [MBProgressHUD hideHUDWindow];
//
//            [self.navigationController pushViewController:pageView animated:YES];
//        });
//    });
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
