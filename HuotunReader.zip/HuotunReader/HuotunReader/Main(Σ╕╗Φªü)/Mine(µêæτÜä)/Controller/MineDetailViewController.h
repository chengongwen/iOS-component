//
//  MineDetailViewController.h
//  HuotunReader
//
//  Created by huotun on 2017/10/24.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "BaseViewController.h"

@interface MineDetailViewController : BaseViewController

@end
