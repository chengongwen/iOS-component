//
//  MBProgressHUD+MJ.h
//
//  Created by mj on 13-4-18.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#import "MBProgressHUD.h"

#define kHUDMissAnimationTime 2.0f
#define kHUDFadeAnimationTime 0.8f       // HUD动画消失时间
#define kLoginHUDFadeAnimationTime 10.0f // HUD动画消失时间

@interface MBProgressHUD (MJ)
+ (void)showSuccess:(NSString *)success toView:(UIView *)view;
+ (void)showError:(NSString *)error toView:(UIView *)view;

+ (void)showSuccess:(NSString *)success;
+ (void)showError:(NSString *)error;

/**
 永远显示在第一次层（window）
 
 @param title title
 */
+ (void)showMessageWindow:(NSString *)title;

+ (MBProgressHUD *)showMessage:(NSString *)message;
+ (MBProgressHUD *)showMessage:(NSString *)message toView:(UIView *)view;

+ (void)hideHUDForView:(UIView *)view;
+ (void)hideHUD;
+ (void)hideHUDWindow;

// 只有文字,会回收
+ (void)showInfo:(NSString *)info;


/**
 显示提示 MBProgressHUD(默认3s)自动消失（title，message其一可为空）
 */
+ (void)showTipsWindow:(NSString *)title;
+ (void)showTipsWithTitle:(NSString *)title message:(NSString *)message;
+ (void)showTipsWithTitle:(NSString *)title message:(NSString *)message toView:(UIView *)view;
+ (void)showMessageWithTitle:(NSString *)title message:(NSString *)message toView:(UIView *)view afterDelay:(float)afterDelay;

@end
