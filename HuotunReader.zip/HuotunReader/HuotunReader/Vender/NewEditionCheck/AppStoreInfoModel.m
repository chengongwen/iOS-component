//
//  AppStoreInfoModel.m
//  safeepay-ios-new
//
//  Created by san_xu on 2017/3/30.
//  Copyright © 2017年 com.app.huakala. All rights reserved.
//

#import "AppStoreInfoModel.h"

@implementation AppStoreInfoModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key{}

@end
