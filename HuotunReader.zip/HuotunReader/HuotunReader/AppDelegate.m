//
//  AppDelegate.m
//  HuotunReader
//
//  Created by chengongwen on 2017/10/23.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "AppDelegate.h"
#import "MainTabViewController.h"
#import "DatabaseManager.h"
#import "LaunchAd.h"
#import "ChapterObject.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    
    self.account = @"huotun";
    
    MainTabViewController *tabBarCtrl = [[MainTabViewController alloc] init];
    self.tabBarCtrl = tabBarCtrl;
    
    /*
    NSURL *fileURL = [[NSBundle mainBundle] URLForResource:@"埋点协议" withExtension:@"txt"];
    NSData *data = [NSData dataWithContentsOfURL:fileURL];
    ChapterObject *chapterObject = [[ChapterObject alloc] init];
    chapterObject.catalogueId = @"book1";
    chapterObject.chapterNum = 0;
    chapterObject.title = @"埋点协议";
    [[DatabaseManager shareInstance] insertChapterDB:chapterObject data:data];
    
    for (int i = 1; i <= 99; i++ ) {
        int randowIndex = i %3;
        if ( randowIndex == 0) {
            NSURL *fileURL = [[NSBundle mainBundle] URLForResource:@"login" withExtension:@"txt"];
            NSData *data = [NSData dataWithContentsOfURL:fileURL];
            ChapterObject *chapterObject = [[ChapterObject alloc] init];
            chapterObject.catalogueId = @"book1";
            chapterObject.chapterNum = i;
            chapterObject.title = [NSString stringWithFormat:@"%i login_登录协议",i];
            [[DatabaseManager shareInstance] insertChapterDB:chapterObject data:data];
        }
        else if (randowIndex == 1) {
            NSURL *fileURL = [[NSBundle mainBundle] URLForResource:@"user_info" withExtension:@"txt"];
            NSData *data = [NSData dataWithContentsOfURL:fileURL];
            ChapterObject *chapterObject = [[ChapterObject alloc] init];
            chapterObject.catalogueId = @"book1";
            chapterObject.chapterNum = i;
            chapterObject.title = [NSString stringWithFormat:@"%i user_info_个人信息协议",i];
            [[DatabaseManager shareInstance] insertChapterDB:chapterObject data:data];
        }
        else {
            NSURL *fileURL = [[NSBundle mainBundle] URLForResource:@"social" withExtension:@"txt"];
            NSData *data = [NSData dataWithContentsOfURL:fileURL];
            ChapterObject *chapterObject = [[ChapterObject alloc] init];
            chapterObject.catalogueId = @"book1";
            chapterObject.chapterNum = i;
            chapterObject.title = [NSString stringWithFormat:@"%i social_设计相关协议",i];
            [[DatabaseManager shareInstance] insertChapterDB:chapterObject data:data];
        }
    }
    
    // 空数据
    ChapterObject *chapterObjectOther = [[ChapterObject alloc] init];
    chapterObjectOther.catalogueId = @"book1";
    chapterObjectOther.chapterNum = 100;
    chapterObjectOther.title = @"other";
    [[DatabaseManager shareInstance] insertChapterDB:chapterObjectOther data:nil];
    */
    
    // 加载广告
    //[[LaunchAd shareLaunchAdManager] asyncLaunchAdMesg];
    
    self.window.rootViewController = tabBarCtrl;
    [self.window makeKeyAndVisible];
    
    return YES;
}

#pragma mark - Static
+ (AppDelegate *)shareAppDelegate {
    return (AppDelegate *)([UIApplication sharedApplication].delegate);
}

- (void)officialServer {
    self.apiURL = @"http://api.i.1miaobang.com/api";
    self.wwwURL = @"http://www.i.1miaobang.com";
    self.imgURL = @"http://img.i.1miaobang.com";
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
