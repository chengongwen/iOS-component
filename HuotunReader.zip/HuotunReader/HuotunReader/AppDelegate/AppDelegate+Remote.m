//
//  YMAppDelegate+Remote.m
//  YueMao
//
//  Created by huotun on 2017/3/27.
//
//

#import <Foundation/Foundation.h>
#import "AppDelegate+Remote.h"
#import "ADeanMethodSwizzling.h"

#import <TencentOpenAPI/TencentOAuth.h>
#import "WXApi.h"
#import "WeiboSDK.h"

#import "YMUmengTrack.h"
#import "UMessage.h"

@implementation AppDelegate (Remote)

+ (void)load {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [self adean_AppDelegateHook];
    });
}

+ (void)adean_AppDelegateHook {
    SwizzlingMethod([AppDelegate class], @selector(application:didFinishLaunchingWithOptions:), @selector(adean_application:didFinishLaunchingWithOptions:));
    
//    SwizzlingMethod([YMAppDelegate class], @selector(application:didRegisterForRemoteNotificationsWithDeviceToken:), @selector(adean_application:didRegisterForRemoteNotificationsWithDeviceToken:));
//    SwizzlingMethod([YMAppDelegate class], @selector(application:didFailToRegisterForRemoteNotificationsWithError:), @selector(adean_application:didFailToRegisterForRemoteNotificationsWithError:));
//    
//    SwizzlingMethod([YMAppDelegate class], @selector(application:didReceiveRemoteNotification:fetchCompletionHandler:), @selector(adean_application:didReceiveRemoteNotification:fetchCompletionHandler:));
//    SwizzlingMethod([YMAppDelegate class], @selector(userNotificationCenter:willPresentNotification:fetchCompletionHandler:withCompletionHandler:), @selector(adean_userNotificationCenter:willPresentNotification:fetchCompletionHandler:withCompletionHandler:));
//    
//    SwizzlingMethod([YMAppDelegate class], @selector(userNotificationCenter:didReceiveNotificationResponse:fetchCompletionHandler:withCompletionHandler:), @selector(adean_userNotificationCenter:didReceiveNotificationResponse:fetchCompletionHandler:withCompletionHandler:));
}

- (BOOL)adean_application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        // 注册推送
        //[self requestDeviceToken:launchOptions];
    });
    
    // 注册推送
    [self requestDeviceToken:launchOptions];
    
    // UMSocial导致主线程卡顿，只能延迟执行
    [self performSelector:@selector(initSdk) withObject:self afterDelay:4.0f];
    
    return [self adean_application:application didFinishLaunchingWithOptions:launchOptions];
}

// 注册推送
- (void)requestDeviceToken:(NSDictionary *)launchOptions {
#pragma mark - 远程推送
    // 推送通知，如果是没有登录的状态启动应用
    // hy:首次启动，设置推送消息的角标为0
    [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
    
    // 注册接收通知的类型
    UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeAlert | UIUserNotificationTypeBadge | UIUserNotificationTypeSound categories:nil];
    [[UIApplication sharedApplication] registerUserNotificationSettings:settings];
    
    // 注册允许接收远程推送通知
    // 自动获取当前设备的UUID，以及App Bundle ID，像苹果服务器发送请求，获取DeviceToken
    // IOS8开始用，IOS7之前就不兼容不能用
    [[UIApplication sharedApplication] registerForRemoteNotifications];
    
    if (kIOSSystemVersion >= 10.0) {
        
        //iOS10必须加下面这段代码。
        UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
        center.delegate = self;
        UNAuthorizationOptions types10 = UNAuthorizationOptionBadge|UNAuthorizationOptionAlert|UNAuthorizationOptionSound;
        [center requestAuthorizationWithOptions:types10 completionHandler:^(BOOL granted, NSError * _Nullable error) {
            
            if (granted) {
                //点击允许
            }
            else {
                //点击不允许
            }
        }];
    }
    
    // 友盟推送
    //设置 AppKey 及 LaunchOptions
    [UMessage startWithAppkey:UMENG_KEY launchOptions:launchOptions];
    
    // 注册通知
    [UMessage registerForRemoteNotifications];
    
    // for log
#ifdef DEBUG
    [UMessage setLogEnabled:YES];
#endif
}

- (void)initSdk {
    // 异步注册友盟统计
    [[YMUmengTrack sharedManager] initUmengTrack];
    
    self.tencentOAuth = [[TencentOAuth alloc] initWithAppId:kQQConnectAppKey andDelegate:[QQApiManager sharedManager]];
    [WXApi registerApp:kWechatAppKey];
    [WeiboSDK registerApp:kSinaAppKey];
}

// 当得到苹果的APNs服务器返回的DeviceToken就会被调用
- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    DLog(@"远程推送deviceToken是：%@", deviceToken);
    
    NSString* deviceTokenStr = [NSString stringWithFormat:@"%@",deviceToken];
    // 去掉左右两边的", @",deviceToken];
    // 去掉左右两边的")<"">"
    deviceTokenStr = [deviceTokenStr substringWithRange:NSMakeRange(1, 71)];
    // 去掉空格
    deviceTokenStr = [deviceTokenStr stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    NSString *oldTokenStr = [[NSUserDefaults standardUserDefaults]objectForKey:YMApplePushTokenKey];
    if (![oldTokenStr isEqualToString:deviceTokenStr]) {
        [[NSUserDefaults standardUserDefaults] setObject:deviceTokenStr forKey:YMApplePushTokenKey];
    }
    DLog(@"远程推送deviceTokenStr从本地中取出是：%@",[[NSUserDefaults standardUserDefaults]objectForKey:YMApplePushTokenKey]);
}


// 获取device token失败后
- (void)application:(UIApplication*)application didFailToRegisterForRemoteNotificationsWithError:(NSError*)error {
    DLog(@"获取token失败，Failed to get token, error: %@", error);
}

#pragma mark - 系统消息通知的方法调用
/**
 UIApplicationStateActive,正在运行中
 UIApplicationStateInactive,
 UIApplicationStateBackground在后台运行中
 */
// 接收到远程推送的消息时调用此方法（前、后、退出都可用，iOS7以后可用）
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler {
    DLog(@"iOS收到远程通知:%@", userInfo);
    
    // 关闭友盟自带的弹出框
    [UMessage setAutoAlert:NO];
    
    [UMessage didReceiveRemoteNotification:userInfo];
    
    application.applicationIconBadgeNumber = 0;
    
    // 不调用该block会报错
    completionHandler(UIBackgroundFetchResultNewData);
    
    // 处理消息通知
    // 1:参与 2:中奖 3:关注开播 4:后台推送 5:红包推送 6:秒榜圈推送 7:屏蔽推送
    //NSInteger apsType = [userInfo[@"type"] integerValue];
    
    if (application.applicationState == UIApplicationStateInactive) {
        //opened from a push notification when the app was on background
        
        // 处理后台点击通知
        [self handleAPSEnterBackground:userInfo];
    }
    else if(application.applicationState == UIApplicationStateActive) {
        // a push notification when the app is running. So that you can display an alert and push in any view
        // 在应用内的推送通知
    }
}

// iOS10新增：处理前台收到通知的代理方法
- (void)userNotificationCenter:(UNUserNotificationCenter *)center willPresentNotification:(UNNotification *)notification withCompletionHandler:(void (^)(UNNotificationPresentationOptions))completionHandler {
    NSDictionary * userInfo = notification.request.content.userInfo;
    DLog(@"iOS10 收到远程通知:%@", userInfo);
    
    // 在应用内的推送通知
    if([notification.request.trigger isKindOfClass:[UNPushNotificationTrigger class]]) {
        
        // 关闭友盟自带的弹出框
        [UMessage setAutoAlert:NO];
        
        // 应用处于前台时的远程推送接受
        // 必须加这句代码
        [UMessage didReceiveRemoteNotification:userInfo];
    }
    else {
        // 应用处于前台时的本地推送接受
    }
}

// iOS10新增：处理后台点击通知的代理方法
- (void)userNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(UNNotificationResponse *)response withCompletionHandler:(void (^)())completionHandler {
    NSDictionary * userInfo = response.notification.request.content.userInfo;
    DLog(@"iOS10 收到远程通知:%@", userInfo);
    
    if([response.notification.request.trigger isKindOfClass:[UNPushNotificationTrigger class]]) {
        
        // 关闭友盟自带的弹出框
        [UMessage setAutoAlert:NO];
        
        //应用处于后台时的远程推送接受
        //必须加这句代码
        [UMessage didReceiveRemoteNotification:userInfo];
        
        // 处理后台点击通知
        [self handleAPSEnterBackground:userInfo];
    }
    else {
        // 应用处于后台时的本地推送接受
    }
}

// aps转换为NSDictionary
- (NSDictionary *)handleAPSInfo:(NSDictionary *)userInfo {
    NSDictionary *dictionary = nil;
    NSString *jsonStr = userInfo[@"jsonStr"];
    if (jsonStr) {
        @try {
            NSData *jsonData = [jsonStr dataUsingEncoding:NSUTF8StringEncoding];
            NSError *err;
            NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                                                                options:NSJSONReadingMutableContainers
                                                                  error:&err];
            dictionary = dic[@"jsonStr"];
            
        } @catch (NSException *exception) {
            
            DLog(@"Caught %@,%@", [exception name], [exception reason]);
        } @finally {
            //
        }
        
        DLog(@"dictionary = %@",dictionary);
    }
    return dictionary;
}


// 处理后台点击通知
- (void)handleAPSEnterBackground:(NSDictionary *)userInfo {
    // 处理消息通知
    //NSInteger apsType = [userInfo[@"type"] integerValue];
    
    // 1:参与 2:中奖 3:关注开播 4:后台推送 5:红包推送 6:秒榜圈推送 7:屏蔽推送
}

#pragma mark - 第三方 URL 调用
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation{
    DLog(@"openURL %@", url);
    
    BOOL result = YES;
    // 其他如支付等SDK的回调
    if ([url.scheme hasPrefix:@"wx"] ) {
        return [WXApi handleOpenURL:url delegate:[WXApiManager sharedManager]];
    }
    else if ([url.scheme hasPrefix:@"tencent"] || [url.scheme hasPrefix:@"QQ"]) {
        [QQApiInterface handleOpenURL:url delegate:[QQApiManager sharedManager]];
        return [TencentOAuth HandleOpenURL:url];
    }
    else if ([url.scheme hasPrefix:@"wb"] || [url.scheme hasPrefix:@"sinaweibosso."]) {
        return [WeiboSDK handleOpenURL:url delegate:[WBApiManager sharedManager]];
    }
    return result;
}

- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url{
    DLog(@"handleOpenURL %@", url);
    BOOL result = YES;

    // 其他如支付等SDK的回调
    if ([url.scheme hasPrefix:@"wx"]) {
        return [WXApi handleOpenURL:url delegate:[WXApiManager sharedManager]];
    }
    else if ([url.scheme hasPrefix:@"tencent"] || [url.scheme hasPrefix:@"QQ"]) {
        
        [QQApiInterface handleOpenURL:url delegate:[QQApiManager sharedManager]];
        return [TencentOAuth HandleOpenURL:url];
    }
    else if ([url.scheme hasPrefix:@"wb"] || [url.scheme hasPrefix:@"sinaweibosso."]) {
        return [WeiboSDK handleOpenURL:url delegate:[WBApiManager sharedManager]];
    }
    return result;
}

@end
