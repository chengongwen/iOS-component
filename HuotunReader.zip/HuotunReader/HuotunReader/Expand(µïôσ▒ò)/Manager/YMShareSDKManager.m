//
//  YMShareSDKManager.m
//  HuotunReader
//
//  Created by chengongwen on 2017/10/23.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "YMShareSDKManager.h"
#import "WBApiManager.h"
#import "WXApiManager.h"
#import "QQApiManager.h"
#import "MJExtension.h"
#import "NSString+MD5.h"
#import "NetWorkTool.h"
#import "UserLoginInfo.h"

static NSString *kAuthScope = @"snsapi_message,snsapi_userinfo,snsapi_friend,snsapi_contact";
static NSString *kAuthOpenID = @"";
static NSString *kAuthState = @"xxx";

@interface YMShareSDKManager()

@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, assign) YMShareSDKSenceType currentShareSenceType;
@property (nonatomic, assign) BOOL isFinishDownload;
@end

@implementation YMShareSDKManager
@synthesize shareSenceType;

+ (instancetype)shareSDKManager {
    static YMShareSDKManager *instance = nil;
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        instance = [[YMShareSDKManager alloc] init];
        instance.isFinishDownload = NO;
        
        // 默认获取保存的信息缓存配置
        [instance reloadShareMegsData];
    });
    return instance;
}

#pragma mark -
#pragma mark - 定时器轮循获取礼物
/**
 异步获取分享信息
 */
- (void)asynDownloadShareMessage {
    [self performSelector:@selector(startTimer) withObject:self afterDelay:5.0f];
}

- (void)startTimer {
    if (!_timer) {
        _timer = [NSTimer scheduledTimerWithTimeInterval:20.0f target:self selector:@selector(asynDownload) userInfo:nil repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];
    }
    [_timer fire];
}

- (void)stop {
    if (_timer) {
        [_timer invalidate];
        _timer = nil;
    }
}

- (void)asynDownload {
    if (self.isFinishDownload) {
        [self stop];
    }
    else {
        if ([NetWorkTool isNetworkEnable]) {
            // 没有列表到本地
            [self asyncDownloadMessages];
        }
    }
}

- (void)asyncDownloadMessages {
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    NSNumber *timeStamp = [NSNumber numberWithLongLong:[[NSDate date] timeIntervalSince1970]];
    NSString *md5 = [NSString md5HexDigest:[NSString stringWithFormat:@"%@%@",IMAGE_SCREAT_KEY,timeStamp]];
    NSDictionary *params = @{
                             @"timestamp":timeStamp,
                             @"md5":md5
                             };
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:params options:NSJSONWritingPrettyPrinted error:nil];
    NSString *param = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    
    NSString *detailURL = KShareMegsURL([AppDelegate shareAppDelegate].apiURL);
    
    [manager POST:detailURL parameters:@{@"param":param} progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {

        NSString *result = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
        NSData *jsonData = [result dataUsingEncoding:NSUTF8StringEncoding];
        NSError *err;
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:jsonData
                                                             options:NSJSONReadingMutableContainers
                                                               error:&err];
        if ([[dict objectForKey:@"code"] intValue] >= 0){
            
            self.isFinishDownload = YES;
            
            /*
            // 分享标题
            NSDictionary *megsDic = [dict objectForKey:@"shareContent"];
            NSArray * messageList = [YMShareSDKMessage mj_objectArrayWithKeyValuesArray:megsDic];
            
            if (messageList.count) {
                [self saveShareMegsData:messageList];
            }*/
        }
        else {
            // 如果请求失败
            DLog(@"请求失败");
            self.isFinishDownload = NO;
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        // 数据报错
        DLog(@"请求失败");
        self.isFinishDownload = NO;
    }];
}

// 默认获取保存的信息
- (void)reloadShareMegsData {
    NSString *homePath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];    //获取应用Document目录路径
    NSString *fileName = [NSString stringWithFormat:@"shareMegsLists.txt"];
    NSString *filePathName = [homePath stringByAppendingPathComponent:fileName];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL isFileExist = [fileManager fileExistsAtPath:filePathName];
    if(!isFileExist) {
        [fileManager createFileAtPath:filePathName contents:nil attributes:nil];
    }
    // 获取文件
    NSArray *list = [NSKeyedUnarchiver unarchiveObjectWithFile:filePathName];
    if (list.count) {
        self.messageList = [NSArray arrayWithArray:list];
    }
}
// 保存的信息
- (void)saveShareMegsData:(NSArray *)messageList {
    
    self.messageList = [NSArray arrayWithArray:messageList];
    
    NSString *homePath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];    //获取应用Document目录路径
    NSString *fileName = [NSString stringWithFormat:@"shareMegsLists.txt"];
    NSString *filePathName = [homePath stringByAppendingPathComponent:fileName];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL isFileExist = [fileManager fileExistsAtPath:filePathName];
    if(!isFileExist) {
        [fileManager createFileAtPath:filePathName contents:nil attributes:nil];
    }
    
    // 写进文件
    isFileExist = [NSKeyedArchiver archiveRootObject:messageList toFile:filePathName];
    if (isFileExist) {
        DLog(@"写进分享文件成功");
    }
    else {
        DLog(@"写进分享文件失败");
    }
}

#pragma mark -
#pragma mark - login
- (void)loginWithSenceType:(YMShareSDKSenceType)senceTpye viewController:(UIViewController*)viewController {
    switch (senceTpye) {
        case YMShareSDKSenceQQ: {
            [UserLoginInfo sharedObject].platform = LoginPlatformQQ;
            NSArray* permissions = [NSArray arrayWithObjects:
                                    kOPEN_PERMISSION_GET_USER_INFO,
                                    kOPEN_PERMISSION_GET_SIMPLE_USER_INFO,
                                    kOPEN_PERMISSION_GET_INFO,
                                    kOPEN_PERMISSION_GET_OTHER_INFO,
                                    kOPEN_PERMISSION_GET_VIP_INFO,
                                    kOPEN_PERMISSION_GET_VIP_RICH_INFO,
                                    nil];
            [[[AppDelegate shareAppDelegate] tencentOAuth] authorize:permissions inSafari:NO];
            break;
        }
        case YMShareSDKSenceWXSession: {
            [UserLoginInfo sharedObject].platform = LoginPlatformWX;
            SendAuthReq* req = [[SendAuthReq alloc] init];
            req.scope = kAuthScope; // @"post_timeline,sns"
            req.state = kAuthState;
            req.openID = kAuthOpenID;
            [WXApi sendAuthReq:req viewController:viewController delegate:[WXApiManager sharedManager]];
            break;
        }
        case YMShareSDKSenceWeibo: {
            [UserLoginInfo sharedObject].platform = LoginPlatformWB;
            WBAuthorizeRequest *request = [WBAuthorizeRequest request];
            request.redirectURI = kRedirectURL;
            request.scope = @"all";
            request.userInfo = @{@"SSO_From": @"SendMessageToWeiboViewController",
                                 @"Other_Info_1": [NSNumber numberWithInt:123],
                                 @"Other_Info_2": @[@"obj1", @"obj2"],
                                 @"Other_Info_3": @{@"key1": @"obj1", @"key2": @"obj2"}};
            [WeiboSDK sendRequest:request];
            break;
        }
        default:
            break;
    }
    [UserLoginInfo sharedObject].operation = OperationTypeLogin;
}


#pragma mark -
#pragma mark - share

// 分享口令
- (void)shareWithMessage:(NSString *)message {
    switch (self.shareSenceType) {
        case YMShareSDKSenceNone:
            break;
            
        case YMShareSDKSenceWeibo:
            //微博
            //[[WBApiManager sharedManager] shareWithMessage:message];
            break;
            
        case YMShareSDKSenceQQ:
            //qq
            //[[QQApiManager sharedManager] shareWithMessage:message scene:QQSceneSession];
            break;
            
        case YMShareSDKSenceQQZone:
            //[[QQApiManager sharedManager] shareWithMessage:message scene:QQSceneTimeline];
            //qq空间
            break;
            
        case YMShareSDKSenceWXSession:
            //微信
            //[[WXApiManager sharedManager] shareWithWXMessage:message scene:WXSceneSession];
            break;
            
        case YMShareSDKSenceWXTimeline:
            //朋友圈
            //[[WXApiManager sharedManager] shareWithWXMessage:message scene:WXSceneTimeline];
            break;
            
        default:
            break;
    }
    self.currentShareSenceType = self.shareSenceType;
    self.shareSenceType = YMShareSDKSenceNone;
    
    // 设置正在分享，不断socket链接
    self.isSharing = YES;
}

// 分享成功
- (void)shareMessageSuccess {
    [MBProgressHUD showTipsWindow:NSLocalizedString(@"分享成功", @"分享成功")];
    
    // 设置正在分享，不断socket链接
    self.isSharing = NO;
    
    //  监听用户发送分享请求
    [[NSNotificationCenter defaultCenter] postNotificationName:kShareSuccessedNotification object:nil];
}

- (void)shareMessageFailure {
    // 设置正在分享，不断socket链接
    self.isSharing = NO;
    [MBProgressHUD showTipsWindow:NSLocalizedString(@"分享失败", @"分享失败")];
}

- (void)shareMessageCancel {
    // 设置正在分享，不断socket链接
    self.isSharing = NO;
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setInteger:10 forKey:@"defaultBut"];
    [userDefaults synchronize];
}

@end
