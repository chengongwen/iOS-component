//
//  YMUmengTrack.h
//  HuotunReader
//
//  Created by chengongwen on 2017/10/23.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "YMShareSDKManager.h"

@interface YMUmengTrack : NSObject

+ (instancetype)sharedManager;

@property (nonatomic, strong) NSString *UmengAppKey;

/**
 *  注册友盟统计
 */
- (void)initUmengTrack;


@end
