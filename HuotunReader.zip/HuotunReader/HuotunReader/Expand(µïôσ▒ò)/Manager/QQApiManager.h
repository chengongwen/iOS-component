//
//  QQApiManager.h
//  HuotunReader
//
//  Created by chengongwen on 2017/10/23.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <TencentOpenAPI/TencentOAuth.h>
#import <TencentOpenAPI/QQApiInterface.h>
#import "YMShareSDKManager.h"

@interface QQApiManager : NSObject<TencentSessionDelegate,QQApiInterfaceDelegate>

+ (instancetype)sharedManager;

@end
