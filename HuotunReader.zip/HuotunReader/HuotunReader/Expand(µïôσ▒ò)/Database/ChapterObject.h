//
//  ChapterObject.h
//  HuotunReader
//
//  Created by huotun on 2017/10/30.
//  Copyright © 2017年 huotunyule. All rights reserved.
//
// 一本书的目录列表和数据的整体结构
//

#import <Foundation/Foundation.h>

@interface ChapterObject : NSObject

@property (nonatomic, assign) NSUInteger resourceId;
@property (nonatomic, copy) NSString *catalogueId;
@property (nonatomic, assign) NSUInteger chapterNum; // 第几章节
@property (nonatomic, copy) NSString *title;           // 章节标题
@property (nonatomic, copy) NSString *path;            // 文件路径

@end
