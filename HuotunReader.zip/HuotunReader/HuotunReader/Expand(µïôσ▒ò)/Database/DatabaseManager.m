//
//  DatabaseManager.m
//  HuotunReader
//
//  Created by chengongwen on 2017/10/30.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "DatabaseManager.h"
#import "CatalogueObject.h"
#import "ChapterObject.h"
#import "GTMBase64.h"

#define kDatabasePath [NSMutableString stringWithFormat:@"%@/%@",kAppDocumentPath,@"database"]

static DatabaseManager *instance = nil;

@interface DatabaseManager ()

@property (strong, nonatomic) NSString *dbPath; //数据库完整路径
@end

@implementation DatabaseManager

+ (instancetype)shareInstance {
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        instance = [[DatabaseManager alloc] init];
        @synchronized(self)
        {
            instance.dbPath = [DatabaseManager appDBPath];
            [instance initializationCatalogueDB];
        }
    });
    return instance;
}

// 创建数据库文件夹目录
+ (NSString *)appDBPath {
    NSString *rootPath = kDatabasePath;
    AppDelegate *appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    NSString *dbPath = [NSMutableString stringWithFormat:@"%@/%@/db.sqlite",rootPath,appDelegate.account];
    DLog(@"数据库文件夹目录：%@",dbPath);
    
    // 如果不存在,则说明是第一次运行这个程序，那么建立这个文件夹
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if (![fileManager fileExistsAtPath:dbPath]) {
        NSString *directryPath = [rootPath stringByAppendingPathComponent:appDelegate.account];
        [fileManager createDirectoryAtPath:directryPath withIntermediateDirectories:YES attributes:nil error:nil];
        NSString *filePath = [directryPath stringByAppendingPathComponent:@"db.sqlite"];
        BOOL result = [fileManager createFileAtPath:filePath contents:nil attributes:nil];
        if (result) {
            DLog(@"数据库创建成功");
        }
        else {
            DLog(@"数据库创建失败");
        }
    }
    return dbPath;
}

#pragma mark -
#pragma mark - 书架 (创建，插入、更新、删除)

// 创建一个书架的table
- (void)initializationCatalogueDB {
    // 获得数据库
    FMDatabase *database = [FMDatabase databaseWithPath:instance.dbPath];
    BOOL result = [database open];
    if (result) {
        // 创表
        NSString *createTableSql = [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS '%@' (resourceId INTEGER PRIMARY KEY AUTOINCREMENT, '%@' TEXT,'%@' TEXT, '%@' TEXT ,'%@' TEXT ,'%@' TEXT,'%@' DOUBLE, '%@' DATETIME )",@"CatalogueDB",@"catalogueId",@"account",@"title",@"author",@"thumbImageURL",@"currentProgress",@"updateTime"];
        result = [database executeUpdate:createTableSql];
        if (result) {
            DLog(@"书架table 创表成功");
        }
        else {
            DLog(@"书架table 创表失败");
        }
    }
    [database close];
}

// 获取所以书架书籍
- (NSArray *)reloadCatalogueDBList {
    NSMutableArray *catalogueArray = [[NSMutableArray alloc] initWithCapacity:10];
    // 获得数据库
    FMDatabase *database = [FMDatabase databaseWithPath:instance.dbPath];
    BOOL result = [database open];
    if (result) {
        // 如果只有order by默认是升序的 等同于ASC
        NSString *findSql = [NSString stringWithFormat:@"SELECT * FROM %@ ORDER BY %@ DESC",@"CatalogueDB",@"updateTime"];
        FMResultSet *rs = [database executeQuery:findSql];
        while ([rs next])
        {
            CatalogueObject *catalogueObject = [[CatalogueObject alloc] init];
            catalogueObject.resourceId = [rs intForColumn:@"resourceId"];
            catalogueObject.catalogueId = [rs stringForColumn:@"catalogueId"];
            catalogueObject.account = [rs stringForColumn:@"account"];
            catalogueObject.title = [rs stringForColumn:@"title"];
            catalogueObject.author = [rs stringForColumn:@"author"];
            catalogueObject.currentProgress = [rs doubleForColumn:@"currentProgress"];
            catalogueObject.thumbImageURL = [rs stringForColumn:@"thumbImageURL"];
            catalogueObject.updateTime = [rs dateForColumn:@"updateTime"];
            [catalogueArray addObject:catalogueObject];
        }
    }
    [database close];
    
    return catalogueArray;
}

// 插入一本书到书架
- (void)insertCatalogueDB:(CatalogueObject *)catalogueObject {
    // 检查数据库表是否存在
    [self initializationCatalogueDB];
   
    // 创建时间的时间戳
    catalogueObject.updateTime = [NSDate date];
    
    FMDatabase *database = [FMDatabase databaseWithPath:instance.dbPath];
    BOOL result = [database open];
    if (result) {
        FMResultSet *rs = [database executeQuery:@"SELECT resourceId FROM CatalogueDB WHERE catalogueId = ? AND account=? "
                                 withArgumentsInArray:[NSArray arrayWithObjects:catalogueObject.catalogueId,catalogueObject.account,nil]];
        if ([rs next]) {
            catalogueObject.resourceId = [rs intForColumn:@"resourceId"];
        }
        else {
            [database beginTransaction];
            
            result = [database executeUpdate:@"insert into CatalogueDB(catalogueId,account,title,author,thumbImageURL,currentProgress,updateTime) values(?,?,?,?,?,?,?,?)"
                        withArgumentsInArray:[NSArray arrayWithObjects:catalogueObject.catalogueId,catalogueObject.account, catalogueObject.title,catalogueObject.author,catalogueObject.thumbImageURL,catalogueObject.currentProgress,catalogueObject.updateTime,nil]];
            if (result) {
                [database commit];
                catalogueObject.resourceId = [database lastInsertRowId];
            }
            else {
                [database rollback];
            }
        }
    }
    [database close];
    
    if (result) {
        DLog(@"插入书架成功");
    }
    else {
        DLog(@"插入书架失败");
    }
}

// 更新书架的书籍顺序
- (void)updateCatalogueDB:(CatalogueObject *)catalogueObject {
    // 更新时间的时间戳
    catalogueObject.updateTime = [NSDate date];
    
    FMDatabase *database = [FMDatabase databaseWithPath:instance.dbPath];
    BOOL result = [database open];
    if (result) {
        FMResultSet *rs = [database executeQuery:@"SELECT resourceId FROM CatalogueDB WHERE catalogueId = ? AND account = ? "
                            withArgumentsInArray:[NSArray arrayWithObjects:catalogueObject.catalogueId,catalogueObject.account,nil]];
        if ([rs next]) {
            catalogueObject.resourceId = [rs intForColumn:@"resourceId"];
            
            if (catalogueObject.resourceId != 0) {
                result = [database executeUpdate:@"update CatalogueDB SET updateTime = ? WHERE resourceid = ?"
                                 withArgumentsInArray:[NSArray arrayWithObjects:catalogueObject.updateTime, catalogueObject.resourceId,nil]];
            }
        }
    }
    [database close];
    
    if (result) {
        DLog(@"更新书架成功");
    }
    else {
        DLog(@"更新书架失败");
    }
}

// 从书架删除一本书
- (void)deleteCatalogueDB:(CatalogueObject *)catalogueObject {
    FMDatabase *database = [FMDatabase databaseWithPath:instance.dbPath];
    BOOL result = [database open];
    if (result) {
        result = [database executeUpdate:@"DELETE FROM CatalogueDB WHERE catalogueId = ?"
                         withArgumentsInArray:[NSArray arrayWithObject:catalogueObject.catalogueId]];
        if (result) {
            [database commit];
        }
        else {
            [database rollback];
        }
    }
    [database close];
    
    if (result) {
        DLog(@"删除书本成功");
    }
    else {
        DLog(@"删除书本失败");
    }
}

#pragma mark -
#pragma mark - 本书的目录 (创建，插入、删除)

// 创建一本书的目录的table
- (void)initializationChapterDB:(NSString *)tableName {
    // 获得数据库
    FMDatabase *database = [FMDatabase databaseWithPath:instance.dbPath];
    BOOL result = [database open];
    if (result) {
        // 创表
        NSString *sqlCreateTable = [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS '%@' (resourceId INTEGER PRIMARY KEY AUTOINCREMENT, '%@' INTEGER, '%@' TEXT, '%@' TEXT)",tableName,@"chapterNum",@"title",@"path"];
        result = [database executeUpdate:sqlCreateTable];
        if (result) {
            DLog(@"%@目录table 创表成功",tableName);
        }
        else {
            DLog(@"%@目录table 创表失败",tableName);
        }
    }
    [database close];
}

// 获取所有当前书架的书籍目录列表
- (NSArray *)reloadChapterDBList:(NSString *)catalogueId {
    NSMutableArray *chapterArray = [[NSMutableArray alloc] initWithCapacity:10];
    // 获得数据库
    FMDatabase *database = [FMDatabase databaseWithPath:instance.dbPath];
    BOOL result = [database open];
    if (result) {
        // 默认是升序的 ASC ,降序DESC
        NSString *querySql = [NSString stringWithFormat:@"SELECT * FROM %@ ORDER BY chapterNum ASC",catalogueId];
        FMResultSet *rs = [database executeQuery:querySql];
        while ([rs next])
        {
            ChapterObject *chapterObject = [[ChapterObject alloc] init];
            chapterObject.resourceId = [rs intForColumn:@"resourceId"];
            chapterObject.catalogueId = catalogueId;
            chapterObject.chapterNum = [rs unsignedLongLongIntForColumn:@"chapterNum"];
            chapterObject.title = [rs stringForColumn:@"title"];
            chapterObject.path = [kAppDocumentPath stringByAppendingString:[rs stringForColumn:@"path"]];
            [chapterArray addObject:chapterObject];
        }
    }
    [database close];
    
    return chapterArray;
}

// 获取单个章节数据信息
- (ChapterObject *)getChapterObject:(NSString *)catalogueId chapterNum:(NSUInteger)chapterNum {
    ChapterObject *chapterObject = nil;
    // 获得数据库
    FMDatabase *database = [FMDatabase databaseWithPath:instance.dbPath];
    BOOL result = [database open];
    if (result) {
        // 查询信息
        NSString *querySql = [NSString stringWithFormat:@"SELECT * FROM %@ WHERE chapterNum = %lu",catalogueId,chapterNum];
        FMResultSet *rs = [database executeQuery:querySql];
        while ([rs next])
        {
            chapterObject = [[ChapterObject alloc] init];
            chapterObject.resourceId = [rs intForColumn:@"resourceId"];
            chapterObject.catalogueId = catalogueId;
            chapterObject.chapterNum = [rs unsignedLongLongIntForColumn:@"chapterNum"];
            chapterObject.title = [rs stringForColumn:@"title"];
            chapterObject.path = [kAppDocumentPath stringByAppendingString:[rs stringForColumn:@"path"]];
        }
    }
    [database close];
    
    return chapterObject;
}

// 插入一章节到书本
- (void)insertChapterDB:(ChapterObject *)chapterObject data:(NSData *)data {
    // 检查数据库表是否存在
    [self initializationChapterDB:chapterObject.catalogueId];
    
    // 创建临时目录，保存文件
    NSMutableString *filePath = [NSMutableString stringWithFormat:@"%@/%@/%@",kDatabasePath,[AppDelegate shareAppDelegate].account,chapterObject.catalogueId];
    [filePath appendFormat:@"/%@.txt",chapterObject.title];
    
    BOOL result = YES;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if (![fileManager fileExistsAtPath:filePath]) {
        NSMutableString *directryPath = [NSMutableString stringWithFormat:@"%@/%@/%@",kDatabasePath,[AppDelegate shareAppDelegate].account,chapterObject.catalogueId];
        result = [fileManager createDirectoryAtPath:directryPath withIntermediateDirectories:YES attributes:nil error:nil];
       
        NSMutableString *tempStr = [[NSMutableString alloc] init];
        [tempStr appendString:directryPath];
        [tempStr appendFormat:@"/%@.txt",chapterObject.title];
        result = [fileManager createFileAtPath:tempStr contents:nil attributes:nil];
        if (result) {
            DLog(@"临时文件创建成功");
        }
        else {
            DLog(@"临时文件创建失败");
        }
    }
        
    // data文件只存放documents后面的目录
    NSString *tempFilePath = [filePath componentsSeparatedByString:@"Documents"][1];
    chapterObject.path = tempFilePath;
    
    FMDatabase *database = [FMDatabase databaseWithPath:instance.dbPath];
    result = [database open];
    if (result) {

        // 检查数据库是否已经存在插入的数据
        NSString *querySql = [NSString stringWithFormat:@"SELECT * FROM %@ WHERE chapterNum = %lu",chapterObject.catalogueId,chapterObject.chapterNum];
        FMResultSet *rs = [database executeQuery:querySql];
        
        BOOL isExsit = [rs next];
        [rs close];
        
        if (isExsit) {
            // 存在
        }
        else {
            [database beginTransaction];
            NSString *insertSql = [NSString stringWithFormat:@"INSERT INTO '%@' ('%@', '%@', '%@') VALUES ('%@', '%@', '%@')",chapterObject.catalogueId, @"chapterNum", @"title", @"path", [NSNumber numberWithUnsignedInteger:chapterObject.chapterNum],chapterObject.title,chapterObject.path];
            result = [database executeUpdate:insertSql];
            
            chapterObject.resourceId = [database lastInsertRowId];
            
            if (result) {
                [database commit];
            }
            else {
                [database rollback];
            }
        }
    }
    [database close];
    
    if (result) {
        DLog(@"插入章节成功");
    }
    else {
        DLog(@"插入章节失败");
    }
        
    if ((NSNull *)data != [NSNull null] ) {
        // Convert to Base64 data
        NSData *base64Data = [GTMBase64 encodeData:data];
        result = [base64Data writeToFile:filePath atomically:YES];
        if (result) {
            DLog(@"写入数据成功");
        }
        else {
            DLog(@"写入数据失败");
        }
    }
    else {
        DLog(@"插入章节数据为空");
    }
}

// 删除章节表
- (void)deleteChapterDB:(ChapterObject *)chapterObject {
    FMDatabase *database = [FMDatabase databaseWithPath:instance.dbPath];
    BOOL result = [database open];
    if (result) {
        NSString *dropSql = [NSString stringWithFormat:@"DROP TABLE %@",chapterObject.catalogueId];
        result = [database executeUpdate:dropSql];
    }
    [database close];
    
    if (result) {
        DLog(@"删除章节成功");
    }
    else {
        DLog(@"删除章节失败");
    }
    
    // 删除本地文件
    NSMutableString *filePath = [NSMutableString stringWithFormat:@"%@/%@/%@",kDatabasePath,[AppDelegate shareAppDelegate].account,chapterObject.catalogueId];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    result = [fileManager removeItemAtPath:filePath error:nil];
    if (result) {
        DLog(@"删除本地文件成功");
    }
    else {
        DLog(@"删除本地文件失败");
    }
}

@end
