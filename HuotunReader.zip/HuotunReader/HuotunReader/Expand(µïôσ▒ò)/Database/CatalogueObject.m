//
//  CatalogueObject.m
//  HuotunReader
//
//  Created by huotun on 2017/10/30.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "CatalogueObject.h"

@implementation CatalogueObject

@end
