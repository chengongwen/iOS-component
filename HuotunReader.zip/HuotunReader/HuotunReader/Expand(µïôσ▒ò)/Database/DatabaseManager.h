//
//  DatabaseManager.h
//  HuotunReader
//
//  Created by chengongwen on 2017/10/30.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDB.h"

@class CatalogueObject;
@class ChapterObject;

@interface DatabaseManager : NSObject

+ (DatabaseManager *)shareInstance;

#pragma mark - 书架
// 创建一个书架的table
- (void)initializationCatalogueDB;

// 获取所以书架书籍
- (NSArray *)reloadCatalogueDBList;

// 插入一本书到书架
- (void)insertCatalogueDB:(CatalogueObject *)catalogueObject;

// 更新书架
- (void)updateCatalogueDB:(CatalogueObject *)catalogueObject;

// 从书架删除一本书
- (void)deleteCatalogueDB:(CatalogueObject *)catalogueObject;


#pragma mark -
#pragma mark - 本书的目录 (创建，插入、删除)

// 创建一本书的目录的table
- (void)initializationChapterDB:(NSString *)tableName;

// 插入一章节到书本,并且数据加密写进本地文件
- (void)insertChapterDB:(ChapterObject *)chapterObject data:(NSData *)data;

// 获取所以书架书籍
- (NSArray *)reloadChapterDBList:(NSString *)catalogueId;

// 获取单个章节数据信息
- (ChapterObject *)getChapterObject:(NSString *)catalogueId chapterNum:(NSUInteger)chapterNum;

// 删除章节表数据
- (void)deleteChapterDB:(ChapterObject *)chapterObject;

@end
