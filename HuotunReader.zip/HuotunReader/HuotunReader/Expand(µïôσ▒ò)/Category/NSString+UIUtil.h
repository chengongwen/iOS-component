//
//  NSString+UIUtil.h
//  YueMao
//
//  Created by HEYANG on 16/5/31.
//
//

#import <Foundation/Foundation.h>

@interface NSString (UIUtil)

// 编码  URLEncodedString
+ (NSString *)URLEncodedString:(NSString *)str;

// 解码  URLDecodedString
+ (NSString *)URLDecodedString:(NSString *)str;

/**
 *  将三位以上的数字，例如@"3123123"转为@"3,123,123"
 */
-(NSString *)changeNumberFormat;

//等级图标名
+ (NSString *)stringWithLevel:(uint16_t)level;
+ (NSString *)getShadowColorHexWithLevel:(uint16_t)level;
+ (NSString *)getLabelColorHexWithLevel:(uint16_t)level;

// 计算字符串的字节数
-(NSInteger)getStringCharSize;

- (CGFloat)getHeightWithFont:(UIFont *)font constrainedToSize:(CGSize)size;
- (CGFloat)getWidthWithFont:(UIFont *)font constrainedToSize:(CGSize)size;

//识别机型
+ (NSString *)iphoneType;

//mac地址
+ (NSString *)macAddress;

@end
