//
//  YMDateTool.h
//  HuotunReader
//
//  Created by chengongwen on 2017/10/23.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YMDateTool : NSObject

#pragma mark - 获取时间或者字符串格式
+ (NSDate *)getDateWithFormat:(NSString *)dateFormat dateStr:(NSString*)dateStr;
+ (NSString*)getDateStrWithFormat:(NSString *)dateFormat date:(NSDate*)date;

/**
 *  根据选择器获取当前年龄的方法
 */
+ (NSInteger)getCurrentAgeWithDate:(NSDate*)date;

/**
 *  根据NSDate NSString 获取星座的方法
 */
+ (NSString*)getZodiacStringWithDate:(NSDate*)date;
+ (NSString *)getAstroWithBirthday:(NSString *)birthday;

/**
 *  根据birthday获取星座图片名称
 */
+ (NSString *)doGetConstellationImageWithBirthday:(NSString *)birthday;


/**
 转换显示时间
 
 @param dateTime   dateTime(s)
 @param dateFormat 转换显示时间格式
 
 @return 时间格式的字符串
 */
+ (NSString *)dateWithFormat:(NSString *)dateFormat dateTime:(double)dateTime;


/**
 格式1: 刚刚，分钟前，小时前，昨天
 *
 *  转换显示时间格式(秒)
 */
+ (NSString *)timeDescriptionWithTime:(time_t)time;

/**
 *  格式2: 今天，昨天
 *
 *  转换显示时间格式(秒)
 */
+ (NSString *)timeDescriptWithTime:(time_t)time;

/**
 *  格式3: 时分秒
 *
 *  转换显示时间格式(秒)
 */
+ (NSString *)timeFormatted:(int)totalSeconds;

@end
