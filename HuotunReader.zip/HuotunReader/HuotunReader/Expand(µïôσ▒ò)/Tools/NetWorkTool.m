//
//  NetWorkTool.m
///  HuotunReader
//
//  Created by chengongwen on 2017/10/23.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "NetWorkTool.h"
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import <CoreTelephony/CTCarrier.h>
#import "CoreStatus.h"

@implementation NetWorkTool

static NetWorkTool *_instance;
+ (instancetype)sharedNetWorkTool{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [self manager];
        
        _instance.requestSerializer = [AFJSONRequestSerializer serializer];
        
        NSSet *set = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript", @"text/html", nil];
        
        _instance.responseSerializer.acceptableContentTypes =[_instance.responseSerializer.acceptableContentTypes setByAddingObjectsFromSet:set];
    });
    
    return _instance;
}

/** 是否处于高速网络环境：3G、4G、Wifi */
+ (BOOL)isHighSpeedNetwork {
    return [CoreStatus isHighSpeedNetwork];
}

+ (BOOL)isNetworkEnable {
    return [CoreStatus isNetworkEnable];
}

+ (BOOL)isWifiEnable {
    return [CoreStatus isWifiEnable];
}

+ (NSString *)currentNetWorkStatusString {
    NSString *currentNetWork = [CoreStatus currentNetWorkStatusString];
    return currentNetWork;
}


+ (NSString *)carrierName {
    CTTelephonyNetworkInfo *telephonyInfo = [[CTTelephonyNetworkInfo alloc] init];
    CTCarrier *carrier = [telephonyInfo subscriberCellularProvider];
    NSString *currentCountry = [carrier carrierName];
    if (currentCountry == nil) {
        currentCountry = NSLocalizedString(@"未知", @"未知");
    }
    return currentCountry;
}

@end
