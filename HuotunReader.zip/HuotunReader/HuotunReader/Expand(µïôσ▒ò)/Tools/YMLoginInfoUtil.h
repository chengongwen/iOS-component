//
//  YMLoginInfoUtil.h
//  YueMao
//
//  Created by chengongwen on 16/9/5.
//
//

#import <UIKit/UIKit.h>

@interface YMLoginInfoUtil : NSObject

+ (instancetype)sharedObject;

/**
 *  初始化登录信息
 *
 *  @return 返回json格式字段
 */
- (NSString *)jsonUserInfo;

/**
 adfv,同台手机的同个应用的唯一标识，即使删除或者切换广告依然保持不变）
 */
- (NSString *)getUniqueDeviceIdentifierAsString;

/**
 mac 地址
 */
- (NSString *)macString;


/**
 adfa
 */
- (NSString *)idfaString;

@end
