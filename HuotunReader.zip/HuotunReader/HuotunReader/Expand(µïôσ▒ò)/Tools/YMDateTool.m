//
//  YMDateTool.m
//  HuotunReader
//
//  Created by chengongwen on 2017/10/23.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "YMDateTool.h"
#import "NSDate+YYAdd.h"

#define kMinuteTimeInterval (60)
#define kHourTimeInterval   (60 * kMinuteTimeInterval)
#define kDayTimeInterval    (24 * kHourTimeInterval)
#define kWeekTimeInterval   (7  * kDayTimeInterval)
#define kMonthTimeInterval  (30 * kDayTimeInterval)
#define kYearTimeInterval   (12 * kMonthTimeInterval)


@implementation YMDateTool

#pragma mark - 获取时间或者字符串格式
+ (NSDate *)getDateWithFormat:(NSString *)dateFormat dateStr:(NSString*)dateStr {
    
    // 创建的格式 yyyyMMdd
    NSDateFormatter *dateFormatter = [NSDateFormatter new];
    dateFormatter.locale = [NSLocale localeWithLocaleIdentifier:@"zh_CN"];
    [dateFormatter setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:8]];
    if (!dateFormat) {
        dateFormat = @"yyyy-MM-dd HH:mm:ss";
    }
    [dateFormatter setDateFormat:dateFormat];
    
    return [dateFormatter dateFromString:dateStr];
}

+ (NSString*)getDateStrWithFormat:(NSString *)dateFormat date:(NSDate*)date {
    
    NSDateFormatter *dateFormatter = [NSDateFormatter new];
    dateFormatter.locale = [NSLocale localeWithLocaleIdentifier:@"zh_CN"];
    if (!dateFormat) {
        dateFormat = @"yyyy-MM-dd HH:mm:ss";
    }
    [dateFormatter setDateFormat:dateFormat];
    
    return [dateFormatter stringFromDate:date];
}

#pragma mark 根据NSDate获取当前年龄的方法
+ (NSInteger)getCurrentAgeWithDate:(NSDate *)date {

    // 通过NSDateComponents 从 date 中提取出 年月日
    NSDateComponents *components1 = [[NSCalendar currentCalendar] components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond fromDate:date];
    
    NSInteger year = [components1 year];
    
    NSInteger month = [components1 month];
    
    NSInteger day = [components1 day];
    
    // 获取系统当前的年月日
    NSDate *currentDate = [NSDate date]; // 获得系统的时间
    
    NSDateComponents *components2 = [[NSCalendar currentCalendar] components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond fromDate:currentDate];
    
    NSInteger currentYear = [components2 year];
    
    NSInteger currentMonth = [components2 month];
    
    NSInteger currentDay = [components2 day];
    
    // 计算年龄
    NSInteger iAge = currentYear - year - 1;
    if ((currentMonth > month) || (currentMonth == month && currentDay >= day)) {
        iAge++;
    }
    return iAge;
}

#pragma mark 根据NSDate获取星座的方法
+ (NSString*)getZodiacStringWithDate:(NSDate*)date {
   
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSUInteger unitFlags = NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond;
    NSDateComponents *dateComponent = [calendar components:unitFlags fromDate:date];
    
    NSInteger month = [dateComponent month];
    NSInteger day = [dateComponent day];
    
    NSString *astroString = NSLocalizedString(@"魔羯水瓶双鱼白羊金牛双子巨蟹狮子处女天秤天蝎射手魔羯", @"魔羯水瓶双鱼白羊金牛双子巨蟹狮子处女天秤天蝎射手魔羯");
    NSString *astroFormat = @"102123444543";
    
    NSString *result;
    
    if (month<1 || month>12 || day<1 || day>31) {
        return NSLocalizedString(@"错误日期格式!", @"错误日期格式!");
    }
    
    if(month==2 && day>29) {
        return NSLocalizedString(@"错误日期格式!!", @"错误日期格式!!");
    }
    else if(month==4 || month==6 || month==9 || month==11) {
        if (day>30) {
            return NSLocalizedString(@"错误日期格式!!!", @"错误日期格式!!!");
        }
    }
    
    result = [NSString stringWithFormat:NSLocalizedString(@"%@座", @"%@座"),[astroString substringWithRange:NSMakeRange(month*2-(day < [[astroFormat substringWithRange:NSMakeRange((month-1), 1)] intValue] - (-19))*2,2)]];
    
    return result;
}

/**
 *  根据NSString获取星座的方法
 */
+ (NSString *)getAstroWithBirthday:(NSString *)birthday {
    if ([birthday isEqualToString:@""] || birthday.length == 0 || (![YMDateTool conformStandardWithNumbers:birthday])) {
        return nil;
    }
    //出生月
    int month = [[birthday substringWithRange:NSMakeRange(4, 2)] intValue];
    //出生天
    int day = [[birthday substringWithRange:NSMakeRange(6, 2)] intValue];
    NSString *astroString = NSLocalizedString(@"魔羯水瓶双鱼白羊金牛双子巨蟹狮子处女天秤天蝎射手魔羯", @"魔羯水瓶双鱼白羊金牛双子巨蟹狮子处女天秤天蝎射手魔羯");
    NSString *astroFormat = @"102123444543";
    NSString *result;
    result=[NSString stringWithFormat:NSLocalizedString(@"%@座", @"%@座"),[astroString substringWithRange:NSMakeRange(month *2-(day < [[astroFormat substringWithRange:NSMakeRange((month-1), 1)] intValue] - (-19))*2,2)]];
    
    return result;
}

/**
 *  根据birthday获取星座图片
 */
+ (NSString *)doGetConstellationImageWithBirthday:(NSString *)birthday {
    
    NSString *constellation = [YMDateTool getAstroWithBirthday:birthday];
    
    NSString *imageName = @"";
    
    if ([constellation isEqualToString:NSLocalizedString(@"魔羯座", @"魔羯座")]) {
        imageName = @"mojie";
    }
    else if ([constellation isEqualToString:NSLocalizedString(@"水瓶座", @"水瓶座")]) {
        imageName = @"shuiping";
    }
    else if ([constellation isEqualToString:NSLocalizedString(@"双鱼座", @"双鱼座")]) {
        imageName = @"shuangyu";
    }
    else if ([constellation isEqualToString:NSLocalizedString(@"白羊座", @"白羊座")]) {
        imageName = @"baiyang";
    }
    else if ([constellation isEqualToString:NSLocalizedString(@"金牛座", @"金牛座")]) {
        imageName = @"jinniu";
    }
    else if ([constellation isEqualToString:NSLocalizedString(@"双子座", @"双子座")]) {
        imageName = @"shuangzi";
    }
    else if ([constellation isEqualToString:NSLocalizedString(@"巨蟹座", @"巨蟹座")]) {
        imageName = @"juxie";
    }
    else if ([constellation isEqualToString:NSLocalizedString(@"狮子座", @"狮子座")]) {
        imageName = @"shizi";
    }
    else if ([constellation isEqualToString:NSLocalizedString(@"处女座", @"处女座")]) {
        imageName = @"chunv";
    }
    else if ([constellation isEqualToString:NSLocalizedString(@"天秤座", @"天秤座")]) {
        imageName = @"tiancheng";
    }
    else if ([constellation isEqualToString:NSLocalizedString(@"天蝎座", @"天蝎座")]) {
        imageName = @"tianxie";
    }
    else if ([constellation isEqualToString:NSLocalizedString(@"射手座", @"射手座")]) {
        imageName = @"sheshou";
    }
    
    return imageName;
}

/**
 *  输入只为数字的方法
 */
+ (BOOL)conformStandardWithNumbers:(NSString *)inputString {
    NSString * regex = @"^[0-9]*$";
    NSPredicate * pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    BOOL basicTest = [pred evaluateWithObject:inputString];
    
    return basicTest;
}

#pragma mark - 转换显示时间
/**
 转换显示时间
 
 @param dateTime   dateTime(s)
 @param dateFormat 转换显示时间格式
 
 @return 时间格式的字符串
 */
+ (NSString *)dateWithFormat:(NSString *)dateFormat dateTime:(double)dateTime {
    if (!dateFormat) {
        dateFormat = @"yyyy-MM-dd HH:mm:ss";
    }
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:dateFormat];
    dateFormatter.locale = [NSLocale localeWithLocaleIdentifier:@"zh_CN"];
    
    NSDate *confromTimesp = [NSDate dateWithTimeIntervalSince1970:dateTime];
    NSString *result = [dateFormatter stringFromDate:confromTimesp];
    
    return result;
}

#pragma mark - 特别的时间格式显示
/**
 格式1: 刚刚，分钟前，小时前，昨天
 */
+ (NSString *)timeDescriptionWithTime:(time_t)time {
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:time];
   
    NSTimeInterval interval = [date timeIntervalSinceDate:[NSDate date]];
    interval = -interval;
    
    // 今天的消息
    NSDateFormatter* dateFormat = [[NSDateFormatter alloc] init];
    dateFormat.locale = [NSLocale localeWithLocaleIdentifier:@"zh_CN"];
    [dateFormat setDateFormat:@"HH:mm"];
    NSString *dateString = [dateFormat stringFromDate:date];
    
    long retTime = 1.0;
    
    // 今天
    if ([date isToday]) {
    
        // 小于3分钟
        if (interval <= 60) {
            return [NSString stringWithFormat:NSLocalizedString(@"刚刚", @"刚刚")];
        }
        // 小于一小时
        else if (interval <= 3600) {
            retTime = interval / 60;
            return [NSString stringWithFormat:NSLocalizedString(@"%ld分钟前", @"%ld分钟前"), retTime];
        }
        // 小于12小时
        else if (interval <= 3600 *24) {
            retTime = interval / 3600;
            return [NSString stringWithFormat:NSLocalizedString(@"%ld小时前", @"%ld小时前"), retTime];
        }
    }
    // 昨天
    else if ([date isYesterday]) {
        return [NSString stringWithFormat:NSLocalizedString(@"昨天%@", @"昨天%@"), dateString];
    }
    else {
        NSDateComponents *components = [[NSCalendar currentCalendar] components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay fromDate:date];
        
        NSDateComponents *today = [[NSCalendar currentCalendar] components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay fromDate:[NSDate date]];
        
        if ([components year] == [today year]) {
            // 今年
            [dateFormat setDateFormat:NSLocalizedString(@"MM月dd日", @"MM月dd日")];
            NSString *mdStr = [dateFormat stringFromDate:date];
            return [NSString stringWithFormat:@"%@%@", mdStr, dateString];
        }
        else {
            // 往年
            [dateFormat setDateFormat:@"yy-MM-dd"];
            NSString *ymdString = [dateFormat stringFromDate:date];
            return [NSString stringWithFormat:@"%@ %@", ymdString, dateString];;
        }
    }
    
    return nil;
}

/**
 *  格式2: 上午,昨天,前天
 */
+ (NSString *)timeDescriptWithTime:(time_t)time {
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:time];
    
    NSTimeInterval interval = [date timeIntervalSinceDate:[NSDate date]];
    interval = -interval;
    
    // 今天的消息
    NSDateFormatter* dateFormat = [[NSDateFormatter alloc] init];
    dateFormat.locale = [NSLocale localeWithLocaleIdentifier:@"zh_CN"];
    [dateFormat setDateFormat:@"HH:mm"];
//    [dateFormat setAMSymbol:NSLocalizedString(@"上午", @"上午")];
//    [dateFormat setPMSymbol:NSLocalizedString(@"下午", @"下午")];
    NSString *dateString = [dateFormat stringFromDate:date];
    
    // 今天
    if ([date isToday]) {
        return dateString;
        // return [NSString stringWithFormat:NSLocalizedString(@"今天%@", @"今天%@"), dateString];
    }
    // 昨天
    else if ([date isYesterday]) {
        return [NSString stringWithFormat:NSLocalizedString(@"昨天 %@", @"昨天 %@"), dateString];
    }
    else {
        NSDateComponents *components = [[NSCalendar currentCalendar] components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay fromDate:date];
        
        NSDateComponents *today = [[NSCalendar currentCalendar] components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay fromDate:[NSDate date]];
        
        if ([components year] == [today year]) {
            // 今年
//            [dateFormat setDateFormat:NSLocalizedString(@"MM月dd日", @"MM月dd日")];
            [dateFormat setDateFormat:NSLocalizedString(@"MM-dd", @"MM-dd")];
            NSString *mdStr = [dateFormat stringFromDate:date];
            return [NSString stringWithFormat:@"%@ %@", mdStr, dateString];
        }
        else {
            // 往年
            [dateFormat setDateFormat:@"yy-MM-dd"];
            NSString *ymdString = [dateFormat stringFromDate:date];
            return [NSString stringWithFormat:@"%@ %@", ymdString, dateString];;
        }
    }
    return nil;
}

+ (NSString *)timeFormatted:(int)totalSeconds
{
    
    int seconds = totalSeconds % 60;
    int minutes = (totalSeconds / 60) % 60;
    int hours = totalSeconds / 3600;
    if(hours==0){
        if(minutes==0){
            return [NSString stringWithFormat:NSLocalizedString(@"%d秒",@"%d秒"), seconds];
        }
         return [NSString stringWithFormat:NSLocalizedString(@"%d分%d秒",@"%d分%d秒"), minutes, seconds];
    }
    return [NSString stringWithFormat:NSLocalizedString(@"%d小时%d分%d秒",@"%d小时%d分%d秒"),hours, minutes, seconds];
} 


@end
