//
//  AlertUtil.h
//
//
//  Created by chengongwen on 13-6-4.
//  Copyright (c) 2013年 ysservice.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AlertUtil : NSObject

/**
 *  消息提示框
 *
 *  @param titles   标题
 *  @param message 内容
 *  @param btnTitle 取消按钮
 */
+ (void)alertWithTitle:(NSString *)titles message:(NSString *)message
           cancelTitle:(NSString  *)btnTitle;

/**
 *  消息提示框
 *
 *  @param message 内容
 */
+ (void)alertWithMessage:(NSString *)message;

@end
