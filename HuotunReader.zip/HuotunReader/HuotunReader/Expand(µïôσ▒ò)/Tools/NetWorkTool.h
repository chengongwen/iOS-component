//
//  NetWorkTool.h
//  HuotunReader
//
//  Created by chengongwen on 2017/10/23.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <AFNetworking/AFNetworking.h>

@interface NetWorkTool : AFHTTPSessionManager

+ (instancetype)sharedNetWorkTool;

/**
 *  检查网络
 */
+ (BOOL)isNetworkEnable;

/** 是否处于高速网络环境：3G、4G、Wifi */
+ (BOOL)isHighSpeedNetwork;

/** 是否是Wifi */
+ (BOOL)isWifiEnable;

/** 获取当前网络状态：字符串 [NSLocalizedString(@"无网络", @"无网络"),@"Wifi",NSLocalizedString(@"蜂窝网络", @"蜂窝网络"),@"2G",@"3G",@"4G",NSLocalizedString(@"未知网络", @"未知网络")] */
+ (NSString *)currentNetWorkStatusString;

/**
 *  运营商名称
 */
+ (NSString *)carrierName;

@end
