//
//  YMLoginInfoUtil.m
//  YueMao
//
//  Created by chengongwen on 16/9/5.
//
//

#import "YMLoginInfoUtil.h"
#import <AdSupport/AdSupport.h>
#import "SAMKeychain.h"
#import "SAMKeychainQuery.h"
#import <AdSupport/ASIdentifierManager.h>
#include <sys/sysctl.h>
#include <sys/socket.h>
#include <net/if.h>
#include <net/if_dl.h>
#import "NetWorkTool.h"

static YMLoginInfoUtil *instance = nil;

@implementation YMLoginInfoUtil

+ (instancetype)sharedObject {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[YMLoginInfoUtil alloc] init];
    });
    return instance;
}

- (NSString *)jsonUserInfo {
    NSString *model = [[UIDevice currentDevice] model];
    NSString *os = [[UIDevice currentDevice] systemVersion];
    NSString *currentNetWork = [NetWorkTool currentNetWorkStatusString];
    NSString *carrierName = [NetWorkTool carrierName];
    NSString *screen = [NSString stringWithFormat:@"%d*%d", (int)[UIScreen mainScreen].bounds.size.width, (int)[UIScreen mainScreen].bounds.size.height];
    NSString *systemVersion = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    
    // deviceId = [[[ASIdentifierManager sharedManager] advertisingIdentifier] UUIDString]
    NSString * deviceId = [self getUniqueDeviceIdentifierAsString];
    
    NSString *channel_id = @"IOS_MB";
    NSString *unionid = @"";
    
    if ([AppDelegate shareAppDelegate].platform == LoginPlatformWX) {
        NSUserDefaults *useDefault = [NSUserDefaults standardUserDefaults];
        unionid = [useDefault objectForKey:@"unionid"];
    }
    
    NSDictionary *params = @{
                             @"channel_id" : channel_id,
                             @"appversion" : systemVersion,
                             @"device" :    model,
                             @"nm" :        currentNetWork,
                             @"mno" :       carrierName,
                             @"screen":     screen,
                             @"os":         os,
                             @"mac":        @"",
                             @"deviceId":   deviceId,
                             @"wechat":     unionid
                             };
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:params options:NSJSONWritingPrettyPrinted error:nil];
    NSString *param = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    
    return param;
}

- (NSString *)getUniqueDeviceIdentifierAsString {
    NSString *appName=[[[NSBundle mainBundle] infoDictionary] objectForKey:(NSString*)kCFBundleNameKey];
    
    NSString *strApplicationUUID = [SAMKeychain passwordForService:appName account:@"incoding"];
    if (strApplicationUUID == nil)
    {
        strApplicationUUID  = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
        
        NSError *error = nil;
        SAMKeychainQuery *query = [[SAMKeychainQuery alloc] init];
        query.service = appName;
        query.account = @"incoding";
        query.password = strApplicationUUID;
        query.synchronizationMode = SAMKeychainQuerySynchronizationModeNo;
        [query save:&error];
    }
    
    return strApplicationUUID;
}

- (NSString * )macString {
    int mib[6];
    size_t len;
    char *buf;
    unsigned char *ptr;
    struct if_msghdr *ifm;
    struct sockaddr_dl *sdl;
    
    mib[0] = CTL_NET;
    mib[1] = AF_ROUTE;
    mib[2] = 0;
    mib[3] = AF_LINK;
    mib[4] = NET_RT_IFLIST;
    
    if ((mib[5] = if_nametoindex("en0")) == 0) {
        printf("Error: if_nametoindex error\n");
        return NULL;
    }
    
    if (sysctl(mib, 6, NULL, &len, NULL, 0) < 0) {
        printf("Error: sysctl, take 1\n");
        return NULL;
    }
    
    if ((buf = malloc(len)) == NULL) {
        printf("Could not allocate memory. error!\n");
        return NULL;
    }
    
    if (sysctl(mib, 6, buf, &len, NULL, 0) < 0) {
        printf("Error: sysctl, take 2");
        free(buf);
        return NULL;
    }
    
    ifm = (struct if_msghdr *)buf;
    sdl = (struct sockaddr_dl *)(ifm + 1);
    ptr = (unsigned char *)LLADDR(sdl);
    NSString *macString = [NSString stringWithFormat:@"%02X:%02X:%02X:%02X:%02X:%02X",
                           *ptr, *(ptr+1), *(ptr+2), *(ptr+3), *(ptr+4), *(ptr+5)];
    free(buf);
    
    return macString;
}

- (NSString *)idfaString {
    
    NSBundle *adSupportBundle = [NSBundle bundleWithPath:@"/System/Library/Frameworks/AdSupport.framework"];
    [adSupportBundle load];
    
    if (adSupportBundle == nil) {
        return @"";
    }
    else{
        
        Class asIdentifierMClass = NSClassFromString(@"ASIdentifierManager");
        
        if(asIdentifierMClass == nil){
            return @"";
        }
        else{
            
            //for no arc
            //ASIdentifierManager *asIM = [[[asIdentifierMClass alloc] init] autorelease];
            //for arc
            ASIdentifierManager *asIM = [[asIdentifierMClass alloc] init];
            
            if (asIM == nil) {
                return @"";
            }
            else{
                
                if(asIM.advertisingTrackingEnabled){
                    return [asIM.advertisingIdentifier UUIDString];
                }
                else{
                    return [asIM.advertisingIdentifier UUIDString];
                }
            }
        }
    }
}

@end
