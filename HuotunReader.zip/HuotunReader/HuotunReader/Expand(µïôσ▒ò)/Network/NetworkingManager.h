//
//  NetworkManager.h
//  HuotunReader
//
//  Created by chengongwen on 2017/11/4.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AFNetworking/AFNetworking.h>

#define BaseURL @"baseURL"

/**定义请求类型的枚举*/
typedef NS_ENUM(NSUInteger,HttpRequestType)
{
    HttpRequestTypeGet = 0,
    HttpRequestTypePost
};

/**定义请求成功的block*/
typedef void(^requestSuccess)(id responseObject);

/**定义缓存的block*/
typedef void(^requestCache)(id responseCache);

/**定义请求失败的block*/
typedef void(^requestFailure)(NSError *error);

/**定义上传进度block*/
typedef void(^uploadProgress)(float progress);

/**定义下载进度block*/
typedef void(^downloadProgress)(float progress);



@interface NetworkingManager : AFHTTPSessionManager

// 是否开启缓存
@property (nonatomic, assign) BOOL isOpenRequestCache;

// 开启日志打印 (Debug级别)
@property (nonatomic, assign) BOOL isOpenLog;

/**
 *  单例方法
 *
 *  @return 实例对象
 */
+ (instancetype)shareManager;

/**
 *  iOS https自建证书的使用,简单的封装
 *  使用方法,在af网络请求的地方加入
 *  [[DBCNetWorkingManager shareManager] setSecurityPolicy:[DBCNetWorkingManager customSecurityPolicy]];
 *  @return AFSecurityPolicy
 */
+ (AFSecurityPolicy *)customSecurityPolicy;

/**
 *  假如是系统信任机构颁发的证书
 *
 *  @return AFSecurityPolicy
 */
+ (AFSecurityPolicy *)TrustInstitutionsSecurityPolicy;

/**
 网络请求的实例方法
 
 *  @param type          GET / POST
 *  @param urlString     请求的地址
 *  @param parameters    请求的参数
 *  @param responseCache 缓存数据的回调
 *  @param successBlock  请求成功的回调
 *  @param failureBlock  请求失败的回调
 *  @param progress 进度
 */
+ (void)requestWithType:(HttpRequestType)type
             requestURL:(NSString *)urlString
             parameters:(id)parameters
          responseCache:(requestCache)responseCache
           successBlock:(requestSuccess)successBlock
           failureBlock:(requestFailure)failureBlock
               progress:(downloadProgress)progress;


/**
 上传文件
 
 *  @param operations   上传图片预留参数---视具体情况而定 可移除
 *  @param filePath     上传文件路径
 *  @param fileName     上传文件名
 *  @param urlString    上传的url
 *  @param successBlock 上传成功的回调
 *  @param failureBlock 上传失败的回调
 *  @param progress     上传进度
 */
+ (void)uploadFileOperations:(NSDictionary *)operations
                  imageArray:(NSArray *)imageArray
                    filePath:(NSString * )filePath
                    fileName:(NSString * )fileName
                  requestURL:(NSString *)urlString
                successBlock:(requestSuccess)successBlock
                 failurBlock:(requestFailure)failureBlock
              upLoadProgress:(uploadProgress)progress;


/**
 上传图片

 @param operations    上传图片预留参数---视具体情况而定 可移除
 @param imageArray    上传的图片数组
 @param width         图片要被压缩到的宽度
 @param urlString     上传的url
 @param successBlock  上传成功的回调
 @param failureBlock  上传失败的回调
 @param progress      上传进度
 */
+ (void)uploadImageWithOperations:(NSDictionary *)operations
                       imageArray:(NSArray *)imageArray
                      targetWidth:(CGFloat )width
                       requestURL:(NSString *)urlString
                     successBlock:(requestSuccess)successBlock
                      failurBlock:(requestFailure)failureBlock
                   upLoadProgress:(uploadProgress)progress;

/**
 文件下载

 *  @param operations   文件下载预留参数---视具体情况而定 可移除
 *  @param savePath     下载文件保存的完整路径
 *  @param urlString    请求的url
 *  @param successBlock 下载文件成功的回调
 *  @param failureBlock 下载文件失败的回调
 *  @param progress     下载文件的进度显示
 */
+ (void)downLoadFileWithOperations:(NSDictionary *)operations
                          savaPath:(NSString *)savePath
                        requestURL:(NSString *)urlString
                      successBlock:(requestSuccess)successBlock
                      failureBlock:(requestFailure)failureBlock
                  downLoadProgress:(downloadProgress)progress;

/**
 取消指定的url请求
 
 *  @param requestType 该请求的请求类型
 *  @param string      该请求的url
 */
+ (void)cancelHttpRequestWithRequestType:(NSString *)requestType
                              requestURL:(NSString *)string;

/**
 取消所有的网络请求
 */
+ (void)cancelAllRequest;

@end
