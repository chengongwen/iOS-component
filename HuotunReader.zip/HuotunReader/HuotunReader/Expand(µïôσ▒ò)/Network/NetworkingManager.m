//
//  NetworkManager.m
//  HuotunReader
//
//  Created by chengongwen on 2017/11/4.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#import "NetworkingManager.h"
#import "UIImage+compressIMG.h"
#import "AFNetworkActivityIndicatorManager.h"
#import "NetworkingCache.h"

static NSMutableArray *_allSessionTask;

@implementation NetworkingManager

static NetworkingManager * manager = nil;

#pragma mark - shareManager
+ (instancetype)shareManager {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[NetworkingManager alloc] initWithBaseURL:[NSURL URLWithString:BaseURL]];
        manager.isOpenRequestCache = NO;
        manager.isOpenLog = YES;
    });
    return manager;
}

/**
 存储着所有的请求task数组
 */
+ (NSMutableArray *)allSessionTask {
    if (!_allSessionTask) {
        _allSessionTask = [[NSMutableArray alloc] init];
    }
    return _allSessionTask;
}

#pragma mark - 重写initWithBaseURL
- (instancetype)initWithBaseURL:(NSURL *)url {
    if (self = [super initWithBaseURL:url]) {
 
#warning 可根据具体情况进行设置
        NSAssert(url,@"您需要为您的请求设置baseUrl");
        
        /**设置请求超时时间*/
        
        self.requestSerializer.timeoutInterval = 30.0f;
        
        /**设置相应的缓存策略*/
        
        self.requestSerializer.cachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
        
        /**分别设置请求以及相应的序列化器*/
        self.requestSerializer = [AFHTTPRequestSerializer serializer];
        
        AFJSONResponseSerializer * response = [AFJSONResponseSerializer serializer];
        
        response.removesKeysWithNullValues = YES;
        
        self.responseSerializer = response;
        
        /**复杂的参数类型 需要使用json传值-设置请求内容的类型*/
        
        [self.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
        
#warning 此处做为测试 可根据自己应用设置相应的值

        /**设置apikey ------类似于自己应用中的tokken---此处仅仅作为测试使用*/
        //[self.requestSerializer setValue:apikey forHTTPHeaderField:@"apikey"];
        
        /**设置接受的类型*/
        [self.responseSerializer setAcceptableContentTypes:[NSSet setWithObjects:@"text/plain",@"application/json",@"text/json",@"text/javascript",@"text/html", nil]];
        
        // 打开状态栏的等待菊花
        [AFNetworkActivityIndicatorManager sharedManager].enabled = YES;
    }
    return self;
}

#pragma mark -customSecurityPolicy
/**
 *  iOS https自建证书的使用,简单的封装
 *  使用方法,在af网络请求的地方加入
 *  [[NetworkingManager shareManager] setSecurityPolicy:[NetworkingManager customSecurityPolicy]];
 *  @return AFSecurityPolicy
 */
+ (AFSecurityPolicy *)customSecurityPolicy {
    // 设置证书模式
    //自建证书文件
    NSString *cerPath = [[NSBundle mainBundle] pathForResource:@"mnchip" ofType:@"cer"];
    
    NSData *cerDat = [NSData dataWithContentsOfFile:cerPath];
    
    AFSecurityPolicy *securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeCertificate];
    
    //允许自检证书
    
    securityPolicy.allowInvalidCertificates = YES;
    
    //域名与服务器一致
    
    securityPolicy.validatesDomainName = YES;
    
    securityPolicy.pinnedCertificates = [[NSSet alloc] initWithObjects:cerDat, nil];
    
    return securityPolicy;
    
}
/**
 *  假如是系统信任机构颁发的证书
 *
 *  @return AFSecurityPolicy
 */
//AFSSLPinningModeNon表示不做SSL pinning，只跟浏览器一样在系统的信任机构列表里验证服务端返回的证书。若证书是信任机构签发的就会通过，若是自己服务器生成的证书，是不会通过的。
//
//AFSSLPinningModeCertificate表示用证书绑定方式验证证书，需要客户端保存有服务端的证书拷贝，这里验证分两步，第一步验证证书的域名/有效期等信息，第二步是对比服务端返回的证书跟客户端返回的是否一致。
//
//AFSSLPinningModePublicKey是用证书绑定方式验证，客户端要有服务端的证书拷贝，只是验证时只验证证书里的公钥，不验证证书的有效期等信息。只要公钥是正确的，就能保证通信不会被窃听，因为中间人没有私钥，无法解开通过公钥加密的数据。
//
//也就是如果你使用后面两种模式你的工程里面需要导入cer证书文件。这个文件的路径随意，AFNetWorking会自动替你寻找。如果你觉得不放心也可以使用下面的代码直接指定文件。
//NSData *certData = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"12306" ofType:@"cer"]];
//NSSet *cerSet  = [NSSet setWithObject:certData];
//if(certData){
//    [securityPolicy setPinnedCertificates:cerSet];
//}
+(AFSecurityPolicy *)TrustInstitutionsSecurityPolicy{
    
    AFSecurityPolicy *securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
    [securityPolicy setValidatesDomainName:YES];
    
    return securityPolicy;

}

#pragma mark - 网络请求的类方法---get/post

/**
 *  网络请求的实例方法
 *
 *  @param type         get / post
 *  @param urlString    请求的地址
 *  @param parameters    请求的参数
 *  @param successBlock 请求成功的回调
 *  @param failureBlock 请求失败的回调
 *  @param progress 进度
 */

+ (void)requestWithType:(HttpRequestType)type requestURL:(NSString *)urlString parameters:(id)parameters responseCache:(requestCache)responseCache successBlock:(requestSuccess)successBlock failureBlock:(requestFailure)failureBlock progress:(downloadProgress)progress {
    
    //读取缓存
    responseCache !=nil ? responseCache([NetworkingCache httpCacheForURL:urlString parameters:parameters]) : nil;
    
    switch (type) {
        case HttpRequestTypeGet:
        {
            __block NSURLSessionDataTask * sessionTask = [[NetworkingManager shareManager] GET:urlString parameters:parameters progress:^(NSProgress * _Nonnull downloadProgress) {
                
                // 下载进度
                dispatch_sync(dispatch_get_main_queue(), ^{
                    progress(downloadProgress.completedUnitCount / downloadProgress.totalUnitCount);
                });
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                
                if (manager.isOpenLog) {
                    DLog(@"responseObject = %@",responseObject);
                }
                
                if (manager.isOpenRequestCache) {
                    // 对数据进行异步缓存
                    responseCache !=nil ? [NetworkingCache setHttpCache:responseObject URL:urlString parameters:parameters] : nil;
                }
                
                // 任务完成
                [[self allSessionTask] removeObject:task];
                
                successBlock(responseObject);
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                
                if (manager.isOpenLog) {
                    DLog(@"error = %@",error);
                }
                failureBlock(error);
            }];
            
            // 添加sessionTask到数组
            sessionTask ? [[self allSessionTask] addObject:sessionTask] : nil;
            break;
        }
            
        case HttpRequestTypePost:
        {
            __block NSURLSessionDataTask * sessionTask = [[NetworkingManager shareManager] POST:urlString parameters:parameters progress:^(NSProgress * _Nonnull uploadProgress) {
                
                progress(uploadProgress.completedUnitCount / uploadProgress.totalUnitCount);
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                
                if (manager.isOpenLog) {
                    DLog(@"responseObject = %@",responseObject);
                }
                
                if (manager.isOpenRequestCache) {
                    // 对数据进行异步缓存
                    responseCache !=nil ? [NetworkingCache setHttpCache:responseObject URL:urlString parameters:parameters] : nil;
                }
                
                // 任务完成
                [[self allSessionTask] removeObject:task];
                
                successBlock(responseObject);
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                
                if (manager.isOpenLog) {
                    DLog(@"error = %@",error);
                }
                failureBlock(error);
            }];
            
            // 添加sessionTask到数组
            sessionTask ? [[self allSessionTask] addObject:sessionTask] : nil;
            break;
        }
    }
}

#pragma mark - 上传文件
/**
 *  上传文件
 */
+ (void)uploadFileOperations:(NSDictionary *)operations imageArray:(NSArray *)imageArray filePath:(NSString *)filePath fileName:(NSString *)fileName requestURL:(NSString *)urlString successBlock:(requestSuccess)successBlock failurBlock:(requestFailure)failureBlock upLoadProgress:(uploadProgress)progress {
    
    __block NSURLSessionDataTask * sessionTask =  [[NetworkingManager shareManager] POST:urlString parameters:operations constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        
        NSError *error = nil;
        [formData appendPartWithFileURL:[NSURL URLWithString:filePath] name:fileName error:&error];
        (failureBlock && error) ? failureBlock(error) : nil;
        
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        
        // 上传进度
        dispatch_sync(dispatch_get_main_queue(), ^{
            progress(uploadProgress.completedUnitCount / uploadProgress.totalUnitCount);
        });
    } success:^(NSURLSessionDataTask * _Nonnull task, NSDictionary *  _Nullable responseObject) {
        
        if (manager.isOpenLog) {
            DLog(@"responseObject = %@",responseObject);
        }
        // 任务完成
        [[self allSessionTask] removeObject:task];
        
        successBlock(responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        if (manager.isOpenLog) {
            DLog(@"error = %@",error);
        }
        failureBlock(error);
    }];
    
    // 添加sessionTask到数组
    sessionTask ? [[self allSessionTask] addObject:sessionTask] : nil;
}


#pragma mark - 多图上传
/**
 *  上传图片
 */
+ (void)uploadImageWithOperations:(NSDictionary *)operations imageArray:(NSArray *)imageArray targetWidth:(CGFloat)width requestURL:(NSString *)urlString successBlock:(requestSuccess)successBlock failurBlock:(requestFailure)failureBlock upLoadProgress:(uploadProgress)progress {
    
    __block NSURLSessionDataTask * sessionTask =  [[NetworkingManager shareManager] POST:urlString parameters:operations constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        
        NSUInteger i = 0;
        /**出于性能考虑,将上传图片进行压缩*/
        for (UIImage * image in imageArray) {
            // image的分类方法
            UIImage *  resizedImage =  [UIImage IMGCompressed:image targetWidth:width];
            NSData * imgData = UIImageJPEGRepresentation(resizedImage, 0.5);
            
            //拼接data
            [formData appendPartWithFileData:imgData name:[NSString stringWithFormat:@"picflie%ld",(long)i] fileName:@"image.png" mimeType:@" image/jpeg"];
            i++;
        }
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        
        // 上传进度
        dispatch_sync(dispatch_get_main_queue(), ^{
            progress(uploadProgress.completedUnitCount / uploadProgress.totalUnitCount);
        });
    } success:^(NSURLSessionDataTask * _Nonnull task, NSDictionary *  _Nullable responseObject) {
        
        if (manager.isOpenLog) {
            DLog(@"responseObject = %@",responseObject);
        }
        // 任务完成
        [[self allSessionTask] removeObject:task];
        
        successBlock(responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        if (manager.isOpenLog) {
            DLog(@"error = %@",error);
        }
        failureBlock(error);
    }];
    
    // 添加sessionTask到数组
    sessionTask ? [[self allSessionTask] addObject:sessionTask] : nil;
}


#pragma mark - 文件下载
/**
 *  文件下载
 */
+ (void)downLoadFileWithOperations:(NSDictionary *)operations savaPath:(NSString *)savePath requestURL:(NSString *)urlString successBlock:(requestSuccess)successBlock failureBlock:(requestFailure)failureBlock downLoadProgress:(downloadProgress)progress {

    __block NSURLSessionDownloadTask *downloadTask = [[NetworkingManager shareManager] downloadTaskWithRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:urlString]] progress:^(NSProgress * _Nonnull downloadProgress) {
        
        // 下载进度
        dispatch_sync(dispatch_get_main_queue(), ^{
            progress(downloadProgress.completedUnitCount / downloadProgress.totalUnitCount);
        });
    } destination:^NSURL * _Nonnull(NSURL * _Nonnull targetPath, NSURLResponse * _Nonnull response) {
        
        // 返回文件位置的URL路径
        return  [NSURL URLWithString:savePath];
        
    } completionHandler:^(NSURLResponse * _Nonnull response, NSURL * _Nullable filePath, NSError * _Nullable error) {
        
        [[self allSessionTask] removeObject:downloadTask];
        
        if (manager.isOpenLog) {
            DLog(@"response = %@ , error = %@",response, error);
        }
        if (error) {
            failureBlock(error);
        }
    }];
    
    // 添加sessionTask到数组
    downloadTask ? [[self allSessionTask] addObject:downloadTask] : nil ;
}

#pragma mark -  取消所有的网络请求
/**
 *  取消所有的网络请求
 */
+ (void)cancelAllRequest {
    // 锁操作
    @synchronized(self) {
        [[self allSessionTask] enumerateObjectsUsingBlock:^(NSURLSessionTask  *_Nonnull task, NSUInteger idx, BOOL * _Nonnull stop) {
            [task cancel];
        }];
        [[self allSessionTask] removeAllObjects];
    }
    //[[NetworkingManager shareManager].operationQueue cancelAllOperations];
}
#pragma mark -   取消指定的url请求/
/**
 *  取消指定的url请求
 */
+ (void)cancelHttpRequestWithRequestType:(NSString *)requestType requestURL:(NSString *)urlString {
    
    if (!urlString) {
        return;
    }
    @synchronized (self) {
        [[self allSessionTask] enumerateObjectsUsingBlock:^(NSURLSessionTask  *_Nonnull task, NSUInteger idx, BOOL * _Nonnull stop) {
            if ([task.currentRequest.URL.absoluteString hasPrefix:urlString]) {
                [task cancel];
                [[self allSessionTask] removeObject:task];
                *stop = YES;
            }
        }];
    }
    
    /*
    NSError * error;
    
    // **根据请求的类型 以及 请求的url创建一个NSMutableURLRequest---通过该url去匹配请求队列中是否有该url,如果有的话 那么就取消该请求*
    
    NSString * urlToPeCanced = [[[[NetworkingManager shareManager].requestSerializer requestWithMethod:requestType URLString:urlString parameters:nil error:&error] URL] path];
    
    for (NSOperation * operation in [NetworkingManager shareManager].operationQueue.operations) {
        
        //如果是请求队列
        if ([operation isKindOfClass:[NSURLSessionTask class]]) {
            
            //请求的类型匹配
            BOOL hasMatchRequestType = [requestType isEqualToString:[[(NSURLSessionTask *)operation currentRequest] HTTPMethod]];
            
            // 请求的url匹配
            BOOL hasMatchRequestUrlString = [urlToPeCanced isEqualToString:[[[(NSURLSessionTask *)operation currentRequest] URL] path]];
            
            //两项都匹配的话  取消该请求
            if (hasMatchRequestType&&hasMatchRequestUrlString) {
                
                [operation cancel];
            }
        }
    }
    */
}
@end

#pragma mark - NSDictionary,NSArray的分类
/*
 新建NSDictionary与NSArray的分类, 控制台打印json数据中的中文
 */
#ifdef DEBUG
@implementation NSArray (Networking)

- (NSString *)descriptionWithLocale:(id)locale {
    NSMutableString *strM = [NSMutableString stringWithString:@"(\n"];
    [self enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        [strM appendFormat:@"\t%@,\n", obj];
    }];
    [strM appendString:@")"];
    
    return strM;
}

@end

@implementation NSDictionary (Networking)

- (NSString *)descriptionWithLocale:(id)locale {
    NSMutableString *strM = [NSMutableString stringWithString:@"{\n"];
    [self enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
        [strM appendFormat:@"\t%@ = %@;\n", key, obj];
    }];
    
    [strM appendString:@"}\n"];
    
    return strM;
}
@end
#endif


