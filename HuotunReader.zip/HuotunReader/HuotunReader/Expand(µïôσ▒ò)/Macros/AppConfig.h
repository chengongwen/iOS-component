//
//  AppConfig.h
//  HuotunReader
//
//  Created by chengongwen on 2017/10/23.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

#ifndef AppConfig_h
#define AppConfig_h

typedef NS_ENUM(NSInteger, LoginPlatform) {
    LoginPlatformVistor = 0,  // 游客登录
    LoginPlatformPhone = 1,
    LoginPlatformQQ = 2,
    LoginPlatformWX = 3,
    LoginPlatformWB = 4,
};

/** 操作类型：绑定、分享、登录 */
typedef NS_ENUM(NSInteger, OperationType) {
    OperationTypeLogin   = 1,
    OperationTypeBinding = 2,
    OperationTypeShare   = 3
};

#define kScreenWidth  ([[UIScreen mainScreen] bounds].size.width)
#define kScreenHeight ([[UIScreen mainScreen] bounds].size.height)

// 获取应用Document目录路径
#define kAppDocumentPath [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]

// 系统版本
#define kIOSSystemVersion    [[[UIDevice currentDevice] systemVersion] floatValue]

// 应用版本检测
#define KAppVersion    [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]

// 8进制颜色转换
#define kRGBColor(r, g, b)      kRGBColorA((r), (g), (b), 1)
#define kRGBColorA(r, g, b, a)  [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)]

// 16进制颜色转换
#define kRGBColor_16BAND(rgbValue)         [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]
#define kRGBColorA_16BAND(rgbValue, a)    [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:(a)]

// 强弱引用
#define WeakSelf    __weak typeof(self) weakSelf = self;
#define StrongSelf  typeof(weakSelf) __strong strongSelf = weakSelf;

// 适配iPhone x
#define kiPhoneX ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1125, 2436), [[UIScreen mainScreen] currentMode].size) : NO)
#define kNaviBarHeight  (kiPhoneX ? 88 : 64)  // 适配iPhone x 导航栏高度
#define kTabBarHeight   (kiPhoneX ? 83 : 49)  // 适配iPhone x 底栏高度
#define kNaviBarPostionY   (kiPhoneX ? 22 : 0)

#define kMinFontSize 10.0f
#define kMaxFontSize 20.0f

#define YMApplePushTokenKey     @"YMApplePushToken"

#define kNoteNotification     @"kNoteNotification"
#define kThemeNotification    @"kThemeNotification"
#define kEditingNotification  @"kEditingNotification"
#define kEndEditNotification  @"kEndEditNotification"

#endif /* AppConfig_h */
