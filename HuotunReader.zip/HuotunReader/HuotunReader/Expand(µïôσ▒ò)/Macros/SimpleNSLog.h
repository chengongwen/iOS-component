//
//  SimpleNSLog.h
//  HuotunReader
//
//  Created by chengongwen on 2017/10/23.
//  Copyright © 2017年 huotunyule. All rights reserved.
//

// 宏定义打印 并设置了一些Debug模式

#ifndef SIMPLE_NSLOG_H
#define SIMPLE_NSLOG_H

#import <Foundation/Foundation.h>
#import <asl.h>

#define THIS_FILE [(@"" __FILE__) lastPathComponent]

#define _YMNSLog(fmt,...) {                                             \
  do                                                                  \
  {                                                                   \
    NSString *str = [NSString stringWithFormat:fmt, ##__VA_ARGS__];   \
    asl_log(NULL, NULL, ASL_LEVEL_NOTICE, "%s", [str UTF8String]);    \
  }                                                                   \
  while (0);                                                          \
}


#define YMNSLog(fmt, ...) _YMNSLog((@"%@:%d %s " fmt), THIS_FILE, __LINE__, __FUNCTION__, ##__VA_ARGS__)

// 使用Dlog打印，Debug模式下打印，上线版非Debug模式就会替换为 无

#ifdef DEBUG
#define DLog(fmt, ...) _YMNSLog((@"%@:%d %s " fmt),    \
          THIS_FILE,                                 \
          __LINE__,                                  \
          __FUNCTION__,                              \
          ##__VA_ARGS__)
#else
    #define DLog(...)
#endif


#endif
